import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SubscriptionComponent } from './account-management/subscription/subscription.component';
import { UserMaintenanceComponent } from './account-management/user-maintenance/user-maintenance.component';
import { TermsOfUseComponent } from './terms-of-use/terms-of-use.component';
import { ActivityLogComponent } from './report/activity-log/activity-log.component';
import { SubscriptionRenewalComponent } from './report/subscription-renewal/subscription-renewal.component';
import { AnnouncementsComponent } from './announcements/announcements.component';
import { ClientInformationComponent } from './account-management/subscription/client-information/client-information.component';
import { ElinformationComponent } from './account-management/subscription/elinformation/elinformation.component';
import { AddNewUsersComponent } from './account-management/subscription/user-maintenance/add-new-users/add-new-users.component';
import { ExistingUsersComponent } from './account-management/subscription/user-maintenance/existing-users/existing-users.component';

@NgModule({
  imports: [
    CommonModule
  ],
  declarations: [SubscriptionComponent, UserMaintenanceComponent, TermsOfUseComponent, ActivityLogComponent, SubscriptionRenewalComponent, AnnouncementsComponent, ClientInformationComponent, ElinformationComponent, AddNewUsersComponent, ExistingUsersComponent]
})
export class AdminModule { }
