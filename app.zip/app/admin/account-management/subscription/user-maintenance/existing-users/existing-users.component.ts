import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-existing-users',
  templateUrl: './existing-users.component.html',
  styleUrls: ['./existing-users.component.css']
})
export class ExistingUsersComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
