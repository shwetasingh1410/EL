import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomeComponent } from './modules/home/home.component';


const appRoutes: Routes = [
    { path: '', redirectTo: 'accounts', pathMatch: 'full' },
    { path: 'home', component: HomeComponent },
    { path: 'accounts', loadChildren: 'app/modules/account/account.module#AccountModule' }
];

@NgModule({
    imports: [RouterModule.forRoot(appRoutes, { useHash: true })],
    exports: [RouterModule]
})

export class AppRoutingModule { }
