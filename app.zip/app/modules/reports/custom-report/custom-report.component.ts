import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-custom-report',
  templateUrl: './custom-report.component.html',
  styleUrls: ['./custom-report.component.css']
})
export class CustomReportComponent implements OnInit {
  availableFieldsData: Array<any>;
  selectedReport: Array<any> = [];
  selectedReportsList: Array<any> = [];
  removedReports: Array<any> = [];
  availableReportsSelected: Array<any> = [];
  isShowSuccess: boolean;
  constructor() {
    this.availableFieldsData = [
      { name: 'Area', code: 'Area' },
      { name: 'BI', code: 'BI' },
      { name: 'CAR/OP', code: 'CAR/OP' },
      { name: 'Category', code: 'Category' },
      { name: 'Cause', code: 'Cause' },
      { name: 'report', code: 'report' },
      { name: 'Depth at Loss', code: 'Depth' },
      { name: 'Drilling Status', code: 'Drilling' },
      { name: 'Event', code: 'Event' },
      { name: 'GOM Area', code: 'GOM' },
      { name: 'Land/Offshore', code: 'Land' },
      { name: 'Location', code: 'Location' },
      { name: 'Loss Type', code: 'Loss' },
      { name: 'OEE', code: 'OEE' },
      { name: 'PD', code: 'PD' },
      { name: 'PTD', code: 'PTD' },
      { name: 'Rating Area', code: 'Rating' },
      { name: 'Subcategory', code: 'Subcategory' },
      { name: 'Subcategory 2', code: 'Subcategory2' },
      { name: 'Total', code: 'Total' },
      { name: 'UGBO', code: 'UGBO' },
      { name: 'US Location Code', code: 'USLocationCode' },
      { name: 'UP/Down/Power', code: 'Up' },
      { name: 'Well Details', code: 'WellDetails' },
      { name: 'Well Type', code: 'WellType' }
    ]

  }

  ngOnInit() {
    this.isShowSuccess = false;
    this.selectedReportsList.length =0;
    this.availableReportsSelected.length = 0;
  }
  openSearchModal() {
    document.getElementById("searchModal").click();
  }
  saveSearchCriteria() {
    document.getElementById("saveCriteriaModal").click();
  }
  saveCriteria() {
    document.getElementById("saveCriteriaModal").click();
  }
  openSummary() {
    document.getElementById("summaryHeading").click();
    // this.active('location');
  }
  reset() {
    this.isShowSuccess = false;
  }

  showSaveMessage() {
    this.isShowSuccess = true;
  }
  addReports() {
    this.isShowSuccess = false;
    var reports = Array.apply(null, this.availableReportsSelected);
    this.availableFieldsData.forEach(c => {
      for (let i = 0; i < reports.length; i++) {
        if (reports[i] === c.code) {
          this.selectedReportsList.push(c.name);
        }
      }
    })
  }
  removeReports() {
    this.isShowSuccess = false;
    var reports = Array.apply(null, this.selectedReportsList);
    // console.log(reports);
    reports.forEach(c => {
      for (let i = 0; i < reports.length; i++) {
        let index = reports.indexOf(c.name);
        this.selectedReportsList.splice(index, 1)
      }
    })
  }
}
