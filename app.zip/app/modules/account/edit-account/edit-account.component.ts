import { Component, OnInit } from '@angular/core';
import { DOCUMENT } from '@angular/platform-browser';
import { Router, ActivatedRoute } from '@angular/router';
import { AccountModel } from '../models/account.model';
import { AccountStoreService } from '../services/account-store.service';
import { AccountService } from '../services/account.service';
import { Account } from '../entity/account';

@Component({
    templateUrl: './edit-account.component.html',
    styleUrls: ['./edit-account.component.css']
})

export class EditAccountComponent implements OnInit {

    selectedRoute: string;

    private accountModel: AccountModel;

    constructor(private router: Router, private activatedRoute: ActivatedRoute, private accountStoreService: AccountStoreService, private accountService: AccountService) {
        this.accountModel = new AccountModel(accountService, accountStoreService)
    }

    ngOnInit() {

        let account = new Account();
        account.setDefaultValue();
        account.accountId = this.activatedRoute.snapshot.params.accountId;
        this.accountModel.setAccount(account);

        this.router.navigate(['subscription-info'], { relativeTo: this.activatedRoute });
    }

    onNavigation() {
        this.router.navigate([this.selectedRoute], { relativeTo: this.activatedRoute });
    }
}