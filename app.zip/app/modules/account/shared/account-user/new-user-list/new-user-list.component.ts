import { Component, OnInit, Output, EventEmitter } from '@angular/core'
import { Router, ActivatedRoute } from '@angular/router';
import { UserSearchParams } from '../user-search-params';
import { AccountUser } from '../../../entity/account-user';
import { AccountModel } from '../../../models/account.model';
import { AccountStoreService } from '../../../services/account-store.service';
import { AccountService } from '../../../services/account.service';
import { NotificationMessage } from '../../../../common/entity/notification-message';
import { AccountEventEmitter } from '../../../account.events';
import { AccountUserInfo } from '../../../entity/account-user-info';
import { UserRoleService } from '../../../../../shared/user-profile/user-role.service';
import { UserRole } from '../../../../../shared/user-profile/user-role';

@Component({
    templateUrl: './new-user-list.component.html',
    styleUrls: ['./new-user-list.component.css']
})

export class NewUserListComponent implements OnInit {

    @Output() onSaveUserEvent = new EventEmitter();

    userSearchParams: UserSearchParams = new UserSearchParams();

    userRoles: UserRole[] = [];

    userList: AccountUser[] = [];

    selectedUser: AccountUser;

    notificationMessage: NotificationMessage = new NotificationMessage();

    isNewSubscription: boolean;

    private accountModel: AccountModel;

    constructor(private accountStoreService: AccountStoreService, private accountService: AccountService, private userRoleService: UserRoleService, private router: Router, private activatedRoute: ActivatedRoute, private accountEvent: AccountEventEmitter) {
        this.accountModel = new AccountModel(accountService, accountStoreService);
    }

    ngOnInit(): void {
        this.getUserRoles();
        this.isNewSubscription = this.activatedRoute.parent.parent.snapshot.params.accountId == undefined;
    }

    onReset(): void {
        this.userList = [];
        this.selectedUser = null;
        this.userSearchParams = new UserSearchParams();
        this.notificationMessage = new NotificationMessage();
    }

    onSearch(): void {

        this.userList = [];
        this.selectedUser = null;
        this.notificationMessage = new NotificationMessage();

        this.accountModel.getILUsers(this.userSearchParams.searchText)
            .subscribe(result => this.userList = result);

    }

    onAdd(accountUser: AccountUser): void {

        this.notificationMessage = new NotificationMessage();

        if (accountUser.accountUserInfo == undefined || accountUser.accountUserInfo == null)
            accountUser.accountUserInfo = new AccountUserInfo();

        this.selectedUser = accountUser;
        this.selectedUser.roleId = this.userSearchParams.roleId;
    }

    getUserDetails(accountUser: AccountUser) {

        this.accountModel.getILUserInfo(accountUser.principalId)
            .subscribe(result => accountUser.accountUserInfo = result,
                       error=>console.log(error));
    }

    isSearchBtnDisabled() {
        return this.userSearchParams.roleId == undefined || this.userSearchParams.searchText == undefined || this.userSearchParams.searchText == null || this.userSearchParams.searchText.length == 0;
    }

    onClose() {
        this.selectedUser = null;
    }

    onSuccess(message: string) {
        this.notificationMessage.successMessage = message;
        this.accountEvent.showActivateAccountButtonEvent.emit(true);
    }

    onError(message: string) {
        this.notificationMessage.errorMessage = message;
    }

    private getUserRoles(): void {

        this.userRoles = this.accountModel.getUserRoles();

        if (this.userRoles == null || this.userRoles.length == 0) {
            this.userRoleService.getUserProfiles().subscribe(result => {
                this.accountModel.setUserRoles(result);
                this.userRoles = result;
            });
        }
    }
}
