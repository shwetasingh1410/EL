import { Component, OnInit } from '@angular/core'
import { Router, ActivatedRoute } from '@angular/router';
import { UserSearchParams } from '../user-search-params';
import { AccountUser } from '../../../entity/account-user';
import { AccountModel } from '../../../models/account.model';
import { AccountStoreService } from '../../../services/account-store.service';
import { AccountService } from '../../../services/account.service';
import { AccountConstants } from '../../../account.const';
import { KeyValuePair } from '../../../../common/entity/key-value-pair';
import { NotificationMessage } from '../../../../common/entity/notification-message';
import { AccountEventEmitter } from '../../../account.events';
import { UserRole } from '../../../../../shared/user-profile/user-role';
import { UserRoleService } from '../../../../../shared/user-profile/user-role.service';

@Component({
    templateUrl: './existing-user-list.component.html',
    styleUrls: ['./existing-user-list.component.html']
})

export class ExistingUserListComponent implements OnInit {

    userSearchParams: UserSearchParams = new UserSearchParams();

    userRoles: UserRole[] = [];

    userList: AccountUser[] = [];

    selectedUser: AccountUser;

    notificationMessage: NotificationMessage = new NotificationMessage();

    isNewSubscription: boolean;

    private accountModel: AccountModel;

    private tempUserList: AccountUser[] = [];

    constructor(private accountStoreService: AccountStoreService, private accountService: AccountService, private userRoleService: UserRoleService, private router: Router, private activatedRoute: ActivatedRoute, private accountEvent: AccountEventEmitter) {
        this.accountModel = new AccountModel(accountService, accountStoreService);
    }

    ngOnInit(): void {
        this.isNewSubscription = this.activatedRoute.parent.parent.snapshot.params.accountId == undefined;
        this.getUserRoles();
        this.loadAllUsers();
    }

    onReset(): void {
        this.userList = this.tempUserList;
        this.selectedUser = null;
        this.userSearchParams = new UserSearchParams();
        this.notificationMessage = new NotificationMessage();
    }

    onSearch(): void {

        this.userList = [];
        this.selectedUser = null;
        this.notificationMessage = new NotificationMessage();

        this.userList = this.accountModel.searchExistingUsers(this.tempUserList, this.userSearchParams);
    }

    onEdit(accountUser: AccountUser): void {
        this.selectedUser = accountUser;
    }

    isSearchBtnDisabled() {
        return !(this.userSearchParams.roleId != undefined || (this.userSearchParams.searchText != undefined && this.userSearchParams.searchText != null && this.userSearchParams.searchText.length > 0) || this.userSearchParams.userType != undefined);
    }

    onRemove(accountUser: AccountUser): void {

        if (this.isNewSubscription) {
            this.accountModel.removeAccountUser(accountUser.emailAddress);
            this.loadAllUsers();

            if (this.userList == null || this.userList.length == 0)
                this.accountEvent.showActivateAccountButtonEvent.emit(false);
        }
    }

    private loadAllUsers() {

        if (this.isNewSubscription) {
            this.tempUserList = this.accountModel.getAllAccountUser();
            this.userList = this.tempUserList;
        }
        else {
            this.accountModel.getExistingUsers(this.activatedRoute.parent.parent.snapshot.params.accountId)
                .subscribe(result => {
                    this.tempUserList = result;
                    this.userList = result;
                });
        }
    }

    onClose() {
        this.selectedUser = null;
    }

    onSuccess(message: string) {
        this.notificationMessage.successMessage = message;
    }

    onError(message: string) {
        this.notificationMessage.errorMessage = message;
    }

    private getUserRoles(): void {
        this.userRoles = this.accountModel.getUserRoles();

        if (this.userRoles == null || this.userRoles.length == 0) {
            this.userRoleService.getUserProfiles().subscribe(result => {
                this.accountModel.setUserRoles(result);
                this.userRoles = result;
            });
        }
    }

    getRoleName(roleId: number) {

        if (this.userRoles != undefined && this.userRoles.length > 0) {

            let profile = this.userRoles.find(e => e.id == roleId);
            if (profile != null)
                return profile.code;
        }
    }
}