import { Component, OnInit, OnDestroy } from '@angular/core'
import { AccountStoreService } from '../../services/account-store.service';
import { AccountService } from '../../services/account.service';
import { Router, ActivatedRoute } from '@angular/router';
import { AccountModel } from '../../models/account.model';
import { AccountEventEmitter } from '../../account.events';
import { Subscription } from 'rxjs';

@Component({
  templateUrl: './account-user.component.html',
  styleUrls: ['./account-user.component.css']
})

export class AccountUserComponent implements OnInit {

  isNewSubscription: boolean;
  showExistingUsersTab: boolean;
  showActivateAccountBtn: boolean;
  subscriptionMessage: string;

  private accountModel: AccountModel;

  constructor(private accountStoreService: AccountStoreService, private accountService: AccountService, private router: Router, private activatedRoute: ActivatedRoute, private accountEvent: AccountEventEmitter) {
    this.accountModel = new AccountModel(accountService, accountStoreService);
  }

  ngOnInit(): void {

    if (this.activatedRoute.parent.snapshot.params.accountId == undefined) {

      this.isNewSubscription = true;

      this.accountEvent.showActivateAccountButtonEvent.subscribe((value) => {
        this.showSubscriptionActivationButton(value);
      });

      let accountUsers = this.accountModel.getAllAccountUser();

      if (accountUsers != null && accountUsers.length > 0) {

        this.showExistingUsersTab = true;
        this.showActivateAccountBtn = true;
        this.router.navigate(['list'], { relativeTo: this.activatedRoute });

      }
      else {
        this.router.navigate(['new'], { relativeTo: this.activatedRoute });
      }

    }
    else {
      this.router.navigate(['list'], { relativeTo: this.activatedRoute });
    }
  }

  onBack(): void {
    this.router.navigate(['account-info'], { relativeTo: this.activatedRoute.parent });
  }

  createAccount(): void {

    this.accountModel.createAccount().subscribe(result => {
      
      if (result)
        this.subscriptionMessage = "Subscription activated successfully";
      else
        this.subscriptionMessage = "Failed to activated subscription";

      document.getElementById("loadModelBtn").click();      
    });

  }

  showSubscriptionActivationButton(flag: boolean) {
    this.showActivateAccountBtn = flag;
    this.showExistingUsersTab = true;
  }

  navigateToHomePage() {
    this.router.navigate(['home']);
  }
}
