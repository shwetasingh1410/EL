import { Component, OnInit, Input, Output, EventEmitter, OnDestroy } from '@angular/core'
import { AccountUser } from '../../../entity/account-user';
import { AccountService } from '../../../services/account.service';
import { AccountStoreService } from '../../../services/account-store.service';
import { AccountModel } from '../../../models/account.model';
import { UserRole } from '../../../../../shared/user-profile/user-role';
import { UserRoleService } from '../../../../../shared/user-profile/user-role.service';

@Component({
    selector: 'user-details',
    templateUrl: './user-details.component.html'
})

export class UserDetailsComponent implements OnInit, OnDestroy {

    @Input() accountUser: AccountUser;

    @Input() isNewSubscription: boolean;

    @Output() onCloseEvent = new EventEmitter();

    @Output() onSuccessEvent: EventEmitter<string> = new EventEmitter<string>();

    @Output() onErrorEvent: EventEmitter<string> = new EventEmitter<string>();

    userRoles: UserRole[] = [];

    private accountModel: AccountModel;

    constructor(private userRoleService: UserRoleService, private accountStoreService: AccountStoreService, private accountService: AccountService) {
        this.accountModel = new AccountModel(accountService, accountStoreService);
    }

    ngOnInit() {

        this.getUserRoles();

        if (this.accountUser.accountUserInfo.firstName == undefined)
            this.getUserDetails();
    }

    ngOnDestroy() {
        this.onSuccessEvent.unsubscribe();
        this.onErrorEvent.unsubscribe();
        this.onCloseEvent.unsubscribe();
    }

    onClose(): void {
        this.onCloseEvent.emit();
    }

    onSave(): void {

        if (this.isNewSubscription) {

            if (!this.isUserAlreadyAdded()) {

                this.accountModel.checkUserExist(this.accountUser.principalId).subscribe(result => {
                    if (!result) {
                        this.accountModel.setAccountUser(this.accountUser);
                        this.onSuccessEvent.emit("Success! user added successfully.");
                    }
                    else {
                        this.onErrorEvent.emit("User already exist");
                    }
                });
            }
            else {
                this.onErrorEvent.emit("User already exist");
            }
        }
        else {
            this.accountModel.setAccountUser(this.accountUser);
        }
    }

    private getUserRoles(): void {

        this.userRoles = this.accountModel.getUserRoles();

        if (this.userRoles == null || this.userRoles.length == 0) {
            this.userRoleService.getUserProfiles().subscribe(result => {
                this.accountModel.setUserRoles(result);
                this.userRoles = result;
            });
        }
    }

    private isUserAlreadyAdded(): boolean {
        let accountUser = this.accountModel.getAccountUser(this.accountUser.emailAddress);
        return accountUser != null ? true : false;
    }

    private getUserDetails() {
        this.accountModel.getILUserInfo(this.accountUser.principalId)
            .subscribe(result => this.accountUser.accountUserInfo = result,
                       error=>console.log(error));
    }


}