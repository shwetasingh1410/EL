import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { AccountStoreService } from '../../services/account-store.service';
import { AccountService } from '../../services/account.service';
import { AccountModel } from '../../models/account.model';
import { Account } from '../../entity/account';
import { AccountEventEmitter } from '../../account.events';
import { NgForm } from '@angular/forms';

@Component({
    templateUrl: './account-info.component.html',
    styleUrls: ['./account-info.component.css']
})

export class AccountInfoComponent implements OnInit {

    account: Account;

    isFormEditable: boolean;

    isNewSubscription: boolean;

    private accountModel: AccountModel;

    constructor(private accountStoreService: AccountStoreService, private accountService: AccountService, private router: Router, private activatedRoute: ActivatedRoute, private accountEvent: AccountEventEmitter) {
        this.accountModel = new AccountModel(accountService, accountStoreService);
    }

    ngOnInit(): void {

        let account = this.accountModel.getAccount();

        if (this.activatedRoute.parent.snapshot.params.accountId == undefined) {
            this.isNewSubscription = true;
            this.isFormEditable = true;
            this.account = account;
        }
        else {

            this.isNewSubscription = false;
            this.isFormEditable = false;

            if (account.customerName == undefined || account.customerName == "")
                this.getAccount(account.accountId);
            else
                this.account = account;
        }
    }

    onContinue(accountInfoForm: NgForm): void {

        if (!this.isFormEditable)
            this.router.navigate(['users'], { relativeTo: this.activatedRoute.parent });

        if (accountInfoForm.form.valid) {

            if (this.activatedRoute.parent.snapshot.params.accountId == undefined) {
                this.saveAccount();
            }

            this.router.navigate(['users'], { relativeTo: this.activatedRoute.parent });
        }
    }

    onBack(): void {
        this.router.navigate(['subscription-info'], { relativeTo: this.activatedRoute.parent });
    }

    onCancel(): void {
        this.isFormEditable = false;
        this.account = this.accountModel.getAccount();
    }

    onEdit(): void {
        this.isFormEditable = true;
    }

    private getAccount(accountId: string) {

        this.accountModel.getAccountInfo(accountId)
            .subscribe(result => {
                this.account = result;
                this.accountModel.setAccount(this.account);
            });
    }

    private saveAccount() {
        this.accountModel.setAccount(this.account);
        this.accountEvent.showUserMaintenanceTabOnCreateSubscription.emit();
    }

    isContinueButtonDisabled(accountForm: NgForm): boolean {

        if (this.isNewSubscription)
            this.accountEvent.disableUserMaintenanceTabOnCreateSubscription.emit(accountForm.form.invalid);
        
        return accountForm.form.invalid;
    }
}