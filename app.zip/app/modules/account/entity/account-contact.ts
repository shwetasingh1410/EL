export class AccountContact {
    name: string;
    companyName: string;
    email: string;
    phone: string;
    address: string;
    city: string;
    country: string;

    setDefaultValue() {
        this.name = "";
        this.companyName = "";
        this.email = "";
        this.phone = "";
        this.address = "";
        this.city = "";
        this.country = "";
    }
}