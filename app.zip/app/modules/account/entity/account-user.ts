import { AccountUserInfo } from "./account-user-info";

export class AccountUser{
    userId:string;
    principalId:string;
    displayName:string;    
    emailAddress:string;
    accountUserInfo:AccountUserInfo;  
    isInternal: boolean;
    isActive:boolean;
    roleId:number;    
}
