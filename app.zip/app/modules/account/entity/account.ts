import { AccountContact } from "./account-contact";

export class Account {

    accountId: string;
    customerName: string;
    startDate: string;
    endDate: string;
    invoiceStatus: string;
    isNotificationSuppressed: boolean;
    isSubscriptionActive: boolean;
    accountContact: AccountContact;

    setDefaultValue() {

        this.accountId = "";
        this.customerName = "";
        this.startDate = "";
        this.endDate = "";
        this.invoiceStatus = "";
        this.isNotificationSuppressed = false;
        this.isSubscriptionActive = true;
        this.accountContact = new AccountContact();
        this.accountContact.setDefaultValue();
    }
}