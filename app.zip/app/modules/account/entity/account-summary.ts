export class AccountSummary {
    accountId:string;    
    subscriptionId:string;
    subscriptionName:string;
}