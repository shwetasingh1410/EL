export const AccountConstants = {
    SubscriptionInfo: "SubscriptionInfo",
    AccountInfo: "AccountInfo",
    AccountUser: "AccountUser",
    UserRoles: "UserRoles",
    WTW: "willistowerswatson.com",
    Willis: "willis.com"
}