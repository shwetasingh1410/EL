import { Observable } from 'rxjs/Rx';
import { Injectable } from '@angular/core';
import { KeyValuePair } from '../../common/entity/key-value-pair';


export class AccountStoreService {

    private dictionary: KeyValuePair[] = [];

    get<T>(key: string): T {
        if (this.dictionary.findIndex(e => e.key == key) > -1)
            return this.dictionary.find(e => e.key == key).value as T;
        else
            return null;
    }

    set(key: string, value: any) {
        let itemIndex = this.dictionary.findIndex(e => e.key == key);
        if (itemIndex > -1) {
            this.dictionary[itemIndex].value = value;
        }
        else {
            this.dictionary.push(new KeyValuePair(key, value));
        }
    }

    clear() {
        this.dictionary = [];
    }
}