import { Observable } from 'rxjs/Rx';
import { Injectable } from '@angular/core';
import { Subscription } from '../entity/subscription';
import { Account } from '../entity/account';
import { WebRequestParameter } from '../../../shared/http/web-request-parameter';
import { AccountSummary } from '../entity/account-summary';
import { AccountUser } from '../entity/account-user';
import { AccountUserInfo } from '../entity/account-user-info';
import { HttpClientWrapper } from '../../../shared/http/http-client-wrapper';

@Injectable()
export class AccountService {

    constructor(private httpClientWrapper: HttpClientWrapper) {
    }

    searchAccounts(searchText: string): Observable<AccountSummary[]> {
        let webRequestParams = new WebRequestParameter("accounts?search=" + searchText);
        return this.httpClientWrapper.get<AccountSummary[]>(webRequestParams);
    }

    searchSubscriptions(searchText: string): Observable<Subscription[]> {
        let webRequestParams = new WebRequestParameter("subscriptions?searchText=" + searchText);
        return this.httpClientWrapper.get<Subscription[]>(webRequestParams);
    }

    getSubscriptionInfo(subscriptionId: string): Observable<Subscription> {
        let webRequestParams = new WebRequestParameter("subscriptions/" + subscriptionId);
        return this.httpClientWrapper.get<Subscription>(webRequestParams);
    }

    getAccountInfo(accountId: string): Observable<Account> {
        let webRequestParams = new WebRequestParameter("accounts/"+ accountId + "/details");
        return this.httpClientWrapper.get<Account>(webRequestParams);
    }

    getExistingUsers(accountId: string): Observable<AccountUser[]> {
        let webRequestParams = new WebRequestParameter("accounts/"+ accountId + "/users");
        return this.httpClientWrapper.get<AccountUser[]>(webRequestParams);
    }

    getILUsers(searchText: string): Observable<AccountUser[]> {
        let webRequestParams = new WebRequestParameter("users?searchText=" + searchText);
        return this.httpClientWrapper.get<AccountUser[]>(webRequestParams);
    }

    getILUserInfo(principleId: string): Observable<AccountUserInfo> {
        let webRequestParams = new WebRequestParameter("userProfile/" + principleId);
        return this.httpClientWrapper.get<AccountUserInfo>(webRequestParams);
    }

    createAccount(body: any): Observable<boolean> {
        let webRequestParams = new WebRequestParameter("accounts/", JSON.stringify(body));
        return this.httpClientWrapper.post<boolean>(webRequestParams);
    }

    checkUserExist(principleId: string): Observable<boolean> {
        let webRequestParams = new WebRequestParameter("accounts/checkUserExist/" + principleId);
        return this.httpClientWrapper.get<boolean>(webRequestParams);
    }

}