import { Component, OnInit, OnDestroy, EventEmitter, Output } from "@angular/core";
import { Subscription } from "../../entity/subscription";
import { SearchParams } from "../../../common/entity/search-params";
import { AccountModel } from "../../models/account.model";
import { AccountStoreService } from "../../services/account-store.service";
import { AccountService } from "../../services/account.service";

@Component({
  selector: 'subscription-search',
  templateUrl: './subscription-search.component.html',
  styleUrls: ['./subscription-search.component.css']
})

export class SubscriptionSearchComponent implements OnInit, OnDestroy {

  @Output() onContinueEvent = new EventEmitter();

  searchParams: SearchParams;

  subscriptionList: Subscription[];

  selectedSubscription: Subscription;

  showNoRecordsFoundMessage: boolean;

  private accountModel: AccountModel;

  constructor(private accountStoreService: AccountStoreService, private accountService: AccountService) {
    this.accountModel = new AccountModel(accountService, accountStoreService)
  }

  ngOnInit() {
    this.subscriptionList = [];
    this.selectedSubscription = null;
    this.searchParams = new SearchParams();
  }

  ngOnDestroy(): void {
    this.onContinueEvent.unsubscribe();
  }

  onContinue(): void {
    document.getElementById("closeSubscriptionSearchModal").click();
    this.accountModel.clearAccountStore();
    this.accountModel.setSubscription(this.selectedSubscription);
    this.onReset();
    this.onContinueEvent.emit();
  }

  onSearch(): void {

    this.subscriptionList = [];
    this.selectedSubscription = null;
    this.showNoRecordsFoundMessage=false;

    if (this.searchParams.searchText != undefined && this.searchParams.searchText != null && this.searchParams.searchText.length > 0) {

      this.accountModel.searchSubscriptions(this.searchParams.searchText)
        .subscribe(result => {
          this.subscriptionList = result;
          this.showNoRecordsFoundMessage = this.subscriptionList == null || this.subscriptionList.length == 0;
        });

    }
  }

  onSelect(subscription: Subscription): void {
    this.selectedSubscription = subscription;
  }

  onReset(): void {
    this.subscriptionList = [];
    this.selectedSubscription = null;
    this.showNoRecordsFoundMessage=false;
    this.searchParams = new SearchParams();
  }

  onClose(): void {
    this.onReset();
  }
}
