import { Component, OnInit } from '@angular/core'
import { Router, ActivatedRoute } from '@angular/router';
import { AccountStoreService } from '../services/account-store.service';
import { AccountService } from '../services/account.service';
import { AccountModel } from '../models/account.model';
import { Account } from '../entity/account';
import { AccountContact } from '../entity/account-contact';
import { AccountEventEmitter } from '../account.events';
import { Subscription } from 'rxjs';

@Component({
    templateUrl: './create-account.component.html',
    styleUrls: ['./create-account.component.css']
})

export class CreateAccountComponent implements OnInit {

    selectedRoute: string;

    showUserMaintenanceTab: boolean;

    isUserMaintenanceDisabled: boolean = false;

    private accountModel: AccountModel;

    constructor(private router: Router, private activatedRoute: ActivatedRoute, private accountStoreService: AccountStoreService, private accountService: AccountService, private accountEvent: AccountEventEmitter) {
        this.accountModel = new AccountModel(accountService, accountStoreService)
    }

    ngOnInit() {

        var account = new Account();
        account.setDefaultValue();
        this.accountModel.setAccount(account);

        this.accountEvent.showUserMaintenanceTabOnCreateSubscription.subscribe(() => this.showUserMaintenance());
        this.accountEvent.disableUserMaintenanceTabOnCreateSubscription.subscribe((value) => this.isUserMaintenanceTabDisabled(value));

        this.router.navigate(['subscription-info'], { relativeTo: this.activatedRoute });
    }

    onNavigation() {
        this.router.navigate([this.selectedRoute], { relativeTo: this.activatedRoute });
    }

    showUserMaintenance() {
        this.showUserMaintenanceTab = true;
    }

    isUserMaintenanceTabDisabled(value: boolean) {
        this.isUserMaintenanceDisabled = value;
    }
}