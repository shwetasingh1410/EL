import { Observable } from 'rxjs/Rx';
import { Account } from '../entity/account';
import { AccountService } from '../services/account.service';
import { AccountStoreService } from '../services/account-store.service';
import { AccountUser } from '../entity/account-user';
import { Subscription } from '../entity/subscription';
import { UserSearchParams } from '../shared/account-user/user-search-params';
import { AccountConstants } from '../account.const';
import { AccountUserInfo } from '../entity/account-user-info';
import { AccountSummary } from '../entity/account-summary';
import { UserRole } from '../../../shared/user-profile/user-role';

export class AccountModel {

    private _accountService: AccountService;

    private _accountStoreService: AccountStoreService;

    constructor(accountService: AccountService, accountStoreService: AccountStoreService) {
        this._accountService = accountService;
        this._accountStoreService = accountStoreService;
    }

    setSubscription(value: Subscription) {
        this._accountStoreService.set(AccountConstants.SubscriptionInfo, value);
    }

    getSubscription() {
        return this._accountStoreService.get<Subscription>(AccountConstants.SubscriptionInfo);
    }

    setAccount(value: Account) {
        this._accountStoreService.set(AccountConstants.AccountInfo, value);
    }

    getAccount() {
        return this._accountStoreService.get<Account>(AccountConstants.AccountInfo);
    }

    setAccountUser(value: AccountUser) {

        value.isInternal = value.emailAddress != undefined ? value.emailAddress.toLowerCase().indexOf(AccountConstants.WTW) > -1 || value.emailAddress.toLowerCase().indexOf(AccountConstants.Willis) > -1 : false;

        var accountUsers = this._accountStoreService.get<AccountUser[]>(AccountConstants.AccountUser);

        if (accountUsers != null) {
            accountUsers = accountUsers.filter(e => e.emailAddress != value.emailAddress);
            accountUsers.push(value);
        }
        else {
            accountUsers = [];
            accountUsers.push(value);
        }

        this._accountStoreService.set(AccountConstants.AccountUser, accountUsers);
    }

    getAccountUser(emailAddress: string): AccountUser {
        let accountUsers = this._accountStoreService.get<AccountUser[]>(AccountConstants.AccountUser);
        return accountUsers != null ? accountUsers.find(e => e.emailAddress == emailAddress) : null;
    }

    getAllAccountUser(): AccountUser[] {
        return this._accountStoreService.get<AccountUser[]>(AccountConstants.AccountUser);
    }

    removeAccountUser(emailAddress: string): void {

        let accountUsers = this._accountStoreService.get<AccountUser[]>(AccountConstants.AccountUser);

        if (accountUsers != null) {            
            this._accountStoreService.set(AccountConstants.AccountUser, accountUsers.filter(e => e.emailAddress != emailAddress));
        }
    }

    clearAccountStore() {
        this._accountStoreService.clear();
    }

    setUserRoles(value: UserRole[]) {
        this._accountStoreService.set(AccountConstants.UserRoles, value);
    }

    getUserRoles() {
        return this._accountStoreService.get<UserRole[]>(AccountConstants.UserRoles);
    }


    getSubscriptionInfo(subscriptionId: string): Observable<Subscription> {
        return this._accountService.getSubscriptionInfo(subscriptionId);
    }

    getAccountInfo(accountId: string): Observable<Account> {
        return this._accountService.getAccountInfo(accountId);
    }

    getExistingUsers(accountId: string): Observable<AccountUser[]> {
        return this._accountService.getExistingUsers(accountId);
    }

    getILUsers(searchText: string): Observable<AccountUser[]> {
        return this._accountService.getILUsers(searchText);
    }

    getILUserInfo(principleId: string): Observable<AccountUserInfo> {
        return this._accountService.getILUserInfo(principleId);
    }

    searchExistingUsers(userList: AccountUser[], userSearchParams: UserSearchParams): AccountUser[] {

        let result = userList;

        if (userSearchParams.roleId != undefined)
            result = result.filter(e => e.roleId == userSearchParams.roleId);

        if (userSearchParams.searchText != undefined && userSearchParams.searchText != null && userSearchParams.searchText.length > 0)
            result = result.filter(e => e.displayName.indexOf(userSearchParams.searchText) > -1 || e.emailAddress.indexOf(userSearchParams.searchText) > -1);

        if (userSearchParams.userType != undefined && userSearchParams.userType != "")
            result = result.filter(e => e.isInternal == (userSearchParams.userType == 'true'));

        return result;
    }

    checkUserExist(principalId: string): Observable<boolean> {
        return this._accountService.checkUserExist(principalId);
    }

    searchSubscriptions(searchText: string): Observable<Subscription[]> {
        return this._accountService.searchSubscriptions(searchText);
    }

    searchAccounts(searchText: string): Observable<AccountSummary[]> {
        return this._accountService.searchAccounts(searchText);
    }

    createAccount(): Observable<boolean> {

        let subscription = this.getSubscription();
        let account = this.getAccount();
        let accountUsers = this.getAllAccountUser();

        let createAccountObj =
            {
                "subscriptionId": subscription.subscriptionId,
                "subscriptionName": subscription.displayName,
                "customerName": account.customerName,
                "isNotificationSuppressed": account.isNotificationSuppressed,
                "isActive": true,
                "startDate": account.startDate,
                "endDate": account.endDate,
                "invoiceStatus": account.invoiceStatus,
                "accountContact":
                    {
                        "name": account.accountContact.name,
                        "email": account.accountContact.email,
                        "phone": account.accountContact.phone,
                        "address": account.accountContact.address,
                        "city": account.accountContact.city,
                        "country": account.accountContact.country,
                        "companyName": account.accountContact.companyName
                    },
                "users": []
            };

        for (let x in accountUsers) {
            createAccountObj.users.push
                ({
                    "roleId": accountUsers[x].roleId,
                    "isActive": accountUsers[x].isActive,
                    "email": accountUsers[x].emailAddress,
                    "firstName": accountUsers[x].accountUserInfo.firstName,
                    "lastName": accountUsers[x].accountUserInfo.lastName,
                    "country": accountUsers[x].accountUserInfo.countryName,
                    "principalId": accountUsers[x].principalId
                });
        }

        return this._accountService.createAccount(createAccountObj);
    }
}
