import { Injectable, EventEmitter } from '@angular/core';

@Injectable()
export class AccountEventEmitter {

    showActivateAccountButtonEvent: EventEmitter<boolean> = new EventEmitter<boolean>();

    showUserMaintenanceTabOnCreateSubscription = new EventEmitter();

    disableUserMaintenanceTabOnCreateSubscription: EventEmitter<boolean> = new EventEmitter<boolean>();
}