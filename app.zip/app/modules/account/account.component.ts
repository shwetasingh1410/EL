import { Component } from '@angular/core'
import { Router, ActivatedRoute } from '@angular/router';
import { AccountStoreService } from './services/account-store.service';
import { Subscription } from './entity/subscription';
import { AccountSummary } from './entity/account-summary';
import { AccountModel } from './models/account.model';
import { AccountService } from './services/account.service';
import { AccountConstants } from './account.const';
import { SearchParams } from '../common/entity/search-params';

@Component({
  templateUrl: './account.component.html',
  styleUrls: ['./account.component.css']
})

export class AccountComponent {

  selectedSubscriptionName: string;
  searchParams: SearchParams;
  searchView: boolean;

  private accountModel: AccountModel;

  constructor(private router: Router, private activatedRoute: ActivatedRoute, private accountStoreService: AccountStoreService, private accountService: AccountService) {

    this.accountModel = new AccountModel(accountService, accountStoreService)
    this.selectedSubscriptionName = 'Subscription Name';
    this.searchView = true;
  }

  toggleSearchView() {
    this.searchView = !this.searchView;
    this.searchParams = new SearchParams();
  }

  onSearch() {
    this.toggleSearchView();
    document.getElementById("accountSearchModalBtn").click();
  }

  onAddSubscription() {
    this.toggleSearchView();
    document.getElementById("subscriptionSearchModalBtn").click();
  }

  navigateToSubscriptionInfoBySubscriptionId(): void {
    this.selectedSubscriptionName = this.accountModel.getSubscription().displayName;
    this.router.navigate(['new'], { relativeTo: this.activatedRoute });
  }

  navigateToSubscriptionInfoByAccountId(accountId: string): void {
    this.selectedSubscriptionName = this.accountModel.getSubscription().displayName;
    this.router.navigate([accountId], { relativeTo: this.activatedRoute });
  }
}
