export class NotificationMessage{
    successMessage:string;
    errorMessage:string;
    warningMessage:string;
}