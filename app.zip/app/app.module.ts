  import { BrowserModule } from '@angular/platform-browser';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import { FormsModule } from '@angular/forms'
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { NgModule, APP_INITIALIZER, ErrorHandler } from '@angular/core';
import { AppComponent } from './app.component';
import { HomeComponent } from './modules/home/home.component';
import { FooterComponent } from './modules/common/footer/footer.component';
import { HttpClientService } from './shared/http/http-client-service';
import { GlobalExceptionHandler } from './shared/exception-handler/exception-handler';

import { ConfigurationService } from './shared/configuration/configuration.service';
import { StorageService } from './shared/storage/storage.service';
import { TokenService } from './shared/token/token.service';
import * as $ from 'jquery';

import { TRANSLATION_PROVIDERS } from './shared/translate/translation';
import { TranslateService } from './shared/translate/translate.service';
import { TranslatePipe } from './shared/translate/translate.pipe';
import { AppRoutingModule } from './app.routing.module';
import { HttpRequestInterceptor } from './shared/http/http-interceptor';
import { AppInitializationFactory } from './startup/app-initialization.factory';
import { StartupService } from './startup/startup.service';
import { UserRoleService } from './shared/user-profile/user-role.service';
import { LoaderComponent } from './shared/loader/loader.component';
import { LoaderService } from './shared/loader/loader.service';
import { HttpClientWrapper } from './shared/http/http-client-wrapper';

@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    FooterComponent,
    TranslatePipe,
    LoaderComponent
  ],
  imports: [
    CommonModule,
    BrowserModule,
    FormsModule,
    HttpClientModule,
    AppRoutingModule
  ],
  providers: [
    StorageService,
    StartupService,
    ConfigurationService,
    TokenService,
    {
      provide: APP_INITIALIZER,
      useFactory: AppInitializationFactory,
      deps: [StartupService],
      multi: true
    },
    {
      provide: HTTP_INTERCEPTORS,
      useClass: HttpRequestInterceptor,
      deps: [LoaderService],
      multi: true
    },
    HttpClientWrapper,
    HttpClientService,
    UserRoleService,
    LoaderService,
    { useClass: GlobalExceptionHandler, provide: ErrorHandler, deps: [TokenService, LoaderService] },
    [TRANSLATION_PROVIDERS, TranslateService]
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
