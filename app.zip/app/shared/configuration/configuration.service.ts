import { Injectable, Injector, Inject } from '@angular/core';
import { DOCUMENT } from '@angular/platform-browser';
import { Http } from '@angular/http';
import { Observable } from 'rxjs/Rx';
import 'rxjs/add/operator/map';
import { StorageService } from '../storage/storage.service';
import { WebRequestParameter } from '../http/web-request-parameter';
import { HttpHeaders, HttpClient } from '@angular/common/http';

@Injectable()
export class ConfigurationService {

  constructor(private http: HttpClient, private _storage: StorageService, @Inject(DOCUMENT) private document) {
  }

  getConfigurations() {

    return new Promise((resolve, reject) => {

      var webRequestParameter = new WebRequestParameter('/configs');
      this.setHeaders(webRequestParameter);

      this.http
        .get<any>(webRequestParameter.url, { headers: webRequestParameter.headers, observe: 'response' })
        .subscribe(result => {
          this._storage.setItem("webApiUrl", result.body.webApiUrl);
          this._storage.setItem("loggedInUserInfo", result.headers.get("loggedInUserInfo"));
          this._storage.setItem("accessToken", result.body.accessToken);
          this._storage.setItem("contactUsUrl", result.body.contactUsUrl);
          this._storage.setItem("licensesUrl", result.body.licensesUrl);
          this._storage.setItem("privacyPolicyUrl", result.body.privacyPolicyUrl);
          resolve(true);
        }),
        (error) => {
          reject(true);
        }
    });
  }

  private setHeaders(webRequestParameter: WebRequestParameter): void {

    webRequestParameter.headers = webRequestParameter.headers || new HttpHeaders();
    webRequestParameter.headers = webRequestParameter.headers.set('Content-Type', 'application/json');
    webRequestParameter.headers = webRequestParameter.headers.set('Accept', 'application/json');
  }

  get hostUrl(): string {
    return this.document.location.protocol + '//' + this.document.location.hostname + ':' + this.document.location.port;
  }

  get apiUrl(): string {
    return this._storage.getItem("webApiUrl");
  }

  get loggedInUserInfo(): string {
    return this._storage.getItem("loggedInUserInfo");
  }


  get licensesUrll() {
    return this._storage.getItem("licensesUrl");
  }

  get privacyPolicyUrl() {
    return this._storage.getItem("privacyPolicyUrl");
  }

  get contactUsUrl() {
    return this._storage.getItem("contactUsUrl");
  }
}
