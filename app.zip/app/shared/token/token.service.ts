import { Injectable, Injector, Inject } from '@angular/core';
import { Http } from '@angular/http';
import { StorageService } from '../storage/storage.service';

@Injectable()
export class TokenService {
    constructor(private _injector: Injector,private _storage: StorageService){
    }

    renewToken() {
        let http = this._injector.get(Http);

        http.get('api/clear-cookies').subscribe((result) => {
              window.location.reload();                
        },
        (error) => {   
            window.location.reload();   
        });
    }
    
    getAccessToken(){
        return this._storage.getItem("accessToken");
    }
}