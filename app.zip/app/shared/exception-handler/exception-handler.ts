import {ErrorHandler, Injector} from '@angular/core';
import { TokenService } from '../token/token.service';
import { Router } from '@angular/router';
import { LoaderService } from '../loader/loader.service';

export class GlobalExceptionHandler implements ErrorHandler {

    constructor(private tokenService: TokenService,private loaderService: LoaderService,private router:Router) { }
    
    handleError(error) { 
      
        console.log(error);

        this.loaderService.hide();   

        if (error.message == "SessionExpired" || error == "SessionExpired") {
            this.tokenService.renewToken();            
        }
        else if (error.message == "UnAuthorized" || error == "UnAuthorized") {
            this.router.navigate(['./unauthorised']);
        }        
    }
  }
