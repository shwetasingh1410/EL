import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-loss-details-report',
  templateUrl: './loss-details-report.component.html',
  styleUrls: ['./loss-details-report.component.css']
})
export class LossDetailsReportComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
