export class Report {
    fieldId: string;
    name: string;
}