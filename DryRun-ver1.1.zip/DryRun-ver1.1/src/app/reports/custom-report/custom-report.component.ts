import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-custom-report',
  templateUrl: './custom-report.component.html',
  styleUrls: ['./custom-report.component.css']
})
export class CustomReportComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
