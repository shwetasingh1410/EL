import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-new-users',
  templateUrl: './add-new-users.component.html',
  styleUrls: ['./add-new-users.component.css']
})
export class AddNewUsersComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
