import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-user-maintenance',
  templateUrl: './user-maintenance.component.html',
  styleUrls: ['./user-maintenance.component.css']
})
export class UserMaintenanceComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
