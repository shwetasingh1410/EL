import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-elinformation',
  templateUrl: './elinformation.component.html',
  styleUrls: ['./elinformation.component.css']
})
export class ElinformationComponent implements OnInit {
  isEditEnabled: boolean
  constructor() { }

  ngOnInit() {
    this.isEditEnabled = false;
  }
  edit() {
    this.isEditEnabled = true;
  }
  save(){
    this.isEditEnabled = false;
  }
  cancel(){
    this.isEditEnabled = false;
  }
}
