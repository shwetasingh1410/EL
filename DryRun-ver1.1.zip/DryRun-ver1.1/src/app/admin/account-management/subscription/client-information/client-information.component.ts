import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-client-information',
  templateUrl: './client-information.component.html',
  styleUrls: ['./client-information.component.css']
})
export class ClientInformationComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
