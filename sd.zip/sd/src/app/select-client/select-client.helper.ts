import { Account } from './select-client.model'

export class SelectClientHelper {
    static mapToAccount(party: any): Account {
        return new Account(party.Id, party.SubscriptionId, party.PartyId,party.AccountId, party.PartyName, party.ConsultancyStatus,
            party.AssociateAllCarriers, party.AccessLevel, party.AssociatedCarriers);
    }
}