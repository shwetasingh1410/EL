import { Injectable } from '@angular/core';

import { Account } from './select-client.model'

import { Carrier, BusinessUnit } from '../carrier-search/carriersearch.model';
import { FavoriteCategory, FavoriteGroup } from '../carrier-favorites-admin/carrier-favorites-admin.model';

import { licenseState, licenseBusinessType } from '../carrier-details/licenses/licenses.model';
import { carrierContactDetails } from '../carrier-details/general/general.model';
import {SearchRequest} from '../carrier-search/carriersearch.model'
import { CoolSessionStorage } from 'angular2-cool-storage';

@Injectable()
export class ClientService {
    private  clientChangeNotification: boolean;
    private accountList: Array<Account>;
    private revertUrl: string;
    private dateOne: string;
    private dateTwo: string;
    private changeSelectedClient: boolean;
    private licenseState: licenseState;
    private group : string;
    private licenseType : number;
    private groupname : string;
    private groupId :string;
    private modeType:number;
    private selectedCategoryAdmin:FavoriteCategory;
    private selectedGroupAdmin:FavoriteGroup;
    private selectedCategoryClient:FavoriteCategory;
    private selectedGroupClient:FavoriteGroup;

    selectedAccount: Account;
    selectedAdminAccount: Account;
    licenseTypeObject:string;
    selectedCarriers: Array<Carrier>;
    selectedCarriersNotification: Array<Carrier>;
    selectedCarriersNotificationDetails;
    selectedReportCarriers : Array<Carrier>;
    localStorage: CoolSessionStorage;
    carrierObject:Carrier;
    clientId;
    clientIdNotification;
    clientIdNotificationForUpdate
    carrierId;
    searchRequest:SearchRequest;

    // selectedBusinessUnits: Array<BusinessUnit>;


    // status flag for each page, where we want to redirect to and from carrier search page
    anyUpdate: boolean;
    unsavedChanges: boolean;
    redirectToSearch: boolean;
    redirectToReport: boolean;
    redirectToClientMaintenance: boolean;
    redirectionFromAdmin: boolean;
    changeClientNotification: boolean;
    fromNotification: boolean;
    redirectToCarrierFavorites : boolean;
    redirectToCarrierFavoritesAdmin : boolean
    redirectToNotification: boolean;
    redirectToNotificationFromDetails: boolean;
    redirectionToClientFavoritesOnAdd: boolean=false;
    fromSearch: boolean;
    recent: boolean=false;

    constructor(localStorage: CoolSessionStorage) {
        this.localStorage=localStorage;
    }
    
    getFromSearch(): boolean {
        return this.fromSearch;
    }
    setFromSearch(fromSearch: boolean) {
        this.fromSearch = fromSearch;
    }


    getAnyUpdate(): boolean {
        return this.anyUpdate;
    }
    setAnyUpdate(anyUpdate: boolean) {
        this.anyUpdate = anyUpdate;
    }

    setAccountList(accountList: Array<Account>) {
        this.accountList = accountList;
    }

    getAccountList() {
        return this.accountList;
    }

    setSelectedCategoryAdmin(category) {
        this.selectedCategoryAdmin=category;
    }

    getSelectedCategoryAdmin() {
        return this.selectedCategoryAdmin;
    }

    setSelectedCategoryClient(category) {
        this.selectedCategoryClient=category;
    }

    getSelectedCategoryClient() {
        return this.selectedCategoryClient;
    }

    setSelectedGroupAdmin(group) {
        this.selectedGroupAdmin=group;
    }

    getSelectedGroupAdmin() {
        return this.selectedGroupAdmin;
    }

    setSelectedGroupClient(group) {
        this.selectedGroupClient=group;
    }

    getSelectedGroupClient() {
        return this.selectedGroupClient;
    }

    setModeType(modeType:number){
        this.modeType=modeType;
        this.localStorage.setItem('modeType',this.modeType.toString());
    }

    getModeType(){
        var y=this.localStorage.getItem('modeType');
        var x = +y;
        return x;
    }

    getGroupId() {
        return this.groupId;
    }

    setGroupId(GroupId:string) {
this.groupId=GroupId;
    }

    setRevertUrl(url: string) {
        this.localStorage.setItem('url',url);
        this.revertUrl = url;
    }

    getRevertUrl() {
        this.revertUrl=this.localStorage.getItem('url');
        return this.revertUrl;
    }

    isChangeSelectedClient() {
        return this.changeSelectedClient;
    }

    setChangeSelectedClient(flag: boolean) {
        this.changeSelectedClient = flag;
        this.localStorage.setItem('selectedClient',this.changeSelectedClient.toString());
    }

    setClientChangeNotification(flag: boolean) {
        this.clientChangeNotification = flag;
    }

    getClientChangeNotification() {
        return this.clientChangeNotification;
    }


    setCarriers(carriers: Array<Carrier>) {
        this.selectedCarriers = carriers;
    }

    getCarriers(): Array<Carrier> {
        return this.selectedCarriers;
    }
    
    setCarriersNotification(carriers: Array<Carrier>) {
        this.selectedCarriersNotification = carriers;
    }

    getCarriersNotification(): Array<Carrier> {
        return this.selectedCarriersNotification;
    }

    setCarriersNotificationDetails(carriers: Array<Carrier>) {
        this.selectedCarriersNotificationDetails = carriers;
    }

    getCarriersNotificationDetails() {
        return this.selectedCarriersNotificationDetails;
    }

    setCarriersReport(carriers: Array<Carrier>) {
        this.selectedReportCarriers = carriers;
    }

    getCarriersReport(): Array<Carrier> {
        return this.selectedReportCarriers;
    }

    setFromNotification(status: boolean) {
        this.fromNotification = status;
    }

    getFromNotification(): boolean {
        return this.fromNotification;
    }
    

    setCarrierObject(carriers) {
        // this.localStorage.setObject('carriers',carriers);
        this.carrierObject=carriers;
    }

    getCarrierObject() {
        // let carrier;

        // carrier=this.localStorage.getObject('carriers');
        return this.carrierObject;
    }
    setRecentFlag(value:boolean) {
        // this.localStorage.setObject('carriers',carriers);
        this.recent=value;
    }

    getRecentFlag() {
        // let carrier;

        // carrier=this.localStorage.getObject('carriers');
        return this.recent;
    }
    
    setCarriersForReport(carriers: Array<Carrier>){
        this.selectedReportCarriers = carriers;
    }
    getCarriersForReport(): Array<Carrier> {
        return this.selectedReportCarriers;
    }


    getSelectedAccount() {
        let Account;
        Account=this.localStorage.getObject('account');
        return this.selectedAccount;
    }

    setSelectedAccount(client: Account) {
        this.selectedAccount = client;
        if(client)
        this.localStorage.setObject('account',this.selectedAccount)
    }
    getSelectedAdminAccount() {
        
        return this.selectedAdminAccount;
    }

    setSelectedAdminAccount(client: Account) {
        this.selectedAdminAccount = client;
        
    }

    setRedirectToClientMaintenance(status: boolean) {
        this.redirectToClientMaintenance = status;
    }

    getRedirectToClientMaintenance(): boolean {
        return this.redirectToClientMaintenance;
    }
    setReportDate(dateOne: string,dateTwo:string){
        this.dateOne = dateOne
        this.dateTwo = dateTwo
    }
    getReportDate(num){
        if(num==1) {
        return this.dateOne
        }
        else if(num==2){
        return this.dateTwo
        }
    }

    setRedirectToSearch(status: boolean) {
        this.redirectToSearch = status;
    }
    getRedirectToSearch(): boolean {
        return this.redirectToSearch;
    }

    setRedirectToReport(status: boolean) {
        this.redirectToReport = status;
    }
    getRedirectToReport(): boolean {
        return this.redirectToReport;
    }
    setRedirectToCarrierFavorites(status: boolean) {
        this.redirectToCarrierFavorites = status;
    }
    getRedirectToCarrierFavorites(): boolean {
        return this.redirectToCarrierFavorites;
    }
    setRedirectToCarrierFavoritesAdmin(status: boolean) {
        this.redirectToCarrierFavoritesAdmin = status;
    }

    getRedirectToCarrierFavoritesAdmin(): boolean {
        return this.redirectToCarrierFavoritesAdmin;
    }

    getLicenseState() {
        return this.licenseState;
    }

    setLicenseState(licenseState: licenseState) {
        this.licenseState = licenseState;
    }

    getOwnership() {
        return this.group;
    }
    setOwnership(group: string) {
        this.group = group;
    }
    getLicensed(){
        return this.licenseType;
    }
    setLicensed(licenseType : number ){
        this.licenseType = licenseType;
    }

    setRedirectToNotification(status: boolean) {
      this.redirectToNotification = status;
    }
    getRedirectToNotification(): boolean {
      return this.redirectToNotification;
    }

    setRedirectToNotificationFromDetails(status: boolean) {
      this.redirectToNotificationFromDetails = status;
    }
    getRedirectToNotificationFromDetails(): boolean {
      return this.redirectToNotificationFromDetails;
    }

    setLicenceTypeCountry(licenseTypeObject) {
        this.localStorage.setItem('country',licenseTypeObject);
        this.licenseTypeObject=licenseTypeObject;
    }

    getLicenseTypeCountry() {
        this.licenseTypeObject=this.localStorage.getItem('country');
        return this.licenseTypeObject;
    }

    setAccountId(clientId) {
        this.localStorage.setItem('clientId',clientId);
        this.clientId=clientId;
    }

    getAccountId() {
        return this.clientId;
    }

    setAccountIdNotification(clientIdNotification) {
        this.localStorage.setItem('clientIdNotification',clientIdNotification);
        this.clientIdNotification=clientIdNotification;
    }

    getAccountIdNotification() {
        return this.clientIdNotification;
    }

    setAccountIdNotificationForUpdate(clientIdNotificationForUpdate) {
        this.localStorage.setItem('clientIdNotification',clientIdNotificationForUpdate);
        this.clientIdNotificationForUpdate=clientIdNotificationForUpdate;
    }

    getAccountIdNotificationForUpdate() {
        return this.clientIdNotificationForUpdate;
    }


    setDetailCarrierId(carrierId) {
        this.carrierId=carrierId;
    }

    getDetailCarrierId() {
        return this.carrierId;
    }

    setSearchCarrierState(searchRequest:SearchRequest) {
        this.searchRequest=searchRequest;
    }

    getSearchCarrierState() {
        return this.searchRequest;
    }

    setRedirectionToFavorites(redirect:boolean) {
        this.localStorage.setItem('redirectToFav',redirect.toString())
        this.redirectionToClientFavoritesOnAdd=redirect;
    }

    getRedirectionToFavorites():boolean {
        return this.redirectionToClientFavoritesOnAdd;
    }

    setRedirectFromAdmin(redirect:boolean) {
        this.redirectionFromAdmin=redirect;
    }

    getRedirectFromAdmin():boolean {
        return this.redirectionFromAdmin;
    }
}
