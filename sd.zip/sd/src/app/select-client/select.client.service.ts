﻿import { Injectable } from '@angular/core';
import { Http } from '@angular/http';
import { Observable } from 'rxjs/Rx';
import { Carrier,SearchRequest } from '../carrier-search/carriersearch.model';
import { CarrierSearchHelper } from '../carrier-search/carriersearch.helper';
import { Settings } from '../shared/settings/settings.service';
import { SelectClientHelper } from './select-client.helper';
import { Account } from './select-client.model';
import { serializeUrlParams } from '../shared/http/http.factory';

@Injectable()
export class SelectClientService {

    constructor(private _http: Http, private _settings: Settings) { }

    getAccounts(role: string, userId : string): Observable<Array<Account>> {
        if (role == 'SuperAdmin') {
            return this._http.get(this._settings.getApiUrl() + 'api/accounts/active')
                .map((response) => this.getAccountsHandler(response.json()));
        }
        else if (role == 'MSDBUAdmin' || role == 'MSDAdmin') {
            return this._http.get(this._settings.getApiUrl() + 'api/accounts/active/role-based')
                .map((response) => this.getAccountsHandler(response.json()));
        }
        else {
            return this._http.get(this._settings.getApiUrl() + 'api/users/' + userId +'/accounts')
                .map((response) => this.getAccountsHandler(response.json()));
        }
    }

    getAccountsHandler(response) {
        let result: Array<Account> = new Array<Account>();
        response.forEach(account => {
            result.push(SelectClientHelper.mapToAccount(account));
        });
        return result;
    }


    getSearchResult(searchRequest: SearchRequest) {
    let params: URLSearchParams = serializeUrlParams(searchRequest);
    return this._http.get(this._settings.getApiUrl() + 'api/carriers?' + params.toString())
        .map((response) => this.getSearchResultHandler(response));
}

    getSearchResultHandler(response) {
  let result: Array<Carrier> = new Array<Carrier>();
  response.json().forEach((carrier) => {
      result.push(CarrierSearchHelper.mapToCarrier(carrier))
  });
  return result;
}

}