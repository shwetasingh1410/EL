﻿import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

import { Account } from './select-client.model';
import { ClientService } from './client.service';
import { SelectClientService } from './select.client.service';
import { LoggedInUser } from '../shared/loggedInUser/LoggedInUser';
import { LoaderService } from '../shared/loaderComponent/Loader.service';
import { TranslateService } from '../translate/translate.service';
import {CoolSessionStorage} from 'angular2-cool-storage';
import { Carrier,SearchRequest } from '../carrier-search/carriersearch.model';

@Component({
    selector: 'select-client',
    templateUrl: './select-client.component.html',
    styleUrls: ['./select-client.component.css'],
    providers: [SelectClientService]
})
export class SelectClient {
    accountList: Array<Account>;
    selectedIndex: number;
    isCancelActive: boolean;
    clientId;
    carrier:Carrier;
    localStorage:CoolSessionStorage;
    searchRequest:SearchRequest;

    constructor(localStorage:CoolSessionStorage,private _clientService: ClientService, private _selectClientService: SelectClientService,
        private _loggedInUser: LoggedInUser, private _router: Router, private _loaderService: LoaderService,private _translate: TranslateService) {
        this.localStorage=localStorage;
        this.searchRequest=new SearchRequest();
        // this.redirectToHome();
        if (this._clientService.getSelectedAccount() === undefined ||
            this._clientService.getSelectedAccount() === null) {
            this._loaderService.show();
            this._selectClientService.getAccounts(_loggedInUser.getUserRoleCode(), _loggedInUser.getEncryptedUserId())
                .subscribe((accountList) => {
                    this.handleGetAccounts(accountList);
                    this._loaderService.hide();
                });
        } else if (this._clientService.isChangeSelectedClient()) {
            // this.accountList = this._clientService.getAccountList();
            this.isCancelActive = true;
            this._clientService.setChangeSelectedClient(false);
            this._loaderService.show();
            this._selectClientService.getAccounts(_loggedInUser.getUserRoleCode(), _loggedInUser.getEncryptedUserId())
                .subscribe((accountList) => {
                    this.handleGetAccounts(accountList);
                    this._loaderService.hide();
                });
        }

    }

    ngOnInit() {
            this.selectLang('en');
          }
        
    selectLang(lang: string){
            this._translate.use(lang);
          }

    //redirect to Home if no revert url is available
    // redirectToHome() {
    //     if (this._clientService.getRevertUrl() === undefined)
    //     {
    //         this._router.navigateByUrl('/home');
    //     }
    // }

    handleGetAccounts(accountList: Array<Account>) {
        this.accountList = accountList;
        this._clientService.setAccountList(accountList);
        this.selectClient();
    }

    selectClient() {
        if (this.accountList.length === 0) {
            this.selectClient = null;
            this.clientId='0';
        } else if (this.accountList.length === 1) {
            this.clientId=this.accountList[0].AccountId;
            this._clientService.setSelectedAccount(this.accountList[0]);
            this.cancel();
        } else if (this.selectedIndex !== undefined) {
            
  
      if(this.localStorage.getItem('LegalName')){
        this.localStorage.removeItem('LegalName');
      }
      if(this.localStorage.getItem('CountryId')){
        this.localStorage.removeItem('CountryId');
        this.localStorage.removeItem('CountryCode');
      }
      if(this.localStorage.getItem('CountrySubId')){
        this.localStorage.removeItem('CountrySubId');
      }
      if(this.localStorage.getItem('CompanyTypeId')){
        this.localStorage.removeItem('CompanyTypeId');
      }
      if(this.localStorage.getItem('ApprovalStatusId')){
        this.localStorage.removeItem('ApprovalStatusId');
      }
      if(this.localStorage.getItem('CodeSelection')){
        this.localStorage.removeItem('CodeSelection');
      }
      if(this.localStorage.getItem('Code')){
        this.localStorage.removeItem('Code');
      }
      if(this.localStorage.getItem('LegalNameOperator')){
        this.localStorage.removeItem('LegalNameOperator');
      }
      if(this.localStorage.getItem('GroupCodeId')){
        this.localStorage.removeItem('GroupCodeId');
      }
      if(this.localStorage.getItem('LicenseCountryId')){
        this.localStorage.removeItem('LicenseCountryId');
        this.localStorage.removeItem('LicenseCountryCode');
      }
      if(this.localStorage.getItem('LicenseStateId')){
        this.localStorage.removeItem('LicenseStateId');
        this.localStorage.removeItem('LicenseStateCode');
      }
      if(this.localStorage.getItem('LicenseCodeId')){
        this.localStorage.removeItem('LicenseCodeId');
      }
      if(this.localStorage.getItem('RatingAgencyId')){
        this.localStorage.removeItem('RatingAgencyId');
        this.localStorage.removeItem('RatingAgencyName');
      }
      if(this.localStorage.getItem('RatingAgencyOperator')){
        this.localStorage.removeItem('RatingAgencyOperator');
      }
      if(this.localStorage.getItem('RatingRange')){
        this.localStorage.removeItem('RatingRange');
      }
      if(this.localStorage.getItem('Default')){
        this.localStorage.removeItem('Default');
      }
      if(this.localStorage.getItem('ApprovalStatusAllowed')){
        this.localStorage.removeItem('ApprovalStatusAllowed');
      }
      if(this.localStorage.getItem('RefCode')){
        this.localStorage.removeItem('RefCode');
      }
      if(this.localStorage.getItem('CategoryId')){
        this.localStorage.removeItem('CategoryId');
        this.localStorage.removeItem('CategoryName');
      }
      if(this.localStorage.getItem('CarrierFavoriteId')){
        this.localStorage.removeItem('CarrierFavoriteName');
        this.localStorage.removeItem('CarrierFavoriteId');
      }
      if(this.localStorage.getItem('BusinessUnitId')){
        this.localStorage.removeItem('BusinessUnitId');
      }
      if(this.localStorage.getItem('ResctrictionCodeId')){
        this.localStorage.removeItem('ResctrictionCodeId');
      }
      if(this.localStorage.getItem('QualifierId')){
        this.localStorage.removeItem('QualifierId');
      }
      if(this.localStorage.getItem('CarrierStatusId')){
        this.localStorage.removeItem('CarrierStatusId');
      }
      if(this.localStorage.getItem('IsWillisUser')){
        this.localStorage.removeItem('IsWillisUser');
      }
      if(this.localStorage.getItem('LegalEntity')){
        this.localStorage.removeItem('LegalEntity');
      }
      if(this.localStorage.getItem('TobaIndicator')){
        this.localStorage.removeItem('TobaIndicator');
      }
      if(this.localStorage.getItem('Mode')){
        this.localStorage.removeItem('Mode');
      }
    
            this.clientId=this.accountList[this.selectedIndex].AccountId;
            this._clientService.setSelectedAccount(this.accountList[this.selectedIndex]);
            this.cancel();
        }
    }

    cancel() {
        this._clientService.setChangeSelectedClient(false);
        var url=this._clientService.getRevertUrl();
        if(url){
            if(url.endsWith('carrier-doc'))
            this._router.navigateByUrl(this._clientService.getRevertUrl());
            else if(url.endsWith('notification')){
                this._router.navigate(['./notification/account/'+this.clientId]);
            }
            else if(url.endsWith('carrier-search')){
                if(this.clientId)
                this._router.navigate(['./carrier-search/client/'+this.clientId]);
                else{
                    var cl:Account=this._clientService.getSelectedAccount();
                    if(cl)
                    this._router.navigate(['./carrier-search/client/'+cl.AccountId]);
                }
                
            }
            else if(url.endsWith('general') || url.endsWith('summary') || url.endsWith('documents')){
                var car:any;
                if(this._clientService.getCarrierObject()){
                    car=this._clientService.getCarrierObject();
                }else{
                    car=this.localStorage.getObject('carriers');
                }
                if(car && car.WillisCode){
                    this.localStorage.setObject('carriers',car);
                    var code='code';
                    var carrier='carrier';
                    var client='client';
                    var account=this._clientService.getSelectedAccount();
                    var tabName:string=url;
                    
                    if(account) {
                        var associates=account.AssociatedCarriers;
                        var count:number=0;
                        if(associates) {
                            associates.forEach(associate => {
                                if(associate)
                                if(associate.WillisCode)
                                if(associate.WillisCode == car.WillisCode){
                                    count++;
                                }
                            })
                        }
                        if(count==0){
                            if(account.AssociateAllCarriers) {
                                this._router.navigate(['carrier-detail',client,this.clientId,carrier,car.CarrierId,code,car.WillisCode,tabName]);
                            }
                            else {
                                this._router.navigate(['forbidden']);
                            }
                        }else if(count > 0) {
                            this._router.navigate(['carrier-detail',client,this.clientId,carrier,car.CarrierId,code,car.WillisCode,tabName]);
                        }
                    }else {
                        this._router.navigate(['forbidden']);
                    }
                }else{
                    this._router.navigate(['forbidden']);
                }
            }
            else{
                if(this.localStorage) {
                    var cc=this._clientService.getSelectedAccount();
                    var guid=this.localStorage.getItem('guid');
                    this.searchRequest.LegalNameOperator = '1';
                    this.searchRequest.RatingAgencyOperator = '0';
                    this.searchRequest.CodeSelection='willis';
                    this.searchRequest.Code=guid;
                    this.searchRequest.ClientId=cc.Id;
                    this._selectClientService.getSearchResult(this.searchRequest).subscribe(result => {
                    this.carrier=result[0];
                    if(this.carrier) {
                    this.localStorage.setItem('clientId',cc.AccountId);
                    this.localStorage.setObject('carriers',this.carrier);
                    this.localStorage.setObject('account',cc);
                        this._clientService.setAccountId(cc.Id);
                        this._clientService.setDetailCarrierId(this.carrier.CarrierId);
                        var code='code';
                        var carrier='carrier';
                        var client='client';
                        var tabName='documents';
                        this._router.navigate(['carrier-detail',client,cc.AccountId,carrier,this.carrier.CarrierId,code,guid,tabName]);
                    
                    }
                    else{
                        this._router.navigate(['forbidden']);
                    }
                    })
                }
                else{
                    this._router.navigate(['forbidden']);
                }
            }
        }
        
    }
}