﻿export const ratingAgencyScaleSummaryResult = [
    {
        "AMBest": "A++",
        "SP": "AAA",
        "Moody": "Aaa",
        "Fitch": "aaaa"
    },
    {
        "AMBest": "B++",
        "SP": "BBB",
        "Moody": "Bbb",
        "Fitch": "bbbb"
    }
];



