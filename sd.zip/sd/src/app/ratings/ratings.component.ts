import { Component, OnInit } from '@angular/core';
import { RatingAgencyScaleSummaryService } from './ratings.service';
import { RatingAgencyScaleSummary } from './ratings.model';
import { ratingAgencyScaleSummaryResult } from './ratings.mock.data';
import { TranslateService } from '../translate/translate.service';

@Component({
  selector: 'app-ratings',
  templateUrl: './ratings.component.html',
  styleUrls: ['./ratings.component.css'],
  providers: [RatingAgencyScaleSummaryService]
})

export class RatingsComponent implements OnInit {
  ratingAgencyScaleSummaryList: Array<RatingAgencyScaleSummary>;
  isError: boolean;
  isSuccess: boolean;
  message: string;

  constructor(private _ratingAgencyScaleSummaryService: RatingAgencyScaleSummaryService,private _translate: TranslateService) {
  }

  ngOnInit() {
    this.getRatingAgencyScaleSummary();
    this.selectLang('en');
  }

  selectLang(lang: string) {
    this._translate.use(lang);
  }

  getRatingAgencyScaleSummary() {
    this._ratingAgencyScaleSummaryService
      .getRatingAgencyScaleSummary().
      subscribe((result) => {
        this.ratingAgencyScaleSummaryList = result;
      }, (error) => this.handleError(error));
  }

  showError(message: string) {
    this.isSuccess = false;
    this.isError = true;
    setTimeout(() => {
      this.isError = false;
    }, 3000);
    this.message = message;

  }

  handleError(error) {
    this.isSuccess = false;
    this.isError = true;
    setTimeout(() => {
      this.isError = false;
    }, 3000);
    this.showError('Some Error Occured, please report to support team along with steps to reproduce');
  }
}
