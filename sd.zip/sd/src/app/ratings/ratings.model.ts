export class RatingAgencyScaleSummary {
    AMBest: string;
    SP: string;
    Moody: string;
    Fitch: string;

    constructor(AMBest: string, SP: string, Moody: string, Fitch: string) {
        this.AMBest = AMBest;
        this.SP = SP;
        this.Moody = Moody;
        this.Fitch = Fitch;
    }   
}





