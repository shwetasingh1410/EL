import { FormsModule } from '@angular/forms';
import { Component, OnInit, ViewChild, ElementRef, AfterContentInit } from '@angular/core';
import { LoaderService } from '../shared/loaderComponent/Loader.service';
import { Router } from '@angular/router';
import { LoggedInUser } from '../shared/loggedInUser/LoggedInUser';
import { EditUserService } from './edituser.service';
import { UserDetails, Role, Account, UserType, AccountActionIndicator, UserRole, AccountAccess, ConsultancyStatus } from './edituser.model';
import * as _ from "lodash";
import { TranslateService } from '../translate/translate.service';
declare var $: any;
@Component({
  selector: 'app-edituser',
  templateUrl: './edituser.component.html',
  styleUrls: ['./edituser.component.css'],
  providers: [EditUserService]
})
export class EdituserComponent implements AfterContentInit {

  selectUserType: number;
  searchText: string;
  userSearchResult: Array<UserDetails>;
  selectedSearchIndex: number;
  selectedUser: UserDetails;
  accounts: Array<Account>;
  selectedUserAccountList: Array<Account>;
  removeSelectedAccounts: Array<string>;
  rolesList: Array<Role>;
  message: string;
  highpriority: boolean = true;
  selectedAccountId;

  isSearchVisible: boolean;
  isUserDataLoaded: boolean;
  showRoles: boolean;
  showDetails: boolean;
  isroleopen: boolean;
  isdetailsopen: boolean;
  isSearchClicked: boolean;
  isSuccess: boolean;
  isError: boolean;
  noAccountToRemove: boolean;
  _this: any = this;
  selectedAccountValue: string;
  isAuthorized: boolean;
  selectedUserInfo: UserDetails;
  constructor(private _loaderService: LoaderService, private _router: Router, private _editUserService: EditUserService
    , private _loggedInUser: LoggedInUser, private _translate: TranslateService) {
    this.cancel();
  }

  ngAfterContentInit(): void {
    this._loaderService.show();

    this._editUserService.getRoles(this._loggedInUser.getRole())
      .subscribe((result) => {
        this.rolesList = result;
        this._loaderService.hide();
      }, (error) => {
        this._loaderService.hide();
        this.handleError(error)
      });

    this._editUserService.getAccounts()
      .subscribe((result) => {
        this._loaderService.hide();
        this.accounts = result;
        var msdbuDropdown;
        var msdDropdown;
        msdDropdown = this.accounts.filter(client => client.AccessLevel == AccountAccess.AllAdmins);
        msdbuDropdown = this.accounts.filter(client => client.AccessLevel == AccountAccess.AllAdmins && client.ConsultancyStatus == ConsultancyStatus.NonConsultancy);
        if (this._loggedInUser.getUserRoleCode() === 'MSDAdmin') {
          this.accounts = msdDropdown;
        }
        if (this._loggedInUser.getUserRoleCode() === 'MSDBUAdmin') {
          this.accounts = msdbuDropdown;
        }
        if (this.accounts.length > 0)
          this.selectedAccountValue = this.accounts[0].Id;
      }, (error) => {
        this._loaderService.hide();
        this.handleError(error)
      });
    this.selectLang('en');


  }

  selectLang(lang: string) {
    // set current lang;
    this._translate.use(lang);
  }

  cancel() {
    this.isSearchVisible = false;
    this.isUserDataLoaded = false;
    this.showRoles = false;
    this.showDetails = false;
    this.isdetailsopen = true;
    this.selectedUser = null;
    this.selectedSearchIndex = null;
    this.userSearchResult = null;
    this.isSearchClicked = false;
    this.selectUserType = null;
    this.searchText = null;
    this.removeSelectedAccounts = null;
    this.isSuccess = false;
    this.noAccountToRemove = false;
    this.isError = false;
    this.selectedUserAccountList = [];
    this.selectedUserInfo = null;
    this.selectedAccountValue = null;
  }

  reset() {
    this.searchText = null;
    this.selectedSearchIndex = null;
  }

  contentload() {
    let userType = this.selectUserType;
    this.cancel();
    this.selectUserType = userType;
    this.isSearchVisible = true;
  }

  resetSearchModal(){
    
    //  $(this).removeData('bs.modal')
   //   $('#searchModal').on('hidden.bs.modal', function() {
     //     $('#content').empty();
       // }); 

  }
  // search user and display pop up with result data
  searchload() {
    this.userSearchResult = null;
    this.isUserDataLoaded=false;
    var text = this.searchText;
    text = text.replace(/'/g, '"');
    this._editUserService
      .getUserSearchResult(text, this.selectUserType)
      .subscribe((result) => {

        this.userSearchResult = result;
        this.isUserDataLoaded = true;
      }, (error) => {

        this.handleError(error)
      });


  }

  selectload() {
    // get selected user
    this._loaderService.show()
    this.selectedUser = this.userSearchResult[this.selectedSearchIndex];
    this.searchText = this.selectedUser.DisplayName;
    this._editUserService.getUser(this.selectedUser).
      subscribe((result) => {
        if ((this._loggedInUser.getUserRoleCode() == 'MSDBUAdmin' && (result.UserRole.RoleCode == 'MSDBUAdmin' || result.UserRole.RoleCode == 'ClientRead' || result.UserRole.RoleCode == 'WillisRead'))
          || (this._loggedInUser.getUserRoleCode() == 'WillisRead' && (result.UserRole.RoleCode == 'ClientRead' || result.UserRole.RoleCode == 'WillisRead'))
          || (result.UserRole.RoleCode == 'ClientRead' && (this._loggedInUser.getUserRoleCode() == 'ClientRead'))
          || (this._loggedInUser.getUserRoleCode() == 'MSDAdmin' && (result.UserRole.RoleCode == 'MSDBUAdmin' || result.UserRole.RoleCode == 'MSDAdmin' || result.UserRole.RoleCode == 'ClientRead' || result.UserRole.RoleCode == 'WillisRead'))
          || (this._loggedInUser.getUserRoleCode() == 'SuperAdmin')) {
          this.selectedUser = result;
          this.showDetails = true;
          this.isdetailsopen = false;
          this.isAuthorized = true;
          // check if User Already Exist
          if (this.selectedUser.UserId) {
            // check if logged in user has higher role compared to selected user
            if (this.checkIfLoggedInUserRoleisHigher()) {
              this._loaderService.hide();
              this.getUserAccounts();
            }
            //throw error if not
            else {
              //this.showDetails = false;
              this._loaderService.hide();
              this.isAuthorized = false;
              this.showError('You are not authorised to update the selected user.');
            }
          } else {
            this._loaderService.hide();
            this.selectedUser.AccountList = [];
            this.selectedUserAccountList = [];
            this.isAccountToRemove();
          }
        } else {
          this._loaderService.hide();
          this.isdetailsopen = false;
          this.showError('You are not authorised to update the selected user.');
        }

      }, (error) => {
        this._loaderService.hide();
        this.handleError(error)
      });
  }

  checkIfLoggedInUserRoleisHigher() {
    return this._loggedInUser.getRole().getRank() <= this.selectedUser.UserRole.getRank();
  }


  getUserAccounts() {
    this._loaderService.show();
    this._editUserService.getAccountsForUser(this.selectedUser)
      .subscribe((result) => {
        this._loaderService.hide();
        this.selectedUser = result;
        this.selectedUserAccountList = _.cloneDeep(this.selectedUser.AccountList);
        this.isAccountToRemove();
        this.setShowRoles(this.selectedUser.UserRole.getRank());
      }, (error) => {
        this._loaderService.hide();
        this.handleError(error)
      });
  }

  onSelectedUserRoleChange($event) {
    if (parseInt($event) != 0) {
      let index = this.rolesList.findIndex(role => role.Rank == parseInt($event));
      if (index != -1) {
        this.selectedUser.setUserRole(this.rolesList[index]);
      }
    }
    this.setShowRoles(parseInt($event));
    this.selectedAccountValue = null;
  }

  // show/hide user roles based on role type
  setShowRoles(userRole: UserRole) {
    switch (userRole) {
      case UserRole.WillisReader:
      case UserRole.ClientReader:
        this.showRoles = true;
        break;
      case UserRole.SuperAdministrator:
      case UserRole.MsdAdministrator:
      case UserRole.MsdBuAdministrator:
      default:
        this.showRoles = false;
        break;

    }
  }

  // Save Record using http request
  saverecord() {
    this.selectedUser.AccountList = this.selectedUserAccountList;
    if (this.selectedUser.UserId) {
      if (this.selectedUser.UserRole.RoleCode == "MSDBUAdmin" || this.selectedUser.UserRole.RoleCode == "MSDAdmin" || this.selectedUser.UserRole.RoleCode == "SuperAdmin") {
        this.getAssociatedAccountsForUser();
        if (this.selectedUserInfo.AccountList.length > 0) {
          this.selectedUserInfo.AccountList.forEach(element => {
            element.ActionIndicator = AccountActionIndicator.Remove;
          });
        }
        this.selectedUser.AccountList = this.selectedUserInfo.AccountList;

      }
      this.updateUser();
    } else {
      this.createUser();
    }
  }

  getAssociatedAccountsForUser() {
    this._editUserService.getAccountsForUser(this.selectedUser)
      .subscribe((result) => {
        this.selectedUserInfo = result;
      }, (error) => {
        this._loaderService.hide();
        this.handleError(error)
      });
  }



  updateUser() {
    this._loaderService.show();
    this._editUserService.updateUser(this.selectedUser)
      .subscribe((result) => {
        if (result) {
          this._loaderService.hide();
          this.showSuccess('User update completed');
          this.resetAccountList();
          // this.selectedAccountValue = null;
        }
        else {
          this._loaderService.hide();
          this.showError('User update failed');
        }
      }, (error) => {
        this._loaderService.hide();
        this.handleError(error)
      });
  }

  createUser() {
    this._loaderService.show();
    this._editUserService.createUser(this.selectedUser)
      .subscribe((result) => {
        this._loaderService.hide();
        this.selectedUser.UserId = result.text();
        this.showSuccess('User created successfully.');
        this.resetAccountList();
        // this.selectedAccountValue = null;
      }, (error) => {
        this._loaderService.hide();
        this.handleError(error)
      });
  }

  resetAccountList() {
    this.selectedUser.AccountList = this.selectedUser.AccountList
      .filter((account) => account.ActionIndicator !== AccountActionIndicator.Remove);
    this.selectedUser.AccountList
      .forEach((account) => {
        account.ActionIndicator = AccountActionIndicator.None;
      });
    if (this.selectedUser.UserRole.RoleCode == "MSDBUAdmin" || this.selectedUser.UserRole.RoleCode == "MSDAdmin" || this.selectedUser.UserRole.RoleCode == "SuperAdmin") {
      this.selectedUser.AccountList = [];
      this.selectedUserInfo = null;
    }
    this.selectedUserAccountList = this.selectedUser.AccountList;

  }


  // remove selected Client from User Client List
  selectremove() {
    this.removeSelectedAccounts.forEach((clientId) => {
      let index = this.getClientindexSelectedUserAccountList(clientId);
      if (index !== -1) {
        if (this.getClientindexSelectedUser(clientId) === -1) {
          this.selectedUserAccountList.splice(index, 1);
          this.selectedUserAccountList = this.selectedUserAccountList;
        } else if (this.selectedUser.AccountList.length > 0) {
          this.selectedUserAccountList[index].ActionIndicator = AccountActionIndicator.Remove;
        } else {
          this.selectedUserAccountList.splice(index, 1);
          this.selectedUserAccountList = this.selectedUserAccountList;
        }
      }
    });
    this.isAccountToRemove();
  }

  // function to check, if there is any account to be removed from user 
  isAccountToRemove() {
    let length = this.selectedUserAccountList
      .filter((account) => account.ActionIndicator == AccountActionIndicator.Add
        || account.ActionIndicator == AccountActionIndicator.None).length;
    if (length == 0)
      this.noAccountToRemove = true;
    else
      this.noAccountToRemove = false;

  }

  // Get Client Index based on Index Selected User AccountList
  getClientindexSelectedUserAccountList(accountId: string): number {
    return this.selectedUserAccountList.findIndex((account) => account.AccountId == accountId);
  }

  // Get Client Index from Selected User
  getClientindexSelectedUser(accountId: string): number {
    return this.selectedUser.AccountList.findIndex((account) => account.AccountId == accountId);
  }


  // add selectd client in user client list
  selectadd(accountId: string) {
    if (this.selectedAccountValue !== null) {
      accountId = this.selectedAccountValue;
    }
    else {
      accountId = accountId;
    }
    let existingIndex = this.getClientindexSelectedUserAccountList(accountId);
    if (existingIndex == -1) {
      let index = this.accounts.findIndex((account) => account.AccountId == accountId);
      if (index !== -1) {
        let account: Account = this.accounts[index];
        account.ActionIndicator = AccountActionIndicator.Add;
        this.selectedUserAccountList.push(account);
        this.selectedUserAccountList = this.selectedUserAccountList;
      }
    } else if (existingIndex >= 0) {
      if (this.selectedUserAccountList[existingIndex].ActionIndicator == AccountActionIndicator.Add) {
        this.selectedUserAccountList[existingIndex].ActionIndicator = AccountActionIndicator.Add;
        this.showError('Already Exists!')
      }
      else {
        if (this.selectedUserAccountList[existingIndex].ActionIndicator == AccountActionIndicator.None) {
          this.showError('Already Exists!')
        }

        this.selectedUserAccountList[existingIndex].ActionIndicator = AccountActionIndicator.None;

      }      
    }
    this.isAccountToRemove();
  }

  onSelectedAccountChange($event) {
    this.selectedAccountValue = $event;
  }

  handleError(error) {
    this.isSuccess = false;
    this.isError = true;
    setTimeout(() => {
      this.isError = false;
    }, 3000);
    //error.status = 412;
    if (error.status === 412) {
      this.showError('Error 412 : Input Output Validation Error. Please enter details again. ');
    }
    else if (error.status === 422) {
      this.showError('Error 422 : Business Validation Error. Please try again');
    }
    else if (error.status === 500) {
      this.showError('500 Internal Server Error. Please try again');
    }
    else {
      this.showError('Server Error. Please try again');
    }
  }

  showSuccess(message: string) {
    this.message = message;
    this.isSuccess = true;
    setTimeout(() => {
      this.isSuccess = false;
    }, 3000);
  }

  showError(message: string) {
    this.isError = true;
    setTimeout(() => {
      this.isError = false;
    }, 3000);
    this.message = message;
  }
}
