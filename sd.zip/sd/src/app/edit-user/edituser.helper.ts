﻿//will help in common utility static functions 
import { UserDetails, Account, Role, AccountActionIndicator } from './edituser.model';
export class EditUserHelper {

    static mapToUserDetails(user: any): UserDetails {
        //return User Object
        return new UserDetails(user.PrincipalId, user.UserId, user.DisplayName, user.Surname,
            user.Forename, user.EmailAddress, user.Country);
    }

    static mapToAccount(party: any, action: AccountActionIndicator): Account {
        //return Account Object
        //console.log(userClient);
        return new Account(party.Id, party.SubscriptionId, party.PartyId, party.AccountId, party.PartyName, party.ConsultancyStatus,
            party.AssociateAllCarriers, party.AccessLevel, action);
    }

    static mapToRole(role: any): Role {
        return new Role(role.RoleId, role.RoleCode, role.RoleDescription, role.Rank);
    }


}