﻿export class Role {
    RoleCode: string;
    RoleDescription: string;
    RoleId: string;
    Rank: number;

    constructor(RoleId: string, RoleCode: string, RoleDescription: string, Rank: number) {
        this.RoleId = RoleId;
        this.RoleCode = RoleCode;
        this.RoleDescription = RoleDescription;
        this.Rank = Rank;
    }

    getRank() {
        return this.Rank;
    }
    getRoleCode() {
        return this.RoleCode;
    }
}

export class Account {
    public Id: string;
    public SubscriptionId: string;
    public PartyId: number;
    public AccountId:string;
    public PartyName: string;
    public ConsultancyStatus: ConsultancyStatus;
    public AssociateAllCarriers: boolean;
    public AccessLevel: AccountAccess;
    public DisplayPartyName: string;
    ActionIndicator: AccountActionIndicator;

    constructor(Id: string, SubscriptionId: string, PartyId: number,AccountId:string, PartyName: string, ConsultancyStatus: ConsultancyStatus,
        AssociateAllCarriers: boolean, AccessLevel: AccountAccess, ActionIndicator: AccountActionIndicator) {
        this.Id = Id;
        this.SubscriptionId = SubscriptionId;
        this.PartyId = PartyId;
        this.AccountId = AccountId;
        this.PartyName = PartyName;
        this.ConsultancyStatus = ConsultancyStatus;
        this.AssociateAllCarriers = AssociateAllCarriers;
        this.AccessLevel = AccessLevel;
        this.ActionIndicator=ActionIndicator;

        if (ConsultancyStatus == 0)
            this.DisplayPartyName = PartyName + "(Non-Consultancy)";
        else
            this.DisplayPartyName = PartyName + "(Consultancy)";
    }
}

export class UserDetails {
    PrincipalId: string;
    UserId: string;
    DisplayName: string
    Surname: string;
    Forename: string;
    Initials: string;
    EmailAddress: string;
    Country: string;
    UserLogin: string;
    UserRole: Role;
    AccountList: Array<Account>;

    constructor(PrincipalId: string, UserId: string, DisplayName: string, Surname: string,
        Forename: string, EmailAddress: string, Country: string) {
        this.PrincipalId = PrincipalId;
        this.DisplayName = DisplayName;
        this.Surname = Surname;
        this.Forename = Forename;
        this.EmailAddress = EmailAddress;
        this.Country = Country;
    }

    setAccountList(AccountList: Array<Account>) {
        this.AccountList = AccountList;
    }

    setUserRole(userRole: Role) {
        this.UserRole = userRole;
    }

    setUserId(userId: string) {
        this.UserId = userId;
    }
}

export enum UserType {
    Internal = 1,
    External
}

export enum UserStatus {
    Online = 1,
    Offline
}

export enum UserRole {
    SuperAdministrator = 1,
    MsdAdministrator,
    MsdBuAdministrator,
    WillisReader,
    ClientReader,
}

export enum AccountActionIndicator {
    Remove = 0,
    Add,
    None
}

export enum ConsultancyStatus {
    NonConsultancy = 0,
    Consultancy
}

export enum AccountAccess {
    SuperUsersOnly,
    AllAdmins
    
}


