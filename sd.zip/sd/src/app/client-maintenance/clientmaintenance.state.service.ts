import { Injectable } from '@angular/core';

import { Account, AssociatedCarrier } from './clientmaintenance.model';
@Injectable()
export class ClientMaintenaceState {
    private account: Account;
    // it contains the tempered new list
    private associatedCarriers: Array<AssociatedCarrier>;

    private editClient: boolean;
    private index:number;

    getAccount(): Account {
        return this.account;
    }

    setAccount(account: Account) {
        this.account = account;
    }

    getSelectedIndex():number {
        return this.index;
    }

    setSelectedIndex(index:number) {
        this.index = index;
    }



    setAssociatedCarriers(associatedCarriers: Array<AssociatedCarrier>) {
        this.associatedCarriers = associatedCarriers;
    }

    getAssociatedCarriers(): Array<AssociatedCarrier> {
        return this.associatedCarriers;
    }

    getEditClient() {
        return this.editClient;
    }

    setEditClient(editClient: boolean) {
        this.editClient = editClient;
    }
}