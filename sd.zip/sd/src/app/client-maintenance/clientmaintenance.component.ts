﻿import { Component, ViewChild, ElementRef, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import * as _ from "lodash";

import { ClientmaintenanceService } from './clientmaintenance.service';
import { ClientMaintenaceState } from './clientmaintenance.state.service';
import { CreateClientHelper } from './clientmaintenance.helper';
import { LoggedInUser } from '../shared/loggedInUser/LoggedInUser';
import { ClientService } from '../select-client/client.service';
import { LoaderService } from '../shared/loaderComponent/Loader.service';
import { SelectClientHelper } from '../select-client/select-client.helper';
import { ForbiddenComponent } from '../shared/forbidden/forbidden.component';
import {
  PartyInfo, PartyDetails, AssociatedCarrier, Account, ConsultancyStatus, AccountAccess,
  AssociationStatus
} from './clientmaintenance.model';
import { PageAccessHelper } from '../shared/page-access-levels/page-access-levels.helper';
import { ClientmaintenanceAccessLevels } from './clientmaintenance.access-levels';
declare var $: any;
@Component({
  selector: 'app-clientmaintenance',
  templateUrl: './clientmaintenance.component.html',
  styleUrls: ['./clientmaintenance.component.css'],
  providers: [ClientmaintenanceService, LoggedInUser, PageAccessHelper]
})


export class ClientMaintenanceComponent implements OnInit {

  value: string;
  searchText: string;
  searchCriteria: string;
  entityStatus: string;
  partyId: number;
  AccountId: number;
  message: string;
  selectedPartyIndex: number;
  importClientId: string;
  createButtonLoad = true;
  isModalHidden = false;
  isviewTable = false;
  loadData = false;
  editClient: boolean;
  saveSuccess = false;
  loadAdditonalData = false;
  isError: boolean;
  isSuccess: boolean;
  isSearchingClient: boolean;
  loggedInuserRank: number;
  clientSearchResult: Array<PartyInfo>;
  clientDropdown: Array<Account>;
  associatedCarriersList: Array<AssociatedCarrier>;
  account: Account;
  pageResults: Array<PartyInfo>;
  pageAccessLevels: ClientmaintenanceAccessLevels;
  regExp = ".{2,}";

  constructor(private _router: Router, private _clientmaintenanceService: ClientmaintenanceService, private _loggedInUser: LoggedInUser,
    private _clientMaintenaceState: ClientMaintenaceState, private _clientService: ClientService,
    private _loaderService: LoaderService, private _pageAccessHelper: PageAccessHelper) {
    this.pageAccessLevels = new ClientmaintenanceAccessLevels();
    this.pageResults = new Array<PartyInfo>();
    this.associatedCarriersList = new Array<AssociatedCarrier>();
    this.getPartyDropdown();
  }

  ngOnInit(): void {
    this._pageAccessHelper.getPageAccessLevelsDetails("client-maintenance", this.pageAccessLevels);
    this.isError = false;
    this.isSuccess = false;

  }

  checkAll(ev) {
    this.associatedCarriersList.forEach(x => x.IsDefault = ev.target.checked)
  }
  isAllChecked() {
    return this.associatedCarriersList.every(_ => _.IsDefault);
  }

  checkAllDel(ev) {
    this.associatedCarriersList.forEach(x => x.IsDelete = ev.target.checked)
  }
  isAllCheckedDel() {
    return this.associatedCarriersList.every(_ => _.IsDelete);
  }

  getSavedStatus() {
    this.isError = false;
    this.isSuccess = false;
    if(this._clientService.getRedirectToClientMaintenance()){
      this._clientService.setRedirectToClientMaintenance(false);
      // remove status from memory
      this._clientMaintenaceState.setAccount(undefined);
      this._clientMaintenaceState.setAssociatedCarriers(undefined);
    }else{
      if (this._clientMaintenaceState.getAccount() !== undefined) {
        this.associatedCarriersList = this._clientMaintenaceState.getAssociatedCarriers();
        this.editClient = this._clientMaintenaceState.getEditClient();
        this.loadData = this.loadAdditonalData = true;
        if(this._clientService.getCarriers())
        this._clientService.getCarriers().forEach((carrier) => {
          let index = this.associatedCarriersList.findIndex(car => car.WillisCode == carrier.WillisCode);
          if (index == -1) {
            this.associatedCarriersList
              .push(new AssociatedCarrier(carrier.CarrierId.toString(), carrier.LegalName, carrier.WillisCode,
                '', false, AssociationStatus.Added));
          }
        });
        this.associatedCarriersList.sort((a,b) => {
          if(a.LegalName.toLowerCase() < b.LegalName.toLowerCase())
          return -1;
          if(a.LegalName.toLowerCase() > b.LegalName.toLowerCase())
          return 1;
    
          return 0;
          
        });
        
        if (this._clientMaintenaceState.getSelectedIndex())
          this.selectedPartyIndex = this._clientMaintenaceState.getSelectedIndex();
        this.account = this._clientMaintenaceState.getAccount();
        // remove status from memory
        this._clientMaintenaceState.setAccount(undefined);
        this._clientMaintenaceState.setAssociatedCarriers(undefined);
      }
    } 
  }

  setSavedStatus() {
    this.isError = false;
    this.isSuccess = false;
    this._clientMaintenaceState.setAccount(this.account);
    this._clientMaintenaceState.setSelectedIndex(this.selectedPartyIndex);
    this._clientMaintenaceState.setAssociatedCarriers(this.associatedCarriersList);
    this._clientMaintenaceState.setEditClient(this.editClient);
  }

  cancel() {
    this.isSearchingClient = false;
    this.loadData = false;
    this.searchCriteria = "1";
    this.entityStatus = "1";
    this.searchText = null;
    this.editClient = false;
    this.saveSuccess = false;
    this.loadAdditonalData = false;
    this.isError = false;
    this.isSuccess = false;
    this.isModalHidden = false;
    this.isviewTable = false;
    this.loadAdditonalData = false;
    this.pageResults = new Array<PartyInfo>();
    this.associatedCarriersList = new Array<AssociatedCarrier>();
    this.importClientId = null;
    this.selectedPartyIndex = null;
    //this.account = new Account('', '', 0, '', ConsultancyStatus.NonConsultancy, true, AccountAccess.SuperUsersOnly, []);

    this.account = (this._loggedInUser.UserRole !== undefined && this._loggedInUser.UserRole.Rank === 1) ? new Account('', '', 0, '', '', ConsultancyStatus.NonConsultancy, false, AccountAccess.SuperUsersOnly, [])
      :
      new Account('', '', 0, '', '', ConsultancyStatus.NonConsultancy, false, AccountAccess.AllAdmins, []);
  }

  resetSearchModal() {
    this.searchCriteria = "1";
    this.entityStatus = "1";
    this.searchText = null;
    this.saveSuccess = false;
  }

  getPageResult(event: any) {
    setTimeout(() => this.pageResults = event, 0);
  }

  loadModal() {
    this.cancel();
    this.isModalHidden = true;
    this.loadData = false;
    this.saveSuccess = false;
    this.loadAdditonalData = false;
  }

  loadEdit() {
    this.createButtonLoad = false;
    this.saveSuccess = false;
  }

  loadCreate() {
    this.createButtonLoad = true;
    this.loadData = false;
    this.saveSuccess = false;
  }

  redirectToCarrierSearch() {
    this.setSavedStatus();
    var acc=(this._loggedInUser.UserRole !== undefined && this._loggedInUser.UserRole.Rank === 1) ? new Account('', '', 0, '', '', ConsultancyStatus.NonConsultancy, false, AccountAccess.SuperUsersOnly, [])
    :
    new Account('', '', 0, '', '', ConsultancyStatus.NonConsultancy, false, AccountAccess.AllAdmins, []);
    this._clientService.setSelectedAdminAccount(SelectClientHelper.mapToAccount(acc));
    // flag will help to show redirect button on carrier search page for client mainetnance
    this._clientService.setRedirectToClientMaintenance(true);
    this._clientService.setRedirectFromAdmin(true);
    this._clientService.setRedirectToCarrierFavorites(false);
    this._clientService.setRedirectToCarrierFavoritesAdmin(false);
    this._router.navigate(['./carrier-search']);
  }

  showTable() {
    this.pageResults = new Array<PartyInfo>();
    this.isviewTable = false;
    this.isSearchingClient = true;
    this._clientmaintenanceService.GetListofSubscription(this.searchCriteria, this.searchText).subscribe((result) => {
      this.clientSearchResult = result;
      this.isSearchingClient = false;
      this.isviewTable = true;
      this.saveSuccess = false;
      this.isError = false;
      this.isSuccess = false;
    }, (error) => {
      this.isSearchingClient = false;
      this.showError('Not able to fetch client list');
    });
  }

  getSelectedClientAssociatedCarriers() {
    if (this.importClientId !== undefined && this.importClientId !== null && this.importClientId !== '') {
      this._clientmaintenanceService.GetAssociatedCarriers(this.importClientId, AssociationStatus.Added).subscribe((result) => {
        this.associatedCarriersList = result;
        this.associatedCarriersList.sort((a,b) => {
          if(a.LegalName.toLowerCase() < b.LegalName.toLowerCase())
          return -1;
          if(a.LegalName.toLowerCase() > b.LegalName.toLowerCase())
          return 1;
    
          return 0;
          
        });
        // set status as removed for old list
        this.account.AssociatedCarriers
          .forEach((associatedCarrier) => associatedCarrier.State = AssociationStatus.Removed);

        // set status as added for new list
        this.associatedCarriersList.forEach((carrier) => {
          let oldIndex = this.findAccountAssociatedCarriersIndex(carrier.CarrierId);
          if (oldIndex === -1)
            carrier.State = AssociationStatus.Added;
          else {
            let oldCarrier: AssociatedCarrier = this.account.AssociatedCarriers[oldIndex];
            carrier.State
              = (carrier.IsDefault === oldCarrier.IsDefault ? AssociationStatus.None : AssociationStatus.Modified);
          }
        });
        this.saveSuccess = false;
      });
    } else {
      this.showError('Select Client')
    }
  }

  loadClientData() {
    if (this.selectedPartyIndex !== undefined && this.selectedPartyIndex !== null && this.selectedPartyIndex != -1) {
      this._loaderService.show();
      this.loadAdditonalData = true;
      this.account = this.clientDropdown[this.selectedPartyIndex];
      this._clientmaintenanceService.GetAssociatedCarriers(this.account.Id, AssociationStatus.None)
        .subscribe((result) => {
          this.account.AssociatedCarriers = result;
          this.associatedCarriersList = _.cloneDeep(result);
          this._loaderService.hide();
        });
    } else {
      this.loadAdditonalData = false;
      this.showError('Select Client')
    }

  }

  loadFields(client: PartyInfo) {
    this.isError = false;
    this.isSuccess = false;
    this._clientmaintenanceService.checkPartyAvailability(client.EncryptedPartyId)
      .subscribe((result) => {
        if (!result) {
          this.account.setPartyId(client.PartyId);
          this.account.setPartyName(client.Name);
          this.account.setConsultancyStatus(ConsultancyStatus.NonConsultancy);
          this.editClient = false;
          this.loadData = true;
          this.loadAdditonalData = true;
        } else {
          this.showError('Client already added')
        }
      })
  }

  editFields() {
    this.isError = false;
    this.isSuccess = false;
    this.getPartyDropdown();
    this.cancel();
    this.editClient = true;
    this.loadData = true;
  }

  getPartyDropdown() {
    this.isError = false;
    this.isSuccess = false;
    this._loaderService.show();
    this._clientmaintenanceService.getPartyDropdown()
      .subscribe((result) => {
        var msdbuDropdown;
        var msdDropdown;
        this.clientDropdown = result;
        msdDropdown = this.clientDropdown.filter(client => client.AccessLevel == AccountAccess.AllAdmins);
        msdbuDropdown = this.clientDropdown.filter(client => client.AccessLevel == AccountAccess.AllAdmins && client.ConsultancyStatus == ConsultancyStatus.NonConsultancy);
        if (this._loggedInUser.getUserRoleCode() === 'MSDAdmin') {
          this.clientDropdown = msdDropdown;
        }
        if (this._loggedInUser.getUserRoleCode() === 'MSDBUAdmin') {
          this.clientDropdown = msdbuDropdown;
        }
        this.getSavedStatus();
        this._loaderService.hide();
      });
  }

  // handleError(error) {
  //   this.showError('Some Error Occured, please report to support team along with steps to reproduce');
  // }
  handleError(error) {
    this.isSuccess = false;
    this.isError = true;
    this.isSuccess = false;
    setTimeout(() => {
      this.isError = false;
    }, 3000);
    //error.status = 412;
    if (error.status === 412) {
      this.showError('Input Output Validation Error. Please enter details again. ');
    }
    else if (error.status === 422) {
      this.showError('Business Validation Error. Please try again');
    }
    else if (error.status === 500) {
      this.showError('500 Internal Server Error. Please try again');
    }
    else {
      this.showError('Server Error. Please try again');
    }
  }

  showSuccess(message: string) {
    this.message = 'Client Details saved successfully';
    this.saveSuccess = true;
    this.isSuccess = true;
    setTimeout(() => {
      this.isSuccess = false;
    }, 3000);
    this.isError = false;
  }

  showError(message: string) {
    //this.cancel();
    this.isSuccess = false;
    this.isError = true;
    setTimeout(() => {
      this.isError = false;
    }, 3000);
    this.message = message;
    this._loaderService.hide();
  }

  // Save Record using http request
  saverecord() {
    this.isError = false;
    this.isSuccess = false;
    this.processAssociatedCarriers();
    // this._loaderService.show();
    this.importClientId = null;
    if (this.account.Id) {
      this.updateAccount();
    } else {
      this.createAccount();
    }
    //document.body.scrollTop = 0;
    //document.documentElement.scrollTop = 0;


  }

  updateAccount() {
    this._clientmaintenanceService.updateAccount(this.account)
      .subscribe(() => {
        this.resetAccountAssocaitedCarrierList();
        this.showSuccess('Update user Completed');
        this._loaderService.hide();
      }, (error) => this.handleError(error));
  }

  createAccount() {
    this._clientmaintenanceService.createAccount(this.account)
        .subscribe((result) => {
            this.account.Id = result.text();
        this.resetAccountAssocaitedCarrierList();
        this.showSuccess('Create user Completed');
        this._loaderService.hide();
      }, (error) => this.handleError(error));
  }

  findAccountAssociatedCarriersIndex(carrierId: string) {
    return this.account.AssociatedCarriers.findIndex((carrier) => carrier.CarrierId === carrierId);
  }

  findAssociatedCarriersListIndex(carrierId: string) {
    return this.associatedCarriersList.findIndex((carrier) => carrier.CarrierId === carrierId);
  }

  /*
  * Process Associated Carriers List
  */
  processAssociatedCarriers() {
    this.isError = false;
    this.isSuccess = false;
    this.associatedCarriersList.forEach((carrier) => {
      let oldIndex = this.findAccountAssociatedCarriersIndex(carrier.CarrierId);
      if (oldIndex !== -1) {
        let oldCarrier = this.account.AssociatedCarriers[oldIndex];
        if (carrier.IsDelete)
          carrier.State = AssociationStatus.Removed
        else if (oldCarrier.Comments !== carrier.Comments || oldCarrier.IsDefault !== carrier.IsDefault)
          carrier.State = AssociationStatus.Modified;

        //else part for None
        this.account.AssociatedCarriers[oldIndex] = carrier;
      } else if (oldIndex === -1 && !carrier.IsDelete) {
        carrier.State = AssociationStatus.Added;
        this.account.AssociatedCarriers.push(carrier);
      }
    });
  }


  /*
  *  Reset Associated Carrier List after save and update
  */
  resetAccountAssocaitedCarrierList() {
    this.isError = false;
    this.isSuccess = false;
    this.account.AssociatedCarriers = this.account.AssociatedCarriers
      .filter((carrier) => carrier.State !== AssociationStatus.Removed);

    this.account.AssociatedCarriers
      .forEach((carrier) => carrier.State = AssociationStatus.None);
    this.associatedCarriersList = _.cloneDeep(this.account.AssociatedCarriers);
    this.associatedCarriersList.sort((a,b) => {
      if(a.LegalName.toLowerCase() < b.LegalName.toLowerCase())
      return -1;
      if(a.LegalName.toLowerCase() > b.LegalName.toLowerCase())
      return 1;

      return 0;
      
    });
  }
  
  searchCriteriaChange(searchCriteria) {
    if (searchCriteria == '1') {
      this.regExp = ".{2,}";
    }
    if (searchCriteria == '2') {
      this.regExp = ".{1,}";
    }
  }
}
