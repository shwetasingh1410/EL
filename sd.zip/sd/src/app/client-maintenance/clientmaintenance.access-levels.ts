﻿import { IPageAccessLevels } from '../shared/page-access-levels/page-access-levels'

export class ClientmaintenanceAccessLevels implements IPageAccessLevels {
    isAdminOnlyFeatureAvailable: boolean = false;
    isAssociateAllCarriersYesAvailable: boolean = false;
    isChooseClientAvailable: boolean = false;
    isConsultancyAccessible: boolean = false;
}