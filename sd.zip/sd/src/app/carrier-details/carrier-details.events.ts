import { Injectable, EventEmitter } from '@angular/core';

@Injectable()
export class CarrierDetailsEvents {
    CarrierDetailUpdateEvent: EventEmitter<any> = new EventEmitter();
}