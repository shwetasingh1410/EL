import { IPageAccessLevels } from '../shared/page-access-levels/page-access-levels'

export class CarrierDetailsAccessLevels implements IPageAccessLevels {
    IsGeneralHyperlinkAvailable: boolean = true;
   
}