import { Injectable, EventEmitter } from '@angular/core';

@Injectable()
export class FinancialsEvents {
    FinancialsUpdateEvent: EventEmitter<any> = new EventEmitter();
}