﻿import { Component, OnInit, Input, AfterContentInit, ViewChild } from '@angular/core';
import { SafeUrl, DomSanitizer } from '@angular/platform-browser';
import { LoaderService } from '../../shared/loaderComponent/Loader.service';
import { CarrierDetailsService } from '../carrier-details.service';
import { FinacialService } from './financials.service';
import { FinancialsEvents } from './financials.events';
import { Settings } from '../../shared/settings/settings.service';
import { ClientService } from '../../select-client/client.service';
import { Carrier } from '../../carrier-search/carriersearch.model';
import { CoolSessionStorage } from 'angular2-cool-storage';
import { GeneralService } from 'app/carrier-details/general/general.service';
declare var $: any;
import { carrierGeneralInfo } from '../general/general.model';
@Component({
  selector: 'app-financials',
  templateUrl: './financials.component.html',
  styleUrls: ['./financials.component.css'],
  providers: [FinacialService, GeneralService]
})

export class FinancialsComponent implements OnInit {
  financialsDisclaimerText: string
  reportUrl: SafeUrl;
  pdfUrl: SafeUrl;
  excelUrl: SafeUrl;
  selectedReport: string;
  selectedIndex: number;
  selectedHeight: number;
  selectedWidth: string;
  summaryPdfUrl: SafeUrl;
  selectedCarrier;
  summaryPdfIndicator: boolean = false;
  localStorage: CoolSessionStorage;
  private _subscribe;
  carrierGeneralInfo: carrierGeneralInfo;

  // disclaimerText: string;
  @ViewChild('disfinacialclaimerText') disfinacialclaimerText;
  subReports: Array<any> = [{
    reportSubType: 'Assets',
    name: 'Balance Sheet - Assets',
    height: 900,
    width: '100'
  },
  {
    reportSubType: 'Liabilities',
    name: 'Balance Sheet - Liabilities',
    height: 1000,
    width: '105'
  },
  {
    reportSubType: 'IncomeStatement',
    name: 'Income Statement',
    height: 1300,
    width: '106'
  },
  {
    reportSubType: 'Ratios',
    name: 'Ratios',
    height: 1800,
    width: '100'
  }];

  constructor(private _generalService: GeneralService, private _loaderService: LoaderService, private _carrierDetailsService: CarrierDetailsService, private _sanitizer: DomSanitizer,
    private _finacialService: FinacialService, private _settings: Settings, private _clientService: ClientService, localStorage: CoolSessionStorage, private _financialsEvents: FinancialsEvents) {

    this.exportToPdf;
    this.exportSummaryToPdf;
    this.localStorage = localStorage;
    this.financialsDisclaimerText = "The information compiled in this report by Willis Towers Watson is compiled from third party sources we consider to be reliable. However we do not guarantee and are not responsible for its accuracy or completeness and no warranty or representation of accuracy or completeness is given. We do not offer advice in relation to tax, accounting, regulatory, legal or investment matters and you must take separate advice as you consider necessary regarding such matters. This report is not prepared for and should not be construed as providing investment advice or services. It speaks only as to the date on which it was created and we shall have no obligation to update or amend. Willis Towers Watson does not guarantee or otherwise warrant the solvency of any insurer. Willis Towers Watson assumes no responsibility or duty in tort, contract or otherwise to any third party in respect of this document. Please note that this report is confidential and not for onward dissemination. "
  }

  ngOnInit() {
    this._subscribe = this._financialsEvents.FinancialsUpdateEvent.subscribe(
      (showMenu) => {
        this.ngOnInit();
        this._subscribe.unsubscribe();
      }
    );
    this.formReportUrl(0);
    this.exportToPdf();
    this.exportSummaryToPdf();
    this._loaderService.show();
    this.GetDisclaimer();
    // this._finacialService.GetDisclaimer()
    //   .subscribe((result) => {
    //     this.disclaimerText.nativeElement.innerHTML = result;
    //   });
    this.selectedCarrier = this.localStorage.getObject('carriers');
    // this.summaryPdfIndicator = this._carrierDetailsService.hideSummaryPdf(this.selectedCarrier.CompanyType);
    this.companyTypeValue();

  }

  companyTypeValue() {
    this._generalService.GetCarrierGeneralInfo(this.selectedCarrier.WillisCode, new Date().getFullYear())
      .subscribe(CarrierGeneralInfoResult => {
        if (CarrierGeneralInfoResult) {
          this.carrierGeneralInfo = CarrierGeneralInfoResult;
          this._carrierDetailsService.setCompanyType(this.carrierGeneralInfo.carrierContactDetails.type)
          this.summaryPdfIndicator = this._carrierDetailsService.hideSummaryPdf(this.carrierGeneralInfo.carrierContactDetails.type);

        }
      })
  }



  GetDisclaimer() {

    this._finacialService.GetDisclaimer()
      .subscribe((result) => {
        this.disfinacialclaimerText.nativeElement.innerHTML = result;
        $('#disfinacialclaimerText a').attr('target', '_blank');
        setTimeout(() => {
          this._loaderService.hide();
        }, 5000);



      });
  }

  formReportUrl(index: any) {
    this.selectedIndex = index;
    this.selectedReport = this.subReports[index].name;
    this.selectedHeight = this.subReports[index].height;
    this.selectedWidth = this.subReports[index].width;
    this.selectedWidth = this.selectedWidth.concat('%');

    this._carrierDetailsService.getReportsUrl(this._carrierDetailsService.getReportUrl(), 'Financials|reportSubType=' + this.subReports[index].reportSubType)
      .subscribe((result) => {

        result = this._settings.getReportsUrl() + result.substring(4);
        this.reportUrl = this._sanitizer.bypassSecurityTrustResourceUrl(result);
      }, (error) => { });
  }

  exportToPdf() {
    this._carrierDetailsService.getReportsUrl(this._carrierDetailsService.getPdfUrl(), '')
      .subscribe((result) => {

        this.pdfUrl = this._settings.getReportsUrl() + result.substring(4);
      }, (error) => { });

    return this.pdfUrl;
  }

  exportToExcel() {
    this._carrierDetailsService.getReportsUrl(this._carrierDetailsService.getExcelUrl(), '')
      .subscribe((result) => {
        result = this._settings.getReportsUrl() + result.substring(4);
        this.excelUrl = this._sanitizer.bypassSecurityTrustResourceUrl(result);
      }, (error) => { });

  }


  exportSummaryToPdf() {
    this._carrierDetailsService.getReportsUrl(this._carrierDetailsService.getSummaryPdfUrl(), '')
      .subscribe((result) => {
        this.summaryPdfUrl = this._settings.getReportsUrl() + result.substring(4);
      }, (error) => { });
    return this.summaryPdfUrl;
  }
}

