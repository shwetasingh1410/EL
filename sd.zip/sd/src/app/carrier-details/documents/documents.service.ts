import { Injectable } from '@angular/core';
import { Http, RequestOptions, Headers,ResponseContentType } from '@angular/http';
import { Observable } from 'rxjs';
import { DocumentPost } from './documents.component'
import { Settings } from '../../shared/settings/settings.service';

@Injectable()
export class DocumentService {
    constructor(private _http: Http, private _settings: Settings) { }

    GetCarrierDocuments(CompanyCode:string,ClientId): Observable<any> {

            let headers = new Headers();
            headers.append('Content-Type', 'application/json');
            let options = new RequestOptions({ headers: headers });
            
            return this._http.post(this._settings.getDocumentApiUrl() + 'api/documents/carrier-documents',
                JSON.stringify({
                    'CompanyCode': CompanyCode,
                    'ClientId':ClientId,
                    'Called':'Documents'
                }), options).map((response) => response.json());
    }

    GetDownloadedDocumentInfo(documentId): Observable<any> {
        return this._http.get(this._settings.getDocumentApiUrl() + 'api/documents/carrierDocument/'+documentId)
            .map((response) => response.json());
    }

    GetExportDocument(DocumentDetails:Array<DocumentPost>): Observable<any> {
                    let headers = new Headers();
                    headers.append('Content-Type', 'application/json');
                    let options = new RequestOptions({ headers: headers});
                    
                    return this._http.post(this._settings.getReportsUrl()+'documents/merge/view-mergedpdf',
                        JSON.stringify({
        "ConvertDocumentParams": { "DocumentDetails" : DocumentDetails}
                        }), options).map((response) => { return response.json()
                        });
            }

            downloadReport(folderName : string) {
                window.open(this._settings.getReportsUrl()+'documents/merge/download-mergedpdf/'+folderName);
            } 
            
    
}