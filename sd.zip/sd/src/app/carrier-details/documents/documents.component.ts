import { Component, OnInit } from '@angular/core';
import { ClientService } from '../../select-client/client.service';
import { DocumentService } from './documents.service';
import { DocumentsEvents } from './documents.events';
import { Carrier } from '../../carrier-search/carriersearch.model';
import { DocumentsPipe,DateFormatPipe } from './documents.pipe';
import * as FileSaver  from 'file-saver';
import { CoolSessionStorage } from 'angular2-cool-storage';
import { Router, ActivatedRoute } from '@angular/router';
import { CarrierDetailsService } from '../carrier-details.service';
import { Settings } from '../../shared/settings/settings.service';

@Component({
  selector: 'app-documents',
  templateUrl: './documents.component.html',
  styleUrls: ['./documents.component.css'],
  providers:[DocumentService]
})
export class DocumentsComponent implements OnInit {

  selectedCarrier;
  carrierDocs;
  clientId;
  selectedAccountId;
  downloaded;
  localStorage:CoolSessionStorage;
  sub;
  exportArray:Array<DocumentPost>;
  pdfUrl:string;
  private _subscribe;

  constructor(private _settings:Settings,private _carrierDetailsService:CarrierDetailsService,private _route:ActivatedRoute,private _clientService:ClientService,private _documentsService:DocumentService,localStorage:CoolSessionStorage,private _documentsEvents:DocumentsEvents) { 
    this.localStorage=localStorage;
    this.exportArray=[];
  }

  ngOnInit() {
    this._subscribe=this._documentsEvents.DocumentsUpdateEvent.subscribe(
      (showMenu) => {
        this.ngOnInit();
        this._subscribe.unsubscribe();
      }
    );
    this.exportToPdf();
    if(this.localStorage.getObject('carriers')){
      this.selectedCarrier=this.localStorage.getObject('carriers');
      this.selectedAccountId=this._clientService.getAccountId();  
    }
    this.getCarrierDocs();
  }

  exportToPdf() {
    this._carrierDetailsService.getReportsUrl(this._carrierDetailsService.getPdfUrl(), '')
        .subscribe((result) => {
            this.pdfUrl = this._settings.getReportsUrl() + result.substring(4);
        }, (error) => { });

    return this.pdfUrl;
}

  getCarrierDocs() {
    if(this.selectedCarrier && this.selectedAccountId){
      if(this.selectedCarrier.WillisCode){
        this._documentsService.GetCarrierDocuments(this.selectedCarrier.WillisCode, this.selectedAccountId).subscribe(result => {
          if(result){
            this.carrierDocs=result;
            this.carrierDocs.forEach(carrier => {
              if(carrier.CreatedOn){
              var dateTransform = carrier.CreatedOn;
              dateTransform=dateTransform.substring(0,9);
              carrier.CreatedOn=new Date(dateTransform);
              }            
            });
          }
        })
      }
    }
  }

  getDate(date){
    var day=date.substring(0,2);
    var month=+date.substring(3,5);
    var year=date.substring(6,10);
    month=month-1;
    var datum= new Date(year,month,day);
    return datum;
  }

  downloadFile(doc) {
    if(doc){
      if(doc.DocumentName=='Non-Narrative Fact Sheet - current'){
        document.getElementById("factsheet").click();
      }else{
        this._documentsService.GetDownloadedDocumentInfo(doc.DocumentId).subscribe(result => {
          this.fetchFile(result);
        })
      }
      
    }

  }

fetchFile(data){
  var content=this.base64ToArrayBuffer(data.Content);
  var blob = new Blob([content], { type: data.ContentType});
  var filename = data.Title;
  var url= window.URL.createObjectURL(blob);
  FileSaver.saveAs(blob, filename);
}

 base64ToArrayBuffer(base64) {
  var binaryString =  window.atob(base64);
  var binaryLen = binaryString.length;
  var bytes = new Uint8Array(binaryLen);
  for (var i = 0; i < binaryLen; i++)        {
      var ascii = binaryString.charCodeAt(i);
      bytes[i] = ascii;
  }
  return bytes;
}

export() {
  if(this.exportArray)
  if(this.exportArray.length>0)
  this._documentsService.GetExportDocument(this.exportArray).subscribe(result => {
    var folderName = result;
    this._documentsService.downloadReport(folderName);
  })
}

onCheckboxChange(doc:any,$event) {
  if($event){
    if(this.exportArray){
      if(this.exportArray.length==0){
        var docName=doc.DocumentName;
        var docId=doc.DocumentId;
        var postDoc:DocumentPost=new DocumentPost(docName,docId);
        this.exportArray.push(postDoc);
      }
      else if(this.exportArray.length>0){
        let index=this.exportArray.findIndex(exp=>exp.DocumentName==doc.DocumentName);
        if(index==-1) {
          var docName=doc.DocumentName;
          var docId=doc.DocumentId;
          var postDoc:DocumentPost=new DocumentPost(docName,docId);
          this.exportArray.push(postDoc);
        }
      }
    }
  }else{
    let index=this.exportArray.findIndex(exp=>exp.DocumentName==doc.DocumentName);
    if(index != -1) {
      this.exportArray.splice(index,1);
    }
  }
}

}

export class DocumentPost {
  DocumentName:string;
  DocumentBlobId:string;

  constructor(docName,docId) {
    this.DocumentName=docName;
    this.DocumentBlobId=docId;
  }
}

