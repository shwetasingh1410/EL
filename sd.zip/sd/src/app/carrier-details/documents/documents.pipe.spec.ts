import { DocumentsPipe } from './documents.pipe';

describe('DocumentsPipe', () => {
  it('create an instance', () => {
    const pipe = new DocumentsPipe();
    expect(pipe).toBeTruthy();
  });
});
