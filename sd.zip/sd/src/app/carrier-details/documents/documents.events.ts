import { Injectable, EventEmitter } from '@angular/core';

@Injectable()
export class DocumentsEvents {
    DocumentsUpdateEvent: EventEmitter<any> = new EventEmitter();
}