import { Component, OnInit } from '@angular/core';
import { Router,ActivatedRoute } from '@angular/router';
import { CoolSessionStorage } from 'angular2-cool-storage';
import { ClientService } from '../../select-client/client.service';
@Component({
  selector: 'app-ownership',
  templateUrl: './ownership.component.html',
  styleUrls: ['./ownership.component.css']
})
export class OwnershipComponent implements OnInit {

  selectedCarrier;
  selectedAccount;
  groupcode;
  sub;
  
  constructor(private localStorage:CoolSessionStorage,private _route:ActivatedRoute,private _router:Router,private _clientService:ClientService) { }

  ngOnInit() {
    this.sub = this._route.params.subscribe(params => {
      this.groupcode = params['groupCode'];
      this.Ownership(this.groupcode);
    })
  }

  Ownership(groupCode) {
    this.selectedAccount=this.localStorage.getObject('account')
    this._clientService.setOwnership(groupCode);
    this._router.navigateByUrl('/carrier-search/client/'+this.selectedAccount.AccountId);
  }

}
