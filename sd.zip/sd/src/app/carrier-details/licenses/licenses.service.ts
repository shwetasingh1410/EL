import { Injectable } from '@angular/core';
import { Http, RequestOptions } from '@angular/http';
import { Observable } from 'rxjs';
import 'rxjs/add/operator/map';

import { environment } from '../../../environments/environment';
import { licenseBusinessType, licenseState } from './licenses.model';
import { Settings } from '../../shared/settings/settings.service';
import { LicensesHelper } from './licenses.helper';
import { LoggedInUser } from '../../shared/loggedInUser/LoggedInUser';

@Injectable()

export class LicensesService {
    constructor(private _http: Http, private _settings: Settings,  private _loggedInUser: LoggedInUser) { }

    // GetLicenseTypes(carrierId: number, countryCode: string): Observable<licenseBusinessType> {
    //     return this._http.get(this._settings.getApiUrl() + 'api/carriers/' + carrierId + '/licenses/country/' + countryCode + '/types')
    //         .map((response) => {
    //             let licenseResult: licenseBusinessType;
    //             licenseResult = LicensesHelper.mapToLicenseType(response.json());
    //             return licenseResult;
    //         })
    // }
    // GetLicenseGrades(carrierId: number, countryCode: string): Observable<licenseState> {
    //     return this._http.get(this._settings.getApiUrl() + 'api/carriers/' + carrierId + '/licenses/country/' + countryCode + '/grades')
    //         .map((response) => {
    //             let licenseGradeResult: licenseState;
    //             licenseGradeResult = LicensesHelper.mapToLicenseGradeDetails(response.json());
    //             return licenseGradeResult;
    //         })
    // }
   

    GetLicenseTypes(carrierId: number, countryCode: string ): Observable<Array<licenseBusinessType>> {
        return this._http.get(this._settings.getApiUrl() + 'api/carriers/'+carrierId+'/licenses/countries/'+countryCode+'/types')
        .map((response) => {
            let licenseResult: Array<licenseBusinessType> = new Array<licenseBusinessType>();
            response.json().forEach((licenses) => {
                licenseResult.push(LicensesHelper.mapToLicenseType(licenses))
            });
            return licenseResult;  
        });
    }
    


    GetLicenseGrades(carrierId: number, countryCode: string ): Observable<Array<licenseState>> {
        return this._http.get(this._settings.getApiUrl() + 'api/carriers/'+carrierId+'/licenses/countries/'+countryCode+'/grades')
        .map((response) => {
            let licenseStateResult: Array<licenseState> = new Array<licenseState>();
            response.json().forEach((licensesGrade) => {
                licenseStateResult.push(LicensesHelper.mapToLicenseGradeDetails(licensesGrade))
            });
            return licenseStateResult;
        });
    }

    getLicensesExcelReport(url: string, carrierid: number, companyCode: string) {
        let carriers : Array<any> = new Array<any>();        
        carriers.push(carrierid);
        return this._http.post(url,
            JSON.stringify({ 'CarrierId': carriers,'CompanyCode' : companyCode, 'UserId': this._loggedInUser.getUserId() }))
            .map((response) => { return response.json(); });
    }

    getLicenseReportsURL() {
        return this._settings.getReportsUrl() + 'reports/carrier/params/'
    }

    downloadLicenseExcelReport(folderName : string) {
        window.open(this._settings.getReportsUrl() + 'reports/carrier/download-file/'+folderName);
    }
}