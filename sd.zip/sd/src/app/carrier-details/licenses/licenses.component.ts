﻿import { Component, OnInit, ViewChild } from '@angular/core';
import { Observable } from 'rxjs';
import { Router } from '@angular/router';
import { SafeUrl, DomSanitizer } from '@angular/platform-browser';
import { LoaderService } from '../../shared/loaderComponent/Loader.service';
import { RatingAgency } from '../../disclaimers/disclaimers.model';
import { LicensesService } from './licenses.service';
import { LicensesEvents } from './licenses.events';
import { ClientService } from '../../select-client/client.service';
import { Carrier, Country, BusinessUnit } from '../../carrier-search/carriersearch.model';
import { CarrierDetailsService } from '../carrier-details.service';
import { licenseBusinessType, licenseState, disclaimers } from './licenses.model';
import { Settings } from '../../shared/settings/settings.service';
import { CoolSessionStorage } from 'angular2-cool-storage';
import { WTWDisclaimer, RatingAgencyDisclaimer } from '../../disclaimers/disclaimers.model';
import { DisclaimersService } from '../../disclaimers/disclaimers.service';
import { FinacialService } from '../financials/financials.service';
import * as html2canvas from 'html2canvas';
import * as jsPDF from 'jspdf';
declare global {
  interface Window { onePageCanvas: any; }
}
window.onePageCanvas = window.onePageCanvas || {};
declare var onePageCanvas: any;
declare var $: any;
@Component({
  selector: 'app-licenses',
  templateUrl: './licenses.component.html',
  styleUrls: ['./licenses.component.css'],
  providers: [LicensesService, DisclaimersService, FinacialService]
})

export class LicensesComponent implements OnInit {
  @ViewChild('disclaimerText') disclaimerText;
  isCanada: boolean = false;
  result: Array<RatingAgency>;
  amBestRatingAgencyID: any;
  spRatingAgencyID: any;
  moodeysRatingAgencyID: any;
  fitchRatingAgencyID: any;
  dateToday: Date;
  wtwDisclaimer: WTWDisclaimer;
  ratingAgencyDisclaimerResult: Array<RatingAgencyDisclaimer>;
  selectedCarrier;
  countryName: string;
  carrierId: number;
  countryCode: string;
  WillisCode: string;
  description: string;
  licenseGradeID: string;
  website: string;
  countrySubName: string;
  countrySubCode: string;
  isState: boolean;
  licenseGradeId: number;
  businessTypeId: number;
  isLicensesSection = false;
  mainSection = true;
  licensevalue: licenseState;
  pagevalue: licenseBusinessType;
  licenseTypesResult: Array<licenseBusinessType>;
  licenseGradesResult: Array<licenseState>;
  territoryLicenseGradesResult: Array<licenseState>
  stateLicenseGradesResult: Array<licenseState>
  licenseID: number;
  websiteLink: string;
  licenseDisclaimerText: string;
  localStorage: CoolSessionStorage;
  licenseUrl: any;
  disclaimers: disclaimers;
  private _subscribe;
  ios: boolean;
  constructor(private _loaderService: LoaderService, private _licensesService: LicensesService, private _clientService: ClientService,
    private _router: Router, private _sanitizer: DomSanitizer, private _settings: Settings, localStorage: CoolSessionStorage,
    private _disclaimerService: DisclaimersService, private _finacialService: FinacialService, private _licensesEvents: LicensesEvents) {
    this.stateLicenseGradesResult = [];
    this.territoryLicenseGradesResult = [];
    this.localStorage = localStorage;
    this.ios =  false;
  }

  ngOnInit() {
    this._subscribe = this._licensesEvents.LicensesUpdateEvent.subscribe(
      (showMenu) => {
        this.ngOnInit();
        this._subscribe.unsubscribe();
      }
    );
    this.checkOS();
    this.isLicensesSection = false;
    this.mainSection = true;
    this._loaderService.show();
    this.getDisclaimers();
    this.selectedCarrier = this.localStorage.getObject('carriers');
    this.carrierId = this.selectedCarrier.CarrierId;
    this.countryName = this.selectedCarrier.Country;
    if (this.selectedCarrier.Country == 'United States') {
      this.getLicenseTypes(this.carrierId, 'US');
      this.getLicenseGrades(this.carrierId, 'US');
    }
    else if (this.selectedCarrier.Country == 'Canada') {
      this.getLicenseTypes(this.carrierId, 'CA');
      this.getLicenseGrades(this.carrierId, 'CA');
    }
    else {
      this.getLicenseTypes(this.carrierId, 'MP');
      this.getLicenseGrades(this.carrierId, 'MP');
    }
    this.getLicenseDisclaimerText();
    this.dateToday = new Date();
    this.ratingAgencyDisclaimerResult = [];
    this.disclaimers = new disclaimers("", "", "", "", "");

    this.licenseUrl = this._settings.getLicensesUrl();
    this._loaderService.hide();
  }
  checkOS() {
    // var userAgentMob = navigator.userAgent || navigator.vendor;
    // if (/iPad|iPhone|iPod/.test(userAgentMob)) {
    // if( /iPhone|iPad|iPod/i.test(navigator.userAgent) ) {
    let operatingSystem = !!navigator.platform && /iPad|iPhone|iPod/.test(navigator.platform);
    let xx = /(iPad|iPhone|iPod)/g.test(navigator.userAgent);
    if (operatingSystem == true || xx == true) {
      this.ios == true;
    }
    else {
      this.ios == false;
    }
  }
  getLicenseTypes(carrierId: number, countryCode: string) {
    this.countryCode = countryCode;
    this.selectedCarrier = this.localStorage.getObject('carriers');
    this.carrierId = this.selectedCarrier.CarrierId;
    this._licensesService.GetLicenseTypes(carrierId, countryCode)
      .subscribe(licenseTypesResult => {
        this.licenseTypesResult = licenseTypesResult;
        let businessTypes: Array<number> = new Array<number>();
        this.licenseTypesResult.forEach((item) =>
          businessTypes.push(item.BusinessTypeId)
        );
        businessTypes.sort((a, b) => {
          if (a < b)
            return -1;
          if (a > b)
            return 1;
          return 0;

        });
        this.businessTypeId = businessTypes[businessTypes.length - 1];
      })
  }
  getLicenseGrades(carrierId: number, countryCode: string) {
    this.countryCode = countryCode;
    this.selectedCarrier = this.localStorage.getObject('carriers');
    this.carrierId = this.selectedCarrier.CarrierId;
    this._licensesService.GetLicenseGrades(this.carrierId, countryCode)
      .subscribe(licenseGradesResult => {
        this.licenseGradesResult = licenseGradesResult;
        for (var i in this.licenseGradesResult) {

          let IsState = this.licenseGradesResult[i].IsState;
          if (IsState == true) {
            this.stateLicenseGradesResult.push(this.licenseGradesResult[i]);

          }
          else this.territoryLicenseGradesResult.push(this.licenseGradesResult[i]);

        }
        this.stateLicenseGradesResult = this.stateLicenseGradesResult;
        this.territoryLicenseGradesResult = this.territoryLicenseGradesResult;
      })
  }

  openLicenseSection() {
    this.isLicensesSection = true;
    this.mainSection = false;
  }

  showView(index: number) {
    this.licensevalue = this.licenseGradesResult[index];
    this.website = this.licensevalue.Website;
    this.websiteLink = 'http://' + this.website;
  }

  showViewStates(index: number) {
    this.licensevalue = this.stateLicenseGradesResult[index];
    this.website = this.licensevalue.Website;
    this.websiteLink = 'http://' + this.website;
  }

  showViewTerritory(index: number) {
    this.licensevalue = this.territoryLicenseGradesResult[index];
    this.website = this.licensevalue.Website;
    this.websiteLink = 'http://' + this.website;
  }

  showPage(index: number) {
    if (this.licenseTypesResult.length > 0)
      this._clientService.setLicenceTypeCountry(this.countryCode);
    this.pagevalue = this.licenseTypesResult[index];
    this.licenseID = this.pagevalue.LicenseGradeId;
    this._clientService.setLicensed(this.licenseID);
    this._router.navigateByUrl('/carrier-search/client/' + this._clientService.getAccountId());
  }

  setCountryStateFlag() {
    if (this.licenseTypesResult.length > 0)
      this._clientService.setLicenceTypeCountry(this.countryCode);
    this._clientService.setLicenseState(this.licensevalue);
    this._router.navigateByUrl('/carrier-search/client/' + this._clientService.getAccountId());
  }

  goBacktoLicenses() {
    this.countryName = 'United States';
    this.isLicensesSection = false;
    this.mainSection = true;
    this.selectedCarrier = this.localStorage.getObject('carriers');
    this.carrierId = this.selectedCarrier.CarrierId;
    this.stateLicenseGradesResult = [];
    this.territoryLicenseGradesResult = [];
    this.getLicenseTypes(this.carrierId, 'US');
    this.getLicenseGrades(this.carrierId, 'US');
    this.isCanada = false;
  }

  goBacktoLicensesCanada() {
    this.isCanada = true;
    this.isLicensesSection = false;
    this.mainSection = true;
    this.countryName = 'Canada';
    this.selectedCarrier = this.localStorage.getObject('carriers');


    this.carrierId = this.selectedCarrier.CarrierId;
    this.stateLicenseGradesResult = [];
    this.territoryLicenseGradesResult = [];
    this.getLicenseTypes(this.carrierId, 'CA');
    this.getLicenseGrades(this.carrierId, 'CA');
  }

  getLicenseDisclaimerText() {
    this.licenseDisclaimerText = "The information compiled in this report by Willis Towers Watson is compiled from third party sources we consider to be reliable. However we do not guarantee and are not responsible for its accuracy or completeness and no warranty or representation of accuracy or completeness is given. We do not offer advice in relation to tax, accounting, regulatory, legal or investment matters and you must take separate advice as you consider necessary regarding such matters. This report is not prepared for and should not be construed as providing investment advice or services. It speaks only as to the date on which it was created and we shall have no obligation to update or amend. Willis Towers Watson does not guarantee or otherwise warrant the solvency of any insurer. Willis Towers Watson assumes no responsibility or duty in tort, contract or otherwise to any third party in respect of this document. Please note that this report is confidential and not for onward dissemination. "
  }

  generateLicenseExcelReport() {
    this._licensesService.getLicensesExcelReport(this._licensesService.getLicenseReportsURL() + 'reportType=CarrierDetails|reportSubType=Licenses|exportReport=true|exportFormat=excel', this.selectedCarrier.CarrierNumberId, this.selectedCarrier.WillisCode)
      .subscribe((result) => {
        var folderName = result;
        this._licensesService.downloadLicenseExcelReport(folderName);
      }, (error) => { });

  }

  getDisclaimers() {
    let financialDisclaimer = this._finacialService.GetDisclaimer();
    let WTWDisclaimer = this._disclaimerService.GetDisclaimer();
    let ratingDisclaimer = this._disclaimerService.GetRatingAgencies();

    Observable.forkJoin([financialDisclaimer, WTWDisclaimer, ratingDisclaimer]).subscribe(results => {
      this.disclaimerText.nativeElement.innerHTML = results[0];
      this.disclaimers.wtw = results[1].DisclaimerText;

      var ratingArray = [];
      var callback = [];
      results[2].forEach((re) => {
        if (re.RatingAgencyName === "A.M. Best") {
          this.amBestRatingAgencyID = re.RatingAgencyId;
          ratingArray.push(this._disclaimerService.GetDisclaimerByRatingAgencyId(this.amBestRatingAgencyID));
          callback.push((response) => { this.disclaimers.amBest = response.DisclaimerText; });
        }
        if (re.RatingAgencyName === "Standard & Poor's") {
          this.spRatingAgencyID = re.RatingAgencyId;
          ratingArray.push(this._disclaimerService.GetDisclaimerByRatingAgencyId(this.spRatingAgencyID));
          callback.push((response) => { this.disclaimers.snp = response.DisclaimerText; });
        }
        if (re.RatingAgencyName === "Moody's") {
          this.moodeysRatingAgencyID = re.RatingAgencyId;
          ratingArray.push(this._disclaimerService.GetDisclaimerByRatingAgencyId(this.moodeysRatingAgencyID));
          callback.push((response) => { this.disclaimers.moodys = response.DisclaimerText; });
        }
        if (re.RatingAgencyName === "Fitch") {
          this.fitchRatingAgencyID = re.RatingAgencyId;
          ratingArray.push(this._disclaimerService.GetDisclaimerByRatingAgencyId(this.fitchRatingAgencyID));
          callback.push((response) => { this.disclaimers.fitch = response.DisclaimerText; });
        }
      });

      Observable.forkJoin(ratingArray).subscribe(results => {
        callback[0](results[0]);
        callback[1](results[1]);
        callback[2](results[2]);
        callback[3](results[3]);
      });
    });
  }
  exporthtml() {
    var isCanada = this.isCanada;
    var quotes = document.getElementById('LD');
    if (this.isCanada) {
      var ua = window.navigator.userAgent;
      var msie = ua.indexOf("MSIE ");
      if (msie > 0 || !!navigator.userAgent.match(/Trident.*rv\:11\./)) {
        this.downloadCanadaPDFforIE();
      }
      else  // If another browser, return 0
      {
        html2canvas(document.getElementById('LD')).then(function (canvas) {
          var pdf = new jsPDF('l', 'pt', 'a4');
          pdf.setFont("helvetica");

          setTimeout(() => {
            for (var i = 0; i <= quotes.clientHeight / 700; i++) {
              var srcImg = canvas;
              var sX = 0;
              var sY = 700 * i; // start 700 pixels down for every new page
              var sWidth = 1200;
              var sHeight = 500;
              var dHeight = 500;
              var dX = 0;
              var dY = 0;
              var dWidth = 1200;

              window.onePageCanvas = document.createElement("canvas");
              onePageCanvas.setAttribute('width', 1200);
              onePageCanvas.setAttribute('height', 500);
              var ctx = onePageCanvas.getContext('2d');
              ctx.webkitImageSmoothingEnabled = true;
              ctx.mozImageSmoothingEnabled = true;
              ctx.imageSmoothingEnabled = true;
              ctx.imageSmoothingQuality = "high";
              ctx.drawImage(srcImg, sX, sY, sWidth, sHeight, dX, dY, dWidth, dHeight);


              var canvasDataURL = onePageCanvas.toDataURL("image/png", 1.0);

              var width = onePageCanvas.width;
              var height = onePageCanvas.clientHeight;

              // if (i > 0) {
              //   pdf.addPage();
              // }
              //pdf.setPage(i + 1);
              pdf.fromHTML($('#title').get(0), 30, 25, {
                'width': 550,
                'pagesplit': true,
                'elementHandlers': specialElementHandlers
              });
              pdf.addImage(canvasDataURL, 'PNG', 30, 60, (width * .60), (height * .62), undefined, 'FAST');
              var specialElementHandlers = {
                // '#hidediv1': function (element, render) { return true; },
                // '#hidediv2': function (element, render) { return true; }
              };
              pdf.fromHTML($('#line').get(0), 0, 520, {
                'width': 840,
                'pagesplit': true,
                'elementHandlers': specialElementHandlers
              });
              pdf.fromHTML($('#footer').get(0), 250, 540, {
                'width': 550,
                'pagesplit': true,
                'elementHandlers': specialElementHandlers
              });
            }
            pdf.addPage();
            pdf.fromHTML($('#disclaimer').get(0), 30, 40, {
              'width': 750,
              'pagesplit': true,
              'elementHandlers': specialElementHandlers
            });
            pdf.fromHTML($('#line').get(0), 0, 520, {
              'width': 840,
              'pagesplit': true,
              'elementHandlers': specialElementHandlers
            });
            pdf.fromHTML($('#footer').get(0), 250, 540, {
              'width': 550,
              'pagesplit': true,
              'elementHandlers': specialElementHandlers
            });
            pdf.save('Licenses.pdf');
          }, 100);
        });
      }
    }
    else {
      var ua = window.navigator.userAgent;
      var msie = ua.indexOf("MSIE ");
      if (msie > 0 || !!navigator.userAgent.match(/Trident.*rv\:11\./)) {
        this.downloadPDFforIE();
      }
      else  // If another browser, return 0
      {
        html2canvas(document.getElementById('LD')).then(function (canvas) {
          var pdf = new jsPDF('l', 'pt', 'a4');
          pdf.setFont("helvetica");

          setTimeout(() => {
            for (var i = 0; i <= quotes.clientHeight / 700; i++) {
              var srcImg = canvas;
              var sX = 0;
              var sY = 700 * i; // start 700 pixels down for every new page
              var sWidth = 1200;
              var sHeight = 550;
              var dHeight = 550
              var dX = 0;
              var dY = 0;
              var dWidth = 1200;

              window.onePageCanvas = document.createElement("canvas");
              onePageCanvas.setAttribute('width', 1200);
              onePageCanvas.setAttribute('height', 550);
              var ctx = onePageCanvas.getContext('2d');
              ctx.webkitImageSmoothingEnabled = true;
              ctx.mozImageSmoothingEnabled = true;
              ctx.imageSmoothingEnabled = true;
              ctx.imageSmoothingQuality = "high";
              ctx.drawImage(srcImg, sX, sY, sWidth, sHeight, dX, dY, dWidth, dHeight);


              var canvasDataURL = onePageCanvas.toDataURL("image/png", 1.0);

              var width = onePageCanvas.width;
              var height = onePageCanvas.clientHeight;

              // if (i > 0) {
              //   pdf.addPage();
              // }
              //pdf.setPage(i + 1);
              pdf.fromHTML($('#title').get(0), 30, 25, {
                'width': 550,
                'pagesplit': true,
                'elementHandlers': specialElementHandlers
              });
              pdf.addImage(canvasDataURL, 'PNG', 30, 60, (width * .60), (height * .62), undefined, 'FAST');
              var specialElementHandlers = {
                // '#hidediv1': function (element, render) { return true; },
                // '#hidediv2': function (element, render) { return true; }
              };
              pdf.fromHTML($('#line').get(0), 0, 520, {
                'width': 840,
                'pagesplit': true,
                'elementHandlers': specialElementHandlers
              });
              pdf.fromHTML($('#footer').get(0), 250, 540, {
                'width': 550,
                'pagesplit': true,
                'elementHandlers': specialElementHandlers
              });
            }
            pdf.addPage();
            pdf.fromHTML($('#disclaimer').get(0), 30, 40, {
              'width': 750,
              'pagesplit': true,
              'elementHandlers': specialElementHandlers
            });
            pdf.fromHTML($('#line').get(0), 0, 520, {
              'width': 840,
              'pagesplit': true,
              'elementHandlers': specialElementHandlers
            });
            pdf.fromHTML($('#footer').get(0), 250, 540, {
              'width': 550,
              'pagesplit': true,
              'elementHandlers': specialElementHandlers
            });
            pdf.save('Licenses.pdf');
          }, 100);
        });
      }
    }
  }

  openLicenseUrl() {
    window.open(this.licenseUrl, "_blank");
  }
  downloadPDFforIE() {
    {
      html2canvas(document.getElementById('LD')).then(function (canvas) {
        var pdf = new jsPDF('l', 'pt', 'a4');
        pdf.setFont("helvetica");
        var quotes = document.getElementById('LD');
        setTimeout(() => {
          for (var i = 0; i <= quotes.clientHeight / 700; i++) {
            var srcImg = canvas;
            var sX = 0;
            var sY = 700 * i; // start 700 pixels down for every new page
            var sWidth = 1050;
            var sHeight = 500;
            var dHeight = 500
            var dX = 0;
            var dY = 0;
            var dWidth = 1050;

            window.onePageCanvas = document.createElement("canvas");
            onePageCanvas.setAttribute('width', 1050);
            onePageCanvas.setAttribute('height', 500);
            var ctx = onePageCanvas.getContext('2d');
            ctx.webkitImageSmoothingEnabled = true;
            ctx.mozImageSmoothingEnabled = true;
            ctx.imageSmoothingEnabled = true;
            ctx.imageSmoothingQuality = "high";
            ctx.drawImage(srcImg, sX, sY, sWidth, sHeight, dX, dY, dWidth, dHeight);


            var canvasDataURL = onePageCanvas.toDataURL("image/png", 1.0);

            var width = onePageCanvas.width;
            var height = onePageCanvas.clientHeight;
            pdf.fromHTML($('#title').get(0), 30, 25, {
              'width': 550,
              'pagesplit': true,
              'elementHandlers': specialElementHandlers
            });
            pdf.addImage(canvasDataURL, 'PNG', 30, 60, (width * .60), (height * .62), undefined, 'FAST');
            var specialElementHandlers = {
            };
            pdf.fromHTML($('#line').get(0), 0, 520, {
              'width': 840,
              'pagesplit': true,
              'elementHandlers': specialElementHandlers
            });
            pdf.fromHTML($('#footer').get(0), 250, 540, {
              'width': 550,
              'pagesplit': true,
              'elementHandlers': specialElementHandlers
            });
          }
          pdf.addPage();
          pdf.fromHTML($('#disclaimer').get(0), 30, 40, {
            'width': 750,
            'pagesplit': true,
            'elementHandlers': specialElementHandlers
          });
          pdf.fromHTML($('#line').get(0), 0, 520, {
            'width': 840,
            'pagesplit': true,
            'elementHandlers': specialElementHandlers
          });
          pdf.fromHTML($('#footer').get(0), 250, 540, {
            'width': 550,
            'pagesplit': true,
            'elementHandlers': specialElementHandlers
          });
          pdf.save('LicensesDetails.pdf');
        }, 100);
      });
    }
  }
  downloadCanadaPDFforIE() {
    html2canvas(document.getElementById('LD')).then(function (canvas) {
      var pdf = new jsPDF('l', 'pt', 'a4');
      pdf.setFont("helvetica");
      var quotes = document.getElementById('LD');
      setTimeout(() => {
        for (var i = 0; i <= quotes.clientHeight / 550; i++) {
          var srcImg = canvas;
          var sX = 0;
          var sY = 550 * i; // start 550 pixels down for every new page
          var sWidth = 1050;
          var sHeight = 550
          var dHeight = 550;
          var dX = 0;
          var dY = 0;
          var dWidth = 1050;

          window.onePageCanvas = document.createElement("canvas");
          onePageCanvas.setAttribute('width', 1050);
          onePageCanvas.setAttribute('height', 550);
          var ctx = onePageCanvas.getContext('2d');
          ctx.webkitImageSmoothingEnabled = true;
          ctx.mozImageSmoothingEnabled = true;
          ctx.imageSmoothingEnabled = true;
          ctx.imageSmoothingQuality = "high";
          ctx.drawImage(srcImg, sX, sY, sWidth, sHeight, dX, dY, dWidth, dHeight);


          var canvasDataURL = onePageCanvas.toDataURL("image/png", 1.0);

          var width = onePageCanvas.width;
          var height = onePageCanvas.clientHeight;

          // if (i > 0) {
          //   pdf.addPage();
          // }
          //pdf.setPage(i + 1);
          pdf.fromHTML($('#title').get(0), 30, 25, {
            'width': 550,
            'pagesplit': true,
            'elementHandlers': specialElementHandlers
          });
          pdf.addImage(canvasDataURL, 'PNG', 30, 60, (width * .60), (height * .62), undefined, 'FAST');
          var specialElementHandlers = {
            // '#hidediv1': function (element, render) { return true; },
            // '#hidediv2': function (element, render) { return true; }
          };
          pdf.fromHTML($('#line').get(0), 0, 520, {
            'width': 840,
            'pagesplit': true,
            'elementHandlers': specialElementHandlers
          });
          pdf.fromHTML($('#footer').get(0), 250, 540, {
            'width': 550,
            'pagesplit': true,
            'elementHandlers': specialElementHandlers
          });
        }
        pdf.addPage();
        pdf.fromHTML($('#disclaimer').get(0), 30, 40, {
          'width': 750,
          'pagesplit': true,
          'elementHandlers': specialElementHandlers
        });
        pdf.fromHTML($('#line').get(0), 0, 520, {
          'width': 840,
          'pagesplit': true,
          'elementHandlers': specialElementHandlers
        });
        pdf.fromHTML($('#footer').get(0), 250, 540, {
          'width': 550,
          'pagesplit': true,
          'elementHandlers': specialElementHandlers
        });
        pdf.save('Licenses-Canada.pdf');
      }, 100);
    });
  }
  PDFmob() {
    html2canvas(document.getElementById('LD2')).then(function (canvas) {
      var pdf = new jsPDF('l', 'pt', 'a4');
      pdf.setFont("helvetica");
      var quotes = document.getElementById('LD2');
      setTimeout(() => {
        for (var i = 0; i <= quotes.clientHeight / 700; i++) {
          var srcImg = canvas;
          var sX = 0;
          var sY = 700 * i; // start 650 pixels down for every new page
          var sWidth = 1050;
          var sHeight = 700
          var dHeight = 700;
          var dX = 0;
          var dY = 0;
          var dWidth = 1050;

          window.onePageCanvas = document.createElement("canvas");
          onePageCanvas.setAttribute('width', 1050);
          onePageCanvas.setAttribute('height', 700);
          var ctx = onePageCanvas.getContext('2d');
          ctx.webkitImageSmoothingEnabled = true;
          ctx.mozImageSmoothingEnabled = true;
          ctx.imageSmoothingEnabled = true;
          ctx.imageSmoothingQuality = "high"
          ctx.drawImage(srcImg, sX, sY, sWidth, sHeight, dX, dY, dWidth, dHeight);
          var canvasDataURL = onePageCanvas.toDataURL("image/png", 1.0);
          var width = onePageCanvas.width;
          var height = onePageCanvas.clientHeight;
          if (i > 0) {
            pdf.addPage();
          }
          pdf.setPage(i + 1);
          pdf.addImage(canvasDataURL, 'PNG', 50, 40, (width * .60), (height * .62), undefined, 'FAST');
          var specialElementHandlers = {
          };
          pdf.fromHTML($('#title-mob').get(0), 50, 20, {
            'width': 550,
            'pagesplit': true,
            'elementHandlers': specialElementHandlers
          });
          pdf.fromHTML($('#line').get(0), 0, 520, {
            'width': 840,
            'pagesplit': true,
            'elementHandlers': specialElementHandlers
          });
          pdf.fromHTML($('#footer').get(0), 250, 540, {
            'width': 550,
            'pagesplit': true,
            'elementHandlers': specialElementHandlers
          });
        }
        pdf.addPage();
        pdf.fromHTML($('#disclaimer').get(0), 30, 40, {
          'width': 750,
          'pagesplit': true,
          'elementHandlers': specialElementHandlers
        });
        pdf.fromHTML($('#line').get(0), 0, 520, {
          'width': 840,
          'pagesplit': true,
          'elementHandlers': specialElementHandlers
        });
        pdf.fromHTML($('#footer').get(0), 250, 540, {
          'width': 550,
          'pagesplit': true,
          'elementHandlers': specialElementHandlers
        });
        pdf.save('Licenses.pdf');
      }, 100);
    });

  }
}