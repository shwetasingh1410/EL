import { Injectable, EventEmitter } from '@angular/core';

@Injectable()
export class LicensesEvents {
    LicensesUpdateEvent: EventEmitter<any> = new EventEmitter();
}