﻿import { Component, OnInit, Input, AfterContentInit, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';
declare var $: any;
import { LoaderService } from '../../shared/loaderComponent/Loader.service';
import { SummaryEvents } from './summary.events';
import { SummaryService } from './summary.service';
import { ClientService } from '../../select-client/client.service';
import { Account } from '../../select-client/select-client.model';
import { Carrier } from '../../carrier-search/carriersearch.model';
import { CarrierDetailsService } from '../carrier-details.service';
import { CarrierDetailsEvents } from '../carrier-details.events';
import { ReferenceCode, CreateReferenceCode, carrierSecurityYears, subCarrier } from './summary.model';
import { SafeUrl, DomSanitizer } from '@angular/platform-browser';
import { Settings } from '../../shared/settings/settings.service';
import { FinacialService } from '../financials/financials.service';
import { LoggedInUser } from '../../shared/loggedInUser/LoggedInUser';
import { CoolSessionStorage } from 'angular2-cool-storage';
import { NULL_EXPR } from '@angular/compiler/src/output/output_ast';
import { disclaimers } from './summary.model';
import { WTWDisclaimer, RatingAgencyDisclaimer } from '../../disclaimers/disclaimers.model';
import { DisclaimersService } from '../../disclaimers/disclaimers.service';
import * as html2canvas from 'html2canvas';
import * as jsPDF from 'jspdf';
import { GeneralService } from 'app/carrier-details/general/general.service';
declare global {
  interface Window { onePageCanvas: any; }
}
window.onePageCanvas = window.onePageCanvas || {};
declare var onePageCanvas: any;
import { carrierGeneralInfo } from '../general/general.model';

@Component({
  selector: 'app-summary',
  templateUrl: './summary.component.html',
  styleUrls: ['./summary.component.css'],
  providers: [SummaryService, FinacialService, DisclaimersService, GeneralService]
})
export class SummaryComponent implements OnInit {
  @ViewChild('disclaimerText') disclaimerText;
  carrierGeneralInfo: carrierGeneralInfo;
  amBestRatingAgencyID: any;
  spRatingAgencyID: any;
  moodeysRatingAgencyID: any;
  fitchRatingAgencyID: any;
  disclaimers: disclaimers;
  selectedCarrier;
  selectedAccount;
  carrierId: number;
  referenceResult: ReferenceCode;
  accountId: string;
  clientRefResult: CreateReferenceCode;
  message: string;
  isSuccess: boolean;
  isError: boolean;
  ref: string;
  summarytext: string;
  valueAM: string;
  valueSnP: string;
  reportUrl: SafeUrl;
  AMGraphUrl: SafeUrl;
  SnPGraphUrl: SafeUrl;
  selectedHeight1: number;
  selectedHeight2: number;
  selectedHeight3: number;
  HideTablix: number;
  show: boolean;
  pdfUrl: SafeUrl;
  excelUrl: SafeUrl;
  redirectToNotificationFlag: boolean;
  autoProvisionedUserFlag: boolean;
  summaryPdfUrl: SafeUrl;
  summaryPdfIndicator: boolean = false;
  localStorage: CoolSessionStorage;
  summaryDisclaimerText: string;
  carrierSecurityYears: Array<carrierSecurityYears> = [];
  pdfBtn: boolean = true;
  selectedYear: boolean = true;
  selectedYearNumber: string = '';
  subCarriers: Array<subCarrier> = [];
  subCarrier1: subCarrier;
  subCarriers1: Array<subCarrier> = [];
  subCarrier2: subCarrier;
  subCarriers2: Array<subCarrier> = [];
  isSearchingClient: boolean = false;
  showUnderLyingSecurityYears: boolean = false;
  dateToday: Date;
  private _subscribe;
  new : boolean;
  constructor(private _generalService : GeneralService, private _financialService: FinacialService, private _disclaimerService: DisclaimersService,
    private _summaryService: SummaryService, private _finacialService: FinacialService, private _clientService: ClientService,
    private _loaderService: LoaderService, private _carrierDetailsService: CarrierDetailsService, private _sanitizer: DomSanitizer,
    private _router: Router, private _settings: Settings, private _loggedInUser: LoggedInUser, localStorage: CoolSessionStorage, private _summaryEvents: SummaryEvents, private _carrierDetailsEvents: CarrierDetailsEvents) {
    this.ref = '';
    this.HideTablix = 1;
    this.valueAM = 'Show';
    this.valueSnP = 'Show';
    this.show = false;
    this.new = true;
    //this.exportToExcel;
    this.exportToPdf;
    this.exportSummaryToPdf;
    this.localStorage = localStorage
    this.autoProvisionedUserFlag = this._loggedInUser.getAutoProvisionedUserFlag();
    this.summaryDisclaimerText = "The information compiled in this report by Willis Towers Watson is compiled from third party sources we consider to be reliable. However we do not guarantee and are not responsible for its accuracy or completeness and no warranty or representation of accuracy or completeness is given. We do not offer advice in relation to tax, accounting, regulatory, legal or investment matters and you must take separate advice as you consider necessary regarding such matters. This report is not prepared for and should not be construed as providing investment advice or services. It speaks only as to the date on which it was created and we shall have no obligation to update or amend. Willis Towers Watson does not guarantee or otherwise warrant the solvency of any insurer. Willis Towers Watson assumes no responsibility or duty in tort, contract or otherwise to any third party in respect of this document. Please note that this report is confidential and not for onward dissemination. "
  }

  ngOnInit() {
    // if (this._clientService.getNewSearch()) {
    //   this.new = true;
    //    //var inputValue = (<HTMLInputElement>document.getElementById('iframe')).value;
    //   // inputValue == 'Loading..';
    // }
    this._subscribe = this._summaryEvents.SummaryUpdateEvent.subscribe(
      (showMenu) => {
        this.ngOnInit();
        this._subscribe.unsubscribe();
      }
    );
    this.exportToPdf();
    //this.exportToExcel();
    this.exportSummaryToPdf();
    this.getCarrierSecurityYears();
    this.dateToday = new Date();
    this.disclaimers = new disclaimers("", "", "", "", "");
    //this.formAMGraphUrl(this.HideTablix);
    //this.formSnPGraphUrl(this.HideTablix);
    this._loaderService.show();
    this.GetDisclaimer();
    this.getDisclaimers();
    this.selectedCarrier = this.localStorage.getObject('carriers');
    this.selectedAccount = this.localStorage.getObject('account');
    this.accountId = this.selectedAccount.Id;
    this.carrierId = this.selectedCarrier.CarrierId;
    this.companyTypeValue();
    // this.summaryPdfIndicator = this._carrierDetailsService.hideSummaryPdf(this.selectedCarrier.CompanyType);
    // this.GetReferenceCodeByAccountIdAndCarrierId('7B4163C1-02C9-4B84-85D5-3BCF73BCD13B', this.carrierId);
    this.GetReferenceCodeByAccountIdAndCarrierId(this.accountId, this.carrierId);
  }
  companyTypeValue() {
    this._generalService.GetCarrierGeneralInfo(this.selectedCarrier.WillisCode, new Date().getFullYear())
      .subscribe(CarrierGeneralInfoResult => {
        if (CarrierGeneralInfoResult) {
          this.carrierGeneralInfo = CarrierGeneralInfoResult;
          this._carrierDetailsService.setCompanyType(this.carrierGeneralInfo.carrierContactDetails.type)
          this.summaryPdfIndicator = this._carrierDetailsService.hideSummaryPdf(this.carrierGeneralInfo.carrierContactDetails.type);

        }
      })
  }
  GetDisclaimer() {

    this._finacialService.GetDisclaimer()
      .subscribe((result) => {
        this.disclaimerText.nativeElement.innerHTML = result;
        $('#disclaimerText a').attr('target', '_blank');
        setTimeout(() => {
           this._loaderService.hide();
        }, 30000);
      });
  }




  GetReferenceCodeByAccountIdAndCarrierId(accountId: string, carrierId: number) {
    // this._loaderService.show();
    this.isSuccess = false;
    this.isError = false;
    this._summaryService.GetReferenceCodeByAccountIdAndCarrierId(accountId, carrierId)
      .subscribe(referenceResult => {
        if (referenceResult) {
          this.referenceResult = referenceResult;
          this.summarytext = this.referenceResult.Code;
        }
      })
  }
  saveData() {
    this.isSuccess = false;
    this.isError = false;

    this.ref = this.summarytext;
    this.selectedCarrier = this.localStorage.getObject('carriers');
    this.selectedAccount = this.localStorage.getObject('account');
    this.accountId = this.selectedAccount.Id;
    this.carrierId = this.selectedCarrier.CarrierId;
    this._summaryService.PostReferenceCode(this.accountId, this.carrierId, this.ref)
      .subscribe((clientRefResult) => {
        if (clientRefResult) {
          this.showSuccess('Client Reference created successfully');
        }
        else
          this.showError('Creation of Client Reference Failed');
      }, (error) => this.handleError(error));
  }

  showSuccess(message: string) {

    this.isSuccess = true;
    setTimeout(() => {
      this.isSuccess = false;
    }, 3000);
    this.isError = false;
    this.message = message;
  }

  showError(message: string) {
    this.isSuccess = false;
    this.isError = true;
    setTimeout(() => {
      this.isError = false;
    }, 3000);
    this.message = message;

  }

  handleError(error) {
    this.isSuccess = false;
    this.isError = true;
    setTimeout(() => {
      this.isError = false;
    }, 3000);
    //error.status = 412;
    if (error.status === 412) {
      this.showError('Error 412 : Input Output Validation Error. Please enter details again. ');
    }
    else if (error.status === 422) {
      this.showError('Error 422 : Business Validation Error. Please try again');
    }
    else if (error.status === 500) {
      this.showError('500 Internal Server Error. Please try again');
    }
    else {
      this.showError('Server Error. Please try again');
    }
  }

  formReportUrl(value: boolean) {
    this.selectedHeight1 = 1300;

    this._carrierDetailsService.getReportsUrl(this._carrierDetailsService.getSummaryUrl(value), '')
      .subscribe((result) => {

        result = this._settings.getReportsUrl() + result.substring(4);
        this.reportUrl = this._sanitizer.bypassSecurityTrustResourceUrl(result);
      }, (error) => { });
  }

  formAMGraphUrl(HideTablix: number) {
    this.selectedHeight2 = 550;

    this._carrierDetailsService.getReportsUrl(this._carrierDetailsService.getFormAMGraphUrl(HideTablix), '')
      .subscribe((result) => {

        result = this._settings.getReportsUrl() + result.substring(4);
        this.AMGraphUrl = this._sanitizer.bypassSecurityTrustResourceUrl(result);
      }, (error) => { });
  }

  formSnPGraphUrl(HideTablix: number) {
    this.selectedHeight3 = 460;

    this._carrierDetailsService.getReportsUrl(this._carrierDetailsService.getFormSnPGraphUrl(HideTablix), '')
      .subscribe((result) => {

        result = this._settings.getReportsUrl() + result.substring(4);
        this.SnPGraphUrl = this._sanitizer.bypassSecurityTrustResourceUrl(result);
      }, (error) => { });
  }

  formAMGraphUrl2(HideTablix: number) {
    this.selectedHeight2 = 550;

    this._carrierDetailsService.getReportsUrl(this._carrierDetailsService.getFormAMGraphUrl2(HideTablix), '')
      .subscribe((result) => {

        result = this._settings.getReportsUrl() + result.substring(4);
        this.AMGraphUrl = this._sanitizer.bypassSecurityTrustResourceUrl(result);
      }, (error) => { });
  }

  formSnPGraphUrl2(HideTablix: number) {
    this.selectedHeight3 = 460;

    this._carrierDetailsService.getReportsUrl(this._carrierDetailsService.getFormSnPGraphUrl2(HideTablix), '')
      .subscribe((result) => {

        result = this._settings.getReportsUrl() + result.substring(4);
        this.SnPGraphUrl = this._sanitizer.bypassSecurityTrustResourceUrl(result);
      }, (error) => { });
  }

  hideAMReport() {
    this.show = !this.show;
    if (this.show == true) {
      this.valueAM = 'Hide';
      this.formAMGraphUrl2(this.HideTablix);
    } else {
      this.valueAM = 'Show';
      this.HideTablix = 0;
      this.formAMGraphUrl(this.HideTablix);
    }
  }
  hideSnPReport() {
    this.show = !this.show;
    if (this.show == true) {
      this.valueSnP = 'Hide';
      this.formSnPGraphUrl2(this.HideTablix);
    }
    else {
      this.valueSnP = 'Show';
      this.HideTablix = 0;
      this.formSnPGraphUrl(this.HideTablix);
    }
  }
  exportToPdf() {
    this._carrierDetailsService.getReportsUrl(this._carrierDetailsService.getPdfUrl(), '')
      .subscribe((result) => {

        this.pdfUrl = this._settings.getReportsUrl() + result.substring(4);
      }, (error) => { });

    return this.pdfUrl;
  }

  exportToExcel() {
    this._carrierDetailsService.getReportsUrl(this._carrierDetailsService.getExcelUrl(), '')
      .subscribe((result) => {
        result = this._settings.getReportsUrl() + result.substring(4);
        this.excelUrl = this._sanitizer.bypassSecurityTrustResourceUrl(result);
      }, (error) => { });
    //return this.excelUrl;
  }

  redirectToNotification() {
    if (this._clientService.getFromNotification()) {
      this._router.navigateByUrl('/notification');
      this._clientService.setAnyUpdate(false);
    }
    else {
      this._clientService.setAnyUpdate(true);
      this._clientService.setCarriersNotificationDetails(this.selectedCarrier);
      this._clientService.setRedirectToNotificationFromDetails(true);
      this._router.navigateByUrl('/notification');


    }

  }

  exportSummaryToPdf() {
    this._carrierDetailsService.getReportsUrl(this._carrierDetailsService.getSummaryPdfUrl(), '')
      .subscribe((result) => {
        this.summaryPdfUrl = this._settings.getReportsUrl() + result.substring(4);
      }, (error) => { });
    return this.summaryPdfUrl;
  }

  onClickOfSupplementary() {
    document.getElementById("security").click();
    this.getSubCarrierDetails();
  }

  getCarrierSecurityYears() {
    this.selectedYear = true;
    this.pdfBtn = true;
    this.selectedCarrier = this.localStorage.getObject('carriers');
    if (this.selectedCarrier && this.selectedCarrier.CarrierId)
      this._summaryService.GetCarrierSecurityYears(this.selectedCarrier.CarrierId).subscribe(result => {
        this.carrierSecurityYears = result;
        if (this.carrierSecurityYears.length > 0)
        { this.showUnderLyingSecurityYears = true; }
        this.formReportUrl(this.showUnderLyingSecurityYears);
        var num: Array<number> = [];

        for (var i = 0; i < this.carrierSecurityYears.length; i++) {
          num.push(this.carrierSecurityYears[i].EndDate);
        }
        if (num.length > 0) {
          var max = num.reduce(function (a, b) {
            return Math.max(a, b);
          })

          this.carrierSecurityYears.sort((a, b) => {
            if (a < b)
              return -1;
            if (a > b)
              return 1;

            return 0;

          });

          this.selectedYearNumber = max.toString();
          // this.getSubCarrierDetails();
        }
      })
  }


  getSubCarrierDetails() {
    this.isSearchingClient = true;
    if (this.selectedYearNumber)
      this._summaryService.GetSubCarrierDetails(this.selectedCarrier.CarrierId, this.selectedYearNumber).subscribe(result => {
        this.subCarriers = result;
        if (this.subCarriers.length > 0) {
          var id = this.subCarriers[0].Relationship1CarrierRelationshipID;
          this.subCarriers1 = [];
          this.subCarriers2 = [];
          this.subCarrier1 = null;
          this.subCarrier2 = null;
          this.subCarriers.forEach(sub => {
            if (sub.Relationship1CarrierRelationshipID == id) {
              this.subCarriers1.push(sub);
            } else {
              this.subCarriers2.push(sub);
            }
          })
          this.subCarriers1.forEach(sub1 => {
            if (sub1.Parent == null) {
              this.subCarrier1 = sub1;

            }
          })
          this.subCarriers2.forEach(sub2 => {
            if (sub2.Parent == null) {
              this.subCarrier2 = sub2;
            }
          })
          this.subCarriers1.splice(0, 1);
          this.subCarriers2.splice(0, 1);
          if (this.subCarrier1) {
            this.subCarriers1 = this.subCarriers1.filter(sub => sub.Parent == this.subCarrier1.Tag);
            this.subCarriers1.sort((a, b) => {
              if (a.Subrelationship2LegalName.toLowerCase() < b.Subrelationship2LegalName.toLowerCase())
                return -1;
              if (a.Subrelationship2LegalName.toLowerCase() > b.Subrelationship2LegalName.toLowerCase())
                return 1;

              return 0;

            });
          }

          if (this.subCarrier2) {
            this.subCarriers2 = this.subCarriers2.filter(sub => sub.Parent == this.subCarrier2.Tag);
            this.subCarriers2.sort((a, b) => {
              if (a.Subrelationship2LegalName.toLowerCase() < b.Subrelationship2LegalName.toLowerCase())
                return -1;
              if (a.Subrelationship2LegalName.toLowerCase() > b.Subrelationship2LegalName.toLowerCase())
                return 1;

              return 0;

            });
          }
        }

        this.isSearchingClient = false;
      }, error => {
        this.isSearchingClient = false;
      })

  }
  getDisclaimers() {
    let financialDisclaimer = this._financialService.GetDisclaimer();
    let WTWDisclaimer = this._disclaimerService.GetDisclaimer();
    let ratingDisclaimer = this._disclaimerService.GetRatingAgencies();

    Observable.forkJoin([financialDisclaimer, WTWDisclaimer, ratingDisclaimer]).subscribe(results => {
      this.disclaimerText.nativeElement.innerHTML = results[0];
      this.disclaimers.wtw = results[1].DisclaimerText;

      var ratingArray = [];
      var callback = [];
      results[2].forEach((re) => {
        if (re.RatingAgencyName === "A.M. Best") {
          this.amBestRatingAgencyID = re.RatingAgencyId;
          ratingArray.push(this._disclaimerService.GetDisclaimerByRatingAgencyId(this.amBestRatingAgencyID));
          callback.push((response) => { this.disclaimers.amBest = response.DisclaimerText; });
        }
        if (re.RatingAgencyName === "Standard & Poor's") {
          this.spRatingAgencyID = re.RatingAgencyId;
          ratingArray.push(this._disclaimerService.GetDisclaimerByRatingAgencyId(this.spRatingAgencyID));
          callback.push((response) => { this.disclaimers.snp = response.DisclaimerText; });
        }
        if (re.RatingAgencyName === "Moody's") {
          this.moodeysRatingAgencyID = re.RatingAgencyId;
          ratingArray.push(this._disclaimerService.GetDisclaimerByRatingAgencyId(this.moodeysRatingAgencyID));
          callback.push((response) => { this.disclaimers.moodys = response.DisclaimerText; });
        }
        if (re.RatingAgencyName === "Fitch") {
          this.fitchRatingAgencyID = re.RatingAgencyId;
          ratingArray.push(this._disclaimerService.GetDisclaimerByRatingAgencyId(this.fitchRatingAgencyID));
          callback.push((response) => { this.disclaimers.fitch = response.DisclaimerText; });
        }
      });

      Observable.forkJoin(ratingArray).subscribe(results => {
        callback[0](results[0]);
        callback[1](results[1]);
        callback[2](results[2]);
        callback[3](results[3]);
      });
    });
  }
  downloadPdfAgreeCarrier(select: boolean) {
    this.pdfBtn = true;
    if (true) {
      var quotes = document.getElementById('agreedCarriers');
      var pdf = new jsPDF('p', 'pt', 'a4');
      setTimeout(() => {
        var specialElementHandlers = {
          '#btn1': function (element, render) { return true; },
          '#btn2': function (element, render) { return true; },
          '#hidediv4': function (element, render) { return true; },
          '#status': function (element, render) { return true; },
          '#statusRes': function (element, render) { return true; }
        };
        pdf.fromHTML($('#head').get(0), 50, 70, {
        });
        pdf.fromHTML($('#agreedCarriers').get(0), 50, 40,
          {
            'width': 650,
            'elementHandlers': specialElementHandlers
          });
        pdf.line(0, 780, 900, 780);
        pdf.fromHTML($('#footer-pot').get(0), 130, 780,
          {
            'width': 550,
            'pagesplit': true,
            'elementHandlers': specialElementHandlers
          });
        pdf.addPage();
        pdf.fromHTML($('#dis').get(0), 50, 40,
          {
            'width': 500,
            'pagesplit': true,
            'elementHandlers': specialElementHandlers
          });
        pdf.line(0, 780, 900, 780);
        pdf.fromHTML($('#footer-pot').get(0), 130, 780,
          {
            'width': 550,
            'pagesplit': true,
            'elementHandlers': specialElementHandlers
          });
        pdf.save('UnderlyingSecurity.pdf');
      }, 1000);


    }
  }

  showReportForAgreeCarriers() {
    this.selectedYear = true;
    this.getSubCarrierDetails();
  }

  goToSubCarrier(carrier: any) {
    if (carrier) {
      var cId: any = this.localStorage.getObject('account');
      var clientId = cId.AccountId;
      var carrierId = carrier.StringSubrelationship2SubCarrier_ID;
      var WTWcode = carrier.Subrelationship2CompanyCode;
      var code = 'code';
      var car = 'carrier';
      var client = 'client';
      var carriers = new Carrier(carrierId, carrier.Subrelationship2LegalName, null, carrier.Subrelationship2Country, null, null, carrier.Subrelationship2CompanyCode, null, null, null,
        null, null, null, null, null, null, null, null, null, null, null, null, null, null, '', '', null, null, null, null, null, null, null, null, null);
      this._clientService.setCarrierObject(carriers);
      this.localStorage.setObject('carriers', carriers);
      if (this.localStorage.getObject('carriers')) {
        this._carrierDetailsEvents.CarrierDetailUpdateEvent.emit(true);
        this._summaryEvents.SummaryUpdateEvent.emit(true);
      }
      this._router.navigate(['carrier-detail', client, clientId, car, carrierId, code, WTWcode, 'summary']);
      // window.location.reload();
    }
  }
}


