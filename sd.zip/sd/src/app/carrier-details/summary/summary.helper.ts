import {ReferenceCode, CreateReferenceCode,carrierSecurityYears,subCarrier} from './summary.model';

export class SummaryHelper {
    static mapToReferenceCode(reference : any) :  ReferenceCode{
       return new ReferenceCode(reference.Id, reference.MosaicClientId, reference.CarrierId, reference.Code);
    }

    static mapToCarrierSecurityYears(year): carrierSecurityYears {
        return new carrierSecurityYears(year.EndDate);
    }

    static mapToCarrier(carrier: any):subCarrier {
        return new subCarrier(carrier.Tag,carrier.Parent,carrier.Relationship1CarrierRelationshipID,carrier.StringSubrelationship2SubCarrier_ID, carrier.Subrelationship2LegalName,carrier.Subrelationship2Country,
            carrier.Subrelationship2CompanyCode,carrier.Subrelationship2SubCarrierPercent, carrier.Subrelationship2ApprovalStatusDesc,carrier.Relationship1BeginDate
        ,carrier.Relationship1EndDate);
    }

    // static mapToCreateReferenceCode(create : any) : CreateReferenceCode{
    //     return new CreateReferenceCode(create.Code);
    // }
}