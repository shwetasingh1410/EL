export class ReferenceCode {
    Id: number;
    MosaicClientId: string;
    CarrierId: number;
    Code: string;

    constructor(Id: number, MosaicClientId: string, CarrierId: number, Code: string) {
        this.Id = Id;
        this.MosaicClientId = MosaicClientId;
        this.CarrierId = CarrierId;
        this.Code = Code;
    }

    getId(): number {
        return this.Id;
    }
    setId(Id: number) {
        this.Id = Id;
    }
    getMosaicClientId(): string {
        return this.MosaicClientId;
    }
    setMosaicClientId(MosaicClientId: string) {
        this.MosaicClientId = MosaicClientId;
    }
    getCarrierId(): number {
        return this.CarrierId
    }
    setCarrierId(CarrierId: number) {
        this.CarrierId = CarrierId;
    }
    getCode(): string {
        return this.Code;
    }
    setCode(Code: string) {
        this.Code = Code;
    }
}

export class CreateReferenceCode {
    Code: string;

    constructor(Code: string) {
        this.Code = Code;
    }
    getCode(): string {
        return this.Code;
    }
    setCode(Code: string) {
        this.Code = Code;
    }
}

export class carrierSecurityYears {
    EndDate: number;

    constructor(EndDate: number) {
        this.EndDate = EndDate;
    }
}

export class subCarrier {

    Tag: number;
    Parent: number;
    Relationship1CarrierRelationshipID: number;
    Relationship1EffectiveDate: Date;
    Relationship1CarrierRelationshipTypeID: number;
    Relationship1ParentLegalName: string;
    Relationship1BeginDate: string;
    Relationship1EndDate: string;
    Subrelationship2SubCarrierRelationship_ID: number;
    Subrelationship2SubCarrierPercent: number;
    Subrelationship2SubCarrier_ID: number;
    StringSubrelationship2SubCarrier_ID: string;
    Subrelationship2CompanyCode: string;
    Subrelationship2LegalName: string;
    Subrelationship2RegisteredCountryID: number;
    Subrelationship2Country: string;
    Subrelationship2CountryID: number;
    Subrelationship2ApprovalStatusDesc: string;
    Subrelationship2ApprovalStatus: string;
    Qualifier3QualifierDesc: string;
    Businessunit4BusinessUnit: string;
    Businessunit4BusinessUnit_ID: number;
    Restriction5RestrictionDesc: string;

    constructor(Tag: number, Parent: number, Relationship1CarrierRelationshipID: number, CarrierId: string, LegalName: string, Country: string, WillisCode: string, CombinedRatioPercentage: number, ApprovalStatus: string, Relationship1BeginDate: string, Relationship1EndDate: string) {
        this.StringSubrelationship2SubCarrier_ID = CarrierId;
        this.Subrelationship2LegalName = LegalName;
        this.Subrelationship2Country = Country;
        this.Subrelationship2CompanyCode = WillisCode;
        this.Subrelationship2SubCarrierPercent = CombinedRatioPercentage;
        this.Subrelationship2ApprovalStatusDesc = ApprovalStatus;
        this.Relationship1EndDate = Relationship1EndDate;
        this.Relationship1BeginDate = Relationship1BeginDate;
        this.Tag = Tag;
        this.Parent = Parent;
        this.Relationship1CarrierRelationshipID = Relationship1CarrierRelationshipID;
    }

}
export class disclaimers {
    amBest: string;
    moodys: string;
    snp: string;
    fitch: string;
    wtw: string;

    constructor(amBest: string, moodys: string, snp: string, fitch: string, wtw: string) {
        this.amBest = amBest;
        this.moodys = moodys;
        this.snp = snp;
        this.fitch = fitch;
        this.wtw = wtw;
    }
}