import { Injectable, EventEmitter } from '@angular/core';

@Injectable()
export class SummaryEvents {
    SummaryUpdateEvent: EventEmitter<any> = new EventEmitter();
}