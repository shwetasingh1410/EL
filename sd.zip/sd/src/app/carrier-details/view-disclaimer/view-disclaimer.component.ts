import { Component, OnInit } from '@angular/core';
import { TranslateService } from '../../translate/translate.service';
import { DisclaimersService } from '../../disclaimers/disclaimers.service';
import { RatingAgency } from '../../disclaimers/disclaimers.model';

declare var $: any;
@Component({
  selector: 'app-view-disclaimer',
  templateUrl: './view-disclaimer.component.html',
  styleUrls: ['./view-disclaimer.component.css'],
  providers: [DisclaimersService]
})
export class ViewDisclaimerComponent implements OnInit {
  result: Array<RatingAgency>;
  amBestRatingAgencyID: any;
  spRatingAgencyID: any;
  moodeysRatingAgencyID: any;
  fitchRatingAgencyID: any;
  
  displayGeneralWtwDisclaimer: boolean;
  displayGeneralAmBestRatingAgencyDisclaimer: boolean;
  displayGeneralSPRatingAgencyDisclaimer: boolean;
  displayGeneralMoodyRatingAgencyDisclaimer: boolean;
  displayGeneralFitchRatingAgencyDisclaimer: boolean;

  isError: boolean=false;
  message: string;


  constructor(private _translate: TranslateService, private _disclaimerService: DisclaimersService) {
    
  }

  ngOnInit() {
    
    this._translate.use('en');
    this.GetGeneralWtwDisclaimer();
     this.GetRatingAgencies();
    
    this.displayGeneralWtwDisclaimer = false;
    this.displayGeneralAmBestRatingAgencyDisclaimer = false;
    this.displayGeneralSPRatingAgencyDisclaimer = false;
    this.displayGeneralMoodyRatingAgencyDisclaimer = false;
    this.displayGeneralFitchRatingAgencyDisclaimer = false;
    // this.openGeneralDisclaimer();

  }

  GetRatingAgencies() {
    this._disclaimerService.GetRatingAgencies().subscribe(result => {
      this.result = result;
      this.result.forEach((re) => {
        if (re.RatingAgencyName === "A.M. Best") {
          this.amBestRatingAgencyID = re.RatingAgencyId;
          this.GetGeneralAmBestRatingAgencyDisclaimer(this.amBestRatingAgencyID);
        }
        if (re.RatingAgencyName === "Standard & Poor's") {
          this.spRatingAgencyID = re.RatingAgencyId;
          this.GetGeneralSPRatingAgencyDisclaimer(this.spRatingAgencyID);
        }
        if (re.RatingAgencyName === "Moody's") {
          this.moodeysRatingAgencyID = re.RatingAgencyId;
          this.GetGeneralMoodyRatingAgencyDisclaimer(this.moodeysRatingAgencyID);
        }
        if (re.RatingAgencyName === "Fitch") {
          this.fitchRatingAgencyID = re.RatingAgencyId;
          this.GetGeneralFitchRatingAgencyDisclaimer(this.fitchRatingAgencyID);
        }


      });

    });
  }


  // openGeneralDisclaimer() {
  //   this.GetGeneralWtwDisclaimer();
  //   // this.GetGeneralAmBestRatingAgencyDisclaimer();
  //   // this.GetGeneralSPRatingAgencyDisclaimer();
  //   // this.GetGeneralMoodyRatingAgencyDisclaimer();
  //   // this.GetGeneralFitchRatingAgencyDisclaimer();
    
  // }



  GetGeneralWtwDisclaimer() {
    this._disclaimerService.GetDisclaimer().subscribe(WTWdisclaimerResult => {

      if (WTWdisclaimerResult.IsHidden === false) {
        setTimeout(function () { $('#editorlGeneralWtwDisclaimer').html(WTWdisclaimerResult.DisclaimerText); }, 5);
        this.displayGeneralWtwDisclaimer = true;

      }
      else {
        this.displayGeneralWtwDisclaimer = false;
      }
    }, (error) => this.handleError(error));
  }


  GetGeneralAmBestRatingAgencyDisclaimer(amBestRatingAgencyID:any) {
    this._disclaimerService.GetDisclaimerByRatingAgencyId(amBestRatingAgencyID).subscribe(disclaimerResult => {
      if (disclaimerResult.IsHidden === false) {
        setTimeout(function () { $('#editorGeneralAmBestRatingAgencyDisclaimer').html(disclaimerResult.DisclaimerText); }, 5);
        this.displayGeneralAmBestRatingAgencyDisclaimer = true;
      }
      else {
        this.displayGeneralAmBestRatingAgencyDisclaimer = false;
      }

    }, (error) => this.handleError(error));
  }

  GetGeneralSPRatingAgencyDisclaimer(spRatingAgencyID:any) {
    this._disclaimerService.GetDisclaimerByRatingAgencyId(spRatingAgencyID).subscribe(disclaimerResult => {
      if (disclaimerResult.IsHidden === false) {
        setTimeout(function () { $('#editorGeneralSPRatingAgencyDisclaimer').html(disclaimerResult.DisclaimerText); }, 5);
        this.displayGeneralSPRatingAgencyDisclaimer = true;
      }
      else {
        this.displayGeneralSPRatingAgencyDisclaimer = false;
      }
    }, (error) => this.handleError(error));
  }

  GetGeneralMoodyRatingAgencyDisclaimer(moodeysRatingAgencyID:any) {
    this._disclaimerService.GetDisclaimerByRatingAgencyId(moodeysRatingAgencyID).subscribe(disclaimerResult => {
      if (disclaimerResult.IsHidden === false) {
        setTimeout(function () { $('#editorGeneralMoodyRatingAgencyDisclaimer').html(disclaimerResult.DisclaimerText); }, 5);
        this.displayGeneralMoodyRatingAgencyDisclaimer = true;
      }
      else {
        this.displayGeneralMoodyRatingAgencyDisclaimer = false;
      }

    }, (error) => this.handleError(error));
  }

  GetGeneralFitchRatingAgencyDisclaimer(fitchRatingAgencyID:any) {
    this._disclaimerService.GetDisclaimerByRatingAgencyId(fitchRatingAgencyID).subscribe(disclaimerResult => {
      if (disclaimerResult.IsHidden === false) {
        setTimeout(function () { $('#editorGeneralFitchRatingAgencyDisclaimer').html(disclaimerResult.DisclaimerText);; }, 5);
        this.displayGeneralFitchRatingAgencyDisclaimer = true;
      }
      else {
        this.displayGeneralFitchRatingAgencyDisclaimer = false;
      }
    }, (error) => this.handleError(error));
  }



  showError(message: string) {
    this.isError = true;
    setTimeout(() => {
      this.isError = false;
    }, 3000);
    this.message = message;
  }


  handleError(error) {
    this.isError = true;
    setTimeout(() => {
      this.isError = false;
    }, 3000);
    if (error.status === 412) {
      this.showError('Error 412 : Input Output Validation Error. Please enter details again. ');
    }
    else if (error.status === 422) {
      this.showError('Error 422 : Business Validation Error. Please try again');
    }
    else if (error.status === 500) {
      this.showError('500 Internal Server Error. Please try again');
    }
    else {
      this.showError('Server Error. Please try again');
    }
  }



}
