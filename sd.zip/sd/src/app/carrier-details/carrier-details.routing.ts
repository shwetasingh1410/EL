/*import { Router , RouterModule } from '@angular/router';

import { CarrierDetailsComponent} from './carrier-details.component';
import { GeneralComponent} from './general/general.component';
import { SummaryComponent} from './summary/summary.component';


export const CarrierDetailsRouting = RouterModule.forChild([
    { path: 'carrier-detail/general', component: GeneralComponent, outlet: 'carrierdetail'},
    { path: 'carrier-detail/summary', component: SummaryComponent, outlet: 'carrierdetail'},
    { path: 'carrier-detail', component: GeneralComponent, outlet: 'carrierdetail'},
]);
*/ 