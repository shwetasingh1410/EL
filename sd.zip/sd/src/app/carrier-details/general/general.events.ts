import { Injectable, EventEmitter } from '@angular/core';

@Injectable()
export class GeneralEvents {
    GeneralUpdateEvent: EventEmitter<any> = new EventEmitter();
}