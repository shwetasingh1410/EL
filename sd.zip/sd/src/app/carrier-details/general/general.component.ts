import { Component, OnInit, ViewChild } from '@angular/core';
import { Observable } from 'rxjs';
import { GeneralService } from './general.service';
import { GeneralEvents } from './general.events';
import { ClientService } from '../../select-client/client.service';
import { Carrier } from '../../carrier-search/carriersearch.model';
import { CarrierDetailsService } from '../carrier-details.service';
import { CarrierDetailsEvents } from '../carrier-details.events';
import { LoaderService } from '../../shared/loaderComponent/Loader.service';
import { Router } from '@angular/router';
import { CoolSessionStorage } from 'angular2-cool-storage';
import { SafeUrl, DomSanitizer } from '@angular/platform-browser';
import { GeneralDateFormatPipe, GeneralDatePipe } from './general.pipe';
import {
  carrierGeneralInfo, carrierContactDetails, carrierApprovalStatus,
  carrierRatingSummary, carrierApprovalStatusAuditTrail, carrierMainEntity,
  carrierRatingAuditTrail, carrierWillisShortName, disclaimers, carrierSecurityYears, subCarrier
} from './general.model';
import { PageAccessHelper } from '../../shared/page-access-levels/page-access-levels.helper';
import { GeneralAccessLevels } from './general.access-levels';
import * as FileSaver from 'file-saver';
import { FinacialService } from '../financials/financials.service';
import { TranslateService } from '../../translate/translate.service';
import { DisclaimersService } from '../../disclaimers/disclaimers.service';
import { RatingAgency } from '../../disclaimers/disclaimers.model';
import { FooterEvents } from '../../footer/footer.events'
// import * as pdfMake from 'pdfmake/build/pdfmake.js';
// import * as pdfFonts from 'pdfmake/build/vfs_fonts.js';
// pdfMake.vfs = pdfFonts.pdfMake.vfs;
import * as html2canvas from 'html2canvas';
import * as jsPDF from 'jspdf';
declare global {
  interface Window { onePageCanvas: any; }
}
window.onePageCanvas = window.onePageCanvas || {};
declare var onePageCanvas: any;
declare var $: any;
@Component({
  selector: 'app-general',
  templateUrl: './general.component.html',
  styleUrls: ['./general.component.css'],
  providers: [GeneralService, FinacialService, DisclaimersService]
})
export class GeneralComponent implements OnInit {
  @ViewChild('disclaimerText') disclaimerText;
  showSanctionStatus: boolean;
  sanctionStatus: string;
  hideStatus: boolean;
  hideStatusRes: boolean;
  dis: string;
  dis2: string;
  dateToday: Date;
  isViewModalData: boolean;
  selectedCarrier;
  groupCodeId: string;
  WillisCode: string;
  carrierGeneralInfo: carrierGeneralInfo;
  carrierRatingSummary: carrierRatingSummary;
  ratingAgencyId: string;
  currentCarrierId: number;
  parentCarrierId: number;
  carrierId: number;
  carrierContactDetails: carrierContactDetails;
  country: string;
  state: string;
  type: string;
  group: string;
  legalName: string;
  carrierMainEntity: carrierMainEntity;
  fatcaComplianceStatus: string;
  fatcaCertificateNumber: string;
  fatcaEntityType: string;
  willis: string;
  fein: string;
  naic: string;
  lors: string;
  fetInd: string;
  tobaIndicator: string;
  tobaType: string;
  legalEntity: string;
  fullAddress: string;
  establishedDate: string;
  operatingCategory: string;
  comments: Array<string>;
  organizationType: string;
  marketSecurityContact: string;
  marketSecurityAnalyst: string;
  carrierMainEntityParId; number;
  carrierApprovalStatus: carrierApprovalStatus;
  approvalStatus: string;
  businessUnit: Array<string>;
  restriction: Array<string>;
  qualifiers: Array<string>;
  ratingAgencyName: string;
  ratings: string;
  outLook: string;
  date: string;
  reference: string;
  approvalStatusAuditTrailChangeTypeDesc: string;
  approvalStatusAuditTrailPriorValue: string;
  approvalStatusAuditTrailNewValue: string;
  approvalStatusAuditTrailEffectiveDate: string;
  newAddress: string;
  x: string;
  y: string;
  description: string;
  statementYear: number;
  priorValue: string;
  newValue: string;
  effectiveDate: string;
  businessUnitName: string;
  address: string;
  address1: string;
  address2: string;
  willisShortName: string;
  carrierRatingSummaryResult: Array<carrierRatingAuditTrail>;
  approvalStatusResult: Array<carrierApprovalStatusAuditTrail>;
  carrierWillisShortNameResult: Array<carrierWillisShortName>;
  //willisShortNames: willisShortNames;
  address3: string;
  add: any;
  n1: number; n2: number; n3: number; n4: number; n5: number; n6: number; n7: number; n8: number; n9: number;
  add1: string; add2: string; add3: string; add4: string; add5: string;
  add6: string; add7: string; add8: string; add9: string; add10: string; addFax: string;
  bu1: string; bu2: string; bu3: string; bu4: string; bu5: string;
  re1: string; re2: string; re3: string; re4: string; re5: string;

  pageAccessLevels: GeneralAccessLevels;
  downloadDoucmentName: string;
  localStorage: CoolSessionStorage;
  selectedAccountId;
  carrierDocs;
  result: Array<RatingAgency>;
  amBestRatingAgencyID: any;
  spRatingAgencyID: any;
  moodeysRatingAgencyID: any;
  fitchRatingAgencyID: any;
  disclaimers: disclaimers;
  carrierSecurityYears: Array<carrierSecurityYears> = [];
  pdfBtn: boolean = true;
  selectedYear: boolean = true;
  selectedYearNumber: string = '';
  subCarriers: Array<subCarrier> = [];
  subCarrier1: subCarrier;
  subCarriers1: Array<subCarrier> = [];
  subCarrier2: subCarrier;
  subCarriers2: Array<subCarrier> = [];
  isSearchingClient: boolean = false;
  auditUrl: SafeUrl;
  private _subscribe;
  ios: boolean;

  constructor(private _financialService: FinacialService, private _generalService: GeneralService, private _clientService: ClientService, private _router: Router
    , private _pageAccessHelper: PageAccessHelper, localStorage: CoolSessionStorage, private _loaderService: LoaderService, private _translate: TranslateService, private _disclaimerService: DisclaimersService, private _footerEvents: FooterEvents, private _sanitizer: DomSanitizer, private _generalEvents: GeneralEvents, private _carrierDetailsEvents: CarrierDetailsEvents, private _carrierDetailsService: CarrierDetailsService) {
    this.localStorage = localStorage;
    this.carrierRatingSummaryResult = [];
    this.approvalStatusResult = [];
    this.carrierWillisShortNameResult = [];
    this.hideStatus = true;
    this.hideStatusRes = true;
    this.pageAccessLevels = new GeneralAccessLevels();
    this._translate.use('en');
    this.addFax = '';
  }

  ngOnInit() {
    this._subscribe = this._generalEvents.GeneralUpdateEvent.subscribe(
      (showMenu) => {
        this.ngOnInit();
        this._subscribe.unsubscribe();
      }
    );
    this.addFax = '';
    this.checkOS();
    this._pageAccessHelper.getPageAccessLevelsDetails("carrier-detail-general", this.pageAccessLevels);
    this.selectedCarrier = this.localStorage.getObject('carriers');
    if (this.localStorage.getObject('carriers')) {
      this.selectedCarrier = this.localStorage.getObject('carriers');
      this.selectedAccountId = this._clientService.getAccountId();
    }
    this.WillisCode = this.selectedCarrier.WillisCode;
    if (!this._clientService.getRecentFlag()) {
      this._loaderService.show()
    }
    this.getCarrierGeneralInfo(this.WillisCode, new Date().getFullYear());
    this.dateToday = new Date();
    this.disclaimers = new disclaimers("", "", "", "", "");
    this.getDisclaimers();
    this.getCarrierDocs();
    this.getCarrierSecurityYears();
    this.downloadStaticAuditFile();

  }
  checkOS() {
    // var userAgentMob = navigator.userAgent || navigator.vendor;
    // if (/iPad|iPhone|iPod/.test(userAgentMob)) {
    // if( /iPhone|iPad|iPod/i.test(navigator.userAgent) ) {
    let operatingSystem = !!navigator.platform && /iPad|iPhone|iPod/.test(navigator.platform);
    let xx = /(iPad|iPhone|iPod)/g.test(navigator.userAgent);
    if (operatingSystem == true || xx == true) {
      this.ios == true;
    }
    else {
      this.ios == false;
    }
  }
  refresh() {
    this.selectedCarrier = this.localStorage.getObject('carriers');
    this.WillisCode = this.selectedCarrier.WillisCode;
    this.getCarrierGeneralInfo(this.WillisCode, new Date().getFullYear());

  }

  getCarrierGeneralInfo(companyCode: string, year: number) {
    var carrierGeneralInfo = this._carrierDetailsService.getGeneralInfo();


    this._generalService.GetCarrierGeneralInfo(companyCode, year)
      .subscribe(CarrierGeneralInfoResult => {
        // console.log(CarrierGeneralInfoResult);

        this.carrierGeneralInfo = CarrierGeneralInfoResult;
        this.carrierContactDetails = CarrierGeneralInfoResult.carrierContactDetails;
        this.carrierApprovalStatus = CarrierGeneralInfoResult.carrierApprovalStatus;
        this.carrierRatingSummary = CarrierGeneralInfoResult.carrierRatingSummary;

        this.showSanctionStatus = this.carrierContactDetails.showSanctionStatus;
        this.sanctionStatus = this.carrierContactDetails.sanctionStatus;
        this.country = this.carrierContactDetails.country;
        this.state = this.carrierContactDetails.state;
        this.type = this.carrierContactDetails.type;
        this.group = this.carrierContactDetails.group;
        this.legalName = this.carrierContactDetails.legalName;
        this.carrierMainEntity = this.carrierContactDetails.carrierMainEntity;
        this.fatcaComplianceStatus = this.carrierContactDetails.fatcaComplianceStatus;
        this.fatcaCertificateNumber = this.carrierContactDetails.fatcaCertificateNumber;
        this.fatcaEntityType = this.carrierContactDetails.fatcaEntityType;
        this.willis = this.carrierContactDetails.willis;
        this.fein = this.carrierContactDetails.fein;
        this.naic = this.carrierContactDetails.naic;
        this.lors = this.carrierContactDetails.lors;
        this.fetInd = this.carrierContactDetails.fetInd;
        this.tobaIndicator = this.carrierContactDetails.tobaIndicator;
        this.tobaType = this.carrierContactDetails.tobaType;
        this.legalEntity = this.carrierContactDetails.legalEntity;
        this.fullAddress = this.carrierContactDetails.fullAddress;
        this.establishedDate = this.carrierContactDetails.establishedDate;
        this.operatingCategory = this.carrierContactDetails.operatingCategory;
        this.comments = this.carrierContactDetails.comments;
        this.organizationType = this.carrierContactDetails.organizationType;
        this.marketSecurityContact = this.carrierContactDetails.marketSecurityContact;
        this.marketSecurityAnalyst = this.carrierContactDetails.marketSecurityAnalyst;
        this.carrierMainEntityParId = this.carrierMainEntity[3];
        this.address1 = this.fullAddress.replace(/\|:/g, ",");
        this.address2 = this.address1.replace(/\|/g, ",");
        this.add1 = this.address2.split(",,")[0];
        this.add2 = this.address2.split(",,")[1];
        this.add3 = this.address2.split(",,")[2];
        this.add4 = this.address2.split(",,")[3];
        this.add5 = this.address2.split(",,")[4];
        this.add6 = this.address2.split(",,")[5];
        this.add7 = this.address2.split(",,")[6];
        this.add8 = this.address2.split(",,")[7];
        this.add9 = this.address2.split(",,")[8];
        this.add10 = this.address2.split(",,")[9];

        if (this.add1 != undefined) {
          let str = this.add1;
          this.n1 = str.search("http");
          if (this.n1 != -1) {
            this.n1 = 10;
          }
          else {
            this.n1 = str.search("Fax");
            if (this.n1 != -1) {
              this.add1 = str.slice(0, this.n1 - 1);
              this.addFax = str.slice(this.n1, str.length);
              this.n1 = 5;
            }

          }

        }

        if (this.add2 != undefined) {
          let str2 = this.add2;
          this.n2 = str2.search("http");
          if (this.n2 != -1) {
            this.n2 = 10;
          }
          else {
            this.n2 = str2.search("Fax");
            if (this.n2 != -1) {
              this.add2 = str2.slice(0, this.n2 - 1);
              this.addFax = str2.slice(this.n2, str2.length);
              this.n2 = 5;
            }
          }
        }
        if (this.add3 != undefined) {
          let str3 = this.add3;
          this.n3 = str3.search("http");

          if (this.n3 != -1) {
            this.n3 = 10;
          }
          else {
            this.n3 = str3.search("Fax");
            if (this.n3 != -1) {
              this.add3 = str3.slice(0, this.n3 - 1);
              this.addFax = str3.slice(this.n3, str3.length);
              this.n3 = 5;
            }
          }
        }
        if (this.add4 != undefined) {
          let str4 = this.add4;
          this.n4 = str4.search("http");
          if (this.n4 != -1) {
            this.n4 = 10;
          }
          else {
            this.n4 = str4.search("Fax");
            if (this.n4 != -1) {
              this.add4 = str4.slice(0, this.n4 - 1);
              this.addFax = str4.slice(this.n4, str4.length);
              this.n4 = 5;
            }
          }
        }
        if (this.add5 != undefined) {
          let str5 = this.add5;
          this.n5 = str5.search("http");
          if (this.n5 != -1) {
            this.n5 = 10;
          }
          else {
            this.n5 = str5.search("Fax");
            if (this.n5 != -1) {
              this.add5 = str5.slice(0, this.n5 - 1);
              this.addFax = str5.slice(this.n5, str5.length);
              this.n5 = 5;
            }
          }
        }
        if (this.add6 != undefined) {
          let str6 = this.add6;
          this.n6 = str6.search("http");
          if (this.n6 != -1) {
            this.n6 = 10;
          }
          else {
            this.n6 = str6.search("Fax");
            if (this.n6 != -1) {
              this.add6 = str6.slice(0, this.n6 - 1);
              this.addFax = str6.slice(this.n6, str6.length);
              this.n6 = 5;
            }
          }
        }
        if (this.add7 != undefined) {
          let str7 = this.add7;
          this.n7 = str7.search("http");
          if (this.n7 != -1) {
            this.n7 = 10;
          }
          else {
            this.n7 = str7.search("Fax");
            if (this.n7 != -1) {
              this.add7 = str7.slice(0, this.n7 - 1);
              this.addFax = str7.slice(this.n7, str7.length);
              this.n7 = 5;
            }
          }
        }
        if (this.add8 != undefined) {
          let str8 = this.add8;
          this.n8 = str8.search("http");
          if (this.n8 != -1) {
            this.n8 = 10;
          }
          else {
            this.n8 = str8.search("Fax");
            if (this.n8 != -1) {
              this.add8 = str8.slice(0, this.n8 - 1);
              this.addFax = str8.slice(this.n8, str8.length);
              this.n8 = 5;
            }
          }
        }
        if (this.add9 != undefined) {
          let str9 = this.add9;
          this.n9 = str9.search("http");
          if (this.n9 != -1) {
            this.n9 = 10;
          }
          else {
            this.n9 = str9.search("Fax");
            if (this.n9 != -1) {
              this.add9 = str9.slice(0, this.n9 - 1);
              this.addFax = str9.slice(this.n9, str9.length);
              this.n9 = 5;
            }
          }
        }

        this.approvalStatus = this.carrierApprovalStatus.approvalStatus;
        this.businessUnit = this.carrierApprovalStatus.businessUnit;
        this.restriction = this.carrierApprovalStatus.restriction;
        this.qualifiers = this.carrierApprovalStatus.qualifiers;
        this.comments = this.carrierApprovalStatus.comments;
        /* Business Unit and Restrictions */
        this.bu1 = this.businessUnit[0];
        this.bu2 = this.businessUnit[1];
        this.bu3 = this.businessUnit[2];
        this.bu4 = this.businessUnit[3];
        this.re1 = this.restriction[0];
        this.re2 = this.restriction[1];
        this.re3 = this.restriction[2];
        this.re4 = this.restriction[3];

        this.ratingAgencyId = this.carrierRatingSummary.ratingAgencyId;
        this.ratingAgencyName = this.carrierRatingSummary.ratingAgencyName;
        this.ratings = this.carrierRatingSummary.ratings;
        this.outLook = this.carrierRatingSummary.outLook;
        this.date = this.carrierRatingSummary.date;
        this.reference = this.carrierRatingSummary.reference;

        if (this.businessUnit.length == 0) {
          this.x = 'noShow';
        }
        else { this.x = 'show' };
        if (this.restriction.length == 0) {
          this.y = 'noShow';
        } else {
          this.y = 'show';
        }

        if (!this._clientService.getRecentFlag()) {
          this._loaderService.hide()
        }
      })

  }


  // }

  openAddUrl(urlnumber: number) {

    let addUrlName: any;
    if (urlnumber === 1) {
      addUrlName = this.add1;
    }
    if (urlnumber === 2) {
      addUrlName = this.add2;
    }
    if (urlnumber === 3) {
      addUrlName = this.add3;
    }
    if (urlnumber === 4) {
      addUrlName = this.add4;
    }
    if (urlnumber === 5) {
      addUrlName = this.add5;
    }
    if (urlnumber === 6) {
      addUrlName = this.add6;
    }
    if (urlnumber === 7) {
      addUrlName = this.add7;
    }
    if (urlnumber === 8) {
      addUrlName = this.add8;
    }


    window.open(addUrlName, "_blank");
  }

  getApprovalStatusDetails() {
    this.selectedCarrier = this.localStorage.getObject('carriers');
    this.currentCarrierId = this.selectedCarrier.CarrierId;
    this.parentCarrierId = this.carrierGeneralInfo.carrierContactDetails.carrierMainEntity[3];
    if (this.parentCarrierId) {
      this.getCarrierApprovalStatusByCarrierId(this.parentCarrierId);
    }
    else {
      this.getCarrierApprovalStatusByCarrierId(this.currentCarrierId);
    }

  }


  getCarrierApprovalStatusByCarrierId(carrierId: number) {

    this.selectedCarrier = this.localStorage.getObject('carriers');
    this.carrierId = this.selectedCarrier.CarrierId;
    this._generalService.GetCarrierApprovalStatusByCarrierId(carrierId)
      .subscribe((result) => {
        this.approvalStatusResult = result;
      })

  }
  getCarrierRatingSummary(ratingAgencyId: number, ratingAgencyName: string) {

    this.selectedCarrier = this.localStorage.getObject('carriers');
    this.carrierId = this.selectedCarrier.CarrierId;
    this.ratingAgencyName = ratingAgencyName;
    this._generalService.GetCarrierRatingSummary(this.carrierId, ratingAgencyId)
      .subscribe((result) => {
        this.carrierRatingSummaryResult = result;

      })

  }

  getWillisShortNames() {

    this.selectedCarrier = this.localStorage.getObject('carriers');
    this.carrierId = this.selectedCarrier.CarrierId;
    this._generalService.GetWillisShortNames(this.carrierId)
      .subscribe((result) => {
        this.carrierWillisShortNameResult = result;

      })
  }

  Ownership() {
    this.selectedCarrier = this.localStorage.getObject('carriers');
    this.carrierId = this.selectedCarrier.CarrierId;
    this._clientService.setOwnership(this.carrierContactDetails.groupCodeId);
    this._router.navigateByUrl('/carrier-search/client/' + this._clientService.getAccountId());
  }

  getRatingAgencyNameDocument(documetratingAgencyName: string) {
    if (documetratingAgencyName === "A.M. Best") {
      this.downloadDoucmentName = "MosaicAMBestRatingDefinitions.pdf";
    }
    if (documetratingAgencyName === "Standard & Poor's") {
      this.downloadDoucmentName = "MosaicStandardAndPoorsRatingDefinitions.pdf";
    }
    if (documetratingAgencyName === "Moody's") {
      this.downloadDoucmentName = "MosaicMoodysInsurerRatingDefinitions.pdf";
    }
    if (documetratingAgencyName === "Fitch") {
      this.downloadDoucmentName = "MosaicFitchRatingDefinitions.pdf";
    }

    this._generalService
      .GetRatingAgencyNameDocument(this.downloadDoucmentName)
      .subscribe((result) => {
        this.downloadHelpDocument(result);
      }, (error) => console.log(error));
  }



  downloadHelpDocument(data) {
    var content = this.base64ToArrayBuffer(data.Content);
    var blob = new Blob([content], { type: data.ContentType });
    var fileName = this.downloadDoucmentName;
    var url = window.URL.createObjectURL(blob);
    FileSaver.saveAs(blob, fileName);
  }

  base64ToArrayBuffer(base64) {
    var binaryString = window.atob(base64);
    var binaryLen = binaryString.length;
    var bytes = new Uint8Array(binaryLen);
    for (var i = 0; i < binaryLen; i++) {
      var ascii = binaryString.charCodeAt(i);
      bytes[i] = ascii;
    }
    return bytes;
  }

  getCarrierDocs() {
    if (this.selectedCarrier && this.selectedAccountId) {
      if (this.selectedCarrier.WillisCode) {
        this._generalService.GetCarrierDocuments(this.selectedCarrier.WillisCode, this.selectedAccountId).subscribe(result => {
          if (result) {
            this.carrierDocs = result;
            this.carrierDocs.forEach(carrier => {
              if (carrier.CreatedOn) {
                var dateTransform = carrier.CreatedOn;
                dateTransform = dateTransform.substring(0, 9);
                carrier.CreatedOn = new Date(dateTransform);
              }
            });
          }

        })
      }
    }
  }

  downloadFile(doc) {
    if (doc) {
      this._generalService.GetDownloadedDocumentInfo(doc.DocumentId).subscribe(result => {
        this.fetchFile(result);

      })
    }
  }

  fetchFile(data) {
    var content = this.base64ToArrayBuffer2(data.Content);
    var blob = new Blob([content], { type: data.ContentType });
    var filename = data.Title;
    var url = window.URL.createObjectURL(blob);
    FileSaver.saveAs(blob, filename);
  }

  base64ToArrayBuffer2(base64) {
    var binaryString = window.atob(base64);
    var binaryLen = binaryString.length;
    var bytes = new Uint8Array(binaryLen);
    for (var i = 0; i < binaryLen; i++) {
      var ascii = binaryString.charCodeAt(i);
      bytes[i] = ascii;
    }
    return bytes;
  }

  //general Potrait
  downloadPDFGeneral1() {
    this.getDisclaimers();
    var quotes = document.getElementById('general');
    var pdf = new jsPDF('p', 'pt', 'a4');
    pdf.setLineWidth(0);
    pdf.setDrawColor(255, 255, 255);
    pdf.setFillColor(255, 255, 255);
    pdf.setFontSize(8);
    setTimeout(() => {
      var specialElementHandlers = {
        '#hidediv1': function (element, render) { return true; },
        '#address': function (element, render) { return true; }
      };
      pdf.fromHTML($('#title').get(0), 25, 25,
        {
          'width': 900
        });
      pdf.fromHTML($('#general').get(0), 25, 45,
        {
          'width': 950,
          'elementHandlers': specialElementHandlers
        });
      pdf.fromHTML($('#address').get(0), 460, 45,
        {
          'width': 50
        });
      pdf.setDrawColor(255, 255, 255);
      pdf.fromHTML($('#approvalStatus').get(0), 25, 245,
        {
          'width': 950,
          'elementHandlers': specialElementHandlers
        });
      pdf.setDrawColor(0, 0, 0);
      pdf.line(0, 800, 900, 800);
      pdf.fromHTML($('#footer-pot').get(0),
        140,
        800,
        {
          'width': 1100,
          'pagesplit': true,
          'elementHandlers': specialElementHandlers
        });
      pdf.addPage();
      pdf.setDrawColor(255, 255, 255);
      pdf.fromHTML($('#ratingsSummary').get(0), 25, 45,
        {
          'width': 1200,
          'elementHandlers': specialElementHandlers
        });
      pdf.setDrawColor(0, 0, 0);
      pdf.line(0, 800, 900, 800);
      pdf.fromHTML($('#footer-pot').get(0),
        140,
        800,
        {
          'width': 1100,
          'pagesplit': true,
          'elementHandlers': specialElementHandlers
        });
      pdf.addPage();
      pdf.fromHTML($('#dis').get(0),
        25,
        30,
        {
          'width': 530,
          'pagesplit': true,
          'elementHandlers': specialElementHandlers
        });
      pdf.line(0, 800, 900, 800);
      pdf.fromHTML($('#footer-pot').get(0),
        140,
        800,
        {
          'width': 1150,
          'pagesplit': true,
          'elementHandlers': specialElementHandlers
        });
      pdf.save('CarrierDetails_General.pdf');
    }, 1000);
  }
  //
  //PDF for SVG Generation
  downloadPDFGeneral() {
    // this.getDisclaimers();
    var ua = window.navigator.userAgent;
    var msie = ua.indexOf("MSIE ");
    if (msie > 0 || !!navigator.userAgent.match(/Trident.*rv\:11\./)) {
      this.downloadForIE();
    }
    else  // If another browser, return 0
    {
      var quotes = document.getElementById('customers');
      html2canvas(document.getElementById('customers')).then(function (canvas) {
        var pdf = new jsPDF('l', 'pt', 'a4');
        pdf.fromHTML($('#title').get(0),
          30,
          30,
          {
            'width': 750,
            'pagesplit': true
          });
        var source = $('#footer')[0];

        setTimeout(() => {
          for (var i = 0; i <= quotes.clientHeight / 850; i++) {
            var srcImg = canvas;
            var sX = 0;
            var sY = 850 * i; // start 700 pixels down for every new page
            var sWidth = 1200;
            var sHeight = 850;
            var dX = 0;
            var dY = 0;
            var dWidth = 1200;
            var dHeight = 850;

            window.onePageCanvas = document.createElement("canvas");
            onePageCanvas.setAttribute('width', 1200);
            onePageCanvas.setAttribute('height', 850);
            var ctx = onePageCanvas.getContext('2d');
            ctx.drawImage(srcImg, sX, sY, sWidth, sHeight, dX, dY, dWidth, dHeight);

            var canvasDataURL = onePageCanvas.toDataURL("image/png", 1.0);

            var width = onePageCanvas.width;
            var height = onePageCanvas.clientHeight;

            if (i > 0) {
              pdf.fromHTML($('#line').get(0),
                0,
                530,
                {
                  'width': 840,
                  'pagesplit': true,
                  'elementHandlers': specialElementHandlers
                });
              pdf.fromHTML($('#footer').get(0),
                250,
                550,
                {
                  'width': 550,
                  'pagesplit': true,
                  'elementHandlers': specialElementHandlers
                });
              pdf.addPage();
            }
            pdf.setPage(i + 1);

            pdf.addImage(canvasDataURL, 'PNG', 30, 30, (width * .60), (height * .72), undefined, 'FAST');
          }
          var specialElementHandlers = {
          };
          //pdf.line(0, 780, 900, 780);
          pdf.fromHTML($('#line').get(0),
            0,
            530,
            {
              'width': 840,
              'pagesplit': true,
              'elementHandlers': specialElementHandlers
            });
          pdf.fromHTML($('#footer').get(0),
            250,
            550,
            {
              'width': 550,
              'pagesplit': true,
              'elementHandlers': specialElementHandlers
            });
          pdf.addPage();
          pdf.setTextColor(0, 0, 0);
          pdf.fromHTML($('#dis').get(0),
            30,
            40,
            {
              'width': 750,
              'pagesplit': true,
              'elementHandlers': specialElementHandlers
            });
          pdf.fromHTML($('#line').get(0),
            0,
            530,
            {
              'width': 840,
              'pagesplit': true,
              'elementHandlers': specialElementHandlers
            });
          pdf.fromHTML($('#footer').get(0),
            250,
            550,
            {
              'width': 550,
              'pagesplit': true,
              'elementHandlers': specialElementHandlers
            });
          pdf.save('CarrierDetails-General.pdf');
        }, 1000);
      }
      );
    }
  }
  //ApprovalHistory
  historyModalPdf() {
    // this.getDisclaimers();
    var pdf = new jsPDF('p', 'pt', 'a4');
    setTimeout(() => {
      var specialElementHandlers = {
        '#hidediv2': function (element, render) { return true; },
        '#hidediv4': function (element, render) { return true; }
      };
      pdf.fromHTML($('#historyModal').get(0),
        40,
        40,
        {
          'width': 550,
          'pagesplit': true,
          'elementHandlers': specialElementHandlers
        });
      pdf.line(0, 780, 900, 780);
      pdf.fromHTML($('#footer').get(0),
        130,
        780,
        {
          'width': 550,
          'pagesplit': true,
          'elementHandlers': specialElementHandlers
        });
      pdf.addPage();
      pdf.fromHTML($('#dis').get(0),
        50,
        40,
        {
          'width': 500,
          'pagesplit': true,
          'elementHandlers': specialElementHandlers
        });
      pdf.line(0, 780, 900, 780);
      pdf.fromHTML($('#footer').get(0),
        130,
        780,
        {
          'width': 550,
          'pagesplit': true,
          'elementHandlers': specialElementHandlers
        });
      pdf.save('ViewHistory.pdf');
    }, 1000);
  }

  //AgencyHistory
  agencyHistoryModalPdf() {
    // this.getDisclaimers();
    var quotes = document.getElementById('agencyHistoryModal');
    var pdf = new jsPDF('p', 'pt', 'a4');
    setTimeout(() => {
      var specialElementHandlers = {
        '#hidediv3': function (element, render) { return true; },
        '#hidediv4': function (element, render) { return true; }
      };
      pdf.fromHTML($('#agencyHistoryModal').get(0),
        50,
        40,
        {
          'width': 650,
          'pagesplit': true,
          'elementHandlers': specialElementHandlers
        });
      pdf.line(0, 780, 900, 780);
      pdf.fromHTML($('#footer').get(0),
        130,
        780,
        {
          'width': 550,
          'pagesplit': true,
          'elementHandlers': specialElementHandlers
        });
      pdf.addPage();
      pdf.fromHTML($('#dis').get(0),
        50,
        40,
        {
          'width': 500,
          'pagesplit': true,
          'elementHandlers': specialElementHandlers
        });
      pdf.line(0, 780, 900, 780);
      pdf.fromHTML($('#footer').get(0),
        130,
        780,
        {
          'width': 550,
          'pagesplit': true,
          'elementHandlers': specialElementHandlers
        });
      pdf.save('AgencyHistory.pdf');
    }, 1000);
  }


  //WillisShortNames
  willisShortNamesModalPdf() {
    // this.getDisclaimers();
    var quotes = document.getElementById('willisShortNamesModal');
    var pdf = new jsPDF('p', 'pt', 'a4');
    setTimeout(() => {
      var specialElementHandlers = {
        '#hidediv1': function (element, render) { return true; },
        '#hidediv5': function (element, render) { return true; }
      };
      pdf.fromHTML($('#willisShortNamesModal').get(0),
        50,
        40,
        {
          'width': 650,
          'elementHandlers': specialElementHandlers
        });
      pdf.line(0, 780, 900, 780);
      pdf.fromHTML($('#footer').get(0),
        130,
        780,
        {
          'width': 550,
          'pagesplit': true,
          'elementHandlers': specialElementHandlers
        });
      pdf.addPage();
      pdf.fromHTML($('#dis').get(0),
        50,
        40,
        {
          'width': 500,
          'pagesplit': true,
          'elementHandlers': specialElementHandlers
        });
      pdf.line(0, 780, 900, 780);
      pdf.fromHTML($('#footer').get(0),
        130,
        780,
        {
          'width': 550,
          'pagesplit': true,
          'elementHandlers': specialElementHandlers
        });
      pdf.save('WilliShortNames.pdf');
    }, 1000);
  }

  openGeneralDisclaimer() {
    window.open("view-disclaimer", "_blank");
  }

  getDisclaimers() {
    let financialDisclaimer = this._financialService.GetDisclaimer();
    let WTWDisclaimer = this._disclaimerService.GetDisclaimer();
    let ratingDisclaimer = this._disclaimerService.GetRatingAgencies();

    Observable.forkJoin([financialDisclaimer, WTWDisclaimer, ratingDisclaimer]).subscribe(results => {
      this.disclaimerText.nativeElement.innerHTML = results[0];
      this.disclaimers.wtw = results[1].DisclaimerTextPlain;

      var ratingArray = [];
      var callback = [];
      results[2].forEach((re) => {
        if (re.RatingAgencyName === "A.M. Best") {
          this.amBestRatingAgencyID = re.RatingAgencyId;
          ratingArray.push(this._disclaimerService.GetDisclaimerByRatingAgencyId(this.amBestRatingAgencyID));
          callback.push((response) => {
            if (response.IsHidden == false) {
              this.disclaimers.amBest = response.DisclaimerTextPlain;
            }
          });
        }
        if (re.RatingAgencyName === "Standard & Poor's") {
          this.spRatingAgencyID = re.RatingAgencyId;
          ratingArray.push(this._disclaimerService.GetDisclaimerByRatingAgencyId(this.spRatingAgencyID));
          callback.push((response) => {
            if (response.IsHidden == false) {
              this.disclaimers.snp = response.DisclaimerTextPlain;
            }
          });
        }
        if (re.RatingAgencyName === "Moody's") {
          this.moodeysRatingAgencyID = re.RatingAgencyId;
          ratingArray.push(this._disclaimerService.GetDisclaimerByRatingAgencyId(this.moodeysRatingAgencyID));
          callback.push((response) => {
            if (response.IsHidden == false) {
              this.disclaimers.moodys = response.DisclaimerTextPlain;
            }
          });
        }
        if (re.RatingAgencyName === "Fitch") {
          this.fitchRatingAgencyID = re.RatingAgencyId;
          ratingArray.push(this._disclaimerService.GetDisclaimerByRatingAgencyId(this.fitchRatingAgencyID));
          callback.push((response) => {
            if (response.IsHidden == false) {
              this.disclaimers.fitch = response.DisclaimerTextPlain;
            }
          });
        }
      });

      Observable.forkJoin(ratingArray).subscribe(results => {
        callback[0](results[0]);
        callback[1](results[1]);
        callback[2](results[2]);
        callback[3](results[3]);
      });
    });
  }


  downloadStaticAuditFile() {
    this.selectedCarrier = this.localStorage.getObject('carriers');
    this._generalService.GetAuditInfo(this.selectedCarrier.WillisCode).subscribe(result => {
      this.auditUrl = this._sanitizer.bypassSecurityTrustResourceUrl(result);
    })
  }

  openDisclaimer() {
    this._footerEvents.footerDisclaimerEvent.emit(true);
  }

  downloadRegionalDocument() {
    this.downloadDoucmentName = 'MosaicRegionalDefinitions.pdf';
    this._generalService
      .GetRatingAgencyNameDocument('MosaicRegionalDefinitions.pdf')
      .subscribe((result) => {
        this.downloadHelpDocument(result);
      }, (error) => console.log(error));
  }

  getCarrierSecurityYears() {
    this.selectedYear = true;
    this.pdfBtn = true;
    this.selectedCarrier = this.localStorage.getObject('carriers');
    if (this.selectedCarrier && this.selectedCarrier.CarrierId)
      this._generalService.GetCarrierSecurityYears(this.selectedCarrier.CarrierId).subscribe(result => {
        this.carrierSecurityYears = result;
        var num: Array<number> = [];

        for (var i = 0; i < this.carrierSecurityYears.length; i++) {
          num.push(this.carrierSecurityYears[i].EndDate);
        }
        this.carrierSecurityYears.sort((a, b) => {
          if (a < b)
            return -1;
          if (a > b)
            return 1;

          return 0;

        });

        if (num.length > 0) {
          var max = num.reduce(function (a, b) {
            return Math.max(a, b);
          })

          this.selectedYearNumber = max.toString();
          // this.getSubCarrierDetails();
        }
      })
  }

  getSubCarrierDetails() {
    this.getDisclaimers();
    this.isSearchingClient = true;
    if (this.selectedYearNumber)
      this._generalService.GetSubCarrierDetails(this.selectedCarrier.CarrierId, this.selectedYearNumber).subscribe(result => {
        this.subCarriers = result;
        if (this.subCarriers.length > 0) {
          var id = this.subCarriers[0].Relationship1CarrierRelationshipID;
          this.subCarriers1 = [];
          this.subCarriers2 = [];
          this.subCarrier1 = null;
          this.subCarrier2 = null;
          this.subCarriers.forEach(sub => {
            if (sub.Relationship1CarrierRelationshipID == id) {
              this.subCarriers1.push(sub);
            } else {
              this.subCarriers2.push(sub);
            }
          })
          this.subCarriers1.forEach(sub1 => {
            if (sub1.Parent == null) {
              this.subCarrier1 = sub1;

            }
          })
          this.subCarriers2.forEach(sub2 => {
            if (sub2.Parent == null) {
              this.subCarrier2 = sub2;
            }
          })
          this.subCarriers1.splice(0, 1);
          this.subCarriers2.splice(0, 1);
          if (this.subCarrier1) {
            this.subCarriers1 = this.subCarriers1.filter(sub => sub.Parent == this.subCarrier1.Tag);
            this.subCarriers1.sort((a, b) => {
              if (a.Subrelationship2LegalName.toLowerCase() < b.Subrelationship2LegalName.toLowerCase())
                return -1;
              if (a.Subrelationship2LegalName.toLowerCase() > b.Subrelationship2LegalName.toLowerCase())
                return 1;

              return 0;

            });
          }

          if (this.subCarrier2) {
            this.subCarriers2 = this.subCarriers2.filter(sub => sub.Parent == this.subCarrier2.Tag);
            this.subCarriers2.sort((a, b) => {
              if (a.Subrelationship2LegalName.toLowerCase() < b.Subrelationship2LegalName.toLowerCase())
                return -1;
              if (a.Subrelationship2LegalName.toLowerCase() > b.Subrelationship2LegalName.toLowerCase())
                return 1;

              return 0;

            });
          }
        }

        this.isSearchingClient = false;
      }, error => {
        this.isSearchingClient = false;
      })

  }

  downloadPdfAgreeCarrier(select: boolean) {
    this.pdfBtn = true;
    if (select) {
      //For yes Selection
      this._loaderService.show();
      setTimeout(() => {
        this.hideStatus = false;
        this.hideStatusRes = false;
      }, 500);
      setTimeout(() => {
        this.hideStatus = true;
        this.hideStatusRes = true;
        this._loaderService.hide();
      }, 5000);
      var quotes = document.getElementById('approvalStatus');
      var pdf = new jsPDF('p', 'pt', 'a4');
      setTimeout(() => {
        var specialElementHandlers = {
          '#btn1': function (element, render) { return true; },
          '#btn2': function (element, render) { return true; },
          '#hidediv4': function (element, render) { return true; },
          '#status': function (element, render) { return true; },
          '#statusRes': function (element, render) { return true; }
        };
        pdf.fromHTML($('#head').get(0), 50, 70, {
        });
        pdf.fromHTML($('#approvalStatus').get(0), 50, 40,
          {
            'width': 650,
            'elementHandlers': specialElementHandlers
          });
        pdf.line(0, 780, 900, 780);
        pdf.fromHTML($('#footer-pot').get(0), 130, 780,
          {
            'width': 550,
            'pagesplit': true,
            'elementHandlers': specialElementHandlers
          });
        pdf.addPage();
        pdf.fromHTML($('#dis').get(0), 50, 40,
          {
            'width': 500,
            'pagesplit': true,
            'elementHandlers': specialElementHandlers
          });
        pdf.line(0, 780, 900, 780);
        pdf.fromHTML($('#footer-pot').get(0), 130, 780,
          {
            'width': 550,
            'pagesplit': true,
            'elementHandlers': specialElementHandlers
          });
        pdf.save('ApprovalStatusSupplementary.pdf');
      }, 1000);

    } else {
      this.hideStatus = true;
      this.hideStatusRes = true;
      var quotes = document.getElementById('approvalStatus');
      var pdf = new jsPDF('p', 'pt', 'a4');
      setTimeout(() => {
        var specialElementHandlers = {
          '#btn1': function (element, render) { return true; },
          '#btn2': function (element, render) { return true; },
          '#hidediv4': function (element, render) { return true; }
        };
        pdf.fromHTML($('#head').get(0), 50, 70, {
        });
        pdf.fromHTML($('#approvalStatus').get(0), 50, 40,
          {
            'width': 650,
            'elementHandlers': specialElementHandlers
          });
        pdf.line(0, 780, 900, 780);
        pdf.fromHTML($('#footer-pot').get(0), 130, 780,
          {
            'width': 550,
            'pagesplit': true,
            'elementHandlers': specialElementHandlers
          });
        pdf.addPage();
        pdf.fromHTML($('#dis').get(0), 50, 40,
          {
            'width': 500,
            'pagesplit': true,
            'elementHandlers': specialElementHandlers
          });
        pdf.line(0, 780, 900, 780);
        pdf.fromHTML($('#footer-pot').get(0), 130, 780,
          {
            'width': 550,
            'pagesplit': true,
            'elementHandlers': specialElementHandlers
          });
        pdf.save('ApprovalStatusSupplementary.pdf');
      }, 1000);
    }
  }

  showReportForAgreeCarriers() {
    this.selectedYear = true;
    this.getSubCarrierDetails();
  }

  goToSubCarrier(carrier: any) {
    if (carrier) {
      var cId: any = this.localStorage.getObject('account');
      var clientId = cId.AccountId;
      var carrierId = carrier.StringSubrelationship2SubCarrier_ID;
      var WTWcode = carrier.Subrelationship2CompanyCode;
      var code = 'code';
      var car = 'carrier';
      var client = 'client';
      var carriers = new Carrier(carrierId, carrier.Subrelationship2LegalName, null, carrier.Subrelationship2Country, null, null, carrier.Subrelationship2CompanyCode, null, null, null,
        null, null, null, null, null, null, null, null, null, null, null, null, null, null, '', '', null, null, null, null, null, null, null, null, null);
      this._clientService.setCarrierObject(carriers);
      this.localStorage.setObject('carriers', carriers);
      if (this.localStorage.getObject('carriers')) {
        this._carrierDetailsEvents.CarrierDetailUpdateEvent.emit(true);
        this._generalEvents.GeneralUpdateEvent.emit(true);
      }

      this._router.navigate(['carrier-detail', client, clientId, car, carrierId, code, WTWcode, 'general']);
      // window.location.reload();
    }
  }
  downloadForIE() {
    var quotes = document.getElementById('customers');
    html2canvas(document.getElementById('customers')).then(function (canvas) {
      var pdf = new jsPDF('l', 'pt', 'a4');
      pdf.fromHTML($('#title').get(0),
        10,
        10,
        {
          'width': 750,
          'pagesplit': true
        });
      // setTimeout(() => {
      for (var i = 0; i <= quotes.clientHeight / 800; i++) {
        var srcImg = canvas;
        var sX = 0;
        var sY = 800 * i; // start 700 pixels down for every new page
        var sWidth = 1050;
        var sHeight = 800;
        var dX = 0;
        var dY = 0;
        var dWidth = 1050;
        var dHeight = 800;

        window.onePageCanvas = document.createElement("canvas");
        onePageCanvas.setAttribute('width', 1200);
        onePageCanvas.setAttribute('height', 900);
        var ctx = onePageCanvas.getContext('2d');
        ctx.drawImage(srcImg, sX, sY, sWidth, sHeight, dX, dY, dWidth, dHeight);

        var canvasDataURL = onePageCanvas.toDataURL("image/png", 1.0);

        var width = onePageCanvas.width;
        var height = onePageCanvas.clientHeight;

        if (i > 0) {
          pdf.fromHTML($('#line').get(0),
            0,
            530,
            {
              'width': 840,
              'pagesplit': true,
              'elementHandlers': specialElementHandlers
            });
          pdf.fromHTML($('#footer').get(0),
            250,
            550,
            {
              'width': 550,
              'pagsplit': true,
              'elementHandlers': specialElementHandlers
            });
          pdf.addPage();
        }
        pdf.setPage(i + 1);

        pdf.addImage(canvasDataURL, 'PNG', 10, 10, (width * .60), (height * .72), undefined, 'FAST');
      }
      var specialElementHandlers = {
      };
      //pdf.line(0, 780, 900, 780);
      pdf.fromHTML($('#line').get(0),
        0,
        530,
        {
          'width': 840,
          'pagesplit': true,
          'elementHandlers': specialElementHandlers
        });
      pdf.fromHTML($('#footer').get(0),
        250,
        550,
        {
          'width': 550,
          'pagesplit': true,
          'elementHandlers': specialElementHandlers
        });
      pdf.addPage();
      pdf.setTextColor(0, 0, 0);
      pdf.fromHTML($('#dis').get(0),
        30,
        40,
        {
          'width': 750,
          'pagesplit': true,
          'elementHandlers': specialElementHandlers
        });
      pdf.fromHTML($('#line').get(0),
        0,
        530,
        {
          'width': 840,
          'pagesplit': true,
          'elementHandlers': specialElementHandlers
        });
      pdf.fromHTML($('#footer').get(0),
        250,
        550,
        {
          'width': 550,
          'pagesplit': true,
          'elementHandlers': specialElementHandlers
        });
      pdf.save('CarrierDetails.pdf');
      // }, 1000);
    }
    );
  }
}

// this.StringSubrelationship2SubCarrier_ID=CarrierId;
//         this.Subrelationship2LegalName=LegalName;
//         this.Subrelationship2Country=Country;
//         this.Subrelationship2CompanyCode=WillisCode;
//         this.Subrelationship2SubCarrierPercent=CombinedRatioPercentage;
//         this.Subrelationship2ApprovalStatusDesc=ApprovalStatus;
//         this.Relationship1EndDate=Relationship1EndDate;
//         this.Relationship1BeginDate=Relationship1BeginDate;
