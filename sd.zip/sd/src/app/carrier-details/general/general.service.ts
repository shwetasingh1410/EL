import { Injectable } from '@angular/core';
import { Http, RequestOptions, Headers } from '@angular/http';
import { Observable } from 'rxjs';
import 'rxjs/add/operator/map';

import { environment } from '../../../environments/environment';
import { carrierGeneralInfo, carrierContactDetails, carrierMainEntity, carrierApprovalStatus, carrierRatingSummary, carrierApprovalStatusAuditTrail, carrierRatingAuditTrail, carrierWillisShortName, carrierSecurityYears, subCarrier } from './general.model';
import { Settings } from '../../shared/settings/settings.service';
import { GeneralHelper } from './general.helper';
import { LoggedInUser } from '../../shared/loggedInUser/LoggedInUser';


@Injectable()

export class GeneralService {
    constructor(private _http: Http, private _settings: Settings,private _loggedInUser:LoggedInUser) { }

    GetCarrierGeneralInfo(companycode: string, year: number): Observable<carrierGeneralInfo> {
      return this._http.get(this._settings.getApiUrl() + 'api/carriers/' + companycode + '/general/year/' + year)
        .map((response) => {
          let detailsResult: carrierGeneralInfo;
          detailsResult = response.json();
          return detailsResult;
        });
    }

    GetAuditInfo(companycode: string) {
        return this._http.post(this._settings.getReportsUrl() + 'reports/carrier/Miscellaneous/params/companyCode='+ companycode +'|reportType=CarrierDetails|reportSubType=AuditTrail|reportNumber=31',
        JSON.stringify({ 'userId': this._loggedInUser.getUserId() }))
        .map((response) => {
            var url=response.json().substring(4);
            var result = this._settings.getReportsUrl() + url;
            return result;
        });  ;
    }

   GetCarrierRatingSummary(carrierid: number, ratingagencyid: number): Observable<Array<carrierRatingAuditTrail>> {
        return this._http.get(this._settings.getApiUrl() + 'api/carriers/' + carrierid + '/audit-trail/rating-agency/' + ratingagencyid)
            .map((response) => {
                let result: carrierRatingAuditTrail[] =[];
                let ratingAuditTrail = JSON.stringify(response.json().carrierRatingAuditTrail);
               JSON.parse(ratingAuditTrail).forEach((ratingTrail) => {
                 result.push(GeneralHelper.mapToRatingTrail(ratingTrail));
               });
                return result;

            });
    }
   
    GetCarrierApprovalStatusByCarrierId(carrierid: number): Observable<Array<carrierApprovalStatusAuditTrail>> {
        return this._http.get(this._settings.getApiUrl() + 'api/carriers/' + carrierid + '/audit-trail/approval-status')
            .map((response) => {
                let result: carrierApprovalStatusAuditTrail[] = [];
                let approvalStatus = JSON.stringify(response.json().carrierApprovalStatusAuditTrail);
                JSON.parse(approvalStatus).forEach((approvalStatusTrail) => {
                  result.push(GeneralHelper.mapToAuditTrailInfo(approvalStatusTrail));
                });
                return result;
            });
    }
   
    GetWillisShortNames(carrierid: number): Observable<Array<carrierWillisShortName>> {
        return this._http.get(this._settings.getApiUrl() + 'api/carriers/' + carrierid + '/short-names')
            .map((response) => {
                let result : carrierWillisShortName [] =[];
                let wtwShortNames = JSON.stringify(response.json().carrierWillisShortName);
                JSON.parse(wtwShortNames).forEach((shortName) => {
                  result.push(GeneralHelper.mapToWillisInfo(shortName));
                });
                return result;
            });
    }

    GetCarrierSecurityYears(carrierid: number): Observable<Array<carrierSecurityYears>> {
        return this._http.get(this._settings.getApiUrl() + 'api/carriers/' + carrierid + '/security-years')
        .map((response) => {
            let result: Array<carrierSecurityYears> = new Array<carrierSecurityYears>();
            response.json().forEach((year) => {
                result.push(GeneralHelper.mapToCarrierSecurityYears(year))
            });
            return result;
        });
    }

    GetSubCarrierDetails(carrierid: number,endDate: string): Observable<Array<subCarrier>> {
        return this._http.get(this._settings.getApiUrl() + 'api/carriers/' + carrierid + '/carrier-id/security-year/'+endDate)
        .map((response) => {
            let result: Array<subCarrier> = new Array<subCarrier>();
            response.json().forEach((carrier) => {
                result.push(GeneralHelper.mapToCarrier(carrier))
            });
            return result;
        });
    }


    // AddCarrierToRecentlyViewedList(companyCode: string) {
    //     let headers = new Headers();
    //     headers.append('Content-Type', 'application/json');
    //     let options = new RequestOptions({ headers: headers });
    //     return this._http.post(this._settings.getApiUrl() + 'api/statistics/add/' + companyCode,
    //         options).map((response) => response);
    // }

    GetRatingAgencyNameDocument(documetName:string) {
        return this._http.get(this._settings.getDocumentApiUrl() + 'api/documents/rating-agency-documents/' + documetName)
            .map((response) => response.json());

    }

    GetCarrierDocuments(CompanyCode:string,ClientId): Observable<any> {
                    let headers = new Headers();
                    headers.append('Content-Type', 'application/json');
                    let options = new RequestOptions({ headers: headers });
                    
                    return this._http.post(this._settings.getDocumentApiUrl() + 'api/documents/carrier-documents',
                        JSON.stringify({
                            'CompanyCode': CompanyCode,
                            'ClientId':ClientId,
                            'Called':'General'
                        }), options).map((response) => response.json());
            }

            GetDownloadedDocumentInfo(documentId): Observable<any> {
                return this._http.get(this._settings.getDocumentApiUrl() + 'api/documents/carrierDocument/'+documentId)
                    .map((response) => response.json());
            }

}
