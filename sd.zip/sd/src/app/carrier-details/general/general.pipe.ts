import { Pipe, PipeTransform } from '@angular/core';
import { DatePipe } from '@angular/common';

@Pipe({
  name: 'general'
})
export class GeneralDatePipe implements PipeTransform {

  transform(value: any, args: any[] = null): any {
    return Object.keys(value).map(key => value[key]);
  }

}


@Pipe({
  name: 'generalDateFormat'
})
export class GeneralDateFormatPipe extends DatePipe implements PipeTransform {
  transform(value: any, args?: any): any {
    return super.transform(value, Constants.DATE_FMT);
  }
}


export class Constants {
  static readonly DATE_FMT = 'MMM dd, yyyy';
}