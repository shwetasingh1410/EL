import { IPageAccessLevels } from '../../shared/page-access-levels/page-access-levels'

export class GeneralAccessLevels implements IPageAccessLevels {
    IsGeneralHyperlinkAvailable: boolean = true;
    IsWillisShortNameButtonAvailable: boolean = true;
    IsExportToPdfButtonAvailable: boolean = true;
    IsCarrierInformationAvailable: boolean = true;
}