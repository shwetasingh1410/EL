﻿import { Injectable } from '@angular/core';
import { Http, RequestOptions, Headers } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import { Settings } from '../shared/settings/settings.service';
import { ClientService } from '../select-client/client.service';
import { LoggedInUser } from '../shared/loggedInUser/LoggedInUser';
import { CoolSessionStorage } from 'angular2-cool-storage';
import { Carrier,SearchRequest} from '../carrier-search/carriersearch.model';
import { CarrierSearchHelper } from '../carrier-search/carriersearch.helper';
import { serializeUrlParams } from '../shared/http/http.factory';

@Injectable()
export class CarrierDetailsService {
    reportUrl: string;
    summaryUrl: string;
    formAMGraphUrl: string;
    formSnPGraphUrl: string;
    formAMGraphUrl2: string;
    formSnPGraphUrl2: string;
    value: number;
    param1: number;
    param2: number;
    HideTablix: number;
    pdfUrl: string;
    excelUrl: string;
    summaryPdfUrl: string;
    summaryPdfIndicator: boolean = false;
    localStorage:CoolSessionStorage;
    selectedCarrier;
    showUnderlyingSecurity:boolean;
    generalInfo:any;
    companyType: string;

    constructor(localStorage:CoolSessionStorage, private _settings: Settings, private _clientService: ClientService, private _loggedInUser: LoggedInUser, private _http: Http) {
        this.localStorage=localStorage;
        // this.selectedCarrier=this.localStorage.getObject('carriers');
        this.param1 = 1;
        this.param2 = 1;

        // get first carrier
        if (this.selectedCarrier !== undefined) {
            
        }
    }

    getSearchResult(searchRequest: SearchRequest) {
        let params: URLSearchParams = serializeUrlParams(searchRequest);
        return this._http.get(this._settings.getApiUrl() + 'api/carriers?' + params.toString())
            .map((response) => this.getSearchResultHandler(response));
    }

    getSearchResultHandler(response) {
        let result: Array<Carrier> = new Array<Carrier>();
        response.json().forEach((carrier) => {
            result.push(CarrierSearchHelper.mapToCarrier(carrier))
        });
        return result;
    }

    getReportsUrl(url: string, parameters: string) {
        return this._http.post(url + parameters, JSON.stringify({ 'userId': this._loggedInUser.getUserId() }))
            .map((response) => {
                return response.json();
            });
    }

    getReportUrl() {
        return this.reportUrl;
    }

    getPdfUrl() {
        return this.pdfUrl;
    }
    getExcelUrl() {
        return this.excelUrl;
    }

    getSummaryUrl(value:boolean) {
        this.showUnderlyingSecurity=false;
        return this.summaryUrl + this.showUnderlyingSecurity;
    }

    getSummaryPdfUrl() {
        return this.summaryPdfUrl;
    }

    getFormAMGraphUrl(HideTablix) {
        this.setDataforAM(HideTablix);
        return this.formAMGraphUrl;
    }
    getFormSnPGraphUrl(HideTablix) {
        this.setDataforSnP(HideTablix);
        return this.formSnPGraphUrl;
    }
    getFormAMGraphUrl2(HideTablix) {
        return this.formAMGraphUrl2;
    }
    getFormSnPGraphUrl2(HideTablix) {
        return this.formSnPGraphUrl2;
    }
    getDataforAM() {
        return this.param1;
    }

    setDataforAM(param1) {
        this.param1 = 0;
    }
    setDataforSnP(param2) {
        return this.param2;
    }

    hideSummaryPdf_old(companyType: string) {
    
        var generalInfo=this.getGeneralInfo();
        let validCompanyType = "u.s. property & casualty";
        let validCompanyType2 = "us pc combined entities";
        let validCompanyType3 = "u.s. life & health";
       if(generalInfo){
        if (validCompanyType.includes(generalInfo.carrierContactDetails.type.toLowerCase())) {
            this.summaryPdfIndicator = true;
        }
        else if(validCompanyType2.includes(generalInfo.carrierContactDetails.type.toLowerCase())){
            this.summaryPdfIndicator = true;   
        }
        else if(validCompanyType3.includes(generalInfo.carrierContactDetails.type.toLowerCase())){
            this.summaryPdfIndicator = true;  
            
        }
        else {
            this.summaryPdfIndicator = false;
        }
       }
       else if(companyType){
        if (validCompanyType == companyType.toLowerCase()) {
            this.summaryPdfIndicator = true;
        }
        else if(validCompanyType2 == companyType.toLowerCase()){
            this.summaryPdfIndicator = true;   
        }
        else if(validCompanyType3 == companyType.toLowerCase()){
            this.summaryPdfIndicator = true;  
            
        }
        else{
            this.summaryPdfIndicator = false;
        }

       }
        return this.summaryPdfIndicator;
    }

    getLicenseCountries(carrierId : string) {
        return this._http.get(this._settings.getApiUrl() + 'api/carriers/' + carrierId + '/licenses/countries')
            .map((response) => {
                return response.json().length;
            });
    }

    getReportDetails(companyCode: string) {
        return this._http.get(this._settings.getApiUrl() + 'api/carriers/' + companyCode + '/reportDetails')
            .map((response) => {
                return response.json();
            });
    }

    callSetter(carrier) {
        this.selectedCarrier=carrier;
        this.setReportData();
    }

    setReportData(){
        this.reportUrl = this._settings.getReportsUrl() + 'reports/carrier/' +
        this.selectedCarrier.WillisCode + '/params/currentYear=' +
         new Date().getFullYear() + '|companyCode=' +this.selectedCarrier.WillisCode
         + '|reportType=';

     this.pdfUrl = this._settings.getReportsUrl() + 'reports/carrier/' +
        this.selectedCarrier.WillisCode + '/params/currentYear=' +
         new Date().getFullYear() + '|companyCode=' +this.selectedCarrier.WillisCode
         + '|reportType=Financials|reportSubType=FactSheet|exportReport=true|exportFormat=pdf';

     this.excelUrl = this._settings.getReportsUrl() + 'reports/carrier/' +
        this.selectedCarrier.WillisCode + '/params/currentYear=' +
         new Date().getFullYear() + '|companyCode=' +this.selectedCarrier.WillisCode
         + '|reportType=Financials|reportSubType=CombinedExcel|exportReport=true|exportFormat=excel';

     this.summaryUrl = this._settings.getSummaryUrl() + 'reports/carrier/' +
        this.selectedCarrier.WillisCode + '/params/currentYear=' +
         new Date().getFullYear() + '|companyCode=' +this.selectedCarrier.WillisCode
         + '|reportType=Summary' + '|reportSubType=Summary' + '|URLToSearch=www~google~com' + '|showlkbtSupplementary=';

     /*this.formAMGraphUrl = this._settings.getFormAMGraphUrl() + 'reports/carrier/' +
        this.selectedCarrier.WillisCode + '/params/currentYear=' +
         new Date().getFullYear() + '|companyCode=' +this.selectedCarrier.WillisCode
         + '|reportType=Summary' + '|reportSubType=Summary' + '|hideChart=3' + '|hideTablix=' + this.getDataforAM() + '|reportNumber=12';

     this.formSnPGraphUrl = this._settings.getFormSnPGraphUrl() + 'reports/carrier/' +
        this.selectedCarrier.WillisCode + '/params/currentYear=' +
         new Date().getFullYear() + '|companyCode=' +this.selectedCarrier.WillisCode
         + '|reportType=Summary' + '|reportSubType=Summary' + '|hideChart=3' + '|hideTablix=' + this.setDataforSnP(this.value) + '|reportNumber=13';

     this.formAMGraphUrl2 = this._settings.getFormAMGraphUrl() + 'reports/carrier/' +
        this.selectedCarrier.WillisCode + '/params/currentYear=' +
         new Date().getFullYear() + '|companyCode=' +this.selectedCarrier.WillisCode
         + '|reportType=Summary' + '|reportSubType=Summary' + '|hideChart=3' + '|hideTablix=0' + '|reportNumber=12';

     this.formSnPGraphUrl2 = this._settings.getFormSnPGraphUrl() + 'reports/carrier/' +
        this.selectedCarrier.WillisCode + '/params/currentYear=' +
         new Date().getFullYear() + '|companyCode=' +this.selectedCarrier.WillisCode
         + '|reportType=Summary' + '|reportSubType=Summary' + '|hideChart=3' + '|hideTablix=0' + '|reportNumber=13';*/
     // console.log(this.reportUrl);
     //console.log(this.pdfUrl);
     this.summaryPdfUrl = this._settings.getReportsUrl() + 'reports/carrier/' +
        this.selectedCarrier.WillisCode + '/params/currentYear=' +
         new Date().getFullYear() + '|companyCode=' +this.selectedCarrier.WillisCode
         + '|reportType=Summary|reportSubType=1PagerB|exportReport=true|exportFormat=pdf';
    }

    setGeneralInfo(generalInfo:any) {
        this.generalInfo=generalInfo;
    }

    getGeneralInfo() {
        return this.generalInfo;
    }
    setCompanyType(companyType) {
        this.companyType = companyType;
    }

    getCompanyType() {
        return this.companyType;
    }
    
    hideSummaryPdf(companyType: string) {
        let selectedCompanyType = companyType.toLowerCase();
        let validCompanyType = "u.s. property & casualty";
        let validCompanyType2 = "us pc combined entities";
        let validCompanyType3 = "u.s. life & health";
        if (selectedCompanyType == validCompanyType || selectedCompanyType == validCompanyType2 || selectedCompanyType == validCompanyType3) {
            this.summaryPdfIndicator = true;
        }
        else {
            this.summaryPdfIndicator = false;
        }
        return this.summaryPdfIndicator;
    }
}