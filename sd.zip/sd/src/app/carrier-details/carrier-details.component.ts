﻿import { Component, OnInit, OnDestroy, Inject } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { DOCUMENT } from '@angular/platform-browser';
declare var $: any;

import { Carrier, SearchRequest, Account } from '../carrier-search/carriersearch.model';
import { CarrierSearchService } from '../carrier-search/carriersearch.service';
import { ClientService } from '../select-client/client.service';
import { CarrierDetailsService } from './carrier-details.service';
import { CarrierDetailsEvents } from './carrier-details.events';
import { PageAccessHelper } from '../shared/page-access-levels/page-access-levels.helper';
import { CarrierDetailsAccessLevels } from './carrier-details.access-levels';
import { CoolSessionStorage } from 'angular2-cool-storage';
import { LoggedInUser } from '../shared/loggedInUser/LoggedInUser';
import { TranslateService } from '../translate/translate.service';
import { GeneralService } from './general/general.service';
import { GeneralEvents } from './general/general.events';
import { SummaryEvents } from './summary/summary.events';
import { FinancialsEvents } from './financials/financials.events';
import { DocumentsEvents } from './documents/documents.events';
import { LicensesEvents } from './licenses/licenses.events';
import { carrierGeneralInfo } from './general/general.model';
import { LoaderService } from '../shared/loaderComponent/Loader.service';


@Component({
  selector: 'app-carrier-details',
  templateUrl: './carrier-details.component.html',
  styleUrls: ['./carrier-details.component.css'],
  providers: [CarrierDetailsService, PageAccessHelper, CarrierSearchService, GeneralService]
})
export class CarrierDetailsComponent implements OnInit, OnDestroy {

  selectedCarrier;
  id;
  carrierId;
  clientId;
  sub;
  country;
  pageAccessLevels: CarrierDetailsAccessLevels;
  localStorage: CoolSessionStorage;
  searchRequest: SearchRequest;
  carrier: Carrier;
  financials;
  willisCode: string = '';
  carrierGeneralInfo: carrierGeneralInfo;
  private _subscribe;
  //reportUrl: string;
  summaryPdfIndicator: boolean = false;
  constructor(private _loggedInUser: LoggedInUser, private _carrierSearchService: CarrierSearchService, private _router: Router, private _route: ActivatedRoute, private _clientService: ClientService,
    private _carrierDetailsService: CarrierDetailsService, private _pageAccessHelper: PageAccessHelper, localStorage: CoolSessionStorage, private _translate: TranslateService, private _generalService: GeneralService, private _carrierDetailsEvents: CarrierDetailsEvents,
    private _generalEvents: GeneralEvents, private _summaryEvents: SummaryEvents, private _financialsEvents: FinancialsEvents, private _documentsEvents: DocumentsEvents, private _licensesEvents: LicensesEvents, @Inject(DOCUMENT) private document: any, private _loaderService: LoaderService) {
    this.localStorage = localStorage;
    this.searchRequest = new SearchRequest();
    this.pageAccessLevels = new CarrierDetailsAccessLevels();

  }
  ngOnInit() {
    this._translate.use('en');
    this._subscribe = this._carrierDetailsEvents.CarrierDetailUpdateEvent.subscribe(
      (showMenu) => {
        this.ngOnInit();
        this._subscribe.unsubscribe();
      }
    );
    if (this.localStorage.getObject('carriers') == undefined) {
      if (!this.localStorage.getObject('carriers'))
        this._router.navigateByUrl('/carrier-search');
    }

    this._pageAccessHelper.getPageAccessLevelsDetails("carrier-detail", this.pageAccessLevels);
    // get first carrier
    if (this.localStorage.getObject('carriers'))
      this.selectedCarrier = this.localStorage.getObject('carriers');
    this.willisCode = this.selectedCarrier.WillisCode;
    this.willisCode = this.willisCode.toUpperCase();

    this._carrierDetailsService.setCompanyType(this.selectedCarrier.CompanyType);
    if (this.selectedCarrier.CompanyType == 'undefined' || this.selectedCarrier.CompanyType == undefined) {
      this.companyTypeValue();
    }
    // if (this.selectedCarrier.CompanyType != undefined) {
    //   this._carrierDetailsService.getCompanyType();
    // }

    this.sub = this._route.params.subscribe(params => {
      this.id = params['codeId'];
      this.id = this.id.toUpperCase();
      this.clientId = params['clientId'];
      this._clientService.setAccountId(this.clientId);
      this.carrierId = params['carrierId'];

      this._clientService.setDetailCarrierId(this.selectedCarrier.CarrierId);
      if (this._clientService.getRecentFlag()) {
        var url: string = this.document.location.href;
        this._loaderService.show()
        if (url.endsWith('general')) {

          // this.selectedCarrier=this.localStorage.getObject('carriers');
          this._generalEvents.GeneralUpdateEvent.emit(true);
        }

      }

      if (this.selectedCarrier)
        if (this.selectedCarrier.WillisCode != this.id) {
          if (this.localStorage) {
            this.localStorage.setObject('account', account);
            // this._carrierSearchService.getAccounts(this._loggedInUser.getUserRoleCode(), this._loggedInUser.getEncryptedUserId()).subscribe(result => {
            var accounts: Array<Account>;
            var account: Account;
            var index = accounts.findIndex(acc => acc.AccountId == params['clientId']);
            if (index != -1) {
              account = accounts[index];
            } else {
              this._router.navigate(['forbidden']);
            }
            this.searchRequest.LegalNameOperator = '1';
            this.searchRequest.RatingAgencyOperator = '0';
            this.searchRequest.CodeSelection = 'willis';
            this.searchRequest.Code = this.id;
            this.searchRequest.ClientId = account.Id;
            this._carrierDetailsService.getSearchResult(this.searchRequest).subscribe(result => {
              if (result)
                this.carrier = result[0];
              else
                this._router.navigate(['forbidden']);

              if (this.carrier) {
                // this.getLicenseCountries();
                // this.getReportDetails(this.carrier.WillisCode);
                // this.getCarrierGeneralInfo(this.carrier.WillisCode,new Date().getFullYear());
                this.selectedCarrier = this.carrier;
                this.localStorage.setItem('clientId', this.clientId);
                this.localStorage.setObject('carriers', this.carrier);
                this.localStorage.setObject('account', account);
                this._clientService.setDetailCarrierId(this.carrierId);
                if (this.willisCode != this.id) {
                  var url: string = this.document.location.href;
                  this.carrierGeneralInfo = null;
                  if (url.endsWith('general')) {

                    this._carrierDetailsEvents.CarrierDetailUpdateEvent.emit(true);
                    this._generalEvents.GeneralUpdateEvent.emit(true);
                  }
                  else if (url.endsWith('summary')) {


                    this._carrierDetailsEvents.CarrierDetailUpdateEvent.emit(true);
                    this._summaryEvents.SummaryUpdateEvent.emit(true);
                  }
                  else if (url.endsWith('financials')) {
                    this._carrierDetailsService.getReportDetails(this.selectedCarrier.WillisCode).subscribe(result => {
                      let reportId = result;
                      if (reportId > 7 && reportId < 12) {
                        if (reportId == 10) //ReportCarrierDetailSummary_LloydsSyndicate
                        {
                          this.financials = 1;
                          this._carrierDetailsEvents.CarrierDetailUpdateEvent.emit(true);
                          this._financialsEvents.FinancialsUpdateEvent.emit(true);
                        }
                        else {
                          this.financials = 0;
                          this._router.navigate(['forbidden']);
                        }
                      }
                      else {
                        this.financials = 1;
                        this._carrierDetailsEvents.CarrierDetailUpdateEvent.emit(true);
                        this._financialsEvents.FinancialsUpdateEvent.emit(true);
                      }
                    });
                  }
                  else if (url.endsWith('documents')) {


                    this._carrierDetailsEvents.CarrierDetailUpdateEvent.emit(true);
                    this._documentsEvents.DocumentsUpdateEvent.emit(true);
                  }
                  else if (url.endsWith('licenses')) {
                    this._carrierDetailsService.getLicenseCountries(this.selectedCarrier.CarrierId).subscribe(result => {
                      let count = result;
                      if (count > 0) {
                        this.country = 0;
                        this._carrierDetailsEvents.CarrierDetailUpdateEvent.emit(true);
                        this._licensesEvents.LicensesUpdateEvent.emit(true);
                      }
                      else {
                        this.country = 1;
                        this._router.navigate(['forbidden']);
                      }
                    });
                  } else {
                    this._router.navigate(['forbidden']);
                  }
                  //  this._router.navigate(['carrier-detail','client',account.AccountId,'carrier',this.carrier.CarrierId,'code',this.id,'general']);
                  //window.location.reload();
                }
              }
              else {
                this._router.navigate(['forbidden']);
              }

            })
            // });
          }
          else {

            this.getLicenseCountries();
            this.getReportDetails(this.selectedCarrier.WillisCode);
            this._carrierDetailsService.callSetter(this.selectedCarrier);
            this.getCarrierGeneralInfo(this.selectedCarrier.WillisCode, new Date().getFullYear());
          }
        }
    })
  }

  navigate(dest: string) {
    this._router.navigate([dest], { relativeTo: this._route })
  }

  ngOnDestroy() {
  }

  getLicenseCountries() {
    this._carrierDetailsService.getLicenseCountries(this.selectedCarrier.CarrierId).subscribe(result => {
      let count = result;
      if (count > 0)
        this.country = 0;
      else
        this.country = 1;
    });
  }

  getReportDetails(companyCode: string) {
    this._carrierDetailsService.getReportDetails(companyCode).subscribe(result => {
      let reportId = result;
      if (reportId > 7 && reportId < 12) {
        if (reportId == 10) //ReportCarrierDetailSummary_LloydsSyndicate
          this.financials = 1;
        else
          this.financials = 0;
      }
      else
        this.financials = 1;
    });
  }

  getCarrierGeneralInfo(companyCode: string, year: number) {
    this._generalService.GetCarrierGeneralInfo(companyCode, year)
      .subscribe(CarrierGeneralInfoResult => {
        this.carrierGeneralInfo = CarrierGeneralInfoResult;
        // this._clientService.setNewSearch(true);
        this._carrierDetailsService.setGeneralInfo(this.carrierGeneralInfo);
        if (this._clientService.getRecentFlag()) {
          setTimeout(() => {
            this._loaderService.hide();
          }, 30000);
          this._clientService.setRecentFlag(false);
        }
      })
  }
  companyTypeValue() {
    this._generalService.GetCarrierGeneralInfo(this.selectedCarrier.WillisCode, new Date().getFullYear())
      .subscribe(CarrierGeneralInfoResult => {
        if (CarrierGeneralInfoResult) {
          this.carrierGeneralInfo = CarrierGeneralInfoResult;
          this._carrierDetailsService.setCompanyType(this.carrierGeneralInfo.carrierContactDetails.type)
          this.summaryPdfIndicator = this._carrierDetailsService.hideSummaryPdf(this.carrierGeneralInfo.carrierContactDetails.type);

        }
      })
  }
}
