﻿import { Injectable } from '@angular/core';
import { Http, RequestOptions, Headers } from '@angular/http';
import { Observable } from 'rxjs/Rx';
import 'rxjs/add/operator/map';
import { RecentlyViewedCarriers} from './recently-viewed-carriers.model';

import { Settings } from '../shared/settings/settings.service';
import { LoggedInUser } from '../shared/loggedInUser/LoggedInUser';

@Injectable()
export class RecentlyViewedCarriersService {
    constructor(private _http: Http, private _settings: Settings, private _loggedInUser: LoggedInUser) {
    }

    getRecentlyViewedCarriers(): Observable<Array<RecentlyViewedCarriers>> {
        return this._http.get(this._settings.getApiUrl() + 'api/statistics/recently-viewed')
            .map((response) => this.getRecentlyViewedCarriersHandler(response.json()));
    }

    getRecentlyViewedCarriersHandler(response) {
        let link: string;
        let result: Array<RecentlyViewedCarriers> = new Array<RecentlyViewedCarriers>();
        response.forEach((carrier) => {
            result.push(new RecentlyViewedCarriers(carrier.CarrierId, carrier.LegalName, carrier.ViewedDate, carrier.WillisCode, carrier.Country, carrier.CarrierNumberId));
        });

        return result;
    }

    AddCarrierToRecentlyViewedList(companyCode: string) {
        let headers = new Headers();
        headers.append('Content-Type', 'application/json');
        let options = new RequestOptions({ headers: headers });
        return this._http.post(this._settings.getApiUrl() + 'api/statistics/add/' + companyCode,
            options).map((response) => response);
    }
}


