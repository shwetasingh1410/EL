import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RecentlyViewedCarriersComponent } from './recently-viewed-carriers.component';

describe('RecentlyViewedCarriersComponent', () => {
  let component: RecentlyViewedCarriersComponent;
  let fixture: ComponentFixture<RecentlyViewedCarriersComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RecentlyViewedCarriersComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RecentlyViewedCarriersComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
