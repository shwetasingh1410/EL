﻿import { Component, OnInit, OnDestroy } from '@angular/core';
import { TranslateService } from '../translate/translate.service';
import { RecentlyViewedCarriersService } from './recently-viewed-carriers.service';
import { Carrier } from "app/carrier-search/carriersearch.model";
import { RecentlyViewedCarriers } from './recently-viewed-carriers.model';
import { ClientService } from '../select-client/client.service';
import { LoggedInUser } from '../shared/loggedInUser/LoggedInUser';
import { Router } from '@angular/router';
//import { SafeContentPipe } from './safe-content.pipe';
import { CoolSessionStorage } from 'angular2-cool-storage';
import { AppEvents } from '../app.events';

declare var $: any;
@Component({
  selector: 'app-recently-viewed-carriers',
  templateUrl: './recently-viewed-carriers.component.html',
  styleUrls: ['./recently-viewed-carriers.component.css'],
  providers: [RecentlyViewedCarriersService],
  //encapsulation: ViewEncapsulation.None
})
export class RecentlyViewedCarriersComponent implements OnInit, OnDestroy {
  carriers: Array<RecentlyViewedCarriers>;
  localStorage: CoolSessionStorage;
  private _subscription;
  constructor(private _recentlyViewedCarriersService: RecentlyViewedCarriersService,
    private _translate: TranslateService, private _clientService: ClientService,
    private _loggedInUser: LoggedInUser, private _router: Router, localStorage: CoolSessionStorage,
    private _appEvents: AppEvents) {
    this.localStorage = localStorage;
  }

  ngOnInit() {
    this.selectLang('en');

    this.displayRecentlyViewedCarriers();

    this._subscription = this._appEvents.AddRecentlyViewedCarrierEvent.subscribe(
      (params) => {
        this.addCarrierToRecentlyViewedList(params);
        this._subscription.unsubscribe();
      }, (error) => {
        //this.handleError(error)
      }
    );
  }

  ngOnDestroy() {
    if (this._subscription && this._subscription != null)
      this._subscription.unsubscribe();
  }

  selectLang(lang: string) {
    // set current lang;
    this._translate.use(lang);
  }

  displayRecentlyViewedCarriers() {
    this._recentlyViewedCarriersService.getRecentlyViewedCarriers().subscribe((result) => {
      this.carriers = result;
    });
  }

  addCarrierToRecentlyViewedList(carrier: any) {
    this._recentlyViewedCarriersService.AddCarrierToRecentlyViewedList(carrier.WillisCode)
      .subscribe((result) => {
      });

    var recentlyAddedCarrier = new RecentlyViewedCarriers(carrier.CarrierId, carrier.LegalName, null, carrier.WillisCode, carrier.Country, carrier.CarrierNumberId);
    var index = this.carriers.findIndex(item => item.WillisCode == carrier.WillisCode);
    if (index !== -1) {
      this.carriers.splice(index, 1);
    }
    this.carriers.unshift(recentlyAddedCarrier);
    if (this.carriers.length > 10) {
      for (var i = 0; i < this.carriers.length - 10; i++) {
        this.carriers.pop();
      }
    }
  }

  navigateToCarrierDetails_carrier(index: number) {
    var data = this.carriers[index];
    this._clientService.setCarrierObject(data);
    var code = 'code';
    var carrier = 'carrier';
    var client = 'client';
    //var account = this._clientService.getSelectedAccount();
    this.localStorage.setObject('carriers', data);
    this._clientService.setRecentFlag(true);
    var account: any = this.localStorage.getObject('account');
    var tabName
    if (this._loggedInUser.getUserRoleCode() != "ClientRead") {
      tabName = "general";
    }
    else {
      tabName = "summary";
    }
    if (account)
      this._router.navigate(['carrier-detail', client, account.AccountId, carrier, data.CarrierId, code, data.WillisCode, tabName]);
    else {
      this._clientService.setRevertUrl(tabName);
      this._router.navigate(['select-client']);
    }
  }
}

