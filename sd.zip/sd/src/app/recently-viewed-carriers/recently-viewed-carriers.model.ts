export class RecentlyViewedCarriers {
    CarrierId: number;
    LegalName: string;
    ViewedDate: Date;
    WillisCode: string;
    Country: string;
    CarrierNumberId : number;

    constructor(CarrierId: number, LegalName: string, ViewedDate: Date, WillisCode: string, Country: string, CarrierNumberId : number) {
        this.CarrierId = CarrierId;
        this.LegalName = LegalName;
        this.ViewedDate = ViewedDate;
        this.WillisCode = WillisCode;
        this.Country = Country;
        this.CarrierNumberId = CarrierNumberId;
    }
}