import { IPageAccessLevels } from '../shared/page-access-levels/page-access-levels'

export class CarrierFavoritesAccessLevels implements IPageAccessLevels {
    isClientPopupAvailable: boolean = false;
   
}