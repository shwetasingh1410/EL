import { Component, OnInit } from '@angular/core';
import { LoggedInUser } from '../shared/loggedInUser/LoggedInUser';
import { Router } from '@angular/router';
import * as _ from "lodash";
import { LoaderService } from '../shared/loaderComponent/Loader.service';
import { CarrierFavService } from './carrierfavorites.service';
import { ClientService } from '../select-client/client.service';
import { Carrier } from '../carrier-search/carriersearch.model';
import { CreateFavoriteCategory, UpdateFavoriteCategory, FavoriteCategory, FavoriteGroup, FavoriteType, CarrierFavorite } from './carrierfavorites.model';
import { SelectClientHelper } from '../select-client/select-client.helper';
import { Account } from '../select-client/select-client.model';
import { GridOptions } from "ag-grid";
import { PageAccessHelper } from '../shared/page-access-levels/page-access-levels.helper';
import { CarrierFavoritesAccessLevels } from './carrierfavorites.access-levels';
import { Observable } from 'rxjs/Rx';
import 'rxjs/add/operator/catch';
import { CoolSessionStorage } from 'angular2-cool-storage';

declare var $:any;
@Component({
  selector: 'app-carrierfavorites',
  templateUrl: './carrierfavorites.component.html',
  styleUrls: ['./carrierfavorites.component.css'],
  providers: [CarrierFavService, LoggedInUser,PageAccessHelper  ]
})
export class CarrierFavoritesComponent implements OnInit {
  selectedCategory: FavoriteCategory;
  categoryNameToUpdate: string;
  groupNameToUpdate: string;
  selectedGroup: FavoriteGroup;
  selectedCarrier: Carrier;
  newCategory: string='';
  CategoryId: string;
  CategoryName: string='';
  NewCategoryName: string='';
  carrierFavoriteToUpdate: string;
  favorite: string='';
  showTable: boolean;
  GroupId: string;
  categoryToUpdate: string;
  FavoriteType: number;
  ClientId: string;
  createdCategory: string;
  createdFavorite: string;
  isError: boolean;
  isSuccess: boolean;
  isShowSuccess: boolean;
  isShowDelete: boolean;
  isShowError: boolean;
  message: string;
  saveSuccess: false;
  selectedCategoryId: string;
  selectedCategory1: string='';
  createdCategoryId: string;
  carrierFavoriteToDelete: string;
  selectedGroupId: string;
  selectedGroupName: string='';
  duplicateGroupName: string='';
  selectedCategoryName: string='';
  duplicateCategoryName: string='';
  categorytoDelete: string;
  GroupName: string='';
  NewGroupName: string='';
  account: Account;
  groupIdToMap: string;
  categoryIdToMap: string;
  categories: Array<FavoriteCategory>;
  typeCategories: Array<FavoriteCategory>;
  typeFavorites: Array<FavoriteGroup>;
  favorites: Array<FavoriteGroup>;
  carriers: Array<CarrierFavorite>;
  selectModeType;
  selectedAccount;
  selectModeTypeName : string;
  gridOptions: GridOptions;
  carrierIds: Array<String>;
  carrierWTWCode: Array<String>;
  selectedCarrierIds: Array<String>;
  isgroupselected:boolean;
  isrowselected:boolean;
  favname:string;
  currentGrpId:string
  allowed:boolean;
  groupallowed:boolean;
  newallowed:boolean;
  allowpush:boolean=true;
  onChangeModeType:number;
  localStorage:CoolSessionStorage;
  pageAccessLevels: CarrierFavoritesAccessLevels;
  newBtnActive:boolean=false;
  existingBtnActive:boolean=true;

  constructor(private _router: Router, private _carrierFavService: CarrierFavService, private _loggedInUser: LoggedInUser,
    private _clientService: ClientService, private _loaderService: LoaderService,private _pageAccessHelper: PageAccessHelper,localStorage:CoolSessionStorage) {
      this.localStorage=localStorage;
      this.pageAccessLevels = new CarrierFavoritesAccessLevels();
    this.createdCategory = '(None)';
    this.createdFavorite = '(None)';
    this.NewCategoryName='';
    this.NewGroupName='';
    this.isgroupselected=true;
    this.isrowselected=true;
    this.favname='';
    this.currentGrpId='';
    this.groupallowed=true;
    this.allowed=true;
    this.newallowed=false;
    this.carriers=[];
    this.carrierIds=[];
    this.carrierWTWCode=[];
    this.selectedCarrierIds=[];
   // this.FavoriteType;
   
   this.selectedCategory= new FavoriteCategory('','',1);
    this.selectedGroup = new FavoriteGroup('','',1);
    this.selectModeTypeName='';
    this.loadtable();
    
  }


  ngOnInit() {
       
    if(this._clientService.getModeType()){
      this.selectModeType=this._clientService.getModeType();
      this.FavoriteType=this.selectModeType;
      this.contentload();
      
     }else {
       if(this._loggedInUser.getUserRoleCode()==='ClientRead' || this._loggedInUser.getUserRoleCode()==='WillisRead' )
       {this.selectModeType=3;
        this.FavoriteType=3;
        this._clientService.setModeType(3);
         setTimeout(() => this.contentload2(), 0);
         
       }
       else
       {
         this.selectModeType=2;
         this._clientService.setModeType(2);
         document.getElementById("modal").click();
         this.contentload();
       }
       
     }
    this.CategoryId = '';
    this.isShowSuccess = false;
    this.isShowDelete = false;
    this.isShowError = false;
    

  }

  contentload() {
    if (this.selectModeType) {
      if(this.selectModeType == 2) {
        this.selectModeTypeName='(Client)'
        this.getCategories();
      this.getCarrierFavorites();
      }
    if(this.selectModeType == 3) {
        this.selectModeTypeName='(Personal)'
        this.getCategories();
      this.getCarrierFavorites();
      }   
    }
    else{
       this.selectModeTypeName='(Admin)'
        this.getCategories();
      this.getCarrierFavorites();
    }
  }

  contentload2() {
    if (this.selectModeType) {
      if(this.selectModeType == 2) {
        this.selectModeTypeName='(Client)'
        this.getCategories();
      this.getCarrierFavorites();
      }
    if(this.selectModeType == 3) {
        this.selectModeTypeName='(Personal)'
        this.getCategories();
      this.getCarrierFavorites();
      }
      
    }
    else{
       this.selectModeTypeName='(Admin)'
        this.getCategories();
      this.getCarrierFavorites();
    }
    if(this._clientService.getCarriers()){
      if(this._clientService.getCarriers().length > 0)
      document.getElementById("secondpopup").click();
    }
  }

  loadtable() {
    this.gridOptions = <GridOptions>{};
    this.gridOptions.rowSelection = 'multiple';
    this.gridOptions.enableSorting = true;
    this.gridOptions.suppressRowClickSelection = true;
    this.gridOptions.rowHeight = 60;
    this.gridOptions.headerHeight =30;
    this.gridOptions.columnDefs = [
      {
        headerName: "",
        width: 25,
        cellStyle: { 'white-space': 'normal' },
        checkboxSelection: true
      },
      {
        headerName: "Legal Name",
        valueGetter: "data.LegalName",
        width: 398,
        cellStyle: { 'white-space': 'normal' }
      },
      {
        headerName: "Country",
        valueGetter: "data.CountryName",
        width: 120,
        cellStyle: { 'white-space': 'normal' }
      },
      {
        headerName: "State",
        valueGetter: "data.StateName",
        width:120,
        cellStyle: { 'white-space': 'normal' }
      },
      {
        headerName: "WTW Code",
        valueGetter: "data.WTWCode",
        width: 80,
        cellStyle: { 'white-space': 'normal' }
      }
    ];
    this.gridOptions.rowData=[];
    if(this._clientService.getGroupId())
    this.getCarrierList();
  }
  getCategories() {
    this.isShowSuccess = false;
    this.isShowDelete = false;
    this.isShowError = false;
    this.isSuccess = false;
    this.isError = false;
    this.allowed=true;
    this.selectedAccount =this.localStorage.getObject('account');    
    if (this.selectedAccount) {
      this.ClientId = this.selectedAccount.Id;
      this._loaderService.show();
      if(this.selectModeType){
         this._carrierFavService.GetCategories(this.selectModeType, this.ClientId)
        .subscribe((result) => {
          this.categories = result;
          this.categories.sort((a,b) => {
            if(a.CategoryName.toLowerCase() < b.CategoryName.toLowerCase())
            return -1;
            if(a.CategoryName.toLowerCase() > b.CategoryName.toLowerCase())
            return 1;
      
            return 0;
            
          });
          let category= this._clientService.getSelectedCategoryClient();
          if(this._clientService.getSelectedCategoryClient()){
            if(category.CategoryName){
              let index=this.categories.findIndex(cat => category.CategoryName == cat.CategoryName);
              this.selectedCategory=this.categories[index];
              this.selectedCategoryId=this.selectedCategory.CategoryId;
              this.selectedCategoryName=this.selectedCategory.CategoryName;
              this.createdCategory=category.CategoryName;
              this.allowed=false;
            this._clientService.setSelectedCategoryClient(null);
            }
          }
          if(this.selectModeType == 2){
            this.FavoriteType=2;
            this.typeCategories=this.categories.filter(
              category => category.FavoriteType === 2);
          }
          if(this.selectModeType == 3){
            this.FavoriteType=3;
            this.typeCategories=this.categories.filter(
              category => category.FavoriteType === 3);
          } 
          this._loaderService.hide();
        },
        (error) => this.handleError(error));
      }
     
    }
  }

  getCarrierFavorites() {
    this.isShowSuccess = false;
    this.isShowDelete = false;
    this.isShowError = false;
    this.isSuccess = false;
    this.isError = false;
    this.groupallowed=true;
    this.CategoryId = '';
    this.selectedAccount =this.localStorage.getObject('account');
    if(this._clientService.getSelectedCategoryClient()) {
      this._loaderService.show();
      var category:FavoriteCategory=this._clientService.getSelectedCategoryClient();
      var account:Account=this.selectedAccount;
      if(account && category)
      this._carrierFavService.GetGroups(this.selectModeType,account.Id,category.CategoryId)
          .subscribe((result) => {
            this.favorites = result;
            this.favorites.sort((a,b) => {
              if(a.GroupName.toLowerCase() < b.GroupName.toLowerCase())
              return -1;
              if(a.GroupName.toLowerCase() > b.GroupName.toLowerCase())
              return 1;
        
              return 0;
              
            })
            if(this._clientService.getSelectedGroupClient()){
            let favorite =this._clientService.getSelectedGroupClient();
            let index=this.favorites.findIndex(fav => favorite.GroupName == fav.GroupName);
            this.selectedGroup=this.favorites[index];
            this.selectedGroupId=this.selectedGroup.GroupId;
            this.selectedGroupName=this.selectedGroup.GroupName;
            this.createdFavorite=this.selectedGroup.GroupName;
            this.groupallowed=false;
            if(this.selectedGroupName.includes(' (MSG)')){
              let pos = this.selectedGroupName.indexOf(' (MSG)');
              this.selectedGroupName=this.selectedGroupName.substring(0,pos);
           }
            if(this.selectedGroupName.includes(' (Client)')){
              let pos = this.selectedGroupName.indexOf(' (Client)');
              this.selectedGroupName=this.selectedGroupName.substring(0,pos);
           }
            if(this.selectedGroupName.includes(' (Personal)')){
              let pos = this.selectedGroupName.indexOf(' (Personal)');
              this.selectedGroupName=this.selectedGroupName.substring(0,pos);
           }
           this._clientService.setSelectedGroupClient(null);
          }
            this._loaderService.hide();
          },
          (error) => {
            this.handleError(error)});
    }else{
      if (this.selectedAccount) {
      this.ClientId = this.selectedAccount.Id;
      this._loaderService.show();
      if(this.selectModeType){
        this._carrierFavService.GetGroups(this.selectModeType, this.ClientId, this.CategoryId)
        .subscribe((result) => {
          this.favorites = result;
          this.favorites.sort((a,b) => {
            if(a.GroupName.toLowerCase() < b.GroupName.toLowerCase())
            return -1;
            if(a.GroupName.toLowerCase() > b.GroupName.toLowerCase())
            return 1;
      
            return 0;
            
          })
          if(this._clientService.getSelectedGroupClient()){
            let favorite =this._clientService.getSelectedGroupClient();
            let index=this.favorites.findIndex(fav => favorite.GroupName == fav.GroupName);
            this.selectedGroup=this.favorites[index];
            this.selectedGroupId=this.selectedGroup.GroupId;
            this.selectedGroupName=this.selectedGroup.GroupName;
            this.createdFavorite=this.selectedGroup.GroupName;
            this.groupallowed=false;
            if(this.selectedGroupName.includes(' (MSG)')){
              let pos = this.selectedGroupName.indexOf(' (MSG)');
              this.selectedGroupName=this.selectedGroupName.substring(0,pos);
           }
            if(this.selectedGroupName.includes(' (Client)')){
              let pos = this.selectedGroupName.indexOf(' (Client)');
              this.selectedGroupName=this.selectedGroupName.substring(0,pos);
           }
            if(this.selectedGroupName.includes(' (Personal)')){
              let pos = this.selectedGroupName.indexOf(' (Personal)');
              this.selectedGroupName=this.selectedGroupName.substring(0,pos);
           }
           this._clientService.setSelectedGroupClient(null);
          }
          if(this.selectModeType == 2){
            this.typeFavorites=this.favorites.filter(
              favorite => favorite.FavoriteType === 2);
          }
          if(this.selectModeType == 3){
            this.typeFavorites=this.favorites.filter(
              favorite => favorite.FavoriteType === 3);
          }
          this._loaderService.hide();
        },
        (error) => this.handleError(error));  
      }
      
    }

    }
    
  }
  getCarrierFavoritesOnChange(selectedCategoryId) {
    if(this.gridOptions.api){
      this.gridOptions.api.setRowData([]);
      this.createdFavorite='(None)';
    }
    else {
      this.gridOptions.rowData = [];
      this.createdFavorite='(None)';
    }

    if(this.onChangeModeType){}else{
      this.onChangeModeType=this.selectModeType;
    }
    this.isSuccess = false;
    this.isError = false;
    this.FavoriteType = this.selectModeType;
    this.selectedAccount =this.localStorage.getObject('account');
    this.CategoryId = selectedCategoryId;
    if(selectedCategoryId){

    }else{
      this.onChangeModeType=this.selectModeType;
    }
    this.groupallowed=true;
    this._loaderService.show();
    if (this.selectedAccount != undefined) {
      this.ClientId = this.selectedAccount.Id;
      if (this.CategoryId != undefined && this.CategoryId != '' && this.CategoryId != null) {
        this._carrierFavService.GetGroups(this.onChangeModeType, this.ClientId, this.CategoryId)
          .subscribe((result) => {
            this.favorites = result;
            this.favorites.sort((a,b) => {
              if(a.GroupName.toLowerCase() < b.GroupName.toLowerCase())
              return -1;
              if(a.GroupName.toLowerCase() > b.GroupName.toLowerCase())
              return 1;
        
              return 0;
              
            })
            this._loaderService.hide();
          },
          (error) => {
            this.handleError(error)});
      }
      else {
        this.CategoryId = '';
        this._carrierFavService.GetGroups(this.onChangeModeType, this.ClientId, this.CategoryId)
          .subscribe((result) => {
            this.favorites = result;
            this.favorites.sort((a,b) => {
              if(a.GroupName.toLowerCase() < b.GroupName.toLowerCase())
              return -1;
              if(a.GroupName.toLowerCase() > b.GroupName.toLowerCase())
              return 1;
        
              return 0;
              
            })
            this._loaderService.hide();
          },
          (error) => {
            this.handleError(error)});
      }
    }
  }
  getCarrierFavoritesByGroupIdOnChange(selectedGroupId) {
    this.GroupId = this.selectedGroupId;
    this.isgroupselected=false;
    this.isrowselected=false;
    this.isSuccess = false;
    this.isError = false;
    if (this.GroupId) {
      this._carrierFavService.GetCarrierFavoritesByGroupId(this.GroupId)
        .subscribe((result) => {
          this.carriers = result;
          if(this.gridOptions.api){
        this.gridOptions.api.setRowData(this.carriers);
      }
      else {
        this.gridOptions.rowData = this.carriers;
      }
        },
        (error) => this.handleError(error));
    }
  }

  saveCategory() {
    this.FavoriteType = this.selectModeType;
    this.selectedAccount =this.localStorage.getObject('account');
    this.createdCategory = this.NewCategoryName;
    if (this.selectedAccount != undefined) {
      this.ClientId = this.selectedAccount.Id;
      this._loaderService.show();
      this._carrierFavService.PostFavoriteCategory(this.NewCategoryName, this.FavoriteType, this.ClientId)
        .subscribe((result) => {
          if (result) {
            this._loaderService.hide();
            document.getElementById('cancelSaveCat').click();
            let NewCategory= new FavoriteCategory(result.text(),this.createdCategory+' '+this.selectModeTypeName,this.FavoriteType);
            this.categories.push(NewCategory);
            this.categories.sort((a,b) => {
              if(a.CategoryName.toLowerCase() < b.CategoryName.toLowerCase())
              return -1;
              if(a.CategoryName.toLowerCase() > b.CategoryName.toLowerCase())
              return 1;
        
              return 0;
              
            });
            this.getCarrierFavoritesOnChange(result.text());
            this.selectedCategory=NewCategory;
            this.selectedCategoryId=result.text();
            this.selectedCategoryName=this.createdCategory;
            this.duplicateCategoryName=this.selectedCategoryName;
            if(this.selectModeType == 2){
              this.typeCategories=this.categories.filter(
                category => category.FavoriteType === 2);
            }
            if(this.selectModeType == 3){
              this.typeCategories=this.categories.filter(
                category => category.FavoriteType === 3);
            }
            this.isShowSuccess = true;
            setTimeout(() => {
              this.isShowSuccess = false;
            }, 1000);
            this.isError = false;
            this.isShowDelete = false;
            this.isShowError = false;
            this.allowed=false;
          }
             },error => {
          {document.getElementById('cancelSaveCat').click();
            this.handleError(error)};
        }
    )
    }
    this.NewCategoryName='';
  }
  saveCarrierFavorite() {

    if(this.selectedCategoryId){
    this.FavoriteType = this.selectModeType;
    this.selectedAccount =this.localStorage.getObject('account');
    this.createdFavorite = this.NewGroupName;
    if (this.selectedAccount != undefined) {
      this.ClientId = this.selectedAccount.Id;
      this._loaderService.show();
      this._carrierFavService.PostFavoriteGroup(this.NewGroupName, this.FavoriteType, this.ClientId)
        .subscribe((result) => {
          if (result) {
            this.carriers=[];
            document.getElementById('cancelSaveGroup').click();
            let NewFavorite= new FavoriteGroup(result.text(),this.createdFavorite+' '+this.selectModeTypeName,this.FavoriteType);
            this.favorites.push(NewFavorite);
            this.favorites.sort((a,b) => {
              if(a.GroupName.toLowerCase() < b.GroupName.toLowerCase())
              return -1;
              if(a.GroupName.toLowerCase() > b.GroupName.toLowerCase())
              return 1;
        
              return 0;
              
            })
            this.selectedGroup=NewFavorite;
            this.selectedGroupId=result.text();
            this.selectedGroupName=this.createdFavorite;
            this.duplicateGroupName=this.selectedGroupName;
            this.isShowSuccess = true;
            setTimeout(() => {
              this.isShowSuccess = false;
            }, 1000);
            this.isShowError = false;
            this.isError = false;
            this.isShowDelete = false;
            this.groupallowed=false;
            this.selectedGroupId = result.text();
            this.selectedCategory.CategoryId = this.selectedCategoryId;
            this._loaderService.hide();
            this.mapGroupCategory();
          }
              },error => {
                document.getElementById('cancelSaveGroup').click();
          this.handleError(error);
        }
    )
    }
  }
  else {
    this.FavoriteType = this.selectModeType;
    this.selectedAccount =this.localStorage.getObject('account');
    this.createdFavorite = this.NewGroupName;
    if (this.selectedAccount != undefined) {
      this.ClientId = this.selectedAccount.Id;
      this._loaderService.show();
      this._carrierFavService.PostFavoriteGroup(this.NewGroupName, this.FavoriteType, this.ClientId)
        .subscribe((result) => {
          if (result) {
            this.carriers=[];
            document.getElementById('cancelSaveGroup').click();
            let NewFavorite= new FavoriteGroup(result.text(),this.createdFavorite+' '+this.selectModeTypeName,this.FavoriteType);
            this.favorites.push(NewFavorite);
            this.favorites.sort((a,b) => {
              if(a.GroupName.toLowerCase() < b.GroupName.toLowerCase())
              return -1;
              if(a.GroupName.toLowerCase() > b.GroupName.toLowerCase())
              return 1;
        
              return 0;
              
            })
            this.selectedGroup=NewFavorite;
            this.selectedGroupId=result.text();
            this.selectedGroupName=this.createdFavorite;
            this.duplicateGroupName=this.selectedGroupName;
            this.isShowSuccess = true;
            setTimeout(() => {
              this.isShowSuccess = false;
            }, 1000);
            this.isError = false;
            this.isShowDelete = false;
            this.isShowError = false;
            this.groupallowed=false;
            this._loaderService.hide();
          }
              },error => {
                document.getElementById('cancelSaveGroup').click();
          this.handleError(error);
        }
    )
    }

  }
    this.NewGroupName='';
    if(this.gridOptions.api){
      this.gridOptions.api.setRowData([]);
    }else {
      this.gridOptions.rowData=[];
    }
  }

  
  checkdisablenew() {
    if($("#newgp").is(":checked")){
      this.newBtnActive=true;
      this.existingBtnActive=false;
      return false;
    }
    else{
      return true;
    }
  }

  checkdisableexisting() {
    if(($("#existinggp").is(":checked"))){
      this.newBtnActive=false;
      this.existingBtnActive=true;
      return false;
    }
    else{
      return true;
    }
  }
  saveCarrierFavoriteOnModal() {
   if($("#existinggp").is(":checked")){
 this.selectedGroupId = this.selectedGroup.GroupId;
    this.selectedGroupName = this.selectedGroup.GroupName;
    this.duplicateGroupName = this.selectedGroup.GroupName;
    this.createdFavorite = this.selectedGroupName;
    this.getCarrierList2(this.selectedGroupId);
   }
   if($("#newgp").is(":checked")){
 this.GroupName = this.GroupName;
    this.FavoriteType = this.selectModeType;
    this.selectedAccount =this.localStorage.getObject('account');
    this.createdFavorite = this.GroupName;
    if (this.selectedAccount != undefined) {
      this.ClientId = this.selectedAccount.Id;
      this._loaderService.show();
      this._carrierFavService.PostFavoriteGroup(this.GroupName, this.FavoriteType, this.ClientId)
        .subscribe((result) => {
          if (result) {
            this.currentGrpId=result.text();
            let NewFavorite= new FavoriteGroup(result.text(),this.createdFavorite+' '+this.selectModeTypeName,this.FavoriteType);
            this.favorites.push(NewFavorite);
            this.favorites.sort((a,b) => {
              if(a.GroupName.toLowerCase() < b.GroupName.toLowerCase())
              return -1;
              if(a.GroupName.toLowerCase() > b.GroupName.toLowerCase())
              return 1;
        
              return 0;
              
            })
            this.selectedGroup=NewFavorite;
            this.selectedGroupName=this.GroupName;
            this.duplicateGroupName=this.GroupName;
            this._loaderService.hide();
            this.getCarrierList2(this.currentGrpId);
            this.isShowSuccess = true;
            setTimeout(() => {
              this.isShowSuccess = false;
            }, 1000);
            this.isError = false;
            this.isShowDelete = false;
            this.isShowError = false;
          }
              },error => {
          this.handleError(error);
        }
    )
    }

   }
   this.groupallowed=false;
  }
  updateCategory() {
    this.categoryToUpdate = this.selectedCategoryId;
    this.categoryNameToUpdate = this.selectedCategoryName
    this.FavoriteType = this.selectModeType;
    //this.selectedAccount =this.localStorage.getObject('account');
    this.createdCategory = this.selectedCategoryName;
    this._loaderService.show();
    if(this.selectedCategoryName != this.duplicateCategoryName){
      this._carrierFavService.PutFavoriteCategory(this.categoryNameToUpdate, this.categoryToUpdate, this.FavoriteType)
      .subscribe((result) => {
        document.getElementById('editCancelCat').click();
        if(this.categories)
        for(let i=0;i<this.categories.length;i++){
          if(this.categories[i].CategoryId === this.categoryToUpdate) {
            this.categories[i].CategoryName=this.createdCategory+' '+this.selectModeTypeName;
            this.duplicateCategoryName=this.createdCategory;
          }
        }
        this.categories.sort((a,b) => {
          if(a.CategoryName.toLowerCase() < b.CategoryName.toLowerCase())
          return -1;
          if(a.CategoryName.toLowerCase() > b.CategoryName.toLowerCase())
          return 1;
    
          return 0;
          
        })
        let matchCatName=this.createdCategory+' '+this.selectModeTypeName;
        let index=this.categories.findIndex(cat => cat.CategoryName == matchCatName);
        if(index != -1)
        this.selectedCategory=this.categories[index];

        if(this.selectModeType == 2){
          this.typeCategories=this.categories.filter(
            category => category.FavoriteType === 2);
        }
        if(this.selectModeType == 3){
          this.typeCategories=this.categories.filter(
            category => category.FavoriteType === 3);
        }
        this.isShowSuccess = true;
        setTimeout(() => {
          this.isShowSuccess = false;
        }, 1000);
        this.isShowError = false;
        this.isError = false;
        this._loaderService.hide();
            },error => {
          this.handleError(error);
        }
    )
    }else{
      document.getElementById('editCancelCat').click();
      this._loaderService.hide();
      this.showSuccess('Updated Successfully.')
    }
    
  }
  updateCarrierFavorite() {
    this.carrierFavoriteToUpdate = this.selectedGroupId;
    this.groupNameToUpdate = this.selectedGroupName;
    this.FavoriteType = this.selectModeType;
    //this.selectedAccount =this.localStorage.getObject('account');
    this.createdFavorite = this.selectedGroupName;
    if(this.selectedGroupName!=this.duplicateGroupName){
      document.getElementById('editCancelGroup').click();
      this._loaderService.show();
      this._carrierFavService.PutFavoriteGroup(this.groupNameToUpdate, this.carrierFavoriteToUpdate, this.FavoriteType)
        .subscribe((result) => {
          if(this.favorites)
          for(let i=0;i<this.favorites.length;i++){
            if(this.favorites[i].GroupId === this.carrierFavoriteToUpdate) {
              this.favorites[i].GroupName=this.createdFavorite+' '+this.selectModeTypeName;
              this.duplicateGroupName=this.createdFavorite;
            }
          }
          this.favorites.sort((a,b) => {
            if(a.GroupName.toLowerCase() < b.GroupName.toLowerCase())
            return -1;
            if(a.GroupName.toLowerCase() > b.GroupName.toLowerCase())
            return 1;
      
            return 0;
            
          })
          let matchCatName=this.createdFavorite+' '+this.selectModeTypeName;
          let index=this.favorites.findIndex(cat => cat.GroupName == matchCatName);
          if(index != -1)
          this.selectedGroup=this.favorites[index];
          this.isShowSuccess = true;
          setTimeout(() => {
            this.isShowSuccess = false;
          }, 1000);
          this.isError = false;
          this.isShowDelete = false;
          this.isShowError = false;
          this._loaderService.hide();
              },error => {
                document.getElementById('editCancelGroup').click();
            this.handleError(error);
          }
      )
    }else{
      this.showSuccess('Updated Successfully.')
    } 
  }
  mapGroupCategory() {
    this.categoryIdToMap = this.selectedCategory.CategoryId;
    this.groupIdToMap = this.selectedGroupId;
    this.selectedAccount =this.localStorage.getObject('account');
    var CId;
    this._loaderService.show();
    this._carrierFavService.PostAssociateGroup(this.categoryIdToMap, this.groupIdToMap)
      .subscribe((result) => {
        this.allowed=false;
        this.createdCategory=this.selectedCategory.CategoryName;
        if(this.selectedAccount)
         CId=this.selectedAccount.Id;
         else
         CId='';
        if(this.categoryIdToMap)
        this._carrierFavService.GetGroups(this.selectModeType, CId, this.categoryIdToMap)
        .subscribe((result) => {
          this.favorites = result;
          this.favorites.sort((a,b) => {
            if(a.GroupName.toLowerCase() < b.GroupName.toLowerCase())
            return -1;
            if(a.GroupName.toLowerCase() > b.GroupName.toLowerCase())
            return 1;
      
            return 0;
            
          })
          let index=this.favorites.findIndex(fav => this.selectedGroupName+' '+this.selectModeTypeName == fav.GroupName);
          this.selectedGroup=this.favorites[index];
          this.selectedGroupId=this.selectedGroup.GroupId;
          this.selectedGroupName=this.selectedGroup.GroupName;
          this.createdFavorite=this.selectedGroup.GroupName;
          
          this._loaderService.hide();
        },
        (error) => {
          this.handleError(error)});
        this.isShowSuccess = true;
        setTimeout(() => {
          this.isShowSuccess = false;
        }, 1000);
        this.isError = false;
        this.isShowDelete = false;
        this.isShowError = false;
      },(error)=>this.handleError(error))

  }
  deleteCategory() {
    let id='';
    this.categorytoDelete = this.selectedCategoryId;
    if(this._loggedInUser.getUserRoleCode()==='ClientRead' || this._loggedInUser.getUserRoleCode()==='WillisRead' )
    {this.FavoriteType=3;}
    this.selectedAccount =this.localStorage.getObject('account');
    if (this.selectedAccount) {
      this.ClientId = this.selectedAccount.Id;}
      else{
        this.ClientId='';
      }
      this._loaderService.show();
    this._carrierFavService.DeleteFavoriteCategory(this.categorytoDelete)
      .subscribe(() => {
        this._carrierFavService.GetCategories(this.FavoriteType,this.ClientId)
        .subscribe((result) => {
          this.categories = result;
          this.categories.sort((a,b) => {
            if(a.CategoryName.toLowerCase() < b.CategoryName.toLowerCase())
            return -1;
            if(a.CategoryName.toLowerCase() > b.CategoryName.toLowerCase())
            return 1;
      
            return 0;
            
          });
          if(this.selectModeType == 2){
            this.typeCategories=this.categories.filter(
              category => category.FavoriteType === 2);
          }
          if(this.selectModeType == 3){
            this.typeCategories=this.categories.filter(
              category => category.FavoriteType === 3);
          }
          this.allowed= true;
          this.newallowed=false;
          this.selectedCategoryId="";
          this._loaderService.hide();
        },(error) => {
          this.handleError(error)});
          this._loaderService.show();
        this._carrierFavService.GetGroups(this.FavoriteType, '', id)
        .subscribe((result) => {
          this.favorites = result;
          this.favorites.sort((a,b) => {
            if(a.GroupName.toLowerCase() < b.GroupName.toLowerCase())
            return -1;
            if(a.GroupName.toLowerCase() > b.GroupName.toLowerCase())
            return 1;
      
            return 0;
            
          })
          if(this.gridOptions.api){
            this.gridOptions.api.setRowData([]);
          }else{
            this.gridOptions.rowData=[];
          }
          this.createdFavorite='(None)';
          this.groupallowed=true;
        this._loaderService.hide();
        },(error) => {
          this.handleError(error)});
        this.createdCategory = '(None)'
        this.isShowDelete = true;
        setTimeout(() => {
          this.isShowDelete = false;
        }, 1000);
        this.isError = false;
        this.isSuccess = false;
      });
  }
  deleteCarrierFavorite() {
    this.carrierFavoriteToDelete = this.selectedGroupId;
    if(this._loggedInUser.getUserRoleCode()==='ClientRead' || this._loggedInUser.getUserRoleCode()==='WillisRead' )
    {this.FavoriteType=3;}
    this.selectedAccount =this.localStorage.getObject('account');
    if (this.selectedAccount) {
      this.ClientId = this.selectedAccount.Id;}
      else{
        this.ClientId='';
      }
      this._loaderService.show();
    this._carrierFavService.DeleteFavoriteGroup(this.carrierFavoriteToDelete)
      .subscribe(() => {
        this._carrierFavService.GetGroups(this.FavoriteType, this.ClientId, this.CategoryId)
        .subscribe((result) => {
          this.favorites = result;
          this.favorites.sort((a,b) => {
            if(a.GroupName.toLowerCase() < b.GroupName.toLowerCase())
            return -1;
            if(a.GroupName.toLowerCase() > b.GroupName.toLowerCase())
            return 1;
      
            return 0;
            
          })
          if(this.gridOptions.api){
            this.gridOptions.api.setRowData([]);
          }else{
            this.gridOptions.rowData=[];
          }
          this.groupallowed = true;
        });
        this.createdFavorite = '(None)';
        this.isShowDelete = true;
        setTimeout(() => {
          this.isShowDelete = false;
        }, 1000);
        this.isError = false;
        this.isSuccess = false;
        this._loaderService.hide();
      }, (error) => this.handleError(error));
  }
  onCategoryChange(category) {
    this.selectedCategory=category;
    this.selectedCategoryId = category.CategoryId;
    this.selectedCategoryName = category.CategoryName;
    this.duplicateCategoryName = category.CategoryName;
    this.createdCategory = this.selectedCategoryName;
    this.CategoryName = category.CategoryName;
    if(this.selectedCategoryName){
      if(this.selectedCategoryName.includes(' (MSG)')){
        this.onChangeModeType=1;
       if(this.selectModeType==2 || this.selectModeType==3) {
        this.allowed=true;
        this.newallowed=true;
      }
    }
    if(this.selectedCategoryName.includes(' (Client)')){
      this.onChangeModeType=2;
      if(this.selectModeType==2) {
        this.allowed=false;
        this.newallowed=false;
      }
      else {
        this.allowed=true;
        this.newallowed=true;
      }
      let pos = this.selectedCategoryName.indexOf(' (Client)');
      this.selectedCategoryName=this.CategoryName.substring(0,pos);
      this.duplicateCategoryName=this.duplicateCategoryName.substring(0,pos);
    }

    if(this.selectedCategoryName.includes(' (Personal)')){
      this.onChangeModeType=3;
      if(this.selectModeType==3) {
        this.allowed=false;
        this.newallowed=false;
      }
      else {
        this.allowed=true;
        this.newallowed=true;
      }
      let pos = this.selectedCategoryName.indexOf(' (Personal)');
      this.selectedCategoryName=this.CategoryName.substring(0,pos);
      this.duplicateCategoryName=this.duplicateCategoryName.substring(0,pos);
    }
    }else{
      this.allowed=true;
      this.newallowed=false;
      this.selectedCategoryName='';
      this.duplicateCategoryName='';
      this.CategoryName='(None)';
      this.createdCategory='(None)';
      this.getCarrierFavoritesOnChange('');
    }
     
      
    this.FavoriteType = this.selectModeType;
    this.selectedAccount =this.localStorage.getObject('account');
    if (this.selectedAccount != undefined) {
      this.ClientId = this.selectedAccount.Id;
      if(this.selectedCategoryId)
      this.getCarrierFavoritesOnChange(this.selectedCategoryId);
      else{
        this.selectedCategoryId='';
        this.getCarrierFavoritesOnChange(this.selectedCategoryId);
      }
    }
  }

  onCarrierFavoriteChange(favorite) {
    this.selectedGroup=favorite;
    this.selectedGroupId = favorite.GroupId;
    this.selectedGroupName = favorite.GroupName;
    this.duplicateGroupName = favorite.GroupName;
    this.createdFavorite = this.selectedGroupName;
    if(this.selectedGroupName){
      if(this.selectedGroupName.includes(' (MSG)')){
        if(this.selectModeType==2 || this.selectModeType==3) {
         this.groupallowed=true;
       }
     }
 
      if(this.selectedGroupName.includes(' (Client)')){
        if(this.selectModeType==2) {
         this.groupallowed=false;
       }
       else {
         this.groupallowed=true;
       }
       let pos = this.selectedGroupName.indexOf(' (Client)');
       this.selectedGroupName=this.selectedGroupName.substring(0,pos);
       this.duplicateGroupName=this.duplicateGroupName.substring(0,pos);
     }
 
     if(this.selectedGroupName.includes(' (Personal)')){
       if(this.selectModeType==3) {
         this.groupallowed=false;
       }
       else {
         this.groupallowed=true;
       }
       let pos = this.selectedGroupName.indexOf(' (Personal)');
       this.selectedGroupName=this.selectedGroupName.substring(0,pos);
       this.duplicateGroupName=this.duplicateGroupName.substring(0,pos);
     }
    }else{
      this.groupallowed=true;
      this.selectedGroupName='';
      this.duplicateGroupName='';
      this.createdFavorite='(None)';
    }
    if(this.selectedGroupId)
    this.getCarrierFavoritesByGroupIdOnChange(this.selectedGroupId);
    else{
      if(this.gridOptions.api != null && this.gridOptions.api != undefined){
        this.gridOptions.api.setRowData([]);
      }
      else {
        this.gridOptions.rowData = [];
      }
    }
  }

  showSuccess(message: string) {
    this.isSuccess = true;
    this.isError = false;
    this.message=message;
    setTimeout(() => {
      this.isSuccess = false;
    }, 1000);
  }

  showError(message: string) {
    this.isSuccess = false;
    this.isError = true;
    this.message = message;
    setTimeout(() => {
      this.isError = false;
    }, 1000);
  }

    handleError(error) {
      this._loaderService.hide();
    this.isShowSuccess = false;
    this.isShowError = true;
    setTimeout(() => {
      this.isShowError = false;
    }, 1000);
    this.isSuccess = false;
    this.isError = true;
    setTimeout(() => {
      this.isError = false;
    }, 1000);

    if(error.status === 412){
    this.showError('Error 412 : Input/Output Validation Error. Please enter details again. ');  
    }
    else if(error.status === 422){
    this.showError('Error 422 : Business Validation Error. Please try again');
    }
    else if(error.status === 500){
    this.showError('500 Internal Server Error. Please try again');
    }
    else{
      this.showError('Server Error. Please try again');
    }
  }

  redirectToSearch() {
    this._clientService.setRedirectionToFavorites(true);
    this.selectedAccount =this.localStorage.getObject('account');
    if (this.selectedAccount) {
      this.account = this.selectedAccount;
      this._clientService.setSelectedAccount(SelectClientHelper.mapToAccount(this.account));
      this._clientService.setRedirectToClientMaintenance(false);
    this._clientService.setRedirectToCarrierFavorites(true);
    this._clientService.setRedirectionToFavorites(true);
    this._clientService.setRedirectToCarrierFavoritesAdmin(false);
    this._clientService.setGroupId(this.selectedGroupId);
    this._clientService.setModeType(this.selectModeType);
    if(this.selectedCategory){
      this._clientService.setSelectedCategoryClient(this.selectedCategory);
    }
    if(this.selectedGroup){
      this._clientService.setSelectedGroupClient(this.selectedGroup);
    }
      this._router.navigate(['./carrier-search/client/'+this.account.AccountId]);
    }
    else{
      this.account = null;
      this._clientService.setSelectedAccount(SelectClientHelper.mapToAccount(this.account));
          this._clientService.setRedirectToClientMaintenance(true);
    this._clientService.setRedirectToCarrierFavorites(true);
    this._clientService.setRedirectToCarrierFavoritesAdmin(false);
    this._clientService.setGroupId(this.selectedGroupId);
    if(this.selectedCategory){
      this._clientService.setSelectedCategoryClient(this.selectedCategory);
    }
    if(this.selectedGroup){
      this._clientService.setSelectedGroupClient(this.selectedGroup);
    }
      this._router.navigate(['./carrier-search/client/'+this._clientService.getAccountId()]);
    }
  }

  getCarrierList() {
       var GId= this._clientService.getGroupId();
    if(GId) {
      if(this._clientService.getCarriers()){
        this.selectedGroupId=this._clientService.getGroupId();
         this.carrierIds=[];
         this.carrierWTWCode=[];
          this._clientService.getCarriers().forEach((carrier) => {
          this.carrierIds.push(carrier.CarrierId.toString());
          this.carrierWTWCode.push(carrier.WillisCode);
        });
        var mockcarriers:Array<CarrierFavorite>;
        this._carrierFavService.GetCarrierFavoritesByGroupId(GId)
        .subscribe((result) => {
          mockcarriers=result;
          if(this.carrierIds.length>=0 && mockcarriers.length >=0) {
            if(mockcarriers.length>=this.carrierIds.length){
              for(var i=0;i<mockcarriers.length;i++) {
                for(var j=0;j<this.carrierIds.length;j++){
                  let index=this.carrierWTWCode.findIndex(id => id == mockcarriers[i].WTWCode);
                  if(index != -1){
                    this.carrierIds.splice(index,1);
                    this.carrierWTWCode.splice(index,1);
                  }
                }
              }
            }else{
              for(var i=0;i<this.carrierIds.length;i++) {
                for(var j=0;j<mockcarriers.length;j++){
                  let index=this.carrierWTWCode.findIndex(id => id == mockcarriers[j].WTWCode);
                  if(index != -1){
                    this.carrierIds.splice(index,1);
                    this.carrierWTWCode.splice(index,1);
                  }
                }
              }
            }
          }
          this.carrierIds=Array.from(new Set(this.carrierIds));
        this._loaderService.show();
          this._carrierFavService.PostAssociateCarriersToGroup(GId,this.carrierIds).subscribe((result)=> {
        this._loaderService.hide();
        this.isShowSuccess = true;
        setTimeout(() => {
         this.isShowSuccess = false;
       }, 1000);
                   this.getCarrierFavoritesByGroupIdOnChange(GId);
                 },error => {
                   this.handleError(error);
                 });

        });
        
        this._clientService.setCarriers(null);
        this._clientService.setGroupId('');
    }
    } 
  }



 removecarriers() {
   if(this.carriers.length != this.gridOptions.api.getSelectedRows().length){
if(this.gridOptions.api.getSelectedRows().length > 0) {
  if(confirm('Are you sure you want to remove the selected carrier(s)?')) {
    this.gridOptions.api.getSelectedRows().forEach((carrier) => {
      this.selectedCarrierIds.push(carrier.CarrierId.toString());
     });
     this._loaderService.show();
   this._carrierFavService.RemoveCarriersFromGroup(this.selectedGroupId,this.selectedCarrierIds)
     .subscribe(() => {
      this._loaderService.hide();
      this.getCarrierFavoritesByGroupIdOnChange(this.selectedGroupId);
       this.isShowDelete = true;
       setTimeout(() => {
        this.isShowDelete = false;
      }, 1000);
       this.isError = false;
       this.isSuccess = false;
       this.selectedCarrierIds=[];
     }, (error) => this.handleError(error));
  }
     }
   }else {
     alert('Removing all Carrier Favorites is not allowed.');
   }
     }

  checkfavorite(category) {
    if(category.FavoriteType == 1) {
      this.favname = '(MSG)'
    }
    if(category.FavoriteType == 1) {
      this.favname = '(Client)'
    }
    if(category.FavoriteType == 1) {
      this.favname = '(Personal)'
    }
    return true;
  }

   getCarrierList2(groupId) {
       var GId= groupId;
    if(GId) {
      if(this._clientService.getCarriers() != null){
        this.selectedGroupId=groupId;
        this.carrierIds=[];
         this.carrierWTWCode=[];
         if(this._clientService.getCarriers().length > 0){
          this._clientService.getCarriers().forEach((carrier) => { 
          this.carrierIds.push(carrier.CarrierId.toString());
          this.carrierWTWCode.push(carrier.WillisCode);
        });
         } var mockcarriers:Array<CarrierFavorite>;
        this._loaderService.show();
         this._carrierFavService.GetCarrierFavoritesByGroupId(groupId)
         .subscribe((result) => {
           mockcarriers=result;
           if(this.carrierIds.length>=0 && mockcarriers.length >=0) {
             if(mockcarriers.length>=this.carrierIds.length){
               for(var i=0;i<mockcarriers.length;i++) {
                 for(var j=0;j<this.carrierIds.length;j++){
                   let index=this.carrierWTWCode.findIndex(id => id == mockcarriers[i].WTWCode);
                   if(index != -1){
                     this.carrierIds.splice(index,1);
                     this.carrierWTWCode.splice(index,1);
                   }
                 }
               }
             }else{
               for(var i=0;i<this.carrierIds.length;i++) {
                 for(var j=0;j<mockcarriers.length;j++){
                   let index=this.carrierWTWCode.findIndex(id => id == mockcarriers[j].WTWCode);
                   if(index != -1){
                     this.carrierIds.splice(index,1);
                     this.carrierWTWCode.splice(index,1);
                   }
                 }
               }
             }
           }
           this.carrierIds=Array.from(new Set(this.carrierIds));
           this._carrierFavService.PostAssociateCarriersToGroup(GId,this.carrierIds).subscribe((result)=> {
            this._loaderService.hide();
             this.getCarrierFavoritesByGroupIdOnChange(GId);
             this._clientService.setCarriers(null);
           },error => {
             this.handleError(error);
           });
        this._loaderService.hide();
         },(error)=>{this.handleError(error)});      



    }
    } 
}

}
