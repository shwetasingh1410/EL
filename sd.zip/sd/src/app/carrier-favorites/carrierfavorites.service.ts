import { Injectable } from '@angular/core';
import { Http, RequestOptions, Headers } from '@angular/http';
import { Observable } from 'rxjs/Rx';
import 'rxjs/add/operator/map';

import { environment } from '../../environments/environment';
import { CarrierFavHelper } from './carrierfavorites.helper';
import { CreateFavoriteCategory, UpdateFavoriteCategory, FavoriteCategory, FavoriteGroup, FavoriteType, CarrierFavorite } from './carrierfavorites.model';
import { Settings } from '../shared/settings/settings.service';

@Injectable()
export class CarrierFavService {
    constructor(private _http: Http, private _settings: Settings) {
    }
GetCategories(FavoriteType : number,ClientId : string): Observable<Array<FavoriteCategory>> {
        return this._http.get(this._settings.getApiUrl() + 'api/favorites/categories?FavoriteType='+FavoriteType+'&AccountId='+ClientId)
        .map((response) => {
            let result: Array<FavoriteCategory> = new Array<FavoriteCategory>();
            response.json().forEach((category) => {
                result.push(CarrierFavHelper.mapToCategoryInfo(category))
            });
            return result;
        });
    }
    GetCarrierFavoritesByGroupId(GroupId : string):Observable<Array<CarrierFavorite>> {
        return this._http.get(this._settings.getApiUrl() + 'api/favorites/groups/'+GroupId+'/carriers')
        .map((response) => {
            let result: Array<CarrierFavorite> = new Array<CarrierFavorite>();
            response.json().forEach((carrier) => {
                result.push(CarrierFavHelper.mapToCarrierInfo(carrier))
            });
            return result;
        });
    }
    GetGroups(FavoriteType : number,ClientId : string,CategoryId : string): Observable<Array<FavoriteGroup>> {
        return this._http.get(this._settings.getApiUrl() + 'api/favorites/groups?FavoriteType='+FavoriteType+'&AccountId='+ClientId+'&CategoryId='+CategoryId)
        .map((response) => {
           let result: Array<FavoriteGroup> = new Array<FavoriteGroup>();
            response.json().forEach((group) => {
                result.push(CarrierFavHelper.mapToGroupInfo(group))
            });
            return result;
        });
    }

    PostFavoriteCategory(CategoryName : string, FavoriteType : number, ClientId : string) {
        let headers = new Headers();
        headers.append('Content-Type', 'application/json');
        let options = new RequestOptions({ headers: headers });
        return this._http.post(this._settings.getApiUrl() + 'api/favorites/categories',
            JSON.stringify({
                'CategoryName': CategoryName,
                'FavoriteType': FavoriteType,
                'AccountId': ClientId
            }), options);
    }
    PostAssociateGroup(CategoryId: string, GroupId : string) {
        let headers = new Headers();
        headers.append('Content-Type', 'application/json');
        let options = new RequestOptions({ headers: headers });
        return this._http.post(this._settings.getApiUrl() + 'api/favorites/categories/'+CategoryId+'/groups/'+GroupId,
            JSON.stringify({
                'CategoryId': CategoryId,
                'GroupId': GroupId
            }), options);
    }

    PutFavoriteCategory(CategoryName: string,CategoryId : string, FavoriteType : number) {
        let headers = new Headers();
        headers.append('Content-Type', 'application/json');
        let options = new RequestOptions({ headers: headers });
        return this._http.put(this._settings.getApiUrl() + 'api/favorites/categories/' + CategoryId,
            JSON.stringify({
                'CategoryName' : CategoryName
                // 'CategoryId': CategoryId,
                // 'FavoriteType': FavoriteType
            }), options);
    }

    DeleteFavoriteCategory(GroupId: string) {
        return this._http.delete(this._settings.getApiUrl() + 'api/favorites/categories/' + GroupId);
    }

    PostFavoriteGroup(GroupName : string, FavoriteType : number, ClientId: string) {
        let headers = new Headers();
        headers.append('Content-Type', 'application/json');
        let options = new RequestOptions({ headers: headers });
        return this._http.post(this._settings.getApiUrl() + 'api/favorites/groups',
            JSON.stringify({
                'GroupName': GroupName,
                'FavoriteType': FavoriteType,
                'AccountId': ClientId
            }), options);
    }
    PutFavoriteGroup(GroupName: string, GroupId: string, FavoriteType : number) {
        let headers = new Headers();
        headers.append('Content-Type', 'application/json');
        let options = new RequestOptions({ headers: headers });
        return this._http.put(this._settings.getApiUrl() + 'api/favorites/groups/' + GroupId,
            JSON.stringify({
                'GroupName': GroupName
            }), options);
    }
    DeleteFavoriteGroup(GroupId: string) {
        return this._http.delete(this._settings.getApiUrl() + 'api/favorites/groups/' + GroupId);
    }
     PostAssociateCarriersToGroup(GroupId : string,Carriers :Array<String>) {
        let headers = new Headers();
        headers.append('Content-Type', 'application/json');
        let options = new RequestOptions({ headers: headers });
        return this._http.post(this._settings.getApiUrl() + 'api/favorites/groups/carriers', JSON.stringify({
                'GroupId': GroupId,
                'Carriers': Carriers
            }), options);
    }

    RemoveCarriersFromGroup(GroupId: string,Carriers:Array<String>) {
        let headers = new Headers();
        let body = JSON.stringify({
                'GroupId': GroupId,
                'Carriers': Carriers
            });
        headers.append('Content-Type', 'application/json');
        let options = new RequestOptions({ headers: headers ,body:body});
        return this._http.delete(this._settings.getApiUrl() + 'api/favorites/groups/carriers',options);
    }
}