export class CreateFavoriteCategory{
    CategoryName : string;
    ClientId : string;
    FavoriteType : FavoriteType;
    constructor(CategoryName : string, ClientId : string, FavoriteType : FavoriteType){
        this.CategoryName = CategoryName;
        this.ClientId = ClientId;
        this.FavoriteType = FavoriteType;
    }
    getCategoryName() : string{
        return this.CategoryName;
    }
    setCategoryName(CategoryName: string) {
        this.CategoryName = CategoryName;
    }
    getClientId(): string {
        return this.ClientId;
    }
    setClientId(ClientId: string) {
        this.ClientId = ClientId;
    }
    getFavoriteType(): FavoriteType {
        return this.FavoriteType;
    }
    setFavoriteType(FavoriteType: FavoriteType) {
        this.FavoriteType = FavoriteType;
    }
}
export class CreateFavoriteGroup{
    GroupName : string;
    ClientId : string;
    FavoriteType : FavoriteType;
    constructor(GroupName : string, ClientId : string, FavoriteType : FavoriteType){
        this.GroupName = GroupName;
        this.ClientId = ClientId;
        this.FavoriteType = FavoriteType;
    }
    getGroupName() : string{
        return this.GroupName;
    }
    setGroupName(GroupName: string) {
        this.GroupName = GroupName;
    }
    getClientId(): string {
        return this.ClientId;
    }
    setClientId(ClientId: string) {
        this.ClientId = ClientId;
    }
    getFavoriteType(): FavoriteType {
        return this.FavoriteType;
    }
    setFavoriteType(FavoriteType: FavoriteType) {
        this.FavoriteType = FavoriteType;
    }
}
export class UpdateFavoriteCategory{
    CategoryName : string;
    FavoriteType : FavoriteType;
    constructor(CategoryName : string,FavoriteType : FavoriteType) {
        this.CategoryName = CategoryName;
        this.FavoriteType = FavoriteType;
    }
    getCategoryName(): string {
        return this.CategoryName;
    }
    setCategoryName(CategoryName: string) {
        this.CategoryName = CategoryName;
    }
    getFavoriteType(): FavoriteType {
        return this.FavoriteType;
    }

    setFavoriteType(FavoriteType: FavoriteType) {
        this.FavoriteType = FavoriteType;
    }
}
export class UpdateFavoriteGroup{
    GroupName : string;
    FavoriteType : FavoriteType;
    constructor(GroupName : string,FavoriteType : FavoriteType) {
        this.GroupName = GroupName;
        this.FavoriteType = FavoriteType;
    }
    getGroupName(): string {
        return this.GroupName;
    }
    setGroupName(GroupName: string) {
        this.GroupName = GroupName;
    }
    getFavoriteType(): FavoriteType {
        return this.FavoriteType;
    }

    setFavoriteType(FavoriteType: FavoriteType) {
        this.FavoriteType = FavoriteType;
    }
}
export class FavoriteCategory{
    CategoryName : string;
    CategoryId : string;
    FavoriteType : FavoriteType;

    constructor(CategoryId : string,CategoryName : string,FavoriteType : FavoriteType) {
        this.CategoryName = CategoryName;
        this.CategoryId = CategoryId;
        this.FavoriteType = FavoriteType;
    }

    getCategoryName(): string {
        return this.CategoryName;
    }

    setCategoryName(CategoryName: string) {
        this.CategoryName = CategoryName;
    }

    getCategoryId(): string {
        return this.CategoryId;
    }

    setCategoryId(CategoryId: string) {
        this.CategoryId = CategoryId;
    }
    getFavoriteType(): FavoriteType {
        return this.FavoriteType;
    }

    setFavoriteType(FavoriteType: FavoriteType) {
        this.FavoriteType = FavoriteType;
    }
}
export class FavoriteGroup{
    GroupName : string;
    GroupId : string;
    FavoriteType : FavoriteType;

    constructor(GroupId : string,GroupName : string,FavoriteType : FavoriteType) {
        this.GroupName = GroupName;
        this.GroupId = GroupId;
        this.FavoriteType = FavoriteType;
    }

    getGroupName(): string {
        return this.GroupName;
    }

    setGroupName(GroupName: string) {
        this.GroupName = GroupName;
    }

    getGroupId(): string {
        return this.GroupId;
    }

    setGroupId(GroupId: string) {
        this.GroupId = GroupId;
    }
    getFavoriteType(): FavoriteType {
        return this.FavoriteType;
    }

    setFavoriteType(FavoriteType: FavoriteType) {
        this.FavoriteType = FavoriteType;
    }
}
export enum FavoriteType{
    Admin = 1,
    Client,
    User
}
export class CarrierFavorite{
    CarrierId : number;
    LegalName : string;
    WTWCode : string;
    CountryName : string;
    StateName : string;
    constructor(CarrierId : number,LegalName : string,WTWCode : string, CountryName : string, StateName : string ) {
        this.CarrierId = CarrierId;
        this.LegalName = LegalName;
        this.WTWCode = WTWCode;
        this.CountryName = CountryName;
        this.StateName = StateName;
    }

    getCarrierId(): number {
        return this.CarrierId;
    }
    setCarrierId(CarrierId: number) {
        this.CarrierId = CarrierId;
    }
    getLegalName(): string {
        return this.LegalName;
    }
    setLegalName(LegalName: string) {
        this.LegalName = LegalName;
    }
    getWTWCode(): string {
        return this.WTWCode;
    }
    setWTWCode(WTWCode: string) {
        this.WTWCode = WTWCode;
    }
    getCountryName(): string {
        return this.CountryName;
    }
    setCountryName(CountryName: string) {
        this.CountryName = CountryName;
    }
    getStateName(): string {
        return this.StateName;
    }
    setStateName(StateName: string) {
        this.StateName = StateName;
    }
}