import { Component, OnInit } from '@angular/core';
import { SafeUrl, DomSanitizer } from '@angular/platform-browser';
import { ActivatedRoute, Router, ParamMap } from '@angular/router';
import { Observable } from 'rxjs/Rx';
import 'rxjs/add/operator/switchMap';
import { LoggedInUser } from '../shared/loggedInUser/LoggedInUser';

import { Settings } from '../shared/settings/settings.service';
import { TranslateService } from '../translate/translate.service';
import { ReportsService } from './reports.service';


@Component({
  selector: 'app-reports',
  templateUrl: './reports.component.html',
  styleUrls: ['./reports.component.css'],
  providers: [ReportsService]

})
export class ReportsComponent {
  message: string;
  reportUrl: SafeUrl;
  reportWidth: number;
  reportHeight: number;
  isReportsActive: boolean;
  role: string;
  printMessage: string;
  reports: Array<any> = [
    {
      ReportName: "AuditTrail", ReportDescription: "Audit Trail Changes", Width: 100, Height: 650
    },
    {
      ReportName: "ApprovedList", ReportDescription: "Approved List", Width: 100, Height: 650
    },
    {
      ReportName: "CarrierApproval", ReportDescription: "Carrier Approval Status Reports", Width: 100, Height: 650
    },
    {
      ReportName: "OperatingStatus", ReportDescription: "Operating Status/Company Type Report", Width: 100, Height: 650
    },
    {
      ReportName: "GroupReport", ReportDescription: "Group Report", Width: 100, Height: 650
    },
    {
      ReportName: "RatingsUpdate", ReportDescription: "Rating Update Report", Width: 100, Height: 650
    },
    {
      ReportName: "MarketingReport", ReportDescription: "Marketing Report - Comparative Ratings", Width: 100, Height: 650
    }];
  MsdReports: Array<any> = [{
    ReportName: "AdminCode", ReportDescription: "Administration Code Report", Width: 100, Height: 650
  },
  {
    ReportName: "MarketComparision", ReportDescription: "Market Comparison Report", Width: 100, Height: 650
  },
  {
    ReportName: "RatingAgency", ReportDescription: "Rating Agency Code Report", Width: 100, Height: 650
  }];


  willisReadReport: Array<any> = [
    {
      ReportName: "AuditTrail", ReportDescription: "Audit Trail Changes", Width: 100, Height: 650
    },
    {
      ReportName: "ApprovedList", ReportDescription: "Approved List", Width: 100, Height: 650
    },
    {
      ReportName: "CarrierApproval", ReportDescription: "Carrier Approval Status Reports", Width: 100, Height: 650
    },
    {
      ReportName: "OperatingStatus", ReportDescription: "Operating Status/Company Type Report", Width: 100, Height: 650
    },
    {
      ReportName: "GroupReport", ReportDescription: "Group Report", Width: 100, Height: 650
    },
    {
      ReportName: "RatingsUpdate", ReportDescription: "Rating Update Report", Width: 100, Height: 650
    },
    {
      ReportName: "MarketingReport", ReportDescription: "Marketing Report - Comparative Ratings", Width: 100, Height: 650
    }];


  constructor(private _router: Router, private _activatedRoute: ActivatedRoute,
    private _settings: Settings, private _sanitizer: DomSanitizer, private _loggedInUser: LoggedInUser,
    private _translate: TranslateService, private _reportsService: ReportsService) {
    this.showReport();
    /*
    this._activatedRoute.queryParams
      .switchMap((params: ParamMap) => Observable.of(params))
      .subscribe((reportCode) => console.log(reportCode));
      */
  }

  ngOnInit() {
    this.role = this._loggedInUser.getUserRoleCode();
    this._translate.use('en');
  }



  showReport() {
    if (this._activatedRoute.snapshot.paramMap.get('reportName') !== null) {
      this.isReportsActive = true;

      this._reportsService.GetReportUrl(this._activatedRoute.snapshot.paramMap.get('reportName'))
        .subscribe((result) => {
          if (result == "Unauthorized") {
            this.reportUrl = null;
            this.message = "You are not authorised to view this page";
          }
          else if (result == "Notfound") {
            this.reportUrl = null;
            this.message = "Sorry, The Report, You are Looking for is not found..";
          }
          else {
            result = this._settings.getReportsUrl() + result.substring(6);
            this.reportUrl = this._sanitizer.bypassSecurityTrustResourceUrl(result);
          }
        }, (error) => { });
    } else {
      this.isReportsActive = false;
    }
  }

  getReport(index: any) {
    let report = this.reports[index];
    //console.log(report);
    //this._router.navigate(['/reports', report.ReportName]);
    if (report.ReportName == "MarketingReport"){//(report.ReportDescription == "Marketing Report - Comparative Ratings") {
      this._router.navigate(['/comparative-report']);
    }
    else if (report.ReportName == "ApprovedList") {
      this.approvedListMessage();
    }
    else {
      this._router.navigate(['/admin-reports', report.ReportName]);

    }

  }
  getMsdReport(index: any) {
    let MsdReport = this.MsdReports[index];
    this._router.navigate(['/admin-reports', MsdReport.ReportName]);
  }

  getWillisReadReport(index: any) {
    let report = this.willisReadReport[index];
    if (report.ReportName == "ApprovedList") {
      this.approvedListMessage();
    }
    else if (report.ReportName == "MarketingReport") {
      this._router.navigate(['/comparative-report']);
    }
    else {
      this._router.navigate(['/reports', report.ReportName]);
    }
    // this._router.navigate(['/reports', {reportName: report.ReportName}]);
  }

  approvedListMessage() {
    this.printMessage = 'The report you have selected is too large to be processed online, it will be prepared offline and emailed to you. Do you wish to proceed? ';
    document.getElementById("approvedListBtn").click();
  }

  generateApprovedListReport() {
    this._reportsService.GetApprovalReportUrl("ApprovalList")
      .subscribe((result) => {
      }, (error) => { });
  }
}
