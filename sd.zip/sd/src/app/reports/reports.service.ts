﻿import { Injectable } from '@angular/core';
import { Http, RequestOptions, Headers } from '@angular/http';
import { Observable } from 'rxjs/Rx';
import { Settings } from '../shared/settings/settings.service';
import { LoggedInUser } from '../shared/loggedInUser/LoggedInUser';

@Injectable()
export class ReportsService {
    constructor(private _http: Http, private _settings: Settings, private _loggedInUser: LoggedInUser) {

    }

    GetReportUrl(reportName : string): Observable<string> {
        return this._http.post(this._settings.getReportsUrl() + 'adminreport/ViewReport/' + reportName,
            JSON.stringify({ 'userId': this._loggedInUser.getUserId()}))
            .map((response) => {
                return response.json();
            });          
    }

    GetApprovalReportUrl(reportName : string): Observable<string> {
        return this._http.post(this._settings.getReportsUrl() + 'adminreport/SendApprovalListNotification/' + reportName,
            JSON.stringify({ 'userId': this._loggedInUser.getUserId()}))
            .map((response) => {
                return response.json();
            });          
    }
}