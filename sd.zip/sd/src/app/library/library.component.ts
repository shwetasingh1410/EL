import { Component, OnInit } from '@angular/core';
import { TranslateService } from '../translate/translate.service';

declare var $: any;
@Component({
  selector: 'app-library',
  templateUrl: './library.component.html',
  styleUrls: ['./library.component.css']
})
export class LibraryComponent implements OnInit {
  constructor(private _translate: TranslateService) {
    
  }

  ngOnInit() {
    this._translate.use('en');

  }
}