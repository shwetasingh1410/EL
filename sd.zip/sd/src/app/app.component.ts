﻿import { Component, Inject, ViewChild, ElementRef, AfterViewInit, OnDestroy, OnInit, SecurityContext, DoCheck } from '@angular/core';
import { DOCUMENT } from '@angular/platform-browser';
import { Router, NavigationEnd  } from '@angular/router';
import { LoaderService } from './shared/loaderComponent/Loader.service';
import { Settings } from './shared/settings/settings.service';
import { Http } from '@angular/http';
import { PageAccessHelper } from './shared/page-access-levels/page-access-levels.helper';
import { MsHomeAccessLevels, HomeAccessLevels } from './app.access-levels';
import { AcceptTermsOfUseService } from './accept-terms-of-use/accept-terms-of-use.service';
import { Storage } from './shared/storage/storage.service';
import * as _ from "lodash";
import { TranslateService } from './translate/translate.service';
import { LoggedInUser } from './shared/loggedInUser/LoggedInUser';
import { AuthService } from './shared/loggedInUser/auth.service';
import { SessionService } from './shared/user-attempt/user-attempt-session.service';
import { DomSanitizer } from '@angular/platform-browser';
import { CoolSessionStorage } from 'angular2-cool-storage';
import { ClientService } from './select-client/client.service';

declare var $: any;
declare var window: any;

import { RecentlyViewedCarriersService } from './recently-viewed-carriers/recently-viewed-carriers.service';
import { Carrier } from "app/carrier-search/carriersearch.model";
import { RecentlyViewedCarriers} from './recently-viewed-carriers/recently-viewed-carriers.model';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
  providers: [PageAccessHelper, AcceptTermsOfUseService, SessionService,RecentlyViewedCarriersService ]
})
export class AppComponent implements OnInit, DoCheck, OnDestroy {

  @ViewChild('hoverElem') el: ElementRef;
  @ViewChild('activeme') el2: ElementRef;
  @ViewChild('activeme1') el3: ElementRef;
  @ViewChild('hoverElem1') el4: ElementRef;
  carriers: Array<RecentlyViewedCarriers>
  active = 'Market Security';
  passive = 'Market Security Admin';
  role: string;
  isAdminActive = false;
  isUserActive = true;
  dropdownOpen = false;
  url = 'url';
  activeUrl: string;
  headervalue;
  isLoading: boolean;
  pageAccessLevels: MsHomeAccessLevels;
  newpageAccessLevels: HomeAccessLevels;
  userLatestTermsOfUseVersionId: any;
  latestTermsOfUseVersionId: any;
  currentVersionId: number;
  termsOfUseText: string;
  acceptTermsOfUseFlag: boolean;
  issave: boolean;
  dropdownmsgfilesOpen = false;
  dropDownRecentCarriersOpen = false;
  msgExist: boolean = false;
  superAdminExist: boolean = false;
  sessionStorageStorage: CoolSessionStorage;
  isUserLoggedIn: Boolean;
  showValue: Boolean;
  isWTWComparativeRating :Boolean = false;

  constructor( @Inject(DOCUMENT) private document: any, private _clientService: ClientService, private _router: Router,
    private _loaderService: LoaderService, private _http: Http, private _settings: Settings
    , private _pageAccessHelper: PageAccessHelper, private _acceptTermsOfUseService: AcceptTermsOfUseService,
    private _storage: Storage, private _translate: TranslateService, private _loggedInUser: LoggedInUser,
    private _sessionService: SessionService, private _sanitizer: DomSanitizer, private _authService: AuthService, sessionStorageStorage: CoolSessionStorage,
    private _recentlyViewedCarriersService: RecentlyViewedCarriersService) {

    this.isUserLoggedIn = this._authService.isUserLoggedIn();
    this.sessionStorageStorage = sessionStorageStorage;
    this.pageAccessLevels = new MsHomeAccessLevels();
    this.newpageAccessLevels = new HomeAccessLevels();
    this.showValue = true;

    this.hitme();
    this._loaderService.showLoader
      .subscribe((result) => {
        this.isLoading = result;

      })
    this._router.events.subscribe(() => this.hitme());
  }

  ngOnInit(): void {
    this.displayRecentlyViewedCarriers();
    this._authService.signInComplete();

    $.getScript('./assets/scripts/richTextEditor.js');
    this._router.events.subscribe((evt) => {
      if (!(evt instanceof NavigationEnd)) {
        return;
      }
      window.scrollTo(0, 0)
    });
    this.functionToDisplayLatesttermsOfUseData();
    this._pageAccessHelper.getPageAccessLevelsDetails("Home", this.newpageAccessLevels);
    this._pageAccessHelper.getPageAccessLevelsDetails("msHome", this.pageAccessLevels);
    this.role = this._loggedInUser.getUserRoleCode();

    if (this.sessionStorageStorage.getItem("FirstAttempt") == "No") {
      this._storage.setItem("isTermsOfUseAccepted", "true");
    }

    if (this.sessionStorageStorage.getItem("FirstAttempt") !== "No") {
      this.functiononload();

    }

    this._translate.use('en');
    this.issave = true;
  }

  displayRecentlyViewedCarriers() {
    this._recentlyViewedCarriersService
      .getRecentlyViewedCarriers().
      subscribe((result) => {
        this.carriers = result;
      }
      );
  }
  navigateToCarrierDetails_carrier(index: number) {
    var data = this.carriers[index];
    this._clientService.setCarrierObject(data);
    var code = 'code';
    var carrier = 'carrier';
    var client = 'client';
    var account = this._clientService.getSelectedAccount();
    var tabName
    if (this._loggedInUser.getUserRoleCode() != "ClientRead") {
      tabName = "general";
    }
    else {
      tabName = "summary";
    }
    if (account)
      this._router.navigate(['carrier-detail', client, account.AccountId, carrier, data.CarrierId, code, data.WillisCode, tabName]);
    else {
      this._clientService.setRevertUrl(tabName);
      this._router.navigate(['select-client']);
    }
  }
  functiononload() {
    this.userLatestTermsOfUseVersionId = this._loggedInUser.getUserLatestTermsOfUseId();
    this.latestTermsOfUseVersionId = this._loggedInUser.getLatestTermsOfUseId();

    if (this.userLatestTermsOfUseVersionId === null || this.userLatestTermsOfUseVersionId === undefined) {
      document.getElementById("Btnmodal").click();

    }
    else if (this.userLatestTermsOfUseVersionId !== null) {
      if (this.userLatestTermsOfUseVersionId !== this.latestTermsOfUseVersionId) {
        document.getElementById("Btnmodal").click();
      }
      else
        this._storage.setItem("isTermsOfUseAccepted", "true");
    }
    else
      this._storage.setItem("isTermsOfUseAccepted", "true");
  }

  ngOnDestroy(): void {

    this._loaderService.showLoader.unsubscribe();
  }



  functionToDisplayLatesttermsOfUseData() {
    this._acceptTermsOfUseService
      .gettermsofuseByCurrentVersion().
        subscribe((result) => {
            this.termsOfUseText = this._sanitizer.sanitize(SecurityContext.HTML, result.TermsOfUseText);
            $('#editoraccepttermsofuse').html(this.termsOfUseText);
            $('#editoraccepttermsofuse a').attr('target', '_blank');
        //this.termsOfUseText = result.TermsOfUseText;
        this.currentVersionId = result.Version;
      });
  }

  acceptTermsOfUse(e): void {

    if (e.target.checked) {
      this.acceptTermsOfUseFlag = true;
      this.issave = false;

    }
    else {
      this.acceptTermsOfUseFlag = false;
      this.issave = true;


    }
  }

  saverecord() {
    this._acceptTermsOfUseService.
      UpdateUserVersion(this._loggedInUser.getUserId(), this.currentVersionId)
      .subscribe((result) => {
        this.sessionStorageStorage.setItem("FirstAttempt", "No");
        this._storage.setItem("isTermsOfUseAccepted", "true");
        document.getElementById("BtnClosemodal").click();
      });
  }



  declinerecord() {
    this.sessionStorageStorage.setItem("FirstAttempt", "");
    this._storage.setItem("isTermsOfUseAccepted", "false");
    document.getElementById("BtnClosemodal").click();
    //this._router.navigateByUrl('/logout');
    //this._authService.signOut();
    window.signOutComponent.zone.run(function () {
      window.signOutComponent.componentFn();
    });
  }


  ngDoCheck() {

    $('#hoverElem').hover(
      () => {
        this.superAdminExist = true;
        this.msgExist = false;
        $('.nav-vertical-submenu').addClass('active');
      },
      () => {
        $('.nav-vertical-submenu').removeClass('active');
      }
    );
    $('#activeme').hover(
      () => {
        $('.nav-vertical-submenu').addClass('active');
      },
      () => {
        $('.nav-vertical-submenu').removeClass('active');
      }
    );
    $('#hoverElem1').hover(
      () => {
        this.superAdminExist = false;
        this.msgExist = true;
        $('.nav-vertical-submenu').addClass('active');
      },
      () => {
        $('.nav-vertical-submenu').removeClass('active');
      }
    );
  }

  menutoggle() {
    $('.navbar-toggler').toggleClass("opentime closedtime");
    $('.nav-mobile-text').toggleClass("hidden-sm-down hidden-sm-up");
  }


  hitme() {
    // $("#recent").load(location.href+ ' #newrecent');
    this.url = this.document.location.href;
    this.activeUrl = this.url.substring(this.url.lastIndexOf('/') + 1);
    if (this._loggedInUser.getUserRoleCode() === 'WillisRead') {
      if (this.url.endsWith('home') || this.url.endsWith('download') || this.url.endsWith('group-code') || this.url.endsWith('forbidden') || this.url.endsWith('url-render') || this.url.endsWith('carrier-search') || this.url.includes('/client/') || this.url.endsWith('carrier-favorites') ||
        this.url.endsWith('notification') || this.url.includes('/acc/') || this.url.includes('/account/') || this.url.endsWith('carrier-doc') || this.url.endsWith('select-client') ||
        this.url.endsWith('general') || this.url.endsWith('summary')
        || this.url.endsWith('financials') || this.url.endsWith('documents') || this.url.endsWith('licenses')
        || this.url.endsWith('reports') || this.url.endsWith('AuditTrail') || this.url.endsWith('ApprovedList') ||
        this.url.endsWith('CarrierApproval') || this.url.endsWith('OperatingStatus') ||
        this.url.endsWith('GroupReport') || this.url.endsWith('RatingsUpdate') || this.url.endsWith('MarketingReport')
        || this.url.endsWith('AdminCode') || this.url.endsWith('MarketComparision') || this.url.endsWith('RatingAgency') ||
        this.url.endsWith('doc-library') || this.url.endsWith('related-links') || this.url.endsWith('user-help') ||
        this.url.endsWith('useinreports') || this.url.endsWith('view-disclaimer') || this.url.includes('returnurl') 
        || this.url.endsWith('comparative-report')) {
          if(this.url.endsWith('comparative-report')){
            this.isWTWComparativeRating = true;
          }
        if (!this._clientService.getRedirectFromAdmin() || this.isWTWComparativeRating) {
          this.passive = 'Market Security Admin';
          this.active = 'Market Security';
          this.isAdminActive = false;
          this.isUserActive = true;
        } else {
          this.active = 'Market Security Admin';
          this.passive = 'Market Security';
          this.isAdminActive = true;
          this.isUserActive = false;
        }
      }
      else {
        this.active = 'Market Security Admin';
        this.passive = 'Market Security';
        this.isAdminActive = true;
        this.isUserActive = false;
      }

    }
    else if (this._loggedInUser.getUserRoleCode() !== 'WillisRead') {
      if (this.url.endsWith('home') || this.url.endsWith('download') || this.url.endsWith('group-code') || this.url.endsWith('forbidden') || this.url.endsWith('url-render') || this.url.endsWith('carrier-search') || this.url.includes('/client/') || this.url.endsWith('carrier-favorites') ||
        this.url.endsWith('notification') || this.url.endsWith('carrier-doc') || this.url.includes('/account/') || this.url.endsWith('select-client') ||
        this.url.endsWith('general') || this.url.endsWith('summary')
        || this.url.endsWith('financials') || this.url.endsWith('documents') || this.url.endsWith('licenses') ||
        this.url.endsWith('doc-library') || this.url.endsWith('related-links') || this.url.endsWith('user-help') ||
        this.url.endsWith('document-search') || this.url.endsWith('useinreports') || this.url.endsWith('view-disclaimer')
        || this.url.includes('returnurl')) {
        if (!this._clientService.getRedirectFromAdmin()) {
          this.passive = 'Market Security Admin';
          this.active = 'Market Security';
          this.isAdminActive = false;
          this.isUserActive = true;
        } else {
          this.active = 'Market Security Admin';
          this.passive = 'Market Security';
          this.isAdminActive = true;
          this.isUserActive = false;
        }
      }
      else {
        this.active = 'Market Security Admin';
        this.passive = 'Market Security';
        this.isAdminActive = true;
        this.isUserActive = false;
      }

    }
    if (this.url.endsWith('home') || this.url.endsWith('#') || this.url.endsWith('') || this.url.endsWith('doc-library') || this.url.endsWith('document-search') || this.url.endsWith('related-links') || this.url.endsWith('download')) {
      this.headervalue = 'Welcome To Market Security';
      this.showValue = false;
    }

    if (this.url.endsWith('msHome')) {
      this.headervalue = 'Market Security Admin';
      this.showValue = true;
    }
    if ( this.url.endsWith('admin-help')){
      this.headervalue = 'Help';
      this.showValue = true; 
    }

    if( this.url.endsWith('manage-library')){
      this.headervalue = 'Manage Library';
      this.showValue = true;
    }
    if (this.url.endsWith('disclaimers') || this.url.endsWith('view-disclaimer')) {
      this.headervalue = 'Manage Disclaimers';
      this.showValue = true;
    }
    if (this.url.endsWith('ratings')) {
      this.headervalue = 'Rating Scale';
      this.showValue = true;
    }
    if (this.url.endsWith('edit-user')) {
      this.headervalue = 'User Maintenance';
      this.showValue = true;
    }
    if (this.url.endsWith('announcements')) {
      this.headervalue = 'Announcements';
      this.showValue = true;
    }
    if( this.url.endsWith('user-help') ){
      this.headervalue = 'Help';
      this.showValue = true
    }
    if (this.url.endsWith('carrier-search') || this.url.includes('/client/') || this.url.endsWith('group-code')) {
      this.headervalue = 'Carrier Search';
      this.showValue = true;
    }
    if (this.url.endsWith('notification') || this.url.includes('/account/') || this.url.endsWith('group-code')) {
      this.headervalue = 'Notifications';
      this.showValue = true;
    }
    if (this.url.endsWith('carrier-doc')) {
      this.headervalue = 'Client Documents';
      this.showValue = true;
    }
    if (this.url.endsWith('home-page-admin')) {
      this.headervalue = 'Home Page - Admin';
      this.showValue = true;
    }
    if (this.url.endsWith('carrier-favorites')) {
      this.headervalue = 'Carrier Favorites Maintenance';
      this.showValue = true;
    }
    if (this.url.endsWith('carrier-favorites-admin')) {
      this.headervalue = 'Carrier Favorites Admin';
      this.showValue = true;
    }
    if (this.url.endsWith('client-maintenance')) {
      this.headervalue = 'Client Maintenance';
      this.showValue = true;
    }
    if (this.url.endsWith('doc-access')) {
      this.headervalue = 'Document Access';
      this.showValue = true;
    }
    if (this.url.endsWith('doc-folder')) {
      this.headervalue = 'Document Folder';
      this.showValue = true;
    }
    if (this.url.endsWith('reports')) {
      this.headervalue = 'Reports';
      this.showValue = true;
    }
    if (this.url.endsWith('useinreports')) {
      this.headervalue = 'Client Reports';
      this.showValue = true;
    }
    if (this.url.endsWith('related-links')) {
      this.headervalue = 'Related Links';
      this.showValue = true;
    }
    if (this.url.endsWith('document-search')) {
      this.headervalue = 'Document Search';
      this.showValue = true;
    }
    if (this.url.endsWith('doc-library')) {
      this.headervalue = 'Library';
      this.showValue = true;
    }
    if (this.url.endsWith('superuseradmin')) {
      this.headervalue = 'Super User Admin';
      this.showValue = true;
    }
    if (this.url.endsWith('select-client')) {
      this.headervalue = 'Select Client';
      this.showValue = true;
    }
    if (this.url.search('carrier-detail') !== -1) {
      this.headervalue = 'Carrier Details';
      this.showValue = true;
    }
    if (this.url.endsWith('(carrierdetails:general)') || this.url.endsWith('(carrierdetails:summary)') || this.url.endsWith('(carrierdetails:financials)') || this.url.endsWith('(carrierdetails:documents)') || this.url.endsWith('(carrierdetails:licenses)') || this.url.endsWith('url-render')) {
      this.headervalue = 'Carrier Details';
      this.showValue = true;
    }
    if (this.url.endsWith('terms-of-use')) {
      this.headervalue = 'Manage Terms Of Use';
      this.showValue = true;
    }
    if (this.url.endsWith('AuditTrail') || this.url.endsWith('ApprovedList') ||
      this.url.endsWith('CarrierApproval') || this.url.endsWith('OperatingStatus') ||
      this.url.endsWith('GroupReport') || this.url.endsWith('RatingsUpdate') || this.url.endsWith('MarketingReport')
      || this.url.endsWith('AdminCode') || this.url.endsWith('MarketComparision') || this.url.endsWith('RatingAgency')
      || this.url.endsWith('comparative-report')) {
      this.headervalue = 'Reports';
      this.showValue = true;
    }

  }

  dropdownstatus() {
    this.dropdownOpen = !this.dropdownOpen;
  }

  dropdownmsgfilesstatus() {
    this.dropdownmsgfilesOpen = !this.dropdownmsgfilesOpen;
  }
  dropDownRecentCarriers() {
    this.dropDownRecentCarriersOpen = !this.dropDownRecentCarriersOpen;
  }

  activeComp(data) {

    if (data == 'Market Security Admin') {
      this.active = 'Market Security Admin';
      this.passive = 'Market Security';
      this.isAdminActive = true;
      this.isUserActive = false;
      this._router.navigate(['msHome']);
      this.headervalue = "Market Security Admin";
      this._sessionService.setsession("No");
      // window.location.reload();
    }
    else {
      this.passive = 'Market Security Admin';
      this.active = 'Market Security';
      this._clientService.setRedirectFromAdmin(false);
      this._clientService.setRedirectToCarrierFavoritesAdmin(false);
      this._clientService.setRedirectToClientMaintenance(false);
      this._clientService.setRedirectToSearch(false);
      this.isAdminActive = false;
      this.isUserActive = true;
      this._router.navigate(['home']);
      this.headervalue = "Welcome To Market Security";
      this.showValue = false;

      //window.location.reload();
    }
  }
  activeCompMob(data) {
    // console.log(data);
    if (data == 'Market Security Admin') {
      this.active = 'Market Security Admin';
      this.passive = 'Market Security';
      this.isAdminActive = true;
      this.isUserActive = false;
      this._router.navigate(['msHome']);
      this.headervalue = "Market Security Admin";
    }
    else {
      this.passive = 'Market Security Admin';
      this.active = 'Market Security';
      this.isAdminActive = false;
      this.isUserActive = true;
      this._router.navigate(['home']);
      this.headervalue = "Welcome To Market Security";
      this.showValue = false;
    }
  }

  logout() {
    this._http.get(this._settings.getApiUrl() + 'api/auth/logout')
      .subscribe((response) => {
        this._sessionService.setsession(1);
        // TODO : redirect to oneplace
      });
  }


}
