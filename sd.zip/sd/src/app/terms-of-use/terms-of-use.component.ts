﻿import { Component, Directive, OnInit, AfterContentInit, SecurityContext } from '@angular/core';
import { LoaderService } from '../shared/loaderComponent/Loader.service';
import { TermsOfUseService } from './terms-of-use.service';
import { TermsOfUse } from './terms-of-use.model';
import { TermsOfUseResult } from './terms-of-use.mock.data';
import { FormsModule } from '@angular/forms';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/observable/fromEvent';
import { Subscription } from 'rxjs/Subscription';
import { TranslateService } from '../translate/translate.service';
import { TruncateModule } from 'ng2-truncate';
import * as _ from 'lodash';
import { SafeContentPipe } from './safe-content.pipe';
import { SanitizeHtml, SanitizeResourceUrl, SanitizeScript, SanitizeStyle, SanitizeUrl } from 'ng2-sanitize';
import { DomSanitizer } from '@angular/platform-browser';
declare var $: any;

@Component({
  selector: 'app-terms-of-use',
  templateUrl: './terms-of-use.component.html',
  styleUrls: ['./terms-of-use.component.css'],
  providers: [TermsOfUseService]
})
export class TermsOfUseComponent implements OnInit, AfterContentInit {

  termsOfUseResult: Array<TermsOfUse>;
  isError: boolean;
  isSuccess: boolean;
  isAlert: boolean;
  message: string;
  saveSuccess: false;
  currentVersionId: number;
  termsOfUseText: string;
  id: string;
  disableDIV: boolean;
  subscription: Subscription;
  iseditable: boolean;
  isFormattingDisabled: boolean;
  iseditclick: boolean;
  previoestermsOfUseText: string;
  issave: boolean;
  entertermsOfUseText: string;  
  constructor(private _loaderService: LoaderService, private _termsOfUseService: TermsOfUseService, private _translate: TranslateService, private _sanitizer: DomSanitizer) {
    // this.termsOfUseResult = new Array<TermsOfUse>();
    this.termsOfUseText = '';

  }


  ngOnInit() {
    this.richTextEditor();
    this._loaderService.show();
    this.subscription = Observable.fromEvent(document, 'keydown').subscribe(e => {
      this.entertermsOfUseText = $('#editor').html();
      if (this.previoestermsOfUseText.trim() === this.entertermsOfUseText) {
        this._loaderService.hide();
        this.issave = true;
      }
      else {
        this._loaderService.hide();
        this.issave = false;
      }

    }, (error) =>{ 
      this._loaderService.hide();
      this.handleError(error)});

    this.subscription = Observable.fromEvent(document, 'keyup').subscribe(e => {
      this.entertermsOfUseText = $('#editor').html();
      if (this.previoestermsOfUseText.trim() === this.entertermsOfUseText) {
        this._loaderService.hide();
        this.issave = true;
      }
      else {
        this._loaderService.hide();
        this.issave = false;
      }

    }, (error) =>{ 
      this._loaderService.hide();
      this.handleError(error)});

    this.iseditable = false;
     this.isFormattingDisabled = true;
    this._translate.use('en');
  }


  ngAfterContentInit() {
    this.functionToFetchtermsOfUseData();
    this.functionToDisplayLatesttermsOfUseData();
    this.issave = true;
    this.iseditable = false;
     this.isFormattingDisabled = true;
    this.isSuccess = false;
    this.isError = false;
    this.isAlert = false;
    this.richTextEditor();
  }

  ngOnDestroy() {
    this.subscription.unsubscribe();
  }

  functionToFetchtermsOfUseData() {
    this._loaderService.show();
    this._termsOfUseService
      .getalltermsofuse().
      subscribe((result) => {
        this._loaderService.hide();
        this.termsOfUseResult = result;
        this.termsOfUseResult.forEach(res => {
          while(res.TermsOfUseText.includes('&lt;') || res.TermsOfUseText.includes('&gt;') || res.TermsOfUseText.includes('&amp;')  ||res.TermsOfUseText.includes('&nbsp;') || res.TermsOfUseText.includes('&quot;'))
          res.TermsOfUseText=res.TermsOfUseText.replace('&lt;','<').replace('&gt;','>').replace(/&nbsp;/g, ' ').replace('&quot;',"'").replace('&nbsp;', ' ').replace('&amp;', '&');
          res.TermsOfUseText=this.htmlToPlaintext(res.TermsOfUseText);
        })

      }, (error) =>{ 
        this._loaderService.hide();
        this.handleError(error)});
  }

  htmlToPlaintext(text) {
    // return text ? String(text).replace(/<[^>]+>/gm, '') : '';
    return text ? String(text).replace(/<[^>]+>/gm, '').replace(/&nbsp;/g, ' ') : '';
    
  }


  functionToDisplayLatesttermsOfUseData() {
    this._loaderService.show();
    this._termsOfUseService
      .gettermsofuseByCurrentVersion().
      subscribe((result) => {
        this._loaderService.hide();
          $("#editor").eq(0).attr("contenteditable", false);
          this.termsOfUseText = this._sanitizer.sanitize(SecurityContext.HTML, result.TermsOfUseText);
          $('#editor').html(this.termsOfUseText);

        //$('#editor').html(result.TermsOfUseText);
        //this.termsOfUseText = result.TermsOfUseText;
        this.previoestermsOfUseText = this.termsOfUseText;
        this.currentVersionId = result.Version;
        this.id = result.Id;
      }, (error) =>{ 
        this._loaderService.hide();
        this.handleError(error)});
  }

  Edittermsofuse(edditVersionId: number) {
    this.gettermsofuseByVersionId(edditVersionId);
    
    this.issave = true;
    if (this.currentVersionId === edditVersionId) {
      this.iseditclick = true;
      this.iseditable = false;
      $("#editor").eq(0).attr("contenteditable", false);

    }
    else {
      this.iseditable = true;
      $("#editor").eq(0).attr("contenteditable", false);

    }

  }

  gettermsofuseByVersionId(edditVersionId: number) {
    this._loaderService.show();
    this._termsOfUseService
      .gettermsofuseByVersion(edditVersionId)
        .subscribe((result) => {
          this._loaderService.hide();
            this.termsOfUseText = this._sanitizer.sanitize(SecurityContext.HTML, result.TermsOfUseText);
            $('#editor').html(this.termsOfUseText);
        
        this.previoestermsOfUseText = result.TermsOfUseText;
        document.body.scrollTop = document.documentElement.scrollTop = 0;
      }, (error) =>{ 
        this._loaderService.hide();
        this.handleError(error)});

  }

  gettexteditorEditableforedit() {
    $("#editor").eq(0).attr("contenteditable", true);
    this.issave = true;
    this.iseditclick = true;
    this.isSuccess = false;
    this.isError = false;
    this.isAlert = false;
    this.iseditable = true;
    this.isFormattingDisabled = false;
  }

  gettexteditorEditableforsave() {

    $("#editor").eq(0).attr("contenteditable", true);
    $('#editor').html('');
    this.previoestermsOfUseText = "";
    this.issave = true;
    this.iseditclick = false;
    this.isSuccess = false;
    this.isError = false;
    this.isAlert = false;
    this.iseditable = true;
    this.isFormattingDisabled = false;
  }

  saverecord() {

    if (this.iseditclick === true) { /* Here If to have the Condition */
      this.UpdateTermsOfUseText();
    } else {
      this.createTermsOfUseText();
    }

  }




  createTermsOfUseText() {
    this.termsOfUseText = $('#editor').html();

    if (this.checkvalidation() === true) {
      this._loaderService.show();
      this._termsOfUseService.CreateTermsOfUseText(this.termsOfUseText, this.currentVersionId)
      .subscribe((result) => {
        this._loaderService.hide();
        this.showSuccess('Terms Of Use Text saved successfully');
        this.functionToFetchtermsOfUseData();
        this.functionToDisplayLatesttermsOfUseData();
        this.issave = true;
        this.currentVersionId = result;
        this.iseditable = false;
        this.isFormattingDisabled = true;
      }, (error) =>{ 
        this._loaderService.hide();
        this.handleError(error)});
    }

  }


  UpdateTermsOfUseText() {
    this.termsOfUseText = $('#editor').html();

    if (this.checkvalidation() === true) {
      this._loaderService.show();
      this._termsOfUseService.UpdateTermsOfUseText(this.termsOfUseText, this.currentVersionId, this.id).subscribe((result) => {
        this._loaderService.hide();
        this.showSuccess('Terms Of Use Text Update successfully');
        this.functionToFetchtermsOfUseData();
        this.functionToDisplayLatesttermsOfUseData();
        this.issave = true;
        this.iseditable = false;
        this.isFormattingDisabled = true;
      }, (error) =>{ 
        this._loaderService.hide();
        this.handleError(error)});
    }

  }

  checkvalidation() {
    this.termsOfUseText = ($('#editor').html());
    if (this.termsOfUseText === undefined || this.termsOfUseText === null || this.termsOfUseText === "" || this.termsOfUseText.trim() === "" || $('#editor').html() == "") {
      this.handleAlert("Message is Required");
      return false;
    }
    else {
      return true;
    }
  }



  getHomepage() {
    this.functionToFetchtermsOfUseData();
    this.functionToDisplayLatesttermsOfUseData();
    this.issave = true;
    this.iseditable = false;
    this.isSuccess = false;
    this.isError = false;
    this.isAlert=false;
  }


  showSuccess(message: string) {
    this.message = message;
    this.isSuccess = true;
    setTimeout(() => {
      this.isSuccess = false;
    }, 3000);
    this.isError = false;
    this.isAlert=false;
  }

  showError(message: string) {
    this.isSuccess = false;
    this.isError = true;
    setTimeout(() => {
      this.isError = false;
    }, 3000);
    this.message = message;
    this.isAlert=false;

  }


  handleError(error) {
    this.isSuccess = false;
    this.isError = true;
    setTimeout(() => {
      this.isError = false;
    }, 3000);
    //error.status = 412;
    if(error.status === 412){
    this.showError('Error 412 : Input Output Validation Error. Please enter details again. ');  
    }
    else if(error.status === 422){
    this.showError('Error 422 : Business Validation Error. Please try again');
    }
    else if(error.status === 500){
    this.showError('500 Internal Server Error. Please try again');
    }
    else{
      this.showError('Server Error. Please try again');
    }
  }

  handleAlert(message: string) {
    this.isAlert = true;
    setTimeout(() => {
      this.isAlert = false;
    }, 3000);
    this.isError = false;
    this.isSuccess = false;
    this.message = message;
    
  }
  ///////////
checkNewText()
{
  this.entertermsOfUseText = $('#editor').html();
  if (this.previoestermsOfUseText.trim() === this.entertermsOfUseText) {
    this.issave = true;
  }
  else {
    this.issave = false;
  }
}

  makeBold() {
    document.execCommand('bold', false, null);
    this.checkNewText();
  }

  makeItalics() {
    document.execCommand('italic', false, null);
    this.checkNewText();
  }

  makeUnderlined() {
    document.execCommand('underline', false, null);
    this.checkNewText();
  }

  makeLeft() {
    document.execCommand('justifyLeft', false, null);
    this.checkNewText();
  }

  makeCenter() {
    document.execCommand('justifyCenter', false, null);
    this.checkNewText();
  }

  makeRight() {
    document.execCommand('justifyRight', false, null);
    this.checkNewText();
  }
  insertUnorderedList() {
    document.execCommand('insertUnorderedList', false, null);
    this.checkNewText();
  }


  insertOrderedList() {
    document.execCommand('insertOrderedList', false, null);
    this.checkNewText();
  }

  createLink() {
    var selected = document.getSelection();
    document.execCommand('createLink', false, 'http://' + selected);
    $("a").attr("target","_blank");
    this.checkNewText();
  }
  removeLink(){
  document.execCommand('unlink', false, null);
  this.checkNewText();
}

  generateHtmlCode() {
    HtmlElement2($("#editor"));

    function HtmlElement2(elem) {
      InsertHtml2($(elem).html());
    }

    function InsertHtml2(data) {
      var mywindow = window.open();
      mywindow.document.write('<html><head><title>Code</title>');
      mywindow.document.write('</head><body >');
      mywindow.document.write(data.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;"));
      mywindow.document.write('</body></html>');
      mywindow.document.close(); // necessary for IE >= 10
      mywindow.focus(); // necessary for IE >= 10
      //mywindow.close();
      return true;
    }
    // document.execCommand('htmlCode',false,null);
  }

  ///////////
  richTextEditor() {
    $(document).ready(function () {
      $("#subscript").click(function () {
        document.execCommand('subscript', false, null);
        
      });
      $("#superscript").click(function () {
        document.execCommand('superscript', false, null);
        
      });
    });
  }
}

