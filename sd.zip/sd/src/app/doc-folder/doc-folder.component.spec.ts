import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DocFolderComponent } from './doc-folder.component';
/*
describe('DocFolderComponent', () => {
  let component: DocFolderComponent;
  let fixture: ComponentFixture<DocFolderComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DocFolderComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DocFolderComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
*/