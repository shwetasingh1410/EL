import { Component, OnInit } from '@angular/core';
import {AfterViewInit, ViewChild, ViewContainerRef} from "@angular/core";
import {ICellEditorAngularComp} from "ag-grid-angular";
import {DocFolderService} from '../doc-folder.service';
import {DocFolderComponent} from '../doc-folder.component';
import { DocFolderEvents } from '../doc-folder.events';

@Component({
  selector: 'app-dropdown-access-editor',
  templateUrl: './dropdown-access-editor.component.html',
  styleUrls: ['./dropdown-access-editor.component.css']
})
export class DropdownAccessEditorComponent implements OnInit, ICellEditorAngularComp, AfterViewInit {
  
    constructor(private _docFolderService:DocFolderService,private _docFolderEvents:DocFolderEvents) {
  
    }
  
    @ViewChild('group', {read: ViewContainerRef}) public group;
    private params: any;
    clientNames=['Yes','No','Special']
    client;
  
    ngOnInit() {
      
    }
    // dont use afterGuiAttached for post gui events - hook into ngAfterViewInit instead for this
    ngAfterViewInit() {
        // this.group.element.nativeElement.focus();
    }
  
    agInit(params: any): void {
        this.params = params;
        this.setClient(this.params.value);
    }
  
  
    getValue(): any {
      if(this.client)
        return this.client;
        else
        return this.params.value;
  
    }
  
    isPopup(): boolean {
        return false;
    }
  
    setClient(client: string): void {
      if(client){
      if(client == 'Yes')
      this.client='Y';
     else if(client == 'No')
      this.client='N';
     else if(client == 'Special')
      this.client='S'
      else this.client=client;
      }
    }
  
    onClick(client:any) {
        this.setClient(client);
        this.params.api.stopEditing();
        // this._docFolderEvents.updateFocusedEvent.emit(this.params);
    }
}
