import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DropdownAccessEditorComponent } from './dropdown-access-editor.component';

describe('DropdownAccessEditorComponent', () => {
  let component: DropdownAccessEditorComponent;
  let fixture: ComponentFixture<DropdownAccessEditorComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DropdownAccessEditorComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DropdownAccessEditorComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
