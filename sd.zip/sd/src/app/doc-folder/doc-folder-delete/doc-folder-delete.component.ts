import { Component, OnInit } from '@angular/core';
import { DocFolderService } from '../doc-folder.service';
import {FolderInfo} from '../doc-folder.model';
import {DocFolderComponent} from '../doc-folder.component';
import { DocFolderEvents } from '../doc-folder.events';

@Component({
  selector: 'app-doc-folder-delete',
  templateUrl: './doc-folder-delete.component.html',
  styleUrls: ['./doc-folder-delete.component.css']
})
export class DocFolderDeleteComponent implements OnInit {

  private params: any;
  folderId:string='';

  constructor(private _docFolderService:DocFolderService, private _docFolderEvents : DocFolderEvents) { }

  ngOnInit() {
  }

  agInit(params: any): void {
    this.params = params;
  }

  deletefromfolder() {
 
    if(this.params){
      this.folderId=this.params.data.DocumentFolderId;
      if(this.folderId ){
        if(confirm('Are you sure you want to delete this folder?'))
        this._docFolderService.DeleteFolderGroupInfo(this.folderId).subscribe(result => {
          // this._docFolderComponent.getFolderInfo();
          this._docFolderEvents.folderDeleteEvent.emit(true);
        })
      }
    }
  }
}
