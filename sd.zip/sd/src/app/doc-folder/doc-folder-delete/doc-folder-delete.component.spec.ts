import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DocFolderDeleteComponent } from './doc-folder-delete.component';

describe('DocFolderDeleteComponent', () => {
  let component: DocFolderDeleteComponent;
  let fixture: ComponentFixture<DocFolderDeleteComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DocFolderDeleteComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DocFolderDeleteComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
