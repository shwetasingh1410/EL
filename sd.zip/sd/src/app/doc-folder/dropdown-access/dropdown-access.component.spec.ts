import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DropdownAccessComponent } from './dropdown-access.component';

describe('DropdownAccessComponent', () => {
  let component: DropdownAccessComponent;
  let fixture: ComponentFixture<DropdownAccessComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DropdownAccessComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DropdownAccessComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
