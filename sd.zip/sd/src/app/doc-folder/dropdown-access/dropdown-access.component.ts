import { Component, OnInit } from '@angular/core';
import {ICellRendererAngularComp} from "ag-grid-angular";
@Component({
  selector: 'app-dropdown-access',
  templateUrl: './dropdown-access.component.html',
  styleUrls: ['./dropdown-access.component.css']
})
export class DropdownAccessComponent implements ICellRendererAngularComp, OnInit {

  private params: any;
  public groupName: string;

  agInit(params: any): void {
      this.params = params;
      this.setGroupName(params);
  }

  ngOnInit() {
      
  }

  refresh(params: any): boolean {
      this.params = params;
      this.setGroupName(params);
      return true;
  }

  private setGroupName(params) {
    this.groupName=params.value;
  };

}
