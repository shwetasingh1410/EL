import { GroupDoc,FolderInfo, FolderDoc } from './doc-folder.model';

export class DocFolderHelper {
    
    static mapToGroupInfo(group: any): GroupDoc {
        return new GroupDoc(group.DocumentGroupId, group.IsCarrierDocument, group.DocumentGroup);
    }
    static mapToFolderDocInfo(folder: any): FolderDoc {
        return new FolderDoc(folder.DocumentFolderId,folder.DocumentFolder);
    }
    static mapToFolderInfo(folder: any): FolderInfo {
        return new FolderInfo(folder.DocumentFolderId,folder.DocumentFolder,folder.DocumentGroupId,folder.DocumentGroup,folder.IsCarrierDocument,folder.SortOrder,folder.ClientAccess);
    }
}