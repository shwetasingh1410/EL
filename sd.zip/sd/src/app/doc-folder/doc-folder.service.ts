import { Injectable } from '@angular/core';
import { Http, RequestOptions, Headers } from '@angular/http';
import { Observable } from 'rxjs/Rx';
import 'rxjs/add/operator/map';

import { Settings } from '../shared/settings/settings.service';
import { DocFolderHelper } from './doc-folder.helper';
import { GroupDoc,FolderInfo, FolderDoc } from './doc-folder.model';


@Injectable()
export class DocFolderService {
    constructor(private _http: Http, private _settings: Settings) {
    }

    
    GetGroupDocuments(): Observable<Array<GroupDoc>> {
        return this._http.get(this._settings.getDocumentApiUrl()+'api/document-folder/groups')
        .map((response) => {
            let result: Array<GroupDoc> = new Array<GroupDoc>();
            response.json().forEach((group) => {
                result.push(DocFolderHelper.mapToGroupInfo(group));
            });
            return result;
        });
    }
    GetFolderDocuments(): Observable<Array<FolderDoc>> {
        return this._http.get(this._settings.getDocumentApiUrl()+'api/document-folder/sharepoint-folders')
        .map((response) => {
            let result: Array<FolderDoc> = new Array<FolderDoc>();
            response.json().forEach((folder) => {
                result.push(DocFolderHelper.mapToFolderDocInfo(folder));
            });
            return result;
        });
    }

    GetFolderInfo(): Observable<Array<FolderInfo>> {
        return this._http.get(this._settings.getDocumentApiUrl()+'api/document-folder')
        .map((response) => {
            let result: Array<FolderInfo> = new Array<FolderInfo>();
            response.json().forEach((folder) => {
                result.push(DocFolderHelper.mapToFolderInfo(folder));
            });
            return result;
        });
    }

    PostDocumentGroupForId(FolderPath:string,FolderGroupId:string, ClientAccess:string) {
        let headers = new Headers();
        headers.append('Content-Type', 'application/json');
        let options = new RequestOptions({ headers: headers });
        return this._http.post(this._settings.getDocumentApiUrl()+'api/document-folder',
            JSON.stringify({
                'FolderPath': FolderPath,
                'FolderGroupId': FolderGroupId,
                'ClientAccess' : ClientAccess
            }), options);
    }
   
    PostDocumentGroupForName(FolderPath:string,FolderGroupName:string, ClientAccess:string) {
        let headers = new Headers();
        headers.append('Content-Type', 'application/json');
        let options = new RequestOptions({ headers: headers });
        return this._http.post(this._settings.getDocumentApiUrl()+'api/document-folder',
            JSON.stringify({
                'FolderPath': FolderPath,
                'FolderGroupName': FolderGroupName,
                'ClientAccess' : ClientAccess
            }), options);
    }

    PutFolderGroupInfo(FolderId:string,FolderGroupId:string,ClientAccess:string) {
        let headers = new Headers();
        headers.append('Content-Type', 'application/json');
        let options = new RequestOptions({ headers: headers });
        return this._http.put(this._settings.getDocumentApiUrl()+'api/document-folder/' + FolderId,
            JSON.stringify({
                'FolderGroupId': FolderGroupId,
                'ClientAccess': ClientAccess
            }), options);
    }

    DeleteFolderGroupInfo(FolderId: string) {
            return this._http.delete(this._settings.getDocumentApiUrl()+'api/document-folder/' + FolderId);
        }
}
