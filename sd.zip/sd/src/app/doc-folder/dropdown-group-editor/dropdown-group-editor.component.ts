import { Component, OnInit } from '@angular/core';
import { GroupDoc } from '../doc-folder.model';
import {AfterViewInit, ViewChild, ViewContainerRef} from "@angular/core";
import {ICellEditorAngularComp} from "ag-grid-angular";
import {DocFolderService} from '../doc-folder.service';
import {DocFolderComponent} from '../doc-folder.component';
import { DocFolderEvents } from '../doc-folder.events';

@Component({
  selector: 'app-dropdown-group-editor',
  templateUrl: './dropdown-group-editor.component.html',
  styleUrls: ['./dropdown-group-editor.component.css']
})
export class DropdownGroupEditorComponent implements OnInit, ICellEditorAngularComp, AfterViewInit {

  constructor(private _docFolderService:DocFolderService,private _docFolderEvents:DocFolderEvents) {

  }

  @ViewChild('group', {read: ViewContainerRef}) public group;
  private params: any;
  grpNames:Array <GroupDoc>;
  selectedGroup:GroupDoc;
  selectedGroupName:string = '';

  ngOnInit() {
    
  }
  // dont use afterGuiAttached for post gui events - hook into ngAfterViewInit instead for this
  ngAfterViewInit() {
      // this.group.element.nativeElement.focus();
  }

  agInit(params: any): void {
    this.getGroupDocs()
      this.params = params;
  }

  getGroupDocs(){
    // this.grpNames=this._docFolderComponent.getGroups(); // TO DO
    this._docFolderService.GetGroupDocuments().subscribe(result => {
      if (result) {
        this.grpNames = result;
      this.setGroup(this.params.value);
      }
    })
    
  }

  getValue(): any {
    if(this.selectedGroupName)
      return this.selectedGroupName;
      else
      return this.params.value;

  }

  isPopup(): boolean {
      return false;
  }

  setGroup(grpName: string): void {
    if(this.grpNames){
      for(let i=0;i<this.grpNames.length;i++){
        if(this.grpNames[i].GroupDocName == grpName){
          this.selectedGroup=this.grpNames[i];
          this.selectedGroupName=grpName;
        }
      }
    }
  }

  // toggleMood(): void {
  //     this.setHappy(!this.happy);
  // }

  onClick(grpName:any) {
    if(grpName)
      this.setGroup(grpName.GroupDocName);
      this.params.api.stopEditing();
      // this._docFolderComponent.gridOptions.api.setFocusedCell(this.params.rowIndex,'ClientAccess');
      // this._docFolderComponent.gridOptions.api.startEditingCell({
      //   rowIndex:this.params.rowIndex,
      //   colKey:'ClientAccess'
      // // });
      // this._docFolderEvents.folderEditStartEvent.emit(this.params);
  }

  // onKeyDown(event): void {
  //     let key = event.which || event.keyCode;
  //     if (key == 37 ||  // left
  //         key == 39) {  // right
  //         this.toggleMood();
  //         event.stopPropagation();
  //     }
  // }

}
