import { Injectable, EventEmitter } from '@angular/core';

@Injectable()
export class DocFolderEvents {
    folderDeleteEvent: EventEmitter<any> = new EventEmitter();
    folderUpdateEvent: EventEmitter<any> = new EventEmitter();
    folderUpdateCancelEvent: EventEmitter<any> = new EventEmitter();
    folderGetGroupsEvent: EventEmitter<any> = new EventEmitter();
    folderEditStartEvent: EventEmitter<any> = new EventEmitter();
    updateFocusedEvent: EventEmitter<any> = new EventEmitter();
    groupUpdateEvent: EventEmitter<any> = new EventEmitter();
}