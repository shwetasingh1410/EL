export class GroupDoc {
    GroupDocId: string;
    GroupCarrierDocuments:boolean;
    GroupDocName: string;

    constructor(GroupDocId: string, GroupCarrierDocuments:boolean, GroupDocName: string) {
        this.GroupDocId = GroupDocId;
        this.GroupCarrierDocuments = GroupCarrierDocuments;
        this.GroupDocName = GroupDocName;
    }
}

export class FolderDoc {
    DocumentFolderId: string;
    DocumentFolder: string;

    constructor(DocumentFolderId: string, DocumentFolder:string) {
        this.DocumentFolderId = DocumentFolderId;
        this.DocumentFolder = DocumentFolder;
    }
}

export class FolderInfo {
    DocumentFolderId: string;
    DocumentFolder: string;
    GroupDocId: string;
    GroupDocName: string;
    GroupCarrierDocuments: boolean;
    SortOrder: number;
    ClientAccess:string;

    constructor(DocumentFolderId: string, DocumentFolder:string, GroupDocId: string, GroupDocName:string, GroupCarrierDocuments:boolean, SortOrder:number, ClientAccess:string ) {
        this.DocumentFolderId = DocumentFolderId;
        this.DocumentFolder = DocumentFolder;
        this.GroupDocId = GroupDocId;
        this.GroupDocName = GroupDocName;
        this.GroupCarrierDocuments = GroupCarrierDocuments;
        this.SortOrder = SortOrder;
        this.ClientAccess = ClientAccess;
    }
}