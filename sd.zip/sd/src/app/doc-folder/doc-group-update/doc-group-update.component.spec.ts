import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DocGroupUpdateComponent } from './doc-group-update.component';

describe('DocGroupUpdateComponent', () => {
  let component: DocGroupUpdateComponent;
  let fixture: ComponentFixture<DocGroupUpdateComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DocGroupUpdateComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DocGroupUpdateComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
