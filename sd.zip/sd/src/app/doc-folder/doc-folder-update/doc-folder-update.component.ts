import { Component, OnInit } from '@angular/core';
import { DocFolderService } from '../doc-folder.service';
import { FolderInfo, GroupDoc } from '../doc-folder.model';
import { DocFolderComponent } from '../doc-folder.component';
import { DocFolderEvents } from '../doc-folder.events';

@Component({
  selector: 'app-doc-folder-update',
  templateUrl: './doc-folder-update.component.html',
  styleUrls: ['./doc-folder-update.component.css'],
  providers: [DocFolderService]
})
export class DocFolderUpdateComponent implements OnInit {

  private params: any;
  folderInfo: Array<FolderInfo> = [];
  groupDocs: Array<GroupDoc> = [];
  folderId: string = '';
  folderGroupId: string = '';
  ClientAccess: string = '';
  edit: boolean = true;

  constructor(private _docFolderService: DocFolderService, private _docFolderEvents: DocFolderEvents) { }

  ngOnInit() {
  }

  agInit(params: any): void {
    this.params = params;
  }

  doedit() {
    this.edit = false;
    this._docFolderEvents.folderUpdateEvent.emit(this.params);
  }

  cancel() {
    this._docFolderEvents.folderUpdateCancelEvent.emit();
  }

  updatetofolder() {
    this.folderId = this.params.data.DocumentFolderId;
    this.ClientAccess = this.params.data.ClientAccess;
      this._docFolderService.GetGroupDocuments().subscribe(result => {
        if (result) {
          this.groupDocs = result;
          for (let i = 0; i < this.groupDocs.length; i++) {
            if (this.groupDocs[i].GroupDocName == this.params.data.GroupDocName) {
              this.folderGroupId = this.groupDocs[i].GroupDocId;
              break;
            }
          }
          switch (this.ClientAccess) {
            case 'Yes': this.ClientAccess = 'Y'; break;
            case 'No': this.ClientAccess = 'N'; break;
            case 'Special': this.ClientAccess = 'S';
          }
          if (this.folderId && this.folderGroupId && this.ClientAccess) {
            this._docFolderService.PutFolderGroupInfo(this.folderId, this.folderGroupId, this.ClientAccess).subscribe(result => {
              // this._docFolderComponent.gridOptions.api.stopEditing();
              // this._docFolderComponent.getFolderInfo();
              this.edit=true;
              this._docFolderEvents.folderUpdateCancelEvent.emit();
            })
          }
        }
      })
    // this.groupDocs = this._docFolderComponent.getGroups(); // TO DO
    
    
  }
}