import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DocFolderUpdateComponent } from './doc-folder-update.component';

describe('DocFolderUpdateComponent', () => {
  let component: DocFolderUpdateComponent;
  let fixture: ComponentFixture<DocFolderUpdateComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DocFolderUpdateComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DocFolderUpdateComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
