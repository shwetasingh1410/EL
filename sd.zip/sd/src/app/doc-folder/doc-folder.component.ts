import { Component, OnInit } from '@angular/core';
import { GroupDoc, FolderInfo, FolderDoc } from './doc-folder.model';
import { TranslateService } from '../translate/translate.service';
import { DocFolderUpdateComponent } from './doc-folder-update/doc-folder-update.component';
import { DocGroupUpdateComponent } from './doc-group-update/doc-group-update.component';
import { DocFolderDeleteComponent } from './doc-folder-delete/doc-folder-delete.component';
import { DropdownGroupEditorComponent } from './dropdown-group-editor/dropdown-group-editor.component';
import { DropdownAccessEditorComponent } from './dropdown-access-editor/dropdown-access-editor.component';
import { DropdownAccessComponent } from './dropdown-access/dropdown-access.component';
import { DropdownGroupComponent } from './dropdown-group/dropdown-group.component';
import { DocFolderService } from './doc-folder.service';
import { DocFolderEvents } from './doc-folder.events';
import { GridOptions } from "ag-grid";
import { LoaderService } from '../shared/loaderComponent/Loader.service';
declare var $: any;

@Component({
  selector: 'app-doc-folder',
  templateUrl: './doc-folder.component.html',
  styleUrls: ['./doc-folder.component.css'],
  providers: [DocFolderService]
})
export class DocFolderComponent implements OnInit {

  gridOptions: GridOptions;
  groupDocs: Array<GroupDoc>;
  folderDocs : Array<FolderDoc>;
  folderInfo: Array<FolderInfo>;
  selectedGroupDoc: GroupDoc;
  selectedFolderDoc: FolderDoc;
  newgroup: boolean;
  newfolder: boolean;
  success: boolean;
  error: boolean;
   isError: boolean;
  isSuccess: boolean;
  isShowError: boolean;
  message: string;
  errMessage: string;
  folderName: string;
  folderGroupId: string;
  folderFolderId: string;
  folderGroupName: string;
  clientAccess: string;
  groupDocNames: Array<String>
  folderDocNames: Array<String>
  clientval: any;
  showAlertMessage : boolean;
  showAlertBox : boolean;

  constructor(private _loaderService:LoaderService,private _translate: TranslateService, private _docFolderEvents: DocFolderEvents
    , private _docFolderService: DocFolderService) {
    this.selectedGroupDoc = new GroupDoc('', true, '');
    this.selectedFolderDoc = new FolderDoc('', '');
    this.showAlertMessage = false;
    this.newgroup = false;
    this.newfolder = false;
    this.success = false;
    this.error = false;
    this.showAlertBox = false;
    this.errMessage = '';
    this.clientAccess = '';
    this.folderName = '';
    this.folderGroupId = '';
    this.folderGroupName = ''
    this.groupDocNames = [];
    this.groupDocs = [];
    this.folderDocNames = [];
    this.folderDocs = [];
    this.folderInfo = [];
    this.loadtable();
    this.clientval = { 'Y': 'Yes', 'N': 'No', 'S': 'Special' };
  }

  ngOnInit() {
    this.success = false;
    this.error = false;
    this.selectLang('en');
    this.getFolderInfo();
    this.getGroupDocs();
    this.getFolderDocs();

    this._docFolderEvents.folderDeleteEvent.subscribe(
      (showMenu) => {
        this.getFolderInfo();
      },(error) => {
            this.handleError(error)}
    );

    this._docFolderEvents.groupUpdateEvent.subscribe(
      (params) => {
        params.api.setFocusedCell(params.rowIndex, 'GroupDocName');
        // this._docFolderComponent.gridOptions.api.setFocusedCell(this.params.rowIndex,'ClientAccess');
    
        params.api.startEditingCell({
          rowIndex: params.rowIndex,
          colKey: 'GroupDocName'
        });
      },(error) => {
            this.handleError(error)}
    );
    this._docFolderEvents.folderUpdateEvent.subscribe(
      (params) => {
        params.api.setFocusedCell(params.rowIndex, 'ClientAccess');
        // this._docFolderComponent.gridOptions.api.setFocusedCell(this.params.rowIndex,'ClientAccess');
    
        params.api.startEditingCell({
          rowIndex: params.rowIndex,
          colKey: 'ClientAccess'
        });
      },(error) => {
            this.handleError(error)}
    );
    // this._docFolderEvents.folderUpdateEvent.subscribe(
    //   (params) => {
    //     this.gridOptions.api.stopEditing();
    //     this.gridOptions.api.setFocusedCell(params.rowIndex,'Update Access');
    //   },(error) => {
    //         this.handleError(error)}
    // );

    this._docFolderEvents.folderUpdateCancelEvent.subscribe(
      (params) => {
        this.gridOptions.api.stopEditing();
        this.getFolderInfo();
      },(error) => {
            this.handleError(error)}
    );

    // this._docFolderEvents.folderEditStartEvent.subscribe(
    //   (params) => {
    //     this.gridOptions.api.setFocusedCell(params.rowIndex,'ClientAccess');
    //     this.gridOptions.api.startEditingCell({
    //       rowIndex:params.rowIndex,
    //       colKey:'ClientAccess'
    //     });
    //   },(error) => {
    //         this.handleError(error)}
    // );

   
    
  }

  

  selectLang(lang: string) {
    this._translate.use(lang);
  }

  loadtable() {
    this.gridOptions = <GridOptions>{};
    this.gridOptions.suppressMenuHide= true;
    this.gridOptions.rowSelection = 'multiple';
    this.gridOptions.enableSorting = true;
    this.gridOptions.suppressClickEdit = true;
    this.gridOptions.stopEditingWhenGridLosesFocus=true;
    this.gridOptions.rowHeight =50;
    this.gridOptions.headerHeight = 40;
    this.gridOptions.columnDefs = [

      {
        headerName: "Folder",
        valueGetter: "data.DocumentFolder",
        width: 400,
        cellStyle: { 'white-space': 'normal' }
      },
      {
        headerName: "Group",
        field: 'GroupDocName',
        cellRendererFramework: DropdownGroupComponent,
        cellEditorFramework: DropdownGroupEditorComponent,
        width: 140,
        cellStyle: { 'white-space': 'normal' },
        type: 'EditableColumn'
      },
      {
        headerName: "",
        cellRendererFramework: DocGroupUpdateComponent,
        width: 100,
        cellStyle: { 'white-space': 'normal' }
      },
      {
        headerName: "Client Access",
        field: 'ClientAccess',
        cellRendererFramework: DropdownAccessComponent,
        cellEditorFramework: DropdownAccessEditorComponent,
        width: 65,
        cellStyle: { 'white-space': 'normal' },
        type: 'EditableColumn'
      },
      {
        headerName: "",
        cellRendererFramework: DocFolderUpdateComponent,
        width: 100,
        cellStyle: { 'white-space': 'normal' }
      },
      {
        headerName: "Delete",
        cellRendererFramework: DocFolderDeleteComponent,
        width: 55,
        cellStyle: { 'white-space': 'normal' }
      }
    ];
    this.gridOptions.columnTypes = {
      'EditableColumn': { editable: true }
    };
    this.gridOptions.rowData = [];
  }
  extractValues(mappings) {
    return Object.keys(mappings);
  }
  getGroupDocs() {
    this._loaderService.show();
    this._docFolderService.GetGroupDocuments().subscribe(result => {
      if (result) {
        this.groupDocs = result;
        this._loaderService.hide();
      }
    },(error) => {
            this.handleError(error)})
  }
  getFolderDocs() {
    this._loaderService.show();
    this._docFolderService.GetFolderDocuments().subscribe(result => {
      if (result) {
        this.folderDocs = result;
        this._loaderService.hide();
      }
    },(error) => {
      this._loaderService.hide();
            this.handleError(error)})
  }

  getFolderInfo() {
    this._loaderService.show();
    this._docFolderService.GetFolderInfo().subscribe(result => {
      if (result) {
        this.folderInfo = result;
        if (this.gridOptions.api && this.folderInfo)
          this.gridOptions.api.setRowData(this.folderInfo);
        else
          this.gridOptions.rowData = this.folderInfo;
          this._loaderService.hide();
      } 
    },(error) => {
      this._loaderService.hide();
            this.handleError(error)});
  }

  onGroupDocChange(GroupDoc: any) {
    if (GroupDoc == 'newgrp') {
      this.newgroup = true;
    }
    else {
      this.newgroup = false;
      this.selectedGroupDoc = GroupDoc;
      this.folderGroupId = GroupDoc.GroupDocId;
    }
  }
  onFolderDocChange(FolderDoc: any) {
    if (FolderDoc == 'newfolder') {
      this.newfolder = true;
    }
    else {
      this.newfolder = false;
      this.selectedFolderDoc = FolderDoc;
      this.folderFolderId = FolderDoc.FolderDocId;
    }
  }

  addfolder() {
    if($('#folderName').length){
     let fname = (<HTMLInputElement>document.getElementById('folderName')).value;
    
    if (fname == ''){
      this.showAlertMessage = true;
      setTimeout(() => {
        this.showAlertMessage = false;
      }, 3000);
    } else{ this.showAlertMessage = false;}}


    if ($("#yes").is(":checked")) {
      this.clientAccess = 'Y'
    }
    if ($("#no").is(":checked")) {
      this.clientAccess = 'N'
    }
    if ($("#special").is(":checked")) {
      this.clientAccess = 'S'
    }
    if(this.selectedFolderDoc)
    this.folderName = this.selectedFolderDoc.DocumentFolder;
   
    if (this.folderName && this.newgroup == true && this.clientAccess) {
      let checkduplicategroup: boolean = true;
      let checkduplicatefolder: boolean = true;
      if (this.groupDocs) {
        for (let i = 0; i < this.groupDocs.length; i++) {
          if (this.groupDocs[i].GroupDocName == this.folderGroupName) {
            checkduplicategroup = false;
            break;
          }
        }
      }
      if (this.folderInfo) {
        for (let i = 0; i < this.folderInfo.length; i++) {
          if (this.folderInfo[i].DocumentFolder == this.folderName) {
            checkduplicatefolder = false;
            break;
          }
        }
      }
      if (checkduplicategroup && checkduplicatefolder) {
        this._loaderService.show();
        this._docFolderService.PostDocumentGroupForName(this.folderName, this.folderGroupName, this.clientAccess).subscribe(result => {
          this.newgroup = false;
          $('input[name=exampleRadios]:radio').removeAttr('checked');
          this.getGroupDocs();
          this.getFolderDocs();
          this.getFolderInfo();
          this._loaderService.hide();
          this.success = true;
          this.error = false;
          setTimeout(() => {
            this.success = false;
          }, 3000);
          this.folderName = '';
          this.folderGroupName = '';
          this.folderGroupId = '';
        })
      }
      else {
        $('input[name=exampleRadios]:radio').removeAttr('checked');
        this.getGroupDocs();
        this.getFolderDocs();
        this.errMessage = 'Group/Folder Name already exists.'
        this.showError(this.errMessage);
        this.error = true;
        setTimeout(() => {
          this.error = false;
          this.errMessage = '';
        }, 3000);
        this.newgroup = false;
        this.folderName = '';
        this.folderGroupName = '';
        this.folderGroupId = '';
      }

    }
    else if (this.folderName && this.newgroup == false && this.clientAccess && this.folderGroupId) {
      let checkduplicatefolder: boolean = true; 
      if (this.folderInfo) {
        for (let i = 0; i < this.folderInfo.length; i++) {
          if (this.folderInfo[i].DocumentFolder == this.folderName) {
            checkduplicatefolder = false;
            break;
          }
        }
      }
      if (checkduplicatefolder) { 
        this._loaderService.show();
        this._docFolderService.PostDocumentGroupForId(this.folderName, this.folderGroupId, this.clientAccess)
        .subscribe(result => {
          $('input[name=exampleRadios]:radio').removeAttr('checked');
          this.getGroupDocs();
          this.getFolderDocs();
          this.getFolderInfo();
          this._loaderService.hide();
          this.success = true;
          this.error = false;
          setTimeout(() => {
            this.success = false;
          }, 3000);
          this.newgroup = false;
          this.folderName = '';
          this.folderGroupId = '';
        },(error) => {
            this.handleError(error)})
      } else {
        $('input[name=exampleRadios]:radio').removeAttr('checked');
        this.getGroupDocs();
        this.getFolderDocs();
        this.errMessage = 'Group/Folder Name already exists.'
        this.showError(this.errMessage);
        this.error = true;
        setTimeout(() => {
          this.error = false;
          this.errMessage = '';
        }, 3000);
        this.newgroup = false;
        this.folderName = '';
        this.folderGroupName = '';
        this.folderGroupId = '';
      }

    }else{
      this.showAlertBox = true;
      setTimeout(() => {
        this.showAlertBox = false;
      }, 3000);
    }

  }

  getGroups() {
    return this.groupDocs;
  }
  getFolders() {
    return this.folderDocs;
  }

showSuccess(message: string) {
    this.success = true;
    this.error = false;
  }

  showError(message: string) {
    this.success = false;
    this.error = true;
    this.message = message;
  }

    handleError(error) {
    this.success = false;
    this.error = true;
    if(error.status === 412){
    this.showError('Error 412 : Input Output Validation Error. Please enter details again. ');  
    }
    else if(error.status === 422){
    this.showError('Error 422 : Business Validation Error. Please try again');
    }
    else if(error.status === 500){
    this.showError('500 Internal Server Error. Please try again');
    }
    else{
      this.showError('Server Error. Please try again');
    }
  }


}
