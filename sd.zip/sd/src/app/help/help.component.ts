import { Component, OnInit } from '@angular/core';
import { LoaderService } from '../shared/loaderComponent/Loader.service';
import { TranslateService } from '../translate/translate.service';
import { HelpService } from './help.component.service';
import * as FileSaver from 'file-saver';


declare var $: any;
@Component({
  selector: 'app-help',
  templateUrl: './help.component.html',
  styleUrls: ['./help.component.css'],
  providers: [HelpService]
})
export class HelpComponent implements OnInit {

  downloadDocumentName: string;
  isHelpError: boolean;
  message: string;

  constructor(private _loaderService: LoaderService, private _translate: TranslateService, private _helpService: HelpService) {
    this.downloadDocumentName = "MosaicHelp.pdf";

  }

  ngOnInit() {
    this.GetHelpDocument(this.downloadDocumentName);
    this._translate.use('en');

  }


  GetHelpDocument(documetName: string) {
    this._loaderService.show();
    this._helpService
      .GetHelpDocument(documetName)
      .subscribe((result) => {
        this._loaderService.hide();
        this.downloadHelpDocument(result);
      }, (error) =>{ 
        this._loaderService.hide();
        this.handleError(error)});
  }

  downloadHelpDocument(data) {
    var content = this.base64ToArrayBuffer(data.Content);
    var blob = new Blob([content], { type: data.ContentType });
    var fileName = this.downloadDocumentName;
    var url = window.URL.createObjectURL(blob);
    FileSaver.saveAs(blob, fileName);
  }

  base64ToArrayBuffer(base64) {
    var binaryString = window.atob(base64);
    var binaryLen = binaryString.length;
    var bytes = new Uint8Array(binaryLen);
    for (var i = 0; i < binaryLen; i++) {
      var ascii = binaryString.charCodeAt(i);
      bytes[i] = ascii;
    }
    return bytes;
  }


  showError(message: string) {
    this.isHelpError = true;
    setTimeout(() => {
      this.isHelpError = false;
    }, 3000);
    this.message = message;
  }


  handleError(error) {
    this.isHelpError = true;
    setTimeout(() => {
      this.isHelpError = false;
    }, 3000);
    if (error.status === 412) {
      this.showError('Error 412 : Input Output Validation Error. Please enter details again. ');
    }
    else if (error.status === 422) {
      this.showError('Error 422 : Business Validation Error. Please try again');
    }
    else if (error.status === 500) {
      this.showError('500 Internal Server Error. Please try again');
    }
    else {
      this.showError('Document is not avilable for download.');
    }
  }


}