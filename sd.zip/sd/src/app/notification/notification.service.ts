import { Injectable } from '@angular/core';
import { Http, RequestOptions, Headers } from '@angular/http';
import { Observable } from 'rxjs/Rx';
import { CarrierSearchHelper } from '../carrier-search/carriersearch.helper';
import { Account } from '../carrier-search/carriersearch.model';
import { NotificationProfile, NotificationProfileCarrier, Notifications, CreateNotificationProfile } from './notifications.model';
import { Settings } from '../shared/settings/settings.service';

@Injectable()
export class NotificationService {
  constructor(private _http: Http, private _settings: Settings) {

  }

  getAccounts(role: string, userId : string): Observable<Array<Account>> {
    if (role == 'SuperAdmin') {
        return this._http.get(this._settings.getApiUrl() + 'api/accounts/active')
            .map((response) => this.getAccountsHandler(response.json()));
    }
    else if (role == 'MSDBUAdmin' || role == 'MSDAdmin') {
        return this._http.get(this._settings.getApiUrl() + 'api/accounts/active/role-based')
            .map((response) => this.getAccountsHandler(response.json()));
    }
    else {
        return this._http.get(this._settings.getApiUrl() + 'api/users/' + userId +'/accounts')
            .map((response) => this.getAccountsHandler(response.json()));
    }
}

getAccountsHandler(response) {
    let result: Array<Account> = new Array<Account>();
    response.forEach(account => {
        result.push(CarrierSearchHelper.mapToAccount(account));
    });
    return result;
}

  GetNotificationDetails(clientId: string): Observable<Notifications> {
    return this._http.get(this._settings.getApiUrl() + 'api/notifications/profile/' + clientId)
      .map((response) => {
        
        let carriers: Array<NotificationProfileCarrier> = new Array<NotificationProfileCarrier>();
        response.json().NotificationProfileCarriers.forEach((carrier) => {
          carriers.push(new NotificationProfileCarrier(carrier.NotificationProfileCarrierID, carrier.CarrierID, carrier.WillisCode, carrier.LegalName, carrier.CountryName));
        });

        let result: Notifications = new Notifications(response.json().NotificationProfile, carriers);
        return result;
      });
  }

  SaveNotificationProfile(profile: CreateNotificationProfile){
    return this._http.post(this._settings.getApiUrl() + 'api/notifications',
      JSON.stringify({
        'ClientId': profile.ClientId,
        'RatingAlertFlag': profile.RatingAlertFlag,
        'WhatsNewAlertFlag': profile.WhatsNewAlertFlag,
        'WhatsNewAlertFrequencyId': profile.WhatsNewAlertFrequencyId,
        'AddCarriers': profile.AddCarriers,
        'RemoveCarriers': profile.RemoveCarriers
      })).map((response) => response.json());
  }
}
