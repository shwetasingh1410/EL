﻿import { Injectable } from '@angular/core';

import { NotificationProfile, NotificationProfileCarrier, Notifications, CreateNotificationProfile } from './notifications.model';

@Injectable()
export class NotificationState {
  private notificationProfile: NotificationProfile;

  private notificationProfileCarrier: Array<NotificationProfileCarrier>;

  private originalNotificationProfileCarrier: Array<NotificationProfileCarrier>;

  private carrierSearchRedirection: boolean;

  getNotificationProfile(): NotificationProfile
  {
    return this.notificationProfile;
  }

  setNotificationProfile(profile: NotificationProfile) {
    this.notificationProfile = profile;
  }

  getNotificationProfileCarrier(): Array<NotificationProfileCarrier> {
    return this.notificationProfileCarrier;
  }

  setNotificationProfileCarrier(carriers: Array<NotificationProfileCarrier>) {
    this.notificationProfileCarrier = carriers;
  }

  getCarrierSearchRedirectionState(): boolean {
    return this.carrierSearchRedirection;
  }

  setCarrierSearchRedirectionState(redirection: boolean) {
    this.carrierSearchRedirection = redirection;
  }

  getOriginalNotificationProfileCarrier(): Array<NotificationProfileCarrier> {
    return this.originalNotificationProfileCarrier;
  }

  setOriginalNotificationProfileCarrier(carriers: Array<NotificationProfileCarrier>) {
    this.originalNotificationProfileCarrier = carriers;
  }
}