﻿export class NotificationProfile {
  Id: number;
  UserId: string;
  MosaicClientId: string;
  RatingAlertFlag: boolean;
  WhatsNewAlertFlag: boolean;
  WhatsNewAlertFrequencyID: number;

  constructor(Id: number, UserId: string, MosaicClientId: string, RatingAlertFlag: boolean, WhatsNewAlertFlag: boolean, WhatsNewAlertFrequencyID: number) {
    this.Id = Id;
    this.UserId = UserId;
    this.MosaicClientId = MosaicClientId;
    this.RatingAlertFlag = RatingAlertFlag;
    this.WhatsNewAlertFlag = WhatsNewAlertFlag;
    this.WhatsNewAlertFrequencyID = WhatsNewAlertFrequencyID; 
  }
}

export class NotificationProfileCarrier {
  NotificationProfileCarrierID: number;  
  CarrierID: number;
  WillisCode: string;
  LegalName: string;
  CountryName: string;
  IsChecked: boolean;

  //constructor(NotificationProfileCarrierID: number, NotificationProfileID: number, CarrierID: number, MosaicClientId: string, TableType: string, WillisCode: string, LegalName: string, CountryName: string) {
  constructor(NotificationProfileCarrierID: number, CarrierID: number, WillisCode: string, LegalName: string, CountryName: string) {
    this.NotificationProfileCarrierID = NotificationProfileCarrierID;    
    this.CarrierID = CarrierID;
    this.WillisCode = WillisCode;
    this.LegalName = LegalName;
    this.CountryName = CountryName;
    this.IsChecked = false;
  }
}

export class Notifications {
  NotificationProfile: NotificationProfile;
  NotificationProfileCarriers: Array<NotificationProfileCarrier>;  

  constructor(NotificationProfile: NotificationProfile, NotificationProfileCarriers: Array<NotificationProfileCarrier>) {
    this.NotificationProfile = NotificationProfile;
    this.NotificationProfileCarriers = NotificationProfileCarriers;    
  }
}

export class CreateNotificationProfile {
  ClientId: string;
  RatingAlertFlag: boolean;
  WhatsNewAlertFlag: boolean;
  WhatsNewAlertFrequencyId: number;
  AddCarriers: Array<number>;
  RemoveCarriers: Array<number>;

  constructor(ClientId: string, RatingAlertFlag: boolean, WhatsNewAlertFlag: boolean, WhatsNewAlertFrequencyId: number, AddCarriers: Array<number>, RemoveCarriers: Array<number>) {
    this.ClientId = ClientId;
    this.RatingAlertFlag = RatingAlertFlag;
    this.WhatsNewAlertFlag = WhatsNewAlertFlag;
    this.WhatsNewAlertFrequencyId = WhatsNewAlertFrequencyId;
    this.AddCarriers = AddCarriers;
    this.RemoveCarriers = RemoveCarriers;
  }   
}
