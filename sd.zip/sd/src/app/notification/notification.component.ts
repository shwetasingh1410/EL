import { Component, OnInit } from '@angular/core';
import { Router,ActivatedRoute } from '@angular/router';
import * as _ from "lodash";

import { LoaderService } from '../shared/loaderComponent/Loader.service';

import { TranslateService } from '../translate/translate.service';
import { ClientService } from '../select-client/client.service';
import { Carrier } from '../carrier-search/carriersearch.model';
import { Account } from '../carrier-search/carriersearch.model';
import { GridOptions } from "ag-grid";
import { LoggedInUser } from '../shared/loggedInUser/LoggedInUser';
import { NotificationService } from './notification.service';
import { NotificationState } from './notification.state.service';
import { NotificationProfile, NotificationProfileCarrier, Notifications, CreateNotificationProfile } from './notifications.model';

@Component({
  selector: 'app-notification',
  templateUrl: './notification.component.html',
  styleUrls: ['./notification.component.css'],
  providers: [NotificationService,LoggedInUser]
})

export class NotificationComponent implements OnInit {
  anyUpdate: boolean;
  clientId: string;
  createProfile: CreateNotificationProfile;
  localProfile: CreateNotificationProfile;
  profile: NotificationProfile;
  unsavedCarrier: Array<NotificationProfileCarrier>;
  profileCarrier: Array<NotificationProfileCarrier>;
  selectedAccount: Account;
  selectedCarriers: Array<Carrier>;
  selectedCarrierDetails;
  isError: boolean;
  isSuccess: boolean;
  message: string;
  saveSuccess: boolean;
  anyCarrierSelected: boolean = false;
  addCarriers: Array<number>;
  removeCarriers: Array<number>;
  gridOptions: GridOptions;
  cancel: boolean = false;

  carrierSearchRedirection: boolean;
  columnDefs = [
  {
    headerName: "",
    width: 40,
    cellStyle: { 'white-space': 'normal' },
    checkboxSelection: true,
    suppressSorting: true
  },
  {
    headerName: "Code",
    valueGetter: "data.WillisCode",
    width: 110,
    cellStyle: { 'white-space': 'normal' }
  },
  {
    headerName: "Legal Name",
    valueGetter: "data.LegalName",
    width: 380,
    cellStyle: { 'white-space': 'normal' }
  },
  {
    headerName: "Country",
    valueGetter: "data.CountryName",
    width: 150,
    cellStyle: { 'white-space': 'normal' }
  }];

  rowData;
  gridApi;
  sub;
  
  constructor(private _loggedInUser:LoggedInUser,private _route:ActivatedRoute,private _notificationService: NotificationService, private _loaderService: LoaderService,
    private _clientService: ClientService, private _router: Router, private _notificationState: NotificationState, private _translate: TranslateService) {
    this.profile = new NotificationProfile(0, "0", "0", false, false, 2);  
    
  }


  ngOnInit(): void {
    
    this.anyUpdate = false;
    this.checkCarrierFromSearch();
    this.selectLang('en');
    this.isError = false;
    this.isSuccess = false;
    this._loaderService.show();
    this.sub = this._route.params.subscribe(params => {
      this._notificationService.getAccounts(this._loggedInUser.getUserRoleCode(),this._loggedInUser.getEncryptedUserId()).subscribe(result => {
        var accounts:Array<Account>=result;
        var account:Account;
        this._loaderService.hide();
        var index=accounts.findIndex(acc => acc.AccountId == params['clientId']);
        if(index!=-1){
          account=accounts[index];
          this.selectedAccount = account;
          this.clientId = this.selectedAccount.Id;
          this._clientService.setSelectedAccount(account);
    
       // carrier search is called from Notification 
       this.carrierSearchRedirection = this._notificationState.getCarrierSearchRedirectionState();
       
             // Notification is called from carrier search
             if(this.clientId) {
               
              let fromCarrierSearch: boolean = this._clientService.getRedirectToNotification();
              
                  let fromCarrierDetails: boolean = this._clientService.getRedirectToNotificationFromDetails();
              
                  if (fromCarrierDetails == true)
                    this.getCarriersFromDetails();
                  else if (this.carrierSearchRedirection == true || fromCarrierSearch == false)
                    this.getCarriersFromCarrierSearch();
                  else
                    this.getNotificationProfile();
             }
        }
      });
     
    },(error) =>{ 
      this._loaderService.hide();
      this.handleError(error)});
   
  }
  checkCarrierFromSearch(){
    this.clientId = this._clientService.getAccountIdNotification();
    if(this._clientService.getFromSearch()){
      this.getCarriersFromCarrierSearch();  
    }
  }
  checkUpdate(event: string){
    this.anyUpdate = true;
  }


  getNotificationProfile() {  
    this._loaderService.show();
    this.isError = false;
    this.isSuccess = false;
    if (this.cancel == true || this.profileCarrier == undefined) {      
        this._notificationService.GetNotificationDetails(this.clientId).subscribe((result) => {
          if (result.NotificationProfile) {
            this._loaderService.hide();
            this.profile = result.NotificationProfile;
            if(this.profile.WhatsNewAlertFrequencyID == 0){
              this.profile.WhatsNewAlertFrequencyID = 2;
            }  
          }
          else {
            this.profile = new NotificationProfile(0, "0", "0", false, false, 2);
            this._loaderService.hide();
          }
        this.profileCarrier = result.NotificationProfileCarriers; 
        this._notificationState.setOriginalNotificationProfileCarrier(result.NotificationProfileCarriers);
        this.setSavedStatus();
        this.rowData = this.profileCarrier;
        },(error) =>{ 
          this._loaderService.hide();
          this.handleError(error)});
   } else {
     this._loaderService.hide();
   }
  this.cancel == false;
  }



  saveProfile() {
    this._loaderService.show();
    this.removeCarriers = new Array<number>();
    this.addCarriers = new Array<number>();
    this.anyUpdate = false;   
    this._notificationService.GetNotificationDetails(this.clientId).subscribe((result) => {
    let originalList: Array<NotificationProfileCarrier> = result.NotificationProfileCarriers; 
    this.profileCarrier.forEach(carrier => {
        if (carrier.NotificationProfileCarrierID == 0)
        { this.addCarriers.push(carrier.CarrierID); }
    });
    originalList.forEach(carrier => {
      let isExist = this.profileCarrier.find(d => d.CarrierID === carrier.CarrierID);    
        if (isExist == null || isExist == undefined)
          this.removeCarriers.push(carrier.NotificationProfileCarrierID);
      });
    this.createProfile = new CreateNotificationProfile(this.clientId, this.profile.RatingAlertFlag, this.profile.WhatsNewAlertFlag, this.profile.WhatsNewAlertFrequencyID, this.addCarriers, this.removeCarriers);    
    this._notificationService.SaveNotificationProfile(this.createProfile)
      .subscribe(() => {
        this.showSuccess('Notification Profile Saved');
        this._loaderService.hide();
        },(error) =>{ 
        this._loaderService.hide();
        this.handleError(error)});
    },(error) =>{ 
      this._loaderService.hide();
      this.handleError(error)});    
  }



  redirectToCarrierSearch() {  
    if(this.anyUpdate){
      this.saveProfile();
      this.anyUpdate = false;
    }
    this.isError = false;
    this.isSuccess = false;
    this.setSavedStatus();
    this.carrierSearchRedirection = true;
    this._clientService.setRedirectToNotification(true);
    this._notificationState.setCarrierSearchRedirectionState(true);
    this._router.navigate(['./carrier-search']);
  }

  getCarriersFromCarrierSearch() { 
    this._loaderService.show(); 
    this.selectedCarriers = this._clientService.getCarriersNotification();  
    this.clientId = this._clientService.getAccountIdNotification();
    if (this.profileCarrier == undefined) {  
        this._notificationService.GetNotificationDetails(this.clientId).subscribe((result) => {  
        if (result.NotificationProfile) {
            this.profile = result.NotificationProfile;
            this.profileCarrier = result.NotificationProfileCarriers;          
            if (this.selectedCarriers) {
                this._loaderService.hide();
                this.anyUpdate = this._clientService.getAnyUpdate();
                this.selectedCarriers.forEach((carrier) => {    
                let isExist: NotificationProfileCarrier = this.profileCarrier.find(d => d.CarrierID == carrier.CarrierNumberId);
                if (isExist == null || isExist == undefined){ 
                    this.profileCarrier.push(new NotificationProfileCarrier(0, carrier.CarrierNumberId, carrier.WillisCode, carrier.LegalName, carrier.Country));
                    this.profileCarrier.sort( function(name1, name2) {
                    if (name1.WillisCode < name2.WillisCode){
                        return -1;
                    }else if(name1.WillisCode > name2.WillisCode){
                        return 1;
                    }else{
                        return 0;	
                    }})    
                  }});        
            }
            else{
                this._loaderService.hide();
            }   
            this._notificationState.setCarrierSearchRedirectionState(false);
            this._clientService.setRedirectToNotification(true);     
            this.rowData = this.profileCarrier;
            if( this.profile.WhatsNewAlertFrequencyID == 0){
                this.profile.WhatsNewAlertFrequencyID = 2;
            } 
        }
        else {
            this._loaderService.hide();
            this.profile = new NotificationProfile(0, "0", "0", false, false, 2);
        }
        this.profileCarrier = result.NotificationProfileCarriers;  
        },(error) =>{ 
        this._loaderService.hide();
        this.handleError(error)});
   }
    else{
     this._loaderService.hide();
    }
  }

  getCarriersFromDetails() {
    this.anyUpdate = this._clientService.getAnyUpdate();
    this._loaderService.show();  
    this.selectedCarrierDetails = this._clientService.getCarriersNotificationDetails();     
      this._notificationService.GetNotificationDetails(this.clientId).subscribe((result) => {        
        this.profile = result.NotificationProfile;
        this.profileCarrier = result.NotificationProfileCarriers; 
        let isExist: NotificationProfileCarrier = this.profileCarrier.find(d => d.CarrierID == this.selectedCarrierDetails.CarrierNumberId);
                  if (isExist == null || isExist == undefined){
                    this._loaderService.hide(); 
                   this.profileCarrier.push(new NotificationProfileCarrier(0, this.selectedCarrierDetails.CarrierNumberId, this.selectedCarrierDetails.WillisCode, this.selectedCarrierDetails.LegalName, this.selectedCarrierDetails.Country));
                   this.profileCarrier.sort( function(name1, name2) {
                    if ( name1.WillisCode < name2.WillisCode ){
                      return -1;
                    }else if( name1.WillisCode > name2.WillisCode ){
                        return 1;
                    }else{
                      return 0;	
                    }
                  })
                  
                  } 
                  else{
                    this._loaderService.hide();
                  }       
             
      this.rowData = this.profileCarrier; 
      },(error) =>{ 
        this._loaderService.hide();
        this.handleError(error)});
  }  

  onRowSelected(event: any) {
    let selectedCarriers: Array<NotificationProfileCarrier> = event.api.getSelectedRows();
    if (selectedCarriers.length > 0) {
      selectedCarriers.forEach(carrier => {
        let index = this.profileCarrier.findIndex(d => d.CarrierID === carrier.CarrierID);
        this.profileCarrier.splice(index, 1);
        this.anyCarrierSelected = true;
      });
    }
    else
      this.anyCarrierSelected = false;
    this.gridApi = event.api;
  }

  removeSelectedCarriers() {
    this.anyUpdate = true;
    this.gridApi.updateRowData({ remove: this.gridApi.getSelectedRows() })    
  }

  setSavedStatus() {
    this.isError = false;
    this.isSuccess = false;
    this._notificationState.setNotificationProfile(this.profile);
    this._notificationState.setNotificationProfileCarrier(this.profileCarrier);
  }  

  cancelChanges() {
    this.anyUpdate = false;
    this.cancel = true;
    this.getNotificationProfile();      
  }
  
  handleError(error) {
    this.showError('Some Error Occured, please report to support team along with steps to reproduce');
  }

  showSuccess(message: string) {
    this.message = message;
    this.saveSuccess = true;
    this.isSuccess = true;
    setTimeout(() => {
      this.isSuccess = false;
    }, 3000);
    this.isError = false;
    
  }

  showError(message: string) {    
    this.isSuccess = false;
    this.isError = true;
    setTimeout(() => {
      this.isError = false;
    }, 3000);
    this.message = message;

  }

  selectLang(lang: string) {
    this._translate.use(lang);
  }
}
