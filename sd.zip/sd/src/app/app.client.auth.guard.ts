import { Injectable } from '@angular/core';
import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot, Router, ActivatedRoute } from '@angular/router';
import { Observable } from 'rxjs/Rx';
import {CoolSessionStorage} from 'angular2-cool-storage'
import { ClientService } from './select-client/client.service';

@Injectable()
export class ClientAuthGuard implements CanActivate {

    localStorage:CoolSessionStorage;

    constructor(private _router: Router, private _clientService: ClientService,private _route:ActivatedRoute,localStorage:CoolSessionStorage) {
        this.localStorage=localStorage;
     }

    canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot)
        : boolean | Observable<boolean> | Promise<boolean> {
        if (state.url.endsWith('carrier-search')  ||
            state.url.endsWith('notification') || state.url.endsWith('carrier-doc') || state.url.endsWith('code-info')) {
            this.checkIfChangeSelectedClient(state.url);
        }
        return true;
    }

    checkIfChangeSelectedClient(url: string) {
        if(this._clientService.getSelectedAdminAccount()){
            //no need to go to select client
        }else{
            if ((this._clientService.isChangeSelectedClient()
            || this._clientService.getSelectedAccount() === undefined) && !url.endsWith('code-info')) {
            this._clientService.setRevertUrl(url);
            this._router
                .navigateByUrl('/select-client');
        }
        }
        if (url.endsWith('carrier-search') ) {
            if(this._clientService.getSelectedAdminAccount()){
                var accoun='';
                this._clientService.setSelectedAdminAccount(null);
                this._router.navigate(['carrier-search/client',accoun])
            }else{
                if(this._clientService.getSelectedAccount()){
                    if(this._clientService.getSelectedAccount().AccountId && this._clientService.getSelectedAccount().Id){
                        this._router.navigate(['carrier-search/client',this._clientService.getSelectedAccount().AccountId])
                    
                    }
                }
                else if(this.localStorage) {
                    if(this.localStorage.getObject('account')) {
                    var acc:any=this.localStorage.getObject('account');
                    if(acc && acc.AccountId)
                    this._router.navigate(['carrier-search/client',acc.AccountId]);
                    }
                }
            }
    }

        if(url.endsWith('notification')) {
            if(this._clientService.getSelectedAccount()){
                if(this._clientService.getSelectedAccount().AccountId && this._clientService.getSelectedAccount().Id){
                if (url.endsWith('notification') ) {
                    this._router.navigate(['notification/account',this._clientService.getSelectedAccount().AccountId])
                }
                }
            }
            else if(this.localStorage.getObject('account')){
                var acc:any=this.localStorage.getObject('account');
                if(acc && acc.AccountId)
                this._router.navigate(['notification/account',acc.AccountId]);
            }
        }

        if(url.endsWith('code-info')){
            var sub;
            var guid;
            url=url.substring(1,6);
            sub = this._route.params.subscribe(params => {
            this.localStorage.setItem('guid',url);
            this._clientService.setRevertUrl('url-render');
            this._router.navigate(['url-render']);
            });
        }
        
    }

}