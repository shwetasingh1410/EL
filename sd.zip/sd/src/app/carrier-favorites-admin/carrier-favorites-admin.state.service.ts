// import { Injectable } from '@angular/core';

// import {FavoriteCategory, FavoriteGroup, CarrierFavorite } from './carrier-favorites-admin.model';
// @Injectable()
// export class CarrierFavAdminState {
//     private FavoriteGroup: FavoriteGroup;
//     // it contains the tempered new list
//     private CarrierFavorites: Array<CarrierFavorite>;


//     getFavoriteGroup(): FavoriteGroup{
//         return this.FavoriteGroup;
//     }

//     setFavoriteGroup(FavoriteGroup: FavoriteGroup) {
//         this.FavoriteGroup= FavoriteGroup;
//     }

//     setCarrierFavorites(CarrierFavorites: Array<CarrierFavorite>) {
//         this.CarrierFavorites = CarrierFavorites;
//     }

//     getCarrierFavorites(): Array<CarrierFavorite> {
//         return this.CarrierFavorites;
//     }
// }