import { UpdateFavoriteCategory, CarrierFavorite, CreateFavoriteCategory,FavoriteCategory,FavoriteType,FavoriteGroup } from './carrier-favorites-admin.model';
export class CarrierFavAdminHelper {
    
    static mapToCategoryInfo(category: any): FavoriteCategory {
        return new FavoriteCategory(category.CategoryId, category.CategoryName, category.FavoriteType);
    }
    static mapToGroupInfo(group: any): FavoriteGroup {
        return new FavoriteGroup(group.GroupId, group.GroupName, group.FavoriteType);
    }
    static mapToCarrierInfo(carrier: any) : CarrierFavorite{
        return new CarrierFavorite(carrier.CarrierId, carrier.LegalName, carrier.WillisCode, carrier.CountryName, carrier.CountrySubName);
    }
}