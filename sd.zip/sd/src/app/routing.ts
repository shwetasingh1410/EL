﻿import { Router, RouterModule } from '@angular/router';

import { HomeComponent } from './home/home.component';
import { RatingsComponent } from './ratings/ratings.component';
import { DisclaimersComponent } from './disclaimers/disclaimers.component';
import { EdituserComponent } from './edit-user/edituser.component';
import { AnnouncementsComponent } from './announcements/announcements.component';
import { CarriersearchComponent } from './carrier-search/carriersearch.component';
import { NotificationComponent } from './notification/notification.component';
import { CarrierDocComponent } from './carrier-doc/carrier-doc.component';
import { HomePageAdminComponent } from './home-page-admin/home-page-admin.component';
import { CarrierFavoritesComponent } from './carrier-favorites/carrierfavorites.component';
import { CarrierFavoritesAdminComponent } from './carrier-favorites-admin/carrier-favorites-admin.component';
import { ClientMaintenanceComponent } from './client-maintenance/clientmaintenance.component';
import { DocAccessComponent } from './doc-access/doc-access.component';
import { DocFolderComponent } from './doc-folder/doc-folder.component';
import { ReportsComponent } from './reports/reports.component';
import { MsHomeComponent } from './ms-home/ms-home.component';
import { SelectClient } from './select-client/select-client.component';
import { ClientAuthGuard } from './app.client.auth.guard';
import {UseInReports} from './use-in-reports/use-in-reports.component';
import { CarrierDetailsComponent } from './carrier-details/carrier-details.component';
import { GeneralComponent } from './carrier-details/general/general.component';
import { SummaryComponent } from './carrier-details/summary/summary.component';
import { FinancialsComponent } from './carrier-details/financials/financials.component';
import { LicensesComponent } from './carrier-details/licenses/licenses.component';
import { DocumentsComponent } from './carrier-details/documents/documents.component';
import { TermsOfUseComponent } from './terms-of-use/terms-of-use.component';
import { ForbiddenComponent } from './shared/forbidden/forbidden.component';
import { UnauthorisedComponent } from './shared/unauthorised/unauthorised.component';
import { PageAccessAuthGuard } from './shared/page-access-levels/page-access-levels.guard';
import { AcceptTermsOfUseComponent } from './accept-terms-of-use/accept-terms-of-use.component';
import { RelatedLinksComponent } from './related-links/related-links.component';
import { LibraryComponent } from './library/library.component';
import { HelpComponent } from './help/help.component';
import { ComparativeReport } from './comparative-report/comparative-report.component'
import { ManageLibraryComponent } from './manage-library/manage-library.component';
import { DocumentSearchComponent } from './document-search/document-search.component';
import { AdminHelpComponent } from './admin-help/admin-help.component';
import { UrlRenderComponent } from './url-render/url-render.component';
import { TermsofuseErrorComponent } from './shared/termsofuseError/termsofuseError.component';
import { ViewDisclaimerComponent } from './carrier-details/view-disclaimer/view-disclaimer.component';
import { DownloadFileComponent } from './download-file/download-file.component';
import { OwnershipComponent } from './carrier-details/ownership/ownership.component';
import { LogoutComponent } from './shared/logout/logout.component';
import { SessionTimeoutComponent } from './shared/session-timeout/session-timeout.component';

export const routing = RouterModule.forRoot([
    { path: 'home', component: HomeComponent},
    { path: 'disclaimers', component: DisclaimersComponent,canActivate: [PageAccessAuthGuard] },
    { path: 'ratings', component: RatingsComponent , canActivate: [PageAccessAuthGuard]},
    { path: 'edit-user', component: EdituserComponent,canActivate: [PageAccessAuthGuard] },
    { path: 'announcements', component: AnnouncementsComponent , canActivate: [PageAccessAuthGuard] },
    { path: 'carrier-search', component: CarriersearchComponent, canActivate: [PageAccessAuthGuard,ClientAuthGuard]},
    { path: 'carrier-search/client/:clientId', component: CarriersearchComponent, canActivate: [PageAccessAuthGuard,ClientAuthGuard]},
    {
        path: 'carrier-detail/:client/:clientId/:carrier/:carrierId/:code/:codeId', component: CarrierDetailsComponent,canActivate: [PageAccessAuthGuard], children: [
            { path: 'general', component: GeneralComponent },
            { path: 'summary', component: SummaryComponent },
            { path: 'financials', component: FinancialsComponent },
            { path: 'documents', component: DocumentsComponent },
            { path: 'licenses', component: LicensesComponent },
            { path: '**', redirectTo: '\general' },
        ]
    },
    { path: 'notification', component: NotificationComponent, canActivate: [PageAccessAuthGuard, ClientAuthGuard] },
    { path: 'notification/account/:clientId', component: NotificationComponent, canActivate: [PageAccessAuthGuard, ClientAuthGuard] },
    { path: 'carrier-doc', component: CarrierDocComponent, canActivate: [PageAccessAuthGuard,ClientAuthGuard] },
    { path: 'home-page-admin', component: HomePageAdminComponent , canActivate: [PageAccessAuthGuard]},
    { path: 'carrier-favorites', component: CarrierFavoritesComponent , canActivate: [PageAccessAuthGuard]},
    { path: 'carrier-favorites/acc/:clientId', component: CarrierFavoritesComponent , canActivate: [PageAccessAuthGuard]},
    { path : 'carrier-favorites-admin', component :CarrierFavoritesAdminComponent, canActivate: [PageAccessAuthGuard]},
    { path: 'client-maintenance', component: ClientMaintenanceComponent,canActivate: [PageAccessAuthGuard] },
    { path: 'doc-access', component: DocAccessComponent, canActivate: [PageAccessAuthGuard]},
    { path: 'doc-folder', component: DocFolderComponent,canActivate: [PageAccessAuthGuard] },
    { path: 'admin-reports', component: ReportsComponent,canActivate: [PageAccessAuthGuard] },
    { path: 'admin-reports/:reportName', component: ReportsComponent ,canActivate: [PageAccessAuthGuard]},
    { path: 'reports', component: ReportsComponent,canActivate: [PageAccessAuthGuard] },
    { path: 'reports/:reportName', component: ReportsComponent ,canActivate: [PageAccessAuthGuard]},
    { path: 'msHome', component: MsHomeComponent,canActivate: [PageAccessAuthGuard] },
    { path: 'select-client', component: SelectClient,canActivate: [PageAccessAuthGuard] },
    { path: 'terms-of-use', component: TermsOfUseComponent, canActivate: [PageAccessAuthGuard]},
    { path: 'forbidden', component: ForbiddenComponent },
    { path: 'forbidden-admin', component: ForbiddenComponent },
    { path: 'unauthorised', component: UnauthorisedComponent },
    { path: 'useinreports', component: UseInReports },
    { path: 'acceptTermsOfUse', component: AcceptTermsOfUseComponent },
    { path: 'related-links', component: RelatedLinksComponent, canActivate: [PageAccessAuthGuard] },
    { path: 'doc-library', component: LibraryComponent, canActivate: [PageAccessAuthGuard] },
    { path: 'user-help', component: HelpComponent, canActivate: [PageAccessAuthGuard] },
    { path: 'comparative-report', component: ComparativeReport },
    { path: 'manage-library', component: ManageLibraryComponent, canActivate: [PageAccessAuthGuard] },
    { path: 'document-search', component: DocumentSearchComponent, canActivate: [PageAccessAuthGuard] },
    { path: 'admin-help', component: AdminHelpComponent, canActivate: [PageAccessAuthGuard] },
    { path: 'url-render', component: UrlRenderComponent, canActivate: [PageAccessAuthGuard,ClientAuthGuard] },
    { path: 'doc/:docName/download', component: DownloadFileComponent, canActivate: [PageAccessAuthGuard] },
    { path: ':guid/code-info', component: UrlRenderComponent,canActivate: [ClientAuthGuard]},
    { path: 'termsofuseError', component: TermsofuseErrorComponent },
    { path: 'view-disclaimer', component: ViewDisclaimerComponent },
    { path: 'download', component: DownloadFileComponent,canActivate: [PageAccessAuthGuard]},
    { path: ':groupCode/group-code', component: OwnershipComponent },
    { path: 'logout', component: LogoutComponent },
    { path: 'session-timeout', component: SessionTimeoutComponent },
    { path: '**', redirectTo: '\home' },
]);
