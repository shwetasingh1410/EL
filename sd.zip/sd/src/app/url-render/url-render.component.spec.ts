import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UrlRenderComponent } from './url-render.component';

describe('UrlRenderComponent', () => {
  let component: UrlRenderComponent;
  let fixture: ComponentFixture<UrlRenderComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UrlRenderComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UrlRenderComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
