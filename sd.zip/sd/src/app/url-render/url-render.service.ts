import { Injectable } from '@angular/core';
import { Http, RequestOptions, Headers } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import { Settings } from '../shared/settings/settings.service';
import { ClientService } from '../select-client/client.service';
import { LoggedInUser } from '../shared/loggedInUser/LoggedInUser';
import { CoolSessionStorage } from 'angular2-cool-storage';
import { Carrier,SearchRequest } from '../carrier-search/carriersearch.model';
import { Account,AccountAccess,AssociatedCarrier,ConsultancyStatus,UserRole } from './url-render.model';
import { UrlRenderHelper } from './url-render.helper';
import { CarrierSearchHelper } from '../carrier-search/carriersearch.helper';
import { serializeUrlParams } from '../shared/http/http.factory';

@Injectable()
export class UrlRenderService {

  constructor(private _http:Http,private _settings:Settings) { }

  getAccounts(role: string, userId : string): Observable<Array<Account>> {
    if (role == 'SuperAdmin') {
        return this._http.get(this._settings.getApiUrl() + 'api/accounts/active')
            .map((response) => this.getAccountsHandler(response.json()));
    }
    else if (role == 'MSDBUAdmin' || role == 'MSDAdmin') {
        return this._http.get(this._settings.getApiUrl() + 'api/accounts/active/role-based')
            .map((response) => this.getAccountsHandler(response.json()));
    }
    else {
        return this._http.get(this._settings.getApiUrl() + 'api/users/' + userId +'/accounts')
            .map((response) => this.getAccountsHandler(response.json()));
    }
}

getAccountsHandler(response) {
    let result: Array<Account> = new Array<Account>();
    response.forEach(account => {
        result.push(UrlRenderHelper.mapToAccount(account));
    });
    return result;
}

getSearchResult(searchRequest: SearchRequest) {
    let params: URLSearchParams = serializeUrlParams(searchRequest);
    return this._http.get(this._settings.getApiUrl() + 'api/carriers?' + params.toString())
        .map((response) => this.getSearchResultHandler(response));
}

getSearchResultHandler(response) {
  let result: Array<Carrier> = new Array<Carrier>();
  response.json().forEach((carrier) => {
      result.push(CarrierSearchHelper.mapToCarrier(carrier))
  });
  return result;
}

}
