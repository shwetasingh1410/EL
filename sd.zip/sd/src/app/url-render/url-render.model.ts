export class Account {
    public Id: string;
    public SubscriptionId: string;
    public PartyId: number;
    public AccountId: string;
    public PartyName: string;
    public ConsultancyStatus: ConsultancyStatus;
    public AssociateAllCarriers: boolean;
    public AccessLevel: AccountAccess;
    public AssociatedCarriers: Array<AssociatedCarrier>;

    constructor(Id: string, SubscriptionId: string, PartyId: number,AccountId:string, PartyName: string, ConsultancyStatus: ConsultancyStatus,
        AssociateAllCarriers: boolean, AccessLevel: AccountAccess, AssociatedCarriers: Array<AssociatedCarrier>) {
        this.Id = Id;
        this.SubscriptionId = SubscriptionId;
        this.PartyId = PartyId;
        this.AccountId=AccountId;
        this.PartyName = PartyName;
        this.ConsultancyStatus = ConsultancyStatus;
        this.AssociateAllCarriers = AssociateAllCarriers;
        this.AssociatedCarriers = AssociatedCarriers;
        this.AccessLevel = AccessLevel;
    }
}

export class AssociatedCarrier {
    CarrierId: string;
    LegalName: string;
    WillisCode: string;
    Comments: string;
    IsDefault: boolean;

    constructor(CarrierId: string, LegalName: string, WillisCode: string,
        Comments: string, IsDefault: boolean) {
        // this.AccountId = AccountId;
        this.CarrierId = CarrierId;
        this.LegalName = LegalName;
        this.WillisCode = WillisCode;
        this.Comments = Comments;
        this.IsDefault = IsDefault;
    }
}
export enum ConsultancyStatus {
    NonConsultancy = 0,
    Consultancy
}

export enum AccountAccess {
    SuperUsersOnly,
    AllAdmins
    
}

export enum UserRole {
    SuperAdministrator = 1,
    MsdAdministrator,
    MsdBuAdministrator,
    WillisReader,
    ClientReader,
}