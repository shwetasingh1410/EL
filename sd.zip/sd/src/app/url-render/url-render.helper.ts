//will help in common utility static functions 
import { Account,AccountAccess,AssociatedCarrier,ConsultancyStatus,UserRole } from './url-render.model';
export class UrlRenderHelper {
    static mapToAccount(party: any): Account {
        return new Account(party.Id, party.SubscriptionId, party.PartyId,party.AccountId, party.PartyName, party.ConsultancyStatus,
            party.AssociateAllCarriers, party.AccessLevel, party.AssociatedCarriers);
    }
}