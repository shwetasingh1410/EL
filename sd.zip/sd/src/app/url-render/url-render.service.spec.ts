import { TestBed, inject } from '@angular/core/testing';

import { UrlRenderService } from './url-render.service';

describe('UrlRenderService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [UrlRenderService]
    });
  });

  it('should be created', inject([UrlRenderService], (service: UrlRenderService) => {
    expect(service).toBeTruthy();
  }));
});
