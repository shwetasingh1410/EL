import { Component, OnInit } from '@angular/core';
import { CoolSessionStorage } from 'angular2-cool-storage';
import { LoggedInUser } from '../shared/loggedInUser/LoggedInUser';
import { Router, ActivatedRoute } from '@angular/router';
import { Carrier,SearchRequest } from '../carrier-search/carriersearch.model';
import { UrlRenderService } from './url-render.service';
import { Account,AccountAccess,AssociatedCarrier,ConsultancyStatus,UserRole } from './url-render.model';
import { ClientService } from '../select-client/client.service';


@Component({
  selector: 'app-url-render',
  templateUrl: './url-render.component.html',
  styleUrls: ['./url-render.component.css'],
  providers: [UrlRenderService]
})
export class UrlRenderComponent implements OnInit {
localStorage;
sub;
url:string;
carriers:Array<Carrier>;
carrier:Carrier;
searchRequest:SearchRequest;
  constructor(private _urlRenderService:UrlRenderService,private _loggedInUser:LoggedInUser,private _route:ActivatedRoute,private _router:Router,private _clientService:ClientService,localStorage:CoolSessionStorage) {
    this.localStorage=localStorage;
    this.searchRequest=new SearchRequest();
   }

  ngOnInit() {
    this.url=this.localStorage.getItem('guid');
    if(this.url)
    {this._urlRenderService.getAccounts(this._loggedInUser.getUserRoleCode(),this._loggedInUser.getEncryptedUserId()).subscribe(result => {
      var accounts:Array<Account>=result;
      var account:Account;
      if(accounts.length == 1){
        account=accounts[0];
        this.searchRequest.LegalNameOperator = '1';
        this.searchRequest.RatingAgencyOperator = '0';
        this.searchRequest.CodeSelection='willis';
        this.searchRequest.Code=this.url;
        this.searchRequest.ClientId=account.Id;
        this._urlRenderService.getSearchResult(this.searchRequest).subscribe(result => {
          this.carrier=result[0];
          if(this.carrier)
          {this.localStorage.setItem('clientId',account.AccountId);
          this.localStorage.setObject('carriers',this.carrier);
          this.localStorage.setObject('account',account);
        this._clientService.setAccountId(account.AccountId);
        this._clientService.setDetailCarrierId(this.carrier.CarrierId);
        var code='code';
        var carrier='carrier';
        var client='client';
        var tabName='documents';
        this._router.navigate(['carrier-detail',client,account.AccountId,carrier,this.carrier.CarrierId,code,this.url,tabName]);
        }else{
          this._router.navigate(['forbidden']);
        }
        })
      }
      else if(accounts.length >1){
        var count:number=0;
        var client:Array<Account>=[];
        accounts.forEach(acc => {
          var carry=acc.AssociatedCarriers;
          if(carry)
          if(carry.length>0) {
            carry.forEach(car=>{
             if(car.WillisCode==this.url) {
             count++;
              client.push(acc);
             }
            })
          }
        })
        if(count > 1) {
          this._router.navigate(['select-client']);
        }else if(count==1){
          this.goToDetails(client);
        }
          else if(count == 0){
            var step:number=0;
            accounts.forEach(acc => {
              if(acc.AssociateAllCarriers){
                step++;
                client.push(acc);
              } 
            })
            if(step==0){
              this._router.navigate(['forbidden']);
            }else if(step == 1) {
              this.goToDetails(client);
            }else{
              this._router.navigate(['select-client']);
            }
        }else{
          this._router.navigate(['forbidden']);
        }

      }else{
        this._router.navigate(['forbidden']);
      }
    });
  }else{
    this._router.navigate(['forbidden']); 
  }}

  goToDetails(client) {
    var cl=client[0];
    this.searchRequest.LegalNameOperator = '1';
    this.searchRequest.RatingAgencyOperator = '0';
    this.searchRequest.CodeSelection='willis';
    this.searchRequest.Code=this.url;
    this.searchRequest.ClientId=cl.Id;
    this._urlRenderService.getSearchResult(this.searchRequest).subscribe(result => {
      this.carrier=result[0];
      this.localStorage.setItem('clientId',cl.AccountId);
      this.localStorage.setObject('carriers',this.carrier);
      this.localStorage.setObject('account',cl);
    this._clientService.setAccountId(cl.AccountId);
    this._clientService.setDetailCarrierId(this.carrier.CarrierId);
    var code='code';
    var carrier='carrier';
    var client='client';
    var tabName='documents';
    this._router.navigate(['carrier-detail',client,cl.AccountId,carrier,this.carrier.CarrierId,code,this.url,tabName]);
    })
  }

}
