﻿import { BrowserModule } from '@angular/platform-browser';
import { NgModule, APP_INITIALIZER, ErrorHandler } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpModule, XHRBackend, RequestOptions, Http } from '@angular/http';
import {AgGridModule} from "ag-grid-angular/main";

import { GlobalErrorHandler } from './shared/error-handling/error.handler';

import { AppComponent } from './app.component';
import { SignOutComponent } from './shared/signoutcomponent/signout.component';
import { HomeComponent } from './home/home.component';
import { FooterComponent } from './footer/footer.component';
import { RatingsComponent } from './ratings/ratings.component';
import { routing } from './routing';
import { DisclaimersComponent } from './disclaimers/disclaimers.component';
import { EdituserComponent } from './edit-user/edituser.component';
import { AnnouncementsComponent } from './announcements/announcements.component';
import { CarriersearchComponent } from './carrier-search/carriersearch.component';
import { CarrierSearchEvents } from './carrier-search/carriersearch.events';
import { NotificationComponent } from './notification/notification.component';
import { NotificationState } from './notification/notification.state.service';
import { CarrierDocComponent } from './carrier-doc/carrier-doc.component';
import { HomePageAdminComponent } from './home-page-admin/home-page-admin.component';
import { CarrierFavoritesComponent } from './carrier-favorites/carrierfavorites.component';
import { ClientMaintenanceComponent } from './client-maintenance/clientmaintenance.component';
import { ClientMaintenaceState } from './client-maintenance/clientmaintenance.state.service';
import { DocAccessComponent } from './doc-access/doc-access.component';
import { DocFolderComponent } from './doc-folder/doc-folder.component';
import { ReportsComponent } from './reports/reports.component';
import { MsHomeComponent } from './ms-home/ms-home.component';
import { SelectClient } from './select-client/select-client.component';
import { CarrierDetailsComponent } from './carrier-details/carrier-details.component';
import { CarrierDetailsEvents } from './carrier-details/carrier-details.events';
import { DocumentsComponent } from './carrier-details/documents/documents.component';
import { DocumentsEvents } from './carrier-details/documents/documents.events';
import { FinancialsComponent } from './carrier-details/financials/financials.component';
import { FinancialsEvents } from './carrier-details/financials/financials.events';
import { GeneralComponent } from './carrier-details/general/general.component';
import { GeneralEvents } from './carrier-details/general/general.events';
import { LicensesComponent } from './carrier-details/licenses/licenses.component';
import { LicensesEvents } from './carrier-details/licenses/licenses.events';
import { SummaryComponent } from './carrier-details/summary/summary.component';
import { SummaryEvents } from './carrier-details/summary/summary.events';
import { TermsOfUseComponent } from './terms-of-use/terms-of-use.component';
import { UseInReports } from './use-in-reports/use-in-reports.component';
import { RelatedLinksComponent } from './related-links/related-links.component';
import { LibraryComponent } from './library/library.component';
import { HelpComponent } from './help/help.component';
import { ComparativeReport } from './comparative-report/comparative-report.component'
import { ManageLibraryComponent } from './manage-library/manage-library.component';
import { DocumentSearchComponent } from './document-search/document-search.component';
import { AdminHelpComponent } from './admin-help/admin-help.component';
// shared Modules
import { Settings, SettingsFactory } from './shared/settings/settings.service';
import { Storage } from './shared/storage/storage.service';
import { AuthService, AuthServiceFactory } from './shared/loggedInUser/auth.service';
import { httpFactory } from './shared/http/http.factory'
//import { HttpProvider } from './shared/http/http.factory'
import { NiceSelectDirective } from './shared/niceSelect/niceSelect';
import { LoaderComponent } from './shared/loaderComponent/loader.component';
import { LoaderService } from './shared/loaderComponent/Loader.service';
import { LoggedInUser } from './shared/loggedInUser/LoggedInUser';
import { PaginationComp } from './shared/pagination/pagination';
import { LinkComponent } from './carrier-search/link-component/link-component.component';
import { CheckComponent } from './carrier-search/check/check.component';
import { DatepickerComponent } from './shared/datepicker/datepicker.component';
import { ForbiddenComponent } from './shared/forbidden/forbidden.component';
import { PageAccessService } from './shared/page-access-levels/page-access-levels.service';
//import { MessageHandler } from './shared/message-handler/message.handler';
import { AcceptTermsOfUseComponent } from './accept-terms-of-use/accept-terms-of-use.component';
//import { MessageHandler } from './shared/message-handler/message.handler';
import { TermsofuseErrorComponent } from './shared/termsofuseError/termsofuseError.component';
import { TruncateModule } from 'ng2-truncate';
import { CoolStorageModule } from 'angular2-cool-storage';
import { SanitizeHtml, SanitizeResourceUrl, SanitizeScript, SanitizeStyle, SanitizeUrl } from 'ng2-sanitize';
import { ViewDisclaimerComponent } from './carrier-details/view-disclaimer/view-disclaimer.component';
import { LogoutComponent } from './shared/logout/logout.component';
import { SessionTimeoutComponent } from './shared/session-timeout/session-timeout.component';
import { RecentlyViewedCarriersComponent } from './recently-viewed-carriers/recently-viewed-carriers.component';
//Auth Guards
import { ClientAuthGuard } from './app.client.auth.guard';
import { ClientService } from './select-client/client.service';
import { CarrierFavoritesAdminComponent } from './carrier-favorites-admin/carrier-favorites-admin.component';
import { TRANSLATION_PROVIDERS}   from './translate/translation';
import { TranslateService }   from './translate/translate.service';
import { TranslatePipe }   from './translate/translate.pipe';
import { DocFolderUpdateComponent } from './doc-folder/doc-folder-update/doc-folder-update.component';
import { DocFolderDeleteComponent } from './doc-folder/doc-folder-delete/doc-folder-delete.component';
import { DropdownGroupComponent } from './doc-folder/dropdown-group/dropdown-group.component';
import { DropdownGroupEditorComponent } from './doc-folder/dropdown-group-editor/dropdown-group-editor.component';
import { DocAccessDeleteComponent } from './doc-access/doc-access-delete/doc-access-delete.component';
import { DocFolderEvents } from './doc-folder/doc-folder.events';
import { DocAccessEvents } from './doc-access/doc-access.events';
import { FooterEvents } from './footer/footer.events';
import { PageAccessAuthGuard } from './shared/page-access-levels/page-access-levels.guard';
import { SessionService } from './shared/user-attempt/user-attempt-session.service';
import { DocumentsPipe,DateFormatPipe } from './carrier-details/documents/documents.pipe';
import { GeneralDateFormatPipe, GeneralDatePipe } from './carrier-details/general/general.pipe';
import { UnauthorisedComponent } from './shared/unauthorised/unauthorised.component';
import { SafeContentPipe } from './terms-of-use/safe-content.pipe';
import { UrlRenderComponent } from './url-render/url-render.component';
import { DownloadFileComponent } from './download-file/download-file.component';
import { OwnershipComponent } from './carrier-details/ownership/ownership.component';
import { DropdownAccessComponent } from './doc-folder/dropdown-access/dropdown-access.component';
import { DropdownAccessEditorComponent } from './doc-folder/dropdown-access-editor/dropdown-access-editor.component';
import { DocGroupUpdateComponent } from './doc-folder/doc-group-update/doc-group-update.component';
import { AppEvents } from './app.events';
import { SortingComponent } from './carrier-search/sorting/sorting.component';

@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    FooterComponent,
    RatingsComponent,
    DisclaimersComponent,
    EdituserComponent,
    AnnouncementsComponent,
    CarriersearchComponent,
    NotificationComponent,
    CarrierDocComponent,
    HomePageAdminComponent,
    CarrierFavoritesComponent,
    ClientMaintenanceComponent,
    DocAccessComponent,
    DocFolderComponent,
    ReportsComponent,
    MsHomeComponent,
    NiceSelectDirective,
    LoaderComponent,
    PaginationComp,
    SelectClient,
    CarrierDetailsComponent,
    SummaryComponent,
    FinancialsComponent,
    DocumentsComponent,
    LicensesComponent,
    GeneralComponent,
    TermsOfUseComponent,
    LinkComponent,
    CheckComponent,
    DatepickerComponent,
    CarrierFavoritesAdminComponent,
    TranslatePipe,
    DocFolderUpdateComponent,
    DocFolderDeleteComponent,
	  RecentlyViewedCarriersComponent,
    DropdownGroupComponent,
      DropdownGroupEditorComponent,
      ForbiddenComponent,
      TermsofuseErrorComponent,
      AcceptTermsOfUseComponent,
      DocAccessDeleteComponent,
      UseInReports,
      ComparativeReport,
      RelatedLinksComponent,
      LibraryComponent,
      UnauthorisedComponent,
      HelpComponent,
      DocumentsPipe,
      DateFormatPipe,
      ManageLibraryComponent,
      DocumentSearchComponent,
      AdminHelpComponent,
      SafeContentPipe,
      SanitizeHtml,
      SanitizeResourceUrl,
      SanitizeScript,
      SanitizeStyle,
      SanitizeUrl,
      UrlRenderComponent,
      ViewDisclaimerComponent,
      DownloadFileComponent,
      OwnershipComponent,
      DropdownAccessComponent,
      DropdownAccessEditorComponent,
      LogoutComponent,
      SessionTimeoutComponent,
      DocGroupUpdateComponent,
      SignOutComponent,
      GeneralDateFormatPipe,
      GeneralDatePipe,
      SortingComponent
      // , ComponentBase
  ],
  imports: [
    TruncateModule,
    BrowserModule,
    FormsModule,
    CoolStorageModule,
    HttpModule,
    routing,
     AgGridModule.withComponents(
            [LinkComponent,CheckComponent,SortingComponent,DocFolderDeleteComponent,DocFolderUpdateComponent,DropdownGroupComponent,DropdownGroupEditorComponent,DocAccessDeleteComponent,DropdownAccessComponent,DropdownAccessEditorComponent,DocGroupUpdateComponent]
        )
  ],
  providers: [
    {
      provide: Http,
      useFactory: httpFactory,
      deps: [XHRBackend, RequestOptions, Storage]
    },      
    Storage,
    Settings,
    AuthService,
    {
      provide: APP_INITIALIZER,
      useFactory: AuthServiceFactory,
      deps: [AuthService],
      multi: true
    },
    {
      provide: ErrorHandler, 
      useClass: GlobalErrorHandler
    },
    LoaderService,
    LoggedInUser,
    ClientAuthGuard,
    ClientService,
    ClientMaintenaceState,
    PageAccessService,
    DocFolderEvents,
    DocAccessEvents,
    CarrierDetailsEvents,
    GeneralEvents,
    SummaryEvents,
    FinancialsEvents,
    DocumentsEvents,
    LicensesEvents,
      FooterEvents,
      AppEvents,
      CarrierSearchEvents,
   PageAccessAuthGuard,
    NotificationState,
    SessionService,
     [ TRANSLATION_PROVIDERS, TranslateService ]
    // PageAccessHelper
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }


