import { Component, OnInit } from '@angular/core';
import { ClientService } from '../../select-client/client.service';
import { UserRole } from '../../shared/model/model';
import { LoggedInUser } from '../../shared/loggedInUser/LoggedInUser';
import { CarrierSearchEvents } from '../carriersearch.events';
import { IHeaderParams } from 'ag-grid';
import {IHeaderAngularComp} from 'ag-grid-angular';
declare var $: any;

@Component({
  selector: 'app-sorting',
  templateUrl: './sorting.component.html',
  styleUrls: ['./sorting.component.css']
})
export class SortingComponent implements OnInit,IHeaderAngularComp  {

  private params: any;
  value: string;
  id:string;
  isClientReader: boolean;
  ascExists:boolean=false;
  descExists:boolean=false;

  agInit(params: any): void {
    this.params = params;

  }
  constructor(private _clientService: ClientService, private _loggedInUser: LoggedInUser,private _carrierSearchEvents:CarrierSearchEvents) { }

  ngOnInit() {
    this.value = this.params.displayName;
    this.id='';
    if(this.value=='A.M. BEST'){
      this.id='HiddenAMBest';
    }
    else if(this.value == 'S&P') {
      this.id='HiddenSnP';
    }
    else if(this.value == "Moody's") {
      this.id='HiddenMoody';
    }
    else if(this.value == 'Fitch') {
      this.id='HiddenFitch';
    }
    else if(this.value == 'As at Date') {
      this.id='HiddenAsAtDate';
    }
    else if(this.value == 'PHS/SHF/ Capacity') {
      this.id='HiddenPHSSHFCapacity';
    }
    else if(this.value == 'NWP') {
      this.id='HiddenNWP';
    }
    else if(this.value == 'Combined Ratio %') {
      this.id='HiddenCombinedRatio';
    }
    else if(this.value == 'Legal Name') {
      this.id='HiddenLegalName';
    }
  }

  sort(){
    var id='#'+this.id;
    if(this.ascExists){
      $(id).removeClass('ag-icon-asc');
      $(id).addClass('ag-icon-desc');
      this.sortDesc();
    }else if(this.descExists) {
      $(id).removeClass('ag-icon');
      $(id).removeClass('ag-icon-desc');
      this.sortNull();
    }else{
      this.removeOthers();
      $(id).addClass('ag-icon');
      $(id).addClass('ag-icon-asc');
      this.sortAsc();
    }
    
  }

  sortDesc() {
    this.ascExists=false;
    this.descExists=true;
    this._carrierSearchEvents.sortDescEvent.emit(this.value);
  }

  sortAsc() {
    this.ascExists=true;
    this.descExists=false;
    this._carrierSearchEvents.sortAscEvent.emit(this.value);
  }

  sortNull() {
    this.ascExists=false;
    this.descExists=false;
    this._carrierSearchEvents.sortNullEvent.emit(this.value);
  }
  
  removeOthers() {
    if(this.id=='HiddenAMBest'){
      $('#HiddenSnP').removeClass('ag-icon');
      $('#HiddenSnP').removeClass('ag-icon-desc');
      $('#HiddenSnP').removeClass('ag-icon-asc');

      $('#HiddenMoody').removeClass('ag-icon');
      $('#HiddenMoody').removeClass('ag-icon-desc');
      $('#HiddenMoody').removeClass('ag-icon-asc');

      $('#HiddenFitch').removeClass('ag-icon');
      $('#HiddenFitch').removeClass('ag-icon-desc');
      $('#HiddenFitch').removeClass('ag-icon-asc');

      $('#HiddenAsAtDate').removeClass('ag-icon');
      $('#HiddenAsAtDate').removeClass('ag-icon-desc');
      $('#HiddenAsAtDate').removeClass('ag-icon-asc');

      $('#HiddenPHSSHFCapacity').removeClass('ag-icon');
      $('#HiddenPHSSHFCapacity').removeClass('ag-icon-desc');
      $('#HiddenPHSSHFCapacity').removeClass('ag-icon-asc');

      $('#HiddenNWP').removeClass('ag-icon');
      $('#HiddenNWP').removeClass('ag-icon-desc');
      $('#HiddenNWP').removeClass('ag-icon-asc');

      $('#HiddenCombinedRatio').removeClass('ag-icon');
      $('#HiddenCombinedRatio').removeClass('ag-icon-desc');
      $('#HiddenCombinedRatio').removeClass('ag-icon-asc');

      $('#HiddenLegalName').removeClass('ag-icon');
      $('#HiddenLegalName').removeClass('ag-icon-desc');
      $('#HiddenLegalName').removeClass('ag-icon-asc');

    }
    else if(this.id=='HiddenSnP') {
      $('#HiddenAMBest').removeClass('ag-icon');
      $('#HiddenAMBest').removeClass('ag-icon-desc');
      $('#HiddenAMBest').removeClass('ag-icon-asc');;

      $('#HiddenMoody').removeClass('ag-icon');
      $('#HiddenMoody').removeClass('ag-icon-desc');
      $('#HiddenMoody').removeClass('ag-icon-asc');

      $('#HiddenFitch').removeClass('ag-icon');
      $('#HiddenFitch').removeClass('ag-icon-desc');
      $('#HiddenFitch').removeClass('ag-icon-asc');

      $('#HiddenAsAtDate').removeClass('ag-icon');
      $('#HiddenAsAtDate').removeClass('ag-icon-desc');
      $('#HiddenAsAtDate').removeClass('ag-icon-asc');

      $('#HiddenPHSSHFCapacity').removeClass('ag-icon');
      $('#HiddenPHSSHFCapacity').removeClass('ag-icon-desc');
      $('#HiddenPHSSHFCapacity').removeClass('ag-icon-asc');

      $('#HiddenNWP').removeClass('ag-icon');
      $('#HiddenNWP').removeClass('ag-icon-desc');
      $('#HiddenNWP').removeClass('ag-icon-asc');

      $('#HiddenCombinedRatio').removeClass('ag-icon');
      $('#HiddenCombinedRatio').removeClass('ag-icon-desc');
      $('#HiddenCombinedRatio').removeClass('ag-icon-asc');

      $('#HiddenLegalName').removeClass('ag-icon');
      $('#HiddenLegalName').removeClass('ag-icon-desc');
      $('#HiddenLegalName').removeClass('ag-icon-asc');
    }
    else if(this.id=='HiddenMoody') {
      $('#HiddenAMBest').removeClass('ag-icon');
      $('#HiddenAMBest').removeClass('ag-icon-desc');
      $('#HiddenAMBest').removeClass('ag-icon-asc');

      $('#HiddenSnP').removeClass('ag-icon');
      $('#HiddenSnP').removeClass('ag-icon-desc');
      $('#HiddenSnP').removeClass('ag-icon-asc');

      $('#HiddenFitch').removeClass('ag-icon');
      $('#HiddenFitch').removeClass('ag-icon-desc');
      $('#HiddenFitch').removeClass('ag-icon-asc');

      $('#HiddenAsAtDate').removeClass('ag-icon');
      $('#HiddenAsAtDate').removeClass('ag-icon-desc');
      $('#HiddenAsAtDate').removeClass('ag-icon-asc');

      $('#HiddenPHSSHFCapacity').removeClass('ag-icon');
      $('#HiddenPHSSHFCapacity').removeClass('ag-icon-desc');
      $('#HiddenPHSSHFCapacity').removeClass('ag-icon-asc');

      $('#HiddenNWP').removeClass('ag-icon');
      $('#HiddenNWP').removeClass('ag-icon-desc');
      $('#HiddenNWP').removeClass('ag-icon-asc');

      $('#HiddenCombinedRatio').removeClass('ag-icon');
      $('#HiddenCombinedRatio').removeClass('ag-icon-desc');
      $('#HiddenCombinedRatio').removeClass('ag-icon-asc');

      $('#HiddenLegalName').removeClass('ag-icon');
      $('#HiddenLegalName').removeClass('ag-icon-desc');
      $('#HiddenLegalName').removeClass('ag-icon-asc');
    }
    else if(this.id=='HiddenFitch') {
      $('#HiddenAMBest').removeClass('ag-icon');
      $('#HiddenAMBest').removeClass('ag-icon-desc');
      $('#HiddenAMBest').removeClass('ag-icon-asc');

      $('#HiddenSnP').removeClass('ag-icon');
      $('#HiddenSnP').removeClass('ag-icon-desc');
      $('#HiddenSnP').removeClass('ag-icon-asc');

      $('#HiddenMoody').removeClass('ag-icon');
      $('#HiddenMoody').removeClass('ag-icon-desc');
      $('#HiddenMoody').removeClass('ag-icon-asc');

      $('#HiddenAsAtDate').removeClass('ag-icon');
      $('#HiddenAsAtDate').removeClass('ag-icon-desc');
      $('#HiddenAsAtDate').removeClass('ag-icon-asc');

      $('#HiddenPHSSHFCapacity').removeClass('ag-icon');
      $('#HiddenPHSSHFCapacity').removeClass('ag-icon-desc');
      $('#HiddenPHSSHFCapacity').removeClass('ag-icon-asc');

      $('#HiddenNWP').removeClass('ag-icon');
      $('#HiddenNWP').removeClass('ag-icon-desc');
      $('#HiddenNWP').removeClass('ag-icon-asc');

      $('#HiddenCombinedRatio').removeClass('ag-icon');
      $('#HiddenCombinedRatio').removeClass('ag-icon-desc');
      $('#HiddenCombinedRatio').removeClass('ag-icon-asc');

      $('#HiddenLegalName').removeClass('ag-icon');
      $('#HiddenLegalName').removeClass('ag-icon-desc');
      $('#HiddenLegalName').removeClass('ag-icon-asc');
    }
    else if(this.id=='HiddenAsAtDate') {
      $('#HiddenAMBest').removeClass('ag-icon');
      $('#HiddenAMBest').removeClass('ag-icon-desc');
      $('#HiddenAMBest').removeClass('ag-icon-asc');

      $('#HiddenSnP').removeClass('ag-icon');
      $('#HiddenSnP').removeClass('ag-icon-desc');
      $('#HiddenSnP').removeClass('ag-icon-asc');

      $('#HiddenMoody').removeClass('ag-icon');
      $('#HiddenMoody').removeClass('ag-icon-desc');
      $('#HiddenMoody').removeClass('ag-icon-asc');

      $('#HiddenFitch').removeClass('ag-icon');
      $('#HiddenFitch').removeClass('ag-icon-desc');
      $('#HiddenFitch').removeClass('ag-icon-asc');

      $('#HiddenPHSSHFCapacity').removeClass('ag-icon');
      $('#HiddenPHSSHFCapacity').removeClass('ag-icon-desc');
      $('#HiddenPHSSHFCapacity').removeClass('ag-icon-asc');

      $('#HiddenNWP').removeClass('ag-icon');
      $('#HiddenNWP').removeClass('ag-icon-desc');
      $('#HiddenNWP').removeClass('ag-icon-asc');

      $('#HiddenCombinedRatio').removeClass('ag-icon');
      $('#HiddenCombinedRatio').removeClass('ag-icon-desc');
      $('#HiddenCombinedRatio').removeClass('ag-icon-asc');

      $('#HiddenLegalName').removeClass('ag-icon');
      $('#HiddenLegalName').removeClass('ag-icon-desc');
      $('#HiddenLegalName').removeClass('ag-icon-asc');
    }
    else if(this.id=='HiddenPHSSHFCapacity') {
      $('#HiddenAMBest').removeClass('ag-icon');
      $('#HiddenAMBest').removeClass('ag-icon-desc');
      $('#HiddenAMBest').removeClass('ag-icon-asc');

      $('#HiddenSnP').removeClass('ag-icon');
      $('#HiddenSnP').removeClass('ag-icon-desc');
      $('#HiddenSnP').removeClass('ag-icon-asc');

      $('#HiddenMoody').removeClass('ag-icon');
      $('#HiddenMoody').removeClass('ag-icon-desc');
      $('#HiddenMoody').removeClass('ag-icon-asc');

      $('#HiddenFitch').removeClass('ag-icon');
      $('#HiddenFitch').removeClass('ag-icon-desc');
      $('#HiddenFitch').removeClass('ag-icon-asc');

      $('#HiddenAsAtDate').removeClass('ag-icon');
      $('#HiddenAsAtDate').removeClass('ag-icon-desc');
      $('#HiddenAsAtDate').removeClass('ag-icon-asc');

      $('#HiddenNWP').removeClass('ag-icon');
      $('#HiddenNWP').removeClass('ag-icon-desc');
      $('#HiddenNWP').removeClass('ag-icon-asc');

      $('#HiddenCombinedRatio').removeClass('ag-icon');
      $('#HiddenCombinedRatio').removeClass('ag-icon-desc');
      $('#HiddenCombinedRatio').removeClass('ag-icon-asc');

      $('#HiddenLegalName').removeClass('ag-icon');
      $('#HiddenLegalName').removeClass('ag-icon-desc');
      $('#HiddenLegalName').removeClass('ag-icon-asc');
    }
    else if(this.id=='HiddenNWP') {
      $('#HiddenAMBest').removeClass('ag-icon');
      $('#HiddenAMBest').removeClass('ag-icon-desc');
      $('#HiddenAMBest').removeClass('ag-icon-asc');

      $('#HiddenSnP').removeClass('ag-icon');
      $('#HiddenSnP').removeClass('ag-icon-desc');
      $('#HiddenSnP').removeClass('ag-icon-asc');

      $('#HiddenMoody').removeClass('ag-icon');
      $('#HiddenMoody').removeClass('ag-icon-desc');
      $('#HiddenMoody').removeClass('ag-icon-asc');

      $('#HiddenFitch').removeClass('ag-icon');
      $('#HiddenFitch').removeClass('ag-icon-desc');
      $('#HiddenFitch').removeClass('ag-icon-asc');

      $('#HiddenAsAtDate').removeClass('ag-icon');
      $('#HiddenAsAtDate').removeClass('ag-icon-desc');
      $('#HiddenAsAtDate').removeClass('ag-icon-asc');

      $('#HiddenPHSSHFCapacity').removeClass('ag-icon');
      $('#HiddenPHSSHFCapacity').removeClass('ag-icon-desc');
      $('#HiddenPHSSHFCapacity').removeClass('ag-icon-asc');

      $('#HiddenCombinedRatio').removeClass('ag-icon');
      $('#HiddenCombinedRatio').removeClass('ag-icon-desc');
      $('#HiddenCombinedRatio').removeClass('ag-icon-asc');

      $('#HiddenLegalName').removeClass('ag-icon');
      $('#HiddenLegalName').removeClass('ag-icon-desc');
      $('#HiddenLegalName').removeClass('ag-icon-asc');
    }
    else if(this.id=='HiddenCombinedRatio') {
      $('#HiddenAMBest').removeClass('ag-icon');
      $('#HiddenAMBest').removeClass('ag-icon-desc');
      $('#HiddenAMBest').removeClass('ag-icon-asc');

      $('#HiddenSnP').removeClass('ag-icon');
      $('#HiddenSnP').removeClass('ag-icon-desc');
      $('#HiddenSnP').removeClass('ag-icon-asc');

      $('#HiddenMoody').removeClass('ag-icon');
      $('#HiddenMoody').removeClass('ag-icon-desc');
      $('#HiddenMoody').removeClass('ag-icon-asc');

      $('#HiddenFitch').removeClass('ag-icon');
      $('#HiddenFitch').removeClass('ag-icon-desc');
      $('#HiddenFitch').removeClass('ag-icon-asc');

      $('#HiddenAsAtDate').removeClass('ag-icon');
      $('#HiddenAsAtDate').removeClass('ag-icon-desc');
      $('#HiddenAsAtDate').removeClass('ag-icon-asc');

      $('#HiddenPHSSHFCapacity').removeClass('ag-icon');
      $('#HiddenPHSSHFCapacity').removeClass('ag-icon-desc');
      $('#HiddenPHSSHFCapacity').removeClass('ag-icon-asc');

      $('#HiddenNWP').removeClass('ag-icon');
      $('#HiddenNWP').removeClass('ag-icon-desc');
      $('#HiddenNWP').removeClass('ag-icon-asc');

      $('#HiddenLegalName').removeClass('ag-icon');
      $('#HiddenLegalName').removeClass('ag-icon-desc');
      $('#HiddenLegalName').removeClass('ag-icon-asc');
    }
    else if(this.id=='HiddenLegalName') {
      $('#HiddenAMBest').removeClass('ag-icon');
      $('#HiddenAMBest').removeClass('ag-icon-desc');
      $('#HiddenAMBest').removeClass('ag-icon-asc');

      $('#HiddenSnP').removeClass('ag-icon');
      $('#HiddenSnP').removeClass('ag-icon-desc');
      $('#HiddenSnP').removeClass('ag-icon-asc');

      $('#HiddenMoody').removeClass('ag-icon');
      $('#HiddenMoody').removeClass('ag-icon-desc');
      $('#HiddenMoody').removeClass('ag-icon-asc');

      $('#HiddenFitch').removeClass('ag-icon');
      $('#HiddenFitch').removeClass('ag-icon-desc');
      $('#HiddenFitch').removeClass('ag-icon-asc');

      $('#HiddenAsAtDate').removeClass('ag-icon');
      $('#HiddenAsAtDate').removeClass('ag-icon-desc');
      $('#HiddenAsAtDate').removeClass('ag-icon-asc');

      $('#HiddenPHSSHFCapacity').removeClass('ag-icon');
      $('#HiddenPHSSHFCapacity').removeClass('ag-icon-desc');
      $('#HiddenPHSSHFCapacity').removeClass('ag-icon-asc');

      $('#HiddenNWP').removeClass('ag-icon');
      $('#HiddenNWP').removeClass('ag-icon-desc');
      $('#HiddenNWP').removeClass('ag-icon-asc');

      $('#HiddenCombinedRatio').removeClass('ag-icon');
      $('#HiddenCombinedRatio').removeClass('ag-icon-desc');
      $('#HiddenCombinedRatio').removeClass('ag-icon-asc');
    }
  }

}
