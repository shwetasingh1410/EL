﻿import { Component, OnInit, Inject } from '@angular/core';
import { SafeUrl, DomSanitizer } from '@angular/platform-browser';
import { Router, ActivatedRoute } from '@angular/router';


import { ClientService } from '../select-client/client.service';
import { UserRole } from '../shared/model/model';
import { LoggedInUser } from '../shared/loggedInUser/LoggedInUser';
import { LoaderService } from '../shared/loaderComponent/Loader.service';

// import { Ng2TableModule } from 'ng2-table/ng2-table';
import { GridOptions } from "ag-grid";
import { LinkComponent } from './link-component/link-component.component';
import { CheckComponent } from './check/check.component';
import { SortingComponent } from './sorting/sorting.component';

import { searchResult } from './carriersearch.mock.data';
import { CarrierSearchService } from './carriersearch.service';
import { CarrierSearchEvents } from './carriersearch.events';
import {
  ApprovalStatus, Account, BusinessUnit, CompanyType, Country, LegalEntity, LicenceType,
  OperatingCategory, Ownership, Qualifier, Restriction, State, LicenseState, Carrier, SearchRequest, RatingAgency,
  RatingAgencyScale, CategoryType, Category, FavoriteGroup, FavoriteType
} from './carriersearch.model'

import { Http, RequestOptions, Headers } from '@angular/http';
import { PageAccessHelper } from '../shared/page-access-levels/page-access-levels.helper';
import { CarrierSearchAccessLevels } from './carriersearch.access-levels';
import { Settings } from '../shared/settings/settings.service';
import { CoolSessionStorage } from 'angular2-cool-storage';
// import { Jquery } from 'jquery';
declare var $: any;


@Component({
  selector: 'app-carriersearch',
  templateUrl: './carriersearch.component.html',
  styleUrls: ['./carriersearch.component.css'],
  providers: [CarrierSearchService, PageAccessHelper]
})
export class CarriersearchComponent implements OnInit {

  FavoriteType: number;
  createdFavorite: string;
  typeFavorites: Array<FavoriteGroup>;
  selectedGroupName: string;
  selectedGroupId: string;
  selectedGroup: FavoriteGroup;
  favorites: Array<FavoriteGroup>;
  CategoryId: string;
  groupallowed: boolean;
  typeCategories: Array<Category>;
  categories: Array<Category>;
  isShowSuccess: boolean;
  isShowDelete: boolean;
  selectedCategory: Category;
  selectedCategoryId: string;
  selectedCategoryName: string;
  createdCategory: string;
  CategoryName: string;
  selectModeType: number;
  CategoryType: number;
  ClientId: string;
  allowed: boolean;
  printMessage: string;
  modalFlag: boolean;

  isClientSelected = false;
  isTableSelected = false;
  group1: string;
  url = 'url';
  selectedAccount: Account;
  isClientReader: boolean;
  selectAllRows: boolean;
  message: string;
  isSuccess: boolean;
  isError: boolean;
  IntersectionObserverEntry
  reportUrl: SafeUrl;
  gridResult: Array<Carrier>;
  gridOptions: GridOptions;

  searchRequest: SearchRequest;
  states: Array<State>;
  licenceStates: Array<LicenseState>;
  approvalStatus: Array<ApprovalStatus>;
  businessUnits: Array<BusinessUnit>;
  companyTypes: Array<CompanyType>;
  countries: Array<Country>;
  licenceCountries: Array<Country>;
  legalEntities: Array<LegalEntity>;
  licenceTypes: Array<LicenceType>;
  operatingCategories: Array<OperatingCategory>;
  ownerships: Array<Ownership>;
  qualifiers: Array<Qualifier>;
  restrictions: Array<Restriction>;
  ratingAgencies: Array<RatingAgency>;
  ratingAgencyScales: Array<RatingAgencyScale>;
  CountryId: number;
  LicenseCountryId: number;
  isWillisUser: number;
  clickIndicator: string;
  dateOne: string;
  dateTwo: string;
  sub;
  redirectToSearchFlag: boolean;
  redirectToClientMaintenanceFlag: boolean;
  redirectToCarrierFavoritesFlag: boolean;
  redirectToCarrierFavoritesAdminFlag: boolean;
  redirectToNotificationFlag: boolean;
  pageAccessLevels: CarrierSearchAccessLevels;
  warningMsg: string = '';
  selectedCountry: Country = null;
  selectedLicenseCountry: Country = null;
  selectedCountryCode: string;
  selectedLicenseState: LicenseState = null;
  selectedRatingName: string = '';


  constructor(private localStorage: CoolSessionStorage, private _router: Router, private _route: ActivatedRoute, private _loggedInUser: LoggedInUser,
    private _clientService: ClientService, private _loaderService: LoaderService,
    private _carrierSearchService: CarrierSearchService, private _http: Http
    , private _pageAccessHelper: PageAccessHelper, private _settings: Settings, private _sanitizer: DomSanitizer,private _carrioerSearchEvents:CarrierSearchEvents) {
    this.pageAccessLevels = new CarrierSearchAccessLevels();

    this.redirectToCarrierFavoritesFlag = false;
    this.redirectToCarrierFavoritesAdminFlag = false;
    this.loadtable();
    this.initialization();
  }

  ngOnInit() { 
    this._carrioerSearchEvents.sortNullEvent.subscribe(
      (showMenu) => {
       this.getSort(showMenu);
      },(error) => {
            this.handleError(error)}
    );
    this._carrioerSearchEvents.sortAscEvent.subscribe(
      (showMenu) => {
       this.getAscSort(showMenu);
      },(error) => {
            this.handleError(error)}
    );
    this._carrioerSearchEvents.sortDescEvent.subscribe(
      (showMenu) => {
       this.getDescSort(showMenu);
      },(error) => {
            this.handleError(error)}
    );
    this._loaderService.show();''   
    $(document).keypress(function (event) {
      var keycode = (event.keyCode ? event.keyCode : event.which);
      if (keycode == '13') {
        $('#find').click();
      }
    });
    this.checkSearchFlag();
    this._pageAccessHelper.getPageAccessLevelsDetails("carrier-search", this.pageAccessLevels);
    if (this._clientService.getSelectedAccount())
      this.selectedAccount = this._clientService.getSelectedAccount();
    if (this.selectedAccount)
      this.searchRequest.ClientId = this.selectedAccount.Id;
    else {
      this.searchRequest.ClientId = '';
    }
    //this.findresults();
    this.checkIfClientReader();
    this.dateOne = this._clientService.getReportDate(1);
    this.dateTwo = this._clientService.getReportDate(2);
    this.redirectToClientMaintenanceFlag = this._clientService.getRedirectToClientMaintenance();
    // this._clientService.setRedirectToClientMaintenance(false);
    this.redirectToSearchFlag = this._clientService.getRedirectToSearch();
    this.redirectToCarrierFavoritesFlag = this._clientService.getRedirectToCarrierFavorites();
    this.redirectToCarrierFavoritesAdminFlag = this._clientService.getRedirectToCarrierFavoritesAdmin();
    this._clientService.setRedirectToCarrierFavoritesAdmin(false);
    this.redirectToNotificationFlag = this._clientService.getRedirectToNotification();
   
    //check Ownership Flag
    let ownership = this._clientService.getOwnership();
    if (ownership !== undefined && ownership !== null) {
      this.searchRequest.GroupCodeId = ownership;
      this.getOwnerships();
    }


    if (this.localStorage) {
      // var search:SearchRequest={} as SearchRequest;
     var search=this.localStorage.getObject('searchRequest');
      if(search){
        if(this.redirectToCarrierFavoritesAdminFlag || this.redirectToClientMaintenanceFlag || this.redirectToSearchFlag || this._clientService.getLicensed() || this._clientService.getLicenseState() || this._clientService.getOwnership()) {
          
        }else{
            if (this.localStorage.getItem('LegalName') && this.localStorage.getItem('LegalName') !== "undefined")
          this.searchRequest.LegalName=this.localStorage.getItem('LegalName');
          if(this.localStorage.getItem('CountryId')){
          this.searchRequest.CountryId=this.localStorage.getItem('CountryId');
          }
          if (this.localStorage.getItem('CountrySubId'))
            this.searchRequest.CountrySubId = +this.localStorage.getItem('CountrySubId');
          if (this.localStorage.getItem('CompanyTypeId'))
            this.searchRequest.CompanyTypeId = +this.localStorage.getItem('CompanyTypeId');
          if (this.localStorage.getItem('ApprovalStatusId'))
            this.searchRequest.ApprovalStatusId = +this.localStorage.getItem('ApprovalStatusId');
          if (this.localStorage.getItem('CodeSelection'))
            this.searchRequest.CodeSelection = this.localStorage.getItem('CodeSelection', );
          if (this.localStorage.getItem('Code'))
            this.searchRequest.Code = this.localStorage.getItem('Code');
          if (this.localStorage.getItem('LegalNameOperator'))
            this.searchRequest.LegalNameOperator = this.localStorage.getItem('LegalNameOperator');
          if (this.localStorage.getItem('GroupCodeId'))
            this.searchRequest.GroupCodeId = this.localStorage.getItem('GroupCodeId');
          if (this.localStorage.getItem('LicenseCountryId'))
            this.searchRequest.LicenseCountryId = this.localStorage.getItem('LicenseCountryId');
          if (this.localStorage.getItem('LicenseStateId'))
            this.searchRequest.LicenseStateId = this.localStorage.getItem('LicenseStateId');
          if (this.localStorage.getItem('LicenseCodeId'))
            this.searchRequest.LicenseCodeId = +this.localStorage.getItem('LicenseCodeId');
          if (this.localStorage.getItem('RatingAgencyId')) { }
          this.searchRequest.RatingAgencyId = this.localStorage.getItem('RatingAgencyId');
          if (this.localStorage.getItem('RatingAgencyOperator'))
            this.searchRequest.RatingAgencyOperator = this.localStorage.getItem('RatingAgencyOperator');
          if (this.localStorage.getItem('RatingRange'))
            this.searchRequest.RatingRange = +this.localStorage.getItem('RatingRange');
          if (this.localStorage.getItem('Default'))
            this.searchRequest.Default = (this.localStorage.getItem('Default') == 'true' ? true : false);
          if (this.localStorage.getItem('ApprovalStatusAllowed'))
            this.searchRequest.ApprovalStatusAllowed = (this.localStorage.getItem('ApprovalStatusAllowed') == 'true' ? true : false);
          if (this.localStorage.getItem('RefCode'))
            this.searchRequest.RefCode = this.localStorage.getItem('RefCode');
          if (this.localStorage.getItem('CategoryId'))
            this.searchRequest.CategoryId = this.localStorage.getItem('CategoryId');
          if (this.localStorage.getItem('CarrierFavoriteId'))
            this.searchRequest.CarrierFavoriteId = this.localStorage.getItem('CarrierFavoriteId');
          if (this.localStorage.getItem('BusinessUnitId'))
            this.searchRequest.BusinessUnitId = +this.localStorage.getItem('BusinessUnitId');
          if (this.localStorage.getItem('ResctrictionCodeId'))
            this.searchRequest.ResctrictionCodeId = +this.localStorage.getItem('ResctrictionCodeId');
          if (this.localStorage.getItem('QualifierId'))
            this.searchRequest.QualifierId = +this.localStorage.getItem('QualifierId');
          if (this.localStorage.getItem('CarrierStatusId'))
            this.searchRequest.CarrierStatusId = +this.localStorage.getItem('CarrierStatusId');
          if (this.localStorage.getItem('IsWillisUser'))
            this.searchRequest.IsWillisUser = +this.localStorage.getItem('IsWillisUser');
          if (this.localStorage.getItem('LegalEntity'))
            this.searchRequest.LegalEntity = this.localStorage.getItem('LegalEntity');
          if (this.localStorage.getItem('TobaIndicator'))
            this.searchRequest.TobaIndicator = this.localStorage.getItem('TobaIndicator');
          if (this.localStorage.getItem('Mode'))
            this.searchRequest.Mode = this.localStorage.getItem('Mode');
        }
      }
    }

    this.sub = this._route.params.subscribe(params => {
      if (params['clientId']) {
        this._carrierSearchService.getAccounts(this._loggedInUser.getUserRoleCode(), this._loggedInUser.getEncryptedUserId()).subscribe(result => {
          var accounts: Array<Account> = result;
          var index = accounts.findIndex(acc => acc.AccountId == params['clientId']);
          if (index != -1) {
            this._clientService.setAccountId(this.searchRequest.ClientId);
            this.searchRequest.ClientId = accounts[index].Id;
            this.selectedAccount = accounts[index];
            this._clientService.setSelectedAccount(this.selectedAccount);
            this.contentload();

            if (!this.redirectToClientMaintenanceFlag || !this.redirectToCarrierFavoritesFlag || !this.redirectToCarrierFavoritesAdminFlag) {
              if (this._clientService.getLicenseState()) {
              } else {
                if(this.redirectToCarrierFavoritesAdminFlag || this.redirectToClientMaintenanceFlag) {
                  this.searchRequest.Mode = 'CM';
                  this.findresults();
                }else{
                  this.findresults();
                }
              }
            }
            else {
              this.searchRequest.Mode = 'CM';
            }
            if (!this.redirectToNotificationFlag) {
              // this.findresults2();
            }

            else {
              this.searchRequest.Mode = 'EN';
            }
          } else {
            this._router.navigate(['forbidden']);
          }

        });

      } else {
        if(this.redirectToCarrierFavoritesAdminFlag){
          //do nothing
          this.searchRequest.ClientId=null;
          // this._clientService.setSelectedAccount(null);
        }else{

          if (this.selectedAccount)
          this.searchRequest.ClientId = this.selectedAccount.Id;
        else {
          this.searchRequest.ClientId = '';
        }
        }
        this.contentload();
        if (!this.redirectToClientMaintenanceFlag || !this.redirectToCarrierFavoritesFlag || !this.redirectToCarrierFavoritesAdminFlag) {
          if (this._clientService.getLicenseState()) {

          } else {
            if(this.redirectToCarrierFavoritesAdminFlag || this.redirectToClientMaintenanceFlag) {
              this.searchRequest.Mode = 'CM';
              this.findresults();
            }else{
              this.findresults();
            }
          }
        }
        else {
          this.searchRequest.Mode = 'CM';
        }
        if (!this.redirectToNotificationFlag) {
          // this.findresults2();
        }

        else {
          this.searchRequest.Mode = 'EN';
        }
      }
    })


    //this.reset2();
  }
  contentload() {
    this.getCategories();
    this.getCarrierFavorites();
  }

  initialization() {
    this.ownerships = [];
    this.isClientSelected = true;
    this.isTableSelected = true;
    this.selectAllRows = false;
    this.getCountry();
    this.getReferenceData();    
    this.getRatingAgencies();
    this.getLicenceCountry();
    this.reset();
  }

  loadtable() {
    this.gridOptions = <GridOptions>{};
    this.gridOptions.rowSelection = 'multiple';
    this.gridOptions.suppressRowClickSelection = true;
    this.gridOptions.enableSorting = true;
    this.gridOptions.rowHeight = 100;
    this.gridOptions.headerHeight = 70;
    this.gridOptions.suppressMovableColumns = true;
    var check = this._loggedInUser.getUserRoleCode();
    this.isClientReader = (this._loggedInUser.getUserRoleCode() === 'ClientRead');
    if (this.isClientReader)
      this.gridOptions.columnDefs = [

        {
          headerName: "Select All",
          children: [
            {
              headerName: "",
              width: 75,
              cellStyle: { 'white-space': 'normal' },
              checkboxSelection: true,
              headerCheckboxSelection: true
            }
          ]
        },
        {
          headerName: "Company Information",
          children: [
            {
              headerName: "Legal Name",
              field: "LegalName",
              headerComponentFramework : SortingComponent,
              cellRendererFramework: LinkComponent,
              width: 140,
              cellStyle: { 'white-space': 'normal' }
            },
          ]
        },
        {
          headerName: "Match Type (P) Previous Name (S) Short Name",
          children: [
            {
              headerName: "Match Type",
              field: "MatchType",
              width: 50,
              cellStyle: { 'white-space': 'normal' }
            },
            {
              headerName: "Country",
              field: "Country",
              width: 80,
              cellStyle: { 'white-space': 'normal' }
            },
            {
              headerName: "State",
              field: "State",
              width: 80,
              cellStyle: { 'white-space': 'normal' }
            },
            {
              headerName: "Company Type",
              field: "CompanyType",
              width: 75,
              cellStyle: { 'white-space': 'normal' }
            }
          ]
        },
        {
          headerName: "WTW Code",
          field: "WillisCode",
          width: 55,
          cellStyle: { 'white-space': 'normal' }
        },
        {
          headerName: "LORS Code",
          field: "LorsCode",
          width: 55,
          cellStyle: { 'white-space': 'normal' }
        },
        {
          headerName: "NAIC Code",
          field: "NaicCode",
          width: 55,
          cellStyle: { 'white-space': 'normal' }
        },
        {
          headerName: "FEIN/AIIN Code",
          field: "FeinCode",
          width: 80,
          cellStyle: { 'white-space': 'normal' }
        },
        {
          headerName: "Ratings Information",
          children: [
            {
              headerName: "A.M. BEST",
              field: "AMBest",
              headerComponentFramework : SortingComponent,
              width: 95,
              cellStyle: { 'white-space': 'normal' }
            },
            {
              headerName: "S&P",
              field: "SnP",
              headerComponentFramework : SortingComponent,
              width: 75,
              cellStyle: { 'white-space': 'normal' }
            },
            {
              headerName: "Moody's",
              field: "Moodys",
              headerComponentFramework : SortingComponent,
              width: 75,
              cellStyle: { 'white-space': 'normal' }
            },
            {
              headerName: "Fitch",
              field: "Fitch",
              headerComponentFramework : SortingComponent,
              width: 100,
              cellStyle: { 'white-space': 'normal' }
            },
          ]
        },
        {
          headerName: '',
          children: [
            {
              headerName: "As at Date",
              field: "AsAtDate",
              headerComponentFramework : SortingComponent,
              width: 80,
              cellStyle: { 'white-space': 'normal' }
            }
          ]
        }
        ,
        {
          headerName: "Financial Information USD millions",
          children: [
            {
              headerName: "PHS/SHF/ Capacity",
              field: "PHSCapacity",
              headerComponentFramework : SortingComponent,
              width: 140,
              cellStyle: { 'white-space': 'normal' }

            },
            {
              headerName: "NWP",
              field: "NWP",
              headerComponentFramework : SortingComponent,
              width: 80,
              cellStyle: { 'white-space': 'normal' }
            },
            {
              headerName: "Combined Ratio %",
              field: "CombinedRatioPercentage",
              headerComponentFramework : SortingComponent,
              width: 120,
              cellStyle: { 'white-space': 'normal' }
            }
          ]
        },
        {
          headerName: "FATCA Status",
          field: "FATCAStatus",
          width: 50,
          cellStyle: { 'white-space': 'normal' }
        },{
          headerName: "",
          field: "HiddenAMBest",
          width: 50,
          hide:true,
          cellStyle: { 'white-space': 'normal' }
        },{
          headerName: "",
          field: "HiddenSnP",
          width: 50,
          hide:true,
          cellStyle: { 'white-space': 'normal' }
        }
        ,{
          headerName: "",
          field: "HiddenFitch",
          width: 50,
          hide:true,
          cellStyle: { 'white-space': 'normal' }
        }
        ,{
          headerName: "",
          field: "HiddenMoody",
          width: 50,
          hide:true,
          cellStyle: { 'white-space': 'normal' }
        }
        ,{
          headerName: "",
          field: "HiddenLegalName",
          width: 50,
          hide:true,
          cellStyle: { 'white-space': 'normal' }
        }
        ,{
          headerName: "",
          field: "HiddenPHSSHFCapacity",
          width: 50,
          hide:true,
          cellStyle: { 'white-space': 'normal' }
        }
        ,{
          headerName: "",
          field: "HiddenNWP",
          width: 50,
          hide:true,
          cellStyle: { 'white-space': 'normal' }
        }
        ,{
          headerName: "",
          field: "HiddenAsAtDate",
          width: 50,
          hide:true,
          cellStyle: { 'white-space': 'normal' }
        }
        ,{
          headerName: "",
          field: "HiddenCombinedRatio",
          width: 50,
          hide:true,
          cellStyle: { 'white-space': 'normal' }
        }

      ];
    else
      this.gridOptions.columnDefs = [
        {
          headerName: "Select All",
          children: [
            {
              headerName: "",
              width: 75,
              cellStyle: { 'white-space': 'normal' },
              checkboxSelection: true,
              headerCheckboxSelection: true
            }
          ]
        },
        {
          headerName: "Company Information",
          children: [
            {
              headerName: "Legal Name",
              field: "LegalName",
              headerComponentFramework : SortingComponent,
              cellRendererFramework: LinkComponent,
              width: 140,
              cellStyle: { 'white-space': 'normal' }
            },
          ]
        },
        {
          headerName: "Match Type (P) Previous Name (S) Short Name",
          children: [
            {
              headerName: "Match Type",
              field: "MatchType",
              width: 50,
              cellStyle: { 'white-space': 'normal' }
            },
            {
              headerName: "Country",
              field: "Country",
              width: 80,
              cellStyle: { 'white-space': 'normal' }
            },
            {
              headerName: "State",
              field: "State",
              width: 80,
              cellStyle: { 'white-space': 'normal' }
            },
            {
              headerName: "Company Type",
              field: "CompanyType",
              width: 75,
              cellStyle: { 'white-space': 'normal' }
            }
          ]
        },
        {
          headerName: "WTW Code",
          field: "WillisCode",
          width: 55,
          cellStyle: { 'white-space': 'normal' }
        },
        {
          headerName: "LORS Code",
          field: "LorsCode",
          width: 55,
          cellStyle: { 'white-space': 'normal' }
        },
        {
          headerName: "NAIC Code",
          field: "NaicCode",
          width: 55,
          cellStyle: { 'white-space': 'normal' }
        },
        {
          headerName: "FEIN/AIIN Code",
          field: "FeinCode",
          width: 80,
          cellStyle: { 'white-space': 'normal' }
        },
        {
          headerName: "Ratings Information",
          children: [
            {
              headerName: "A.M. BEST",
              field: "AMBest",
              headerComponentFramework : SortingComponent,
              width: 95,
              cellStyle: { 'white-space': 'normal' }
            },
            {
              headerName: "S&P",
              field: "SnP",
              headerComponentFramework : SortingComponent,
              width:75,
              cellStyle: { 'white-space': 'normal' }
            },
            {
              headerName: "Moody's",
              field: "Moodys",
              headerComponentFramework : SortingComponent,
              width: 90,
              cellStyle: { 'white-space': 'normal' }
            },
            {
              headerName: "Fitch",
              field: "Fitch",
              headerComponentFramework : SortingComponent,
              width: 100,
              cellStyle: { 'white-space': 'normal' }
            },
          ]
        },
        {
          headerName: '',
          children: [
            {
              headerName: "As at Date",
              field: "AsAtDate",
              headerComponentFramework : SortingComponent,
              width: 80,
              cellStyle: { 'white-space': 'normal' }
            }
          ]
        },
        {
          headerName: "Financial Information USD millions",
          children: [
            {
              headerName: "PHS/SHF/ Capacity",
              field: "PHSCapacity",
              headerComponentFramework : SortingComponent,
              width: 140,
              cellStyle: { 'white-space': 'normal' }

            },
            {
              headerName: "NWP",
              field: "NWP",
              headerComponentFramework : SortingComponent,
              width: 80,
              cellStyle: { 'white-space': 'normal' }
            },
            {
              headerName: "Combined Ratio %",
              field: "CombinedRatioPercentage",
              headerComponentFramework : SortingComponent,
              width: 120,
              cellStyle: { 'white-space': 'normal' }
            },
          ]
        },

        {
          headerName: "Approval Status",
          field: "ApprovalStatus",
          tooltipField: 'ApprovalStatusHover',
          width: 70,
          cellStyle: { 'white-space': 'normal' }
        },
        {
          headerName: "Sanction Status",
          field: "SanctionStatus",
          cellRendererFramework: CheckComponent,
          width: 65,
          cellStyle: { 'white-space': 'normal' }
        },
        {
          headerName: "TOBA End date",
          field: "TOBAEndDate",
          width: 50,
          cellStyle: { 'white-space': 'normal' }
        },
        {
          headerName: "TOBA Indicator",
          field: "TOBAIndicator",
          tooltipField: 'TOBAHover',
          width: 65,
          cellStyle: { 'white-space': 'normal' }
        },
        ,
        {
          headerName: "FATCA Status",
          field: "FATCAStatus",
          width: 70,
          cellStyle: { 'white-space': 'normal' }
        }
        ,{
          headerName: "",
          field: "HiddenAMBest",
          width: 50,
          hide:true,
          cellStyle: { 'white-space': 'normal' }
        }
        ,{
          headerName: "",
          field: "HiddenSnP",
          width: 50,
          hide:true,
          cellStyle: { 'white-space': 'normal' }
        }
        ,{
          headerName: "",
          field: "HiddenFitch",
          width: 50,
          hide:true,
          cellStyle: { 'white-space': 'normal' }
        }
        ,{
          headerName: "",
          field: "HiddenMoody",
          width: 50,
          hide:true,
          cellStyle: { 'white-space': 'normal' }
        }
        ,{
          headerName: "",
          field: "HiddenLegalName",
          width: 50,
          hide:true,
          cellStyle: { 'white-space': 'normal' }
        }
        ,{
          headerName: "",
          field: "HiddenPHSSHFCapacity",
          width: 50,
          hide:true,
          cellStyle: { 'white-space': 'normal' }
        }
        ,{
          headerName: "",
          field: "HiddenNWP",
          width: 50,
          hide:true,
          cellStyle: { 'white-space': 'normal' }
        }
        ,{
          headerName: "",
          field: "HiddenAsAtDate",
          width: 50,
          hide:true,
          cellStyle: { 'white-space': 'normal' }
        }
        ,{
          headerName: "",
          field: "HiddenCombinedRatio",
          width: 50,
          hide:true,
          cellStyle: { 'white-space': 'normal' }
        }
      ];
    //this.gridOptions.rowData=[];
  }

  getSort(sorter) {
    let sortCol='';
    if(sorter=='A.M. BEST'){
      sortCol='HiddenAMBest';
    }
    else if(sorter == 'S&P') {
      sortCol='HiddenSnP';
    }
    else if(sorter == "Moody's") {
      sortCol='HiddenMoody';
    }
    else if(sorter == 'Fitch') {
      sortCol='HiddenFitch';
    }
    else if(sorter == 'As at Date') {
      sortCol='HiddenAsAtDate';
    }
    else if(sorter == 'PHS/SHF/ Capacity') {
      sortCol='HiddenPHSSHFCapacity';
    }
    else if(sorter == 'NWP') {
      sortCol='HiddenNWP';
    }
    else if(sorter == 'Combined Ratio %') {
      sortCol='HiddenCombinedRatio';
    }
    else if(sorter == 'Legal Name') {
      sortCol='HiddenLegalName';
    }
    var sort = [
      {colId: sortCol, sort: null}
  ];
  this.gridOptions.api.setSortModel(sort);
  }

  getAscSort(sorter) {
    let sortCol='';
    if(sorter=='A.M. BEST'){
      sortCol='HiddenAMBest';
    }
    else if(sorter == 'S&P') {
      sortCol='HiddenSnP';
    }
    else if(sorter == "Moody's") {
      sortCol='HiddenMoody';
    }
    else if(sorter == 'Fitch') {
      sortCol='HiddenFitch';
    }
    else if(sorter == 'As at Date') {
      sortCol='HiddenAsAtDate';
    }
    else if(sorter == 'PHS/SHF/ Capacity') {
      sortCol='HiddenPHSSHFCapacity';
    }
    else if(sorter == 'NWP') {
      sortCol='HiddenNWP';
    }
    else if(sorter == 'Combined Ratio %') {
      sortCol='HiddenCombinedRatio';
    }
    else if(sorter == 'Legal Name') {
      sortCol='HiddenLegalName';
    }
    var sort = [
      {colId: sortCol, sort: 'asc'}
  ];
  this.gridOptions.api.setSortModel(sort);
  }

  getDescSort(sorter) {
    let sortCol='';
    if(sorter=='A.M. BEST'){
      sortCol='HiddenAMBest';
    }
    else if(sorter == 'S&P') {
      sortCol='HiddenSnP';
    }
    else if(sorter == "Moody's") {
      sortCol='HiddenMoody';
    }
    else if(sorter == 'Fitch') {
      sortCol='HiddenFitch';
    }
    else if(sorter == 'As at Date') {
      sortCol='HiddenAsAtDate';
    }
    else if(sorter == 'PHS/SHF/ Capacity') {
      sortCol='HiddenPHSSHFCapacity';
    }
    else if(sorter == 'NWP') {
      sortCol='HiddenNWP';
    }
    else if(sorter == 'Combined Ratio %') {
      sortCol='HiddenCombinedRatio';
    }
    else if(sorter == 'Legal Name') {
      sortCol='HiddenLegalName';
    }
    var sort = [
      {colId: sortCol, sort: 'desc'}
  ];
  this.gridOptions.api.setSortModel(sort);
  }

  NumberComparator(a, b) {
    var num1: number = +a;
    var num2: number = +b;

    if (isNaN(num1) && isNaN(num2)) {
      return 0;
    }
    if (isNaN(num1)) {
      return -1;
    }
    if (isNaN(num2)) {
      return 1;
    }

    if (num1 > num2) {
      return 1;
    }

    if (num1 < num2) {
      return -1;
    }

    return 0;
  }

  reset() {
    let clientId = (this.searchRequest !== undefined ? this.searchRequest.ClientId : null);
    this.searchRequest = new SearchRequest();
    this.searchRequest.ClientId = clientId;
    this.searchRequest.LegalNameOperator = '1';
    this.searchRequest.RatingAgencyOperator = '0';
    this.gridResult = new Array<Carrier>();
    this.gridResult=[];
    this.searchRequest.CodeSelection = 'willis';
    this.searchRequest.LegalName = '';
  }

  reset2() {
    if (this.localStorage.getItem('LegalName')) {
      this.localStorage.removeItem('LegalName');
    }
    if (this.localStorage.getItem('CountryId')) {
      this.localStorage.removeItem('CountryId');
      this.localStorage.removeItem('CountryCode');
    }
    if (this.localStorage.getItem('CountrySubId')) {
      this.localStorage.removeItem('CountrySubId');
    }
    if (this.localStorage.getItem('CompanyTypeId')) {
      this.localStorage.removeItem('CompanyTypeId');
    }
    if (this.localStorage.getItem('ApprovalStatusId')) {
      this.localStorage.removeItem('ApprovalStatusId');
    }
    if (this.localStorage.getItem('CodeSelection')) {
      this.localStorage.removeItem('CodeSelection');
    }
    if (this.localStorage.getItem('Code')) {
      this.localStorage.removeItem('Code');
    }
    if (this.localStorage.getItem('LegalNameOperator')) {
      this.localStorage.removeItem('LegalNameOperator');
    }
    if (this.localStorage.getItem('GroupCodeId')) {
      this.localStorage.removeItem('GroupCodeId');
    }
    if (this.localStorage.getItem('LicenseCountryId')) {
      this.localStorage.removeItem('LicenseCountryId');
      this.localStorage.removeItem('LicenseCountryCode');
    }
    if (this.localStorage.getItem('LicenseStateId')) {
      this.localStorage.removeItem('LicenseStateId');
      this.localStorage.removeItem('LicenseStateCode');
    }
    if (this.localStorage.getItem('LicenseCodeId')) {
      this.localStorage.removeItem('LicenseCodeId');
    }
    if (this.localStorage.getItem('RatingAgencyId')) {
      this.localStorage.removeItem('RatingAgencyId');
      this.localStorage.removeItem('RatingAgencyName');
    }
    if (this.localStorage.getItem('RatingAgencyOperator')) {
      this.localStorage.removeItem('RatingAgencyOperator');
    }
    if (this.localStorage.getItem('RatingRange')) {
      this.localStorage.removeItem('RatingRange');
    }
    if (this.localStorage.getItem('Default')) {
      this.localStorage.removeItem('Default');
    }
    if (this.localStorage.getItem('ApprovalStatusAllowed')) {
      this.localStorage.removeItem('ApprovalStatusAllowed');
    }
    if (this.localStorage.getItem('RefCode')) {
      this.localStorage.removeItem('RefCode');
    }
    if (this.localStorage.getItem('CategoryId')) {
      this.localStorage.removeItem('CategoryId');
      this.localStorage.removeItem('CategoryName');
    }
    if (this.localStorage.getItem('CarrierFavoriteId')) {
      this.localStorage.removeItem('CarrierFavoriteId')
      this.localStorage.removeItem('CarrierFavoriteName');
    }
    if (this.localStorage.getItem('BusinessUnitId')) {
      this.localStorage.removeItem('BusinessUnitId');
    }
    if (this.localStorage.getItem('ResctrictionCodeId')) {
      this.localStorage.removeItem('ResctrictionCodeId');
    }
    if (this.localStorage.getItem('QualifierId')) {
      this.localStorage.removeItem('QualifierId');
    }
    if (this.localStorage.getItem('CarrierStatusId')) {
      this.localStorage.removeItem('CarrierStatusId');
    }
    if (this.localStorage.getItem('IsWillisUser')) {
      this.localStorage.removeItem('IsWillisUser');
    }
    if (this.localStorage.getItem('LegalEntity')) {
      this.localStorage.removeItem('LegalEntity');
    }
    if (this.localStorage.getItem('TobaIndicator')) {
      this.localStorage.removeItem('TobaIndicator');
    }
    if (this.localStorage.getItem('Mode')) {
      this.localStorage.removeItem('Mode');
    }
    if(this.gridOptions.api){
      if(this.gridOptions.api.getSelectedRows().length>0){
        this.gridOptions.api.forEachNodeAfterFilter(node => {
          node.setSelected(false);
      })
      }
    }
    let clientId = (this.searchRequest !== undefined ? this.searchRequest.ClientId : null);
    this.searchRequest = new SearchRequest();
    this.searchRequest.LegalName = '';
    this.searchRequest.ClientId = clientId;
    this.searchRequest.LegalNameOperator = '1';
    this.searchRequest.RatingAgencyOperator = '0';
    this.selectedCategory = null;
    this.selectedGroup = null;
    this.searchRequest.CodeSelection = 'willis';
    this.states = [];
    this.licenceStates = [];
    this.getLicenceCountry();
    this.getCountry();
    this.licenceTypes = [];
    this.ratingAgencyScales = [];
    this.getCategories();
    this.getCarrierFavorites();


    this.findresults();

    if (this._loggedInUser.getUserRoleCode() !== 'ClientRead') {
      $('#headingOne').attr('class', 'card-header collapsed');
      $('#headingOne').attr('aria-expanded', 'false');
      $('#collapseOne').attr('aria-expanded', 'false');
      $('#collapseOne').attr('class', 'collapse');
    }

  }
  findresults() {
    this._loaderService.show();
    if (this.searchRequest.CodeSelection !== null && this.searchRequest.CodeSelection == 'clientref') {
      this.searchRequest.RefCode = this.searchRequest.Code;
    }
    if (this.gridOptions.api) {
      var selectedRows: Array<Carrier> = this.gridOptions.api.getSelectedRows();
      var length: number = selectedRows.length;
    } else {
      var selectedRows: Array<Carrier> = [];
      var length: number = 0;
    }
    this._carrierSearchService.getSearchResult(this.searchRequest)
   
      .subscribe((result) => {
        this.gridResult = result;
        if (selectedRows.length > 0) {
          if (this.gridResult.length > 0) {
            if (this.gridResult.length >= length) {
              var duplicateCarriers: Array<Carrier> = [];
              this.gridResult.forEach(carrier => {
                for (var i = 0; i < length; i++) {
                  if (carrier.WillisCode == selectedRows[i].WillisCode) {
                    duplicateCarriers.push(carrier);
                  }
                }
              })
              if (duplicateCarriers.length > 0) {
                if (duplicateCarriers.length >= this.gridResult.length) {
                  for (var i = 0; i < duplicateCarriers.length; i++) {
                    for (var j = 0; j < this.gridResult.length; j++) {
                      if (duplicateCarriers[i].WillisCode == this.gridResult[j].WillisCode) {
                        this.gridResult.splice(j, 1);
                      }
                    }
                  }
                } else {
                  for (var i = 0; i < this.gridResult.length; i++) {
                    for (var j = 0; j < duplicateCarriers.length; j++) {
                      if (duplicateCarriers[j].WillisCode == this.gridResult[i].WillisCode) {
                        this.gridResult.splice(i, 1);
                      }
                    }
                  }
                }
              }
            } else {
              var duplicateCarriers: Array<Carrier> = [];
              selectedRows.forEach(carrier => {
                for (var i = 0; i < this.gridResult.length; i++) {
                  if (carrier.WillisCode == this.gridResult[i].WillisCode) {
                    duplicateCarriers.push(carrier);
                  }
                }
              })
              if (duplicateCarriers.length > 0) {
                if (duplicateCarriers.length >= this.gridResult.length) {
                  for (var i = 0; i < duplicateCarriers.length; i++) {
                    for (var j = 0; j < this.gridResult.length; j++) {
                      if (duplicateCarriers[i].WillisCode == this.gridResult[j].WillisCode) {
                        this.gridResult.splice(j, 1);
                      }
                    }
                  }
                } else {
                  for (var i = 0; i < this.gridResult.length; i++) {
                    for (var j = 0; j < duplicateCarriers.length; j++) {
                      if (duplicateCarriers[j].WillisCode == this.gridResult[i].WillisCode) {
                        this.gridResult.splice(i, 1);
                      }
                    }
                  }
                }
              }

            }
          }

          for (var i = 0; i < this.gridResult.length; i++) {
            selectedRows.push(this.gridResult[i]);
          }
          if (this.gridOptions.api != null) {
            this.gridResult = selectedRows;
            this.gridOptions.api.setRowData(selectedRows);
          }
          else {
            this.gridResult = selectedRows;
            this.gridOptions.rowData = selectedRows;
          }
          var count: number = 0;
          this.gridOptions.api.forEachNodeAfterFilter(node => {
            if (count < length) {
              node.setSelected(true);
              count++;
            } else {
              node.setSelected(false);
            }
          })
        } else {
          if (this.gridOptions.api != null) {
            this.gridOptions.api.setRowData(result);
          }
          else {
            this.gridOptions.rowData = result;
          }
        }
        this.isTableSelected = true;
        this._loaderService.hide();
        this.localStorage.setObject('searchRequest',this.searchRequest);
        if (this.searchRequest.LegalName && this.searchRequest.LegalName !== "undefined") {
            this.searchRequest.LegalName = decodeURIComponent(this.searchRequest.LegalName);
            this.localStorage.setItem('LegalName', this.searchRequest.LegalName);
        }
        else{
          if(this.localStorage.getItem('LegalName')){
            this.localStorage.removeItem('LegalName');
          }
        }
        if (this.searchRequest.CountryId) {
          this.localStorage.setItem('CountryId', this.searchRequest.CountryId.toString());
          if (this.selectedCountryCode)
            this.localStorage.setItem('CountryCode', this.selectedCountryCode);
        }
        else {
          if (this.localStorage.getItem('CountryId')) {
            this.localStorage.removeItem('CountryId');
            this.localStorage.removeItem('CountryCode');
          }
        }
        if (this.searchRequest.CountrySubId)
          this.localStorage.setItem('CountrySubId', this.searchRequest.CountrySubId.toString());
        else {
          if (this.localStorage.getItem('CountrySubId')) {
            this.localStorage.removeItem('CountrySubId');
          }
        }
        if (this.searchRequest.CompanyTypeId)
          this.localStorage.setItem('CompanyTypeId', this.searchRequest.CompanyTypeId.toString());
        else {
          if (this.localStorage.getItem('CompanyTypeId')) {
            this.localStorage.removeItem('CompanyTypeId');
          }
        }
        if (this.searchRequest.ApprovalStatusId)
          this.localStorage.setItem('ApprovalStatusId', this.searchRequest.ApprovalStatusId.toString());
        else {
          if (this.localStorage.getItem('ApprovalStatusId')) {
            this.localStorage.removeItem('ApprovalStatusId');
          }
        }
        if (this.searchRequest.CodeSelection)
          this.localStorage.setItem('CodeSelection', this.searchRequest.CodeSelection);
        else {
          if (this.localStorage.getItem('CodeSelection')) {
            this.localStorage.removeItem('CodeSelection');
          }
        }
        if (this.searchRequest.Code)
          this.localStorage.setItem('Code', this.searchRequest.Code);
        else {
          if (this.localStorage.getItem('Code')) {
            this.localStorage.removeItem('Code');
          }
        }
        if (this.searchRequest.LegalNameOperator)
          this.localStorage.setItem('LegalNameOperator', this.searchRequest.LegalNameOperator);
        else {
          if (this.localStorage.getItem('LegalNameOperator')) {
            this.localStorage.removeItem('LegalNameOperator');
          }
        }
        if (this.searchRequest.GroupCodeId)
          this.localStorage.setItem('GroupCodeId', this.searchRequest.GroupCodeId);
        else {
          if (this.localStorage.getItem('GroupCodeId')) {
            this.localStorage.removeItem('GroupCodeId');
          }
        }
        if (this.searchRequest.LicenseCountryId) {
          this.localStorage.setItem('LicenseCountryId', this.searchRequest.LicenseCountryId.toString());
          if (this.selectedLicenseCountry)
            this.localStorage.setItem('LicenseCountryCode', this.selectedLicenseCountry.CountryCode);
        }
        else {
          if (this.localStorage.getItem('LicenseCountryId')) {
            this.localStorage.removeItem('LicenseCountryId');
            this.localStorage.removeItem('LicenseCountryCode');
          }
        }
        if (this.searchRequest.LicenseStateId) {

          this.localStorage.setItem('LicenseStateId', this.searchRequest.LicenseStateId.toString());
          if (this.selectedLicenseState)
            this.localStorage.setItem('LicenseStateCode', this.selectedLicenseState.CountrySubCodePart);
        }
        else {
          if (this.localStorage.getItem('LicenseStateId')) {
            this.localStorage.removeItem('LicenseStateId');
            this.localStorage.removeItem('LicenseStateCode');
          }
        }
        if (this.searchRequest.LicenseCodeId)
          this.localStorage.setItem('LicenseCodeId', this.searchRequest.LicenseCodeId.toString());
        else {
          if (this.localStorage.getItem('LicenseCodeId')) {
            this.localStorage.removeItem('LicenseCodeId');
          }
        }
        if (this.searchRequest.RatingAgencyId) {
          this.localStorage.setItem('RatingAgencyId', this.searchRequest.RatingAgencyId.toString());
          if (this.selectedRatingName) {
            this.localStorage.setItem('RatingAgencyName', this.selectedRatingName);
          }
        }
        else {
          if (this.localStorage.getItem('RatingAgencyId')) {
            this.localStorage.removeItem('RatingAgencyId');
            this.localStorage.removeItem('RatingAgencyName');
          }
        }
        if (this.searchRequest.RatingAgencyOperator)
          this.localStorage.setItem('RatingAgencyOperator', this.searchRequest.RatingAgencyOperator);
        else {
          if (this.localStorage.getItem('RatingAgencyOperator')) {
            this.localStorage.removeItem('RatingAgencyOperator');
          }
        }
        if (this.searchRequest.RatingRange)
          this.localStorage.setItem('RatingRange', this.searchRequest.RatingRange.toString());
        else {
          if (this.localStorage.getItem('RatingRange')) {
            this.localStorage.removeItem('RatingRange');
          }
        }
        if (this.searchRequest.Default)
          this.localStorage.setItem('Default', this.searchRequest.Default.toString());
        else {
          if (this.localStorage.getItem('Default')) {
            this.localStorage.removeItem('Default');
          }
        }
        if (this.searchRequest.ApprovalStatusAllowed)
          this.localStorage.setItem('ApprovalStatusAllowed', this.searchRequest.ApprovalStatusAllowed.toString());
        else {
          if (this.localStorage.getItem('ApprovalStatusAllowed')) {
            this.localStorage.removeItem('ApprovalStatusAllowed');
          }
        }
        if (this.searchRequest.RefCode)
          this.localStorage.setItem('RefCode', this.searchRequest.RefCode);
        else {
          if (this.localStorage.getItem('RefCode')) {
            this.localStorage.removeItem('RefCode');
          }
        }
        if (this.searchRequest.CategoryId) {
          this.localStorage.setItem('CategoryId', this.searchRequest.CategoryId);
          if (this.selectedCategory)
            this.localStorage.setItem('CategoryName', this.selectedCategory.CategoryName);
        }
        else {
          if (this.localStorage.getItem('CategoryId')) {
            this.localStorage.removeItem('CategoryId');
            this.localStorage.removeItem('CategoryName');
          }
        }
        if (this.searchRequest.CarrierFavoriteId) {
          this.localStorage.setItem('CarrierFavoriteId', this.searchRequest.CarrierFavoriteId);
          if (this.selectedGroup)
            this.localStorage.setItem('CarrierFavoriteName', this.selectedGroup.GroupName);
        }
        else {
          if (this.localStorage.getItem('CarrierFavoriteId')) {
            this.localStorage.removeItem('CarrierFavoriteName');
            this.localStorage.removeItem('CarrierFavoriteId');
          }
        }
        if (this.searchRequest.BusinessUnitId)
          this.localStorage.setItem('BusinessUnitId', this.searchRequest.BusinessUnitId.toString());
        else {
          if (this.localStorage.getItem('BusinessUnitId')) {
            this.localStorage.removeItem('BusinessUnitId');
          }
        }
        if (this.searchRequest.ResctrictionCodeId)
          this.localStorage.setItem('ResctrictionCodeId', this.searchRequest.ResctrictionCodeId.toString());
        else {
          if (this.localStorage.getItem('ResctrictionCodeId')) {
            this.localStorage.removeItem('ResctrictionCodeId');
          }
        }
        if (this.searchRequest.QualifierId)
          this.localStorage.setItem('QualifierId', this.searchRequest.QualifierId.toString());
        else {
          if (this.localStorage.getItem('QualifierId')) {
            this.localStorage.removeItem('QualifierId');
          }
        }
        if (this.searchRequest.CarrierStatusId)
          this.localStorage.setItem('CarrierStatusId', this.searchRequest.CarrierStatusId.toString());
        else {
          if (this.localStorage.getItem('CarrierStatusId')) {
            this.localStorage.removeItem('CarrierStatusId');
          }
        }
        if (this.searchRequest.IsWillisUser)
          this.localStorage.setItem('IsWillisUser', this.searchRequest.IsWillisUser.toString());
        else {
          if (this.localStorage.getItem('IsWillisUser')) {
            this.localStorage.removeItem('IsWillisUser');
          }
        }
        if (this.searchRequest.LegalEntity)
          this.localStorage.setItem('LegalEntity', this.searchRequest.LegalEntity);
        else {
          if (this.localStorage.getItem('LegalEntity')) {
            this.localStorage.removeItem('LegalEntity');
          }
        }
        if (this.searchRequest.TobaIndicator)
          this.localStorage.setItem('TobaIndicator', this.searchRequest.TobaIndicator);
        else {
          if (this.localStorage.getItem('TobaIndicator')) {
            this.localStorage.removeItem('TobaIndicator');
          }
        }
        if (this.searchRequest.Mode)
          this.localStorage.setItem('Mode', this.searchRequest.Mode);
        else {
          if (this.localStorage.getItem('Mode')) {
            this.localStorage.removeItem('Mode');
          }
        }
      },
      (error) => this.handleError(error));
  }
  findresults2() {
    //this._loaderService.show();
    this._carrierSearchService.getSearchResult(this.searchRequest)
      .subscribe((result) => {
        this.gridResult = result;
        this.gridOptions.rowData = result;
        this.isTableSelected = true;
        //this._loaderService.hide();
      },
      (error) => this.handleError(error));
  }

  selectAllRowsClick() {
    this.gridResult.forEach((carrier) => carrier.select = this.selectAllRows);
  }

  getCountry() {
    this._carrierSearchService.getCountries()
      .subscribe((result) => {
        this.countries = result;
        if(this.redirectToCarrierFavoritesAdminFlag || this.redirectToClientMaintenanceFlag || this.redirectToSearchFlag || this._clientService.getLicensed() || this._clientService.getLicenseState() || this._clientService.getOwnership()) {

        } else {
          if (this.localStorage.getItem('CountryId')) {
            this.searchRequest.CountryId = this.localStorage.getItem('CountryId');
            var code = this.localStorage.getItem('CountryCode');
            var index = this.countries.findIndex(country => country.CountryCode == code);
            if (index != -1) {
              this.selectedCountry = this.countries[index];
              this.getState(this.selectedCountry);
            }
          } else {
            this.selectedCountry = null;
          }
        }
      }, (error) => this.handleError(error));

  }

  getState(country: Country) {
    if (country) {
      this.searchRequest.CountryId = country.CountryId;
      this.selectedCountryCode = country.CountryCode;
      // this._loaderService.show();
      this._carrierSearchService.getStates(country.CountryId)
        .subscribe((result) => {
          this.states = result;
          // this._loaderService.hide();
        },
        (error) => this.handleError(error));
    } else {
      this.selectedCountry = null;
      this.searchRequest.CountrySubId = null;
      this.searchRequest.CountryId = null;
      this.states = [];
    }

  }


  getLicenceCountry() {
    this._carrierSearchService.getLicenceCountries()
      .subscribe((result) => {
        this.licenceCountries = result;
        if (this._clientService.getLicenseTypeCountry() && this._clientService.getLicenseTypeCountry() != 'null') {
          var countrycode = this._clientService.getLicenseTypeCountry();
          let index = this.licenceCountries.findIndex(country => country.CountryCode == countrycode);
          if (index != -1) {
            this.selectedLicenseCountry = this.licenceCountries[index];
            this.searchRequest.LicenseCountryId = this.selectedLicenseCountry.CountryId;
          }

          // Check Country and State flag
          let liceseState = this._clientService.getLicenseState();
          if (liceseState) {
            $('#headingOne').removeClass('collapsed');
            $('#collapseOne').addClass('in');
            this.getLicenceState(this.searchRequest.LicenseCountryId);
            this.getLicenceTypes(this.searchRequest.LicenseCountryId);
            // this.searchRequest.LicenseStateId = liceseState.CountrySubCode;
          }

          // Flag for License Type
          let licenseType = this._clientService.getLicensed();
          this._clientService.setLicensed(null);
          if (licenseType) {
            $('#headingOne').removeClass('collapsed');
            $('#collapseOne').addClass('in');
            this.getLicenceTypes(this.searchRequest.LicenseCountryId);
            this.getLicenceState(this.searchRequest.LicenseCountryId);
            this.searchRequest.LicenseCodeId = licenseType;
          }
          this._clientService.setLicenceTypeCountry(null);
        }else{
          if(this.redirectToCarrierFavoritesAdminFlag || this.redirectToClientMaintenanceFlag || this.redirectToSearchFlag || this._clientService.getLicensed() || this._clientService.getLicenseState() || this._clientService.getOwnership()) {
            
                    }else{
          if(this.localStorage.getItem('LicenseCountryId')){
            this.searchRequest.LicenseCountryId=this.localStorage.getItem('LicenseCountryId');
            var code=this.localStorage.getItem('LicenseCountryCode');
            var index=this.licenceCountries.findIndex(country=> country.CountryCode==code);
            if(index!= -1){
              this.selectedLicenseCountry=this.licenceCountries[index];
              this.getLicenceState(this.selectedLicenseCountry.CountryId);
              this.getLicenceTypes(this.selectedLicenseCountry.CountryId); 
            }
            }else{
              this.selectedLicenseCountry=null;
            }
          }
        }
      }, (error) => this.handleError(error));
  }

  licenceCountryChange(country: Country) {
    if (country) {
      this.selectedLicenseCountry = country;
      this.searchRequest.LicenseCountryId = country.CountryId;
      this.getLicenceState(country.CountryId);
      this.getLicenceTypes(country.CountryId);
    } else {
      this.selectedLicenseCountry = null;
      this.searchRequest.LicenseCodeId = null;
      this.searchRequest.LicenseStateId = null;
      this.searchRequest.LicenseCountryId = null;
    }

  }


  getLicenceState(countryId: string) {
    if (countryId) {
      // this._loaderService.show();
      this._carrierSearchService.getLicenceStates(countryId)
        .subscribe((result) => {
          this.licenceStates = result;
          if(this._clientService.getLicenseState()){
            var lstate= this._clientService.getLicenseState();
            let index=this.licenceStates.findIndex(state=> state.CountrySubCodePart == lstate.CountrySubCode)
            if(index!=-1){
              this.searchRequest.LicenseStateId=this.licenceStates[index].CountrySubId;
              this.selectedLicenseState=this.licenceStates[index];
            }
            this._loaderService.hide();
            this._clientService.setLicenseState(null);
          } else {
            if (this.localStorage.getItem('LicenseStateId')) {
              var code = this.localStorage.getItem('LicenseStateCode');
              var index = this.licenceStates.findIndex(country => country.CountrySubCodePart == code);
              if (index != -1) {
                this.selectedLicenseState = this.licenceStates[index];
                this.searchRequest.LicenseStateId = this.licenceStates[index].CountrySubId;

              }
            }
          }
          // this._loaderService.hide();
        },
        (error) => this.handleError(error));
    } else {
      this.searchRequest.CountrySubId = null;
      this.licenceStates = [];
    }
  }

  getLicenceTypes(countryId: string) {
    if (countryId) {
      // this._loaderService.show();
      this._carrierSearchService.getLicenceTypes(countryId)
        .subscribe((result) => {
          this.licenceTypes = result;
          // this._loaderService.hide();
        }, (error) => this.handleError(error));
    } else {
      this.searchRequest.LicenseCodeId = null;
      this.licenceTypes = [];
    }
  }


  getOwnerships() {
    // this._carrierSearchService.getOwnerships()
    //   .subscribe((result) => {
    //     this.ownerships = result;
    //   },
    //   (error) => this.handleError(error));
  }

  getReferenceData() {
      this._carrierSearchService.getReferenceData()
          .subscribe((response) =>
          {
              this.approvalStatus = this._carrierSearchService.getApprovalStatusHandler(response.ApprovalStatus);
              this.ownerships = this._carrierSearchService.getOwnershipsHandler(response.Ownership);
              this.businessUnits = this._carrierSearchService.getBusinessUnitsHandler(response.BusinessUnits);
              this.qualifiers = this._carrierSearchService.getQualifiersHandler(response.Qualifiers);
              this.operatingCategories = this._carrierSearchService.getOperatingCategoriesHandler(response.OperatingCategories);
              this.restrictions = this._carrierSearchService.getRestrictionsHandler(response.Restrictions);
              this.legalEntities = this._carrierSearchService.getLegalEntitiesHandler(response.LegalEntities);
              this.companyTypes = this._carrierSearchService.getCompanyTypesHandler(response.CompanyTypes);
          },
          (error) => this.handleError(error));
  }

  getRatingAgencies() {
    this._carrierSearchService.getRatingAgencies()
      .subscribe((result) => {
        this.ratingAgencies = result;
        if(this.redirectToCarrierFavoritesAdminFlag || this.redirectToClientMaintenanceFlag || this.redirectToSearchFlag || this._clientService.getLicensed() || this._clientService.getLicenseState() || this._clientService.getOwnership()) {
          
        }else{
          if(this.localStorage.getItem('RatingAgencyId')){
            var name=this.localStorage.getItem('RatingAgencyName');
            let index=this.ratingAgencies.findIndex(rating => rating.RatingAgencyName==name);
            if(index != -1){
              this.searchRequest.RatingAgencyId=this.ratingAgencies[index].RatingAgencyId;
              this.getRatingAgencyScales(this.searchRequest.RatingAgencyId);
            }
          }

        }
      },
      (error) => {
        this.handleError(error);
      });
  }

  getRatingAgencyScales(ratingAgencyId: string) {
    if (ratingAgencyId) {
      let index = this.ratingAgencies.findIndex(rating => rating.RatingAgencyId == ratingAgencyId);
      if (index != -1) {
        this.selectedRatingName = this.ratingAgencies[index].RatingAgencyName;
      }
      this._carrierSearchService.getRatingAgencyScales(ratingAgencyId)
        .subscribe((result) => {
          this.ratingAgencyScales = result;
          if(this.redirectToCarrierFavoritesAdminFlag || this.redirectToClientMaintenanceFlag || this.redirectToSearchFlag || this._clientService.getLicensed() || this._clientService.getLicenseState() || this._clientService.getOwnership()) {
            
          }else{
            if(this.localStorage.getItem('RatingRange')){
              var name=+this.localStorage.getItem('RatingRange');
              let index=this.ratingAgencyScales.findIndex(rating => rating.RatingAgencyId==name);
              if(index != -1){
                this.searchRequest.RatingRange=this.ratingAgencyScales[index].RatingAgencyId;
              }
            } else {
              this.searchRequest.RatingRange = null;
            }

          }
          this.searchRequest.RatingRange = null;
        }, (error) => this.handleError(error));
    } else {
      this.selectedRatingName = '';
      this.searchRequest.CountrySubId = null;
      this.searchRequest.RatingAgencyId = null;
      this.searchRequest.RatingRange = null;
      this.ratingAgencyScales = [];
    }
  }


  selectclient() {
    this._clientService.setSelectedAccount(this.selectedAccount);
    this._clientService.setChangeSelectedClient(true);
    this._clientService.setRevertUrl('carrier-search');
    this._router.navigateByUrl('/select-client');
  }



  checkIfClientReader() {
    this.isClientReader = (this._loggedInUser.getUserRoleCode() === 'ClientRead');
  }

  handleError(error) {
    this._loaderService.hide();
    // this.showError('Some Error Occured, please report to support team along with steps to reproduce');
    this.showError('Timeout Error. The result you requested is taking too long to respond. Try Again');
  }

  showSuccess(message: string) {
    this.message = message;
    this.isSuccess = true;
  }

  showError(message: string) {
    this.isError = true;
    this.message = message;
    this._loaderService.hide();
  }

  redirectToPrevious(page: string) {


    // let selectedCarriers: Array<Carrier> = this.gridResult.filter((carrier) => carrier.select == true);

    if (this.gridOptions.api.getSelectedRows()) {
      let selectedCarriers: Array<Carrier> = this.gridOptions.api.getSelectedRows();
      this._clientService.setCarriers(selectedCarriers);
      this._clientService.setCarriersNotification(selectedCarriers);
      if(this.selectedAccount)
      this._clientService.setAccountIdNotification(this.selectedAccount.Id);
      if (selectedCarriers == null || selectedCarriers == undefined || selectedCarriers.length == 0) {
        this._clientService.setAnyUpdate(false);
      }
      else {
        this._clientService.setAnyUpdate(true);
        this._clientService.setFromSearch(true);
      }

    }
    if (page == 'notification' || page == 'client-maintenance') {

    } else {
      if (this._clientService.getModeType()) {
        if (this._clientService.getModeType() == 2 || this._clientService.getModeType() == 3) {
          page = 'carrier-favorites';
        }
        if (this._clientService.getModeType() == 1) {
          page = 'carrier-favorites-admin';
          // this._clientService.setSelectedAccount(undefined);
        }
      }
    }

    this._clientService.setRedirectFromAdmin(false);
    switch (page) {
      case 'client-maintenance':
        //this._clientService.setCarriers()
        this._clientService.setRedirectToClientMaintenance(false);
        break;
      case 'carrier-favorites':
        this._clientService.setRedirectToCarrierFavorites(false);
        break;
      case 'carrier-favorites-admin':
        this._clientService.setRedirectToCarrierFavoritesAdmin(false);

        break;
      case 'notification':
        {
          this._clientService.setRedirectToNotification(false);

          break;
        }

    }
    this._router.navigateByUrl('/' + page);
  }


  changeCode(CodeSelection: string) {
    if (CodeSelection == '' || CodeSelection == null) {
      this.searchRequest.CodeSelection = null;
      this.searchRequest.Code = null;
      this.searchRequest.RefCode = null;
    }
    if(CodeSelection !== "clientref"){
      delete this.searchRequest.RefCode 
    }
  }

  changeCategory(CategoryId: number) {
    if (CategoryId == 0 || CategoryId == null) {
      this.searchRequest.CategoryId = null;
    }
  }

  onChangeState(CountrySubId: number) {
    if (CountrySubId == 0 || CountrySubId == null) {
      this.searchRequest.CountrySubId = null;
    }
  }
  onFavourites(CarrierFavoriteId: number) {
    if (CarrierFavoriteId == 0 || CarrierFavoriteId == null) {
      this.searchRequest.CarrierFavoriteId = null;
    }
  }
  onOwnershipChange(GroupCodeId: number) {
    if (GroupCodeId == 0 || GroupCodeId == null) {
      this.searchRequest.GroupCodeId = null;
    }
  }
  onCompanyTypeChange(CompanyTypeId: number) {
    if (CompanyTypeId == 0 || CompanyTypeId == null) {
      this.searchRequest.CompanyTypeId = null;
      this.searchRequest.ApprovalStatusAllowed=null;
    }
    else{
      this.searchRequest.ApprovalStatusAllowed=true;
    }
  }
  onOperatingChange(CarrierStatusId: number) {
    if (CarrierStatusId == 0 || CarrierStatusId == null) {
      this.searchRequest.CarrierStatusId = null;
    }
  }
  onRatingRangeChange(RatingRange: number) {
    if (RatingRange == 0 || RatingRange == null) {
      this.searchRequest.RatingRange = null;
    }
  }
  onApprovalStatusChange(ApprovalStatusId: number) {
    if (ApprovalStatusId == 0 || ApprovalStatusId == null) {
      this.searchRequest.ApprovalStatusId = null;
      this.searchRequest.ApprovalStatusAllowed=null;
    }
    else{
      this.searchRequest.ApprovalStatusAllowed=true;
    }
  }
  onRestrictionChange(ResctrictionCodeId: number) {
    if (ResctrictionCodeId == 0 || ResctrictionCodeId == null) {
      this.searchRequest.ResctrictionCodeId = null;      
    }
  }
  onQualifierChange(QualifierId: number) {
    if (QualifierId == 0 || QualifierId == null) {
      this.searchRequest.QualifierId = null;
    }
  }
  onBUChange(BusinessUnitId: number) {
    if (BusinessUnitId == 0 || BusinessUnitId == null) {
      this.searchRequest.BusinessUnitId = null;
    }
  }
  onTobaChange(TobaIndicator: string) {
    if (TobaIndicator == '') {
      this.searchRequest.TobaIndicator = null;
    }
  }
  onLEChange(LegalEntity: string) {
    if (LegalEntity) {
      this.searchRequest.LegalEntity = LegalEntity;
    } else {
      this.searchRequest.LegalEntity = null;
    }
  }
  onLicenseStateChange(LicenseState: LicenseState) {
    if (LicenseState) {
      this.selectedLicenseState = LicenseState;
      this.searchRequest.LicenseStateId = LicenseState.CountrySubId;
    } else {
      this.selectedLicenseState = null;
      this.searchRequest.LicenseStateId = null;
    }

  }
  goToCarrierFavorites() {
    if (this._clientService.getRedirectionToFavorites()) {
      if (this.gridOptions.api)
        if (this.gridOptions.api.getSelectedRows()) {
          let selectedCarriers: Array<Carrier> = this.gridOptions.api.getSelectedRows();
          this._clientService.setCarriers(selectedCarriers);
        }
      let page: string;
      if (this._clientService.getModeType()) {
        if (this._clientService.getModeType() == 2 || this._clientService.getModeType() == 3) {
          page = 'carrier-favorites';
          this._clientService.setRedirectToCarrierFavorites(false);
          this._clientService.setRedirectionToFavorites(false);
          this._router.navigateByUrl('/' + page);
        }
      }
    } else {
      let selectedCarriers: Array<Carrier>;
      if (this.gridOptions.api) {
        if (this.gridOptions.api.getSelectedRows().length > 0) {
          selectedCarriers = this.gridOptions.api.getSelectedRows();
          this._clientService.setCarriers(selectedCarriers);
          this._clientService.setModeType(0);
        } else {
          this._clientService.setModeType(0);
        }
      } else {
        this._clientService.setModeType(0);
      }
      this._router.navigateByUrl('/carrier-favorites');
    }
  }


  getCategories() {
    this.selectedAccount = this._clientService.getSelectedAccount();
    if (this.redirectToCarrierFavoritesAdminFlag) {
      if (true) {
        // this.ClientId = this.selectedAccount.Id;
        // this._clientService.setAccountIdNotification(this.selectedAccount.Id);

        //this._loaderService.show();
        // this.selectModeType = 3;
        this._carrierSearchService.GetCategories(1, '')
          .subscribe((result) => {
            this.categories = result;
            this.categories.sort((a, b) => {
              if (a.CategoryName.toLowerCase() < b.CategoryName.toLowerCase())
                return -1;
              if (a.CategoryName.toLowerCase() > b.CategoryName.toLowerCase())
                return 1;

              return 0;

            });
            let category = this._clientService.getSelectedCategoryClient();
            this.allowed = false;
            //this._loaderService.hide();
          },
          (error) => this.handleError(error));
      }
    } else {
      if (this.selectedAccount) {
      this.ClientId = this.selectedAccount.Id;
      this._clientService.setAccountIdNotification(this.selectedAccount.Id);
      
      //this._loaderService.show();
      this.selectModeType = 3;
      this._carrierSearchService.GetCategories(this.selectModeType, this.ClientId)
        .subscribe((result) => {
          this.categories = result;
          this.categories.sort((a,b) => {
          if(a.CategoryName.toLowerCase() < b.CategoryName.toLowerCase())
          return -1;
          if(a.CategoryName.toLowerCase() > b.CategoryName.toLowerCase())
          return 1;
    
          return 0;
          
        });
        if(this.redirectToCarrierFavoritesAdminFlag || this.redirectToClientMaintenanceFlag || this.redirectToSearchFlag || this._clientService.getLicensed() || this._clientService.getLicenseState() || this._clientService.getOwnership()) {
          this._clientService.setOwnership(null);
        }else{

              if (this.localStorage.getItem('CategoryName')) {
                var name = this.localStorage.getItem('CategoryName');
                let index = this.categories.findIndex(category => category.CategoryName == name);
                if (index != -1) {
                  this.selectedCategory = this.categories[index];
                  this.onCategoryChange(this.selectedCategory);
                }
              }
            }
            //this._loaderService.hide();
          },
          (error) => this.handleError(error));
      }
    }

  }

  getCarrierFavorites() {
    var adminFav:boolean=false;
    this.CategoryId = '';
    this.selectedAccount = this._clientService.getSelectedAccount();
    if(this.redirectToCarrierFavoritesAdminFlag){
    adminFav=true;
   }
    if (this.selectedAccount || adminFav) {
      // this.ClientId = this.selectedAccount.Id;

      //this._loaderService.show();
      this.selectModeType = 3;
      if (this.redirectToCarrierFavoritesAdminFlag) {
        this._carrierSearchService.GetGroups(1, '', '')
          .subscribe((result) => {
            this.favorites = result;
            this.favorites.sort((a, b) => {
              if (a.GroupName.toLowerCase() < b.GroupName.toLowerCase())
                return -1;
              if (a.GroupName.toLowerCase() > b.GroupName.toLowerCase())
                return 1;

              return 0;

            })


            //this._loaderService.hide();
          },
          (error) => this.handleError(error));
      } else {
        this._carrierSearchService.GetGroups(this.selectModeType, this.ClientId, this.CategoryId)
        .subscribe((result) => {
          this.favorites = result;
          this.favorites.sort((a,b) => {
          if(a.GroupName.toLowerCase() < b.GroupName.toLowerCase())
          return -1;
          if(a.GroupName.toLowerCase() > b.GroupName.toLowerCase())
          return 1;
    
          return 0;
          
        })
        if(this.redirectToCarrierFavoritesAdminFlag || this.redirectToClientMaintenanceFlag || this.redirectToSearchFlag || this._clientService.getLicensed() || this._clientService.getLicenseState() || this._clientService.getOwnership()) {
          
        }else{
          if(this.localStorage.getItem('CategoryName')){

              } else {
                if (this.localStorage.getItem('CarrierFavoriteName')) {
                  var name = this.localStorage.getItem('CarrierFavoriteName');
                  let index = this.favorites.findIndex(favorite => favorite.GroupName == name);
                  if (index != -1) {
                    this.selectedGroup = this.favorites[index];
                  }
                }

              }
            }
            //this._loaderService.hide();
          },
          (error) => this.handleError(error));
      }

    }
  }

  onCategoryChange(category) {
    this.selectedCategory = category;
    this.selectedCategoryId = category.CategoryId;
    this.selectedCategoryName = category.CategoryName;
    this.createdCategory = this.selectedCategoryName;
    this.CategoryName = category.CategoryName;
    this.selectModeType = 3;
    this.FavoriteType = this.selectModeType;
    if (this.redirectToCarrierFavoritesAdminFlag){
      if (this.selectedCategoryId) {
        this.searchRequest.CategoryId = this.selectedCategory.CategoryId;
        this.getCarrierFavoritesOnChange(this.selectedCategoryId);
      }
      else {
        this.selectedCategoryId = '';
        this.searchRequest.CategoryId = null;
        this.getCarrierFavoritesOnChange(this.selectedCategoryId);
      }
    }else{
      this.selectedAccount = this._clientService.getSelectedAccount();
      if (this.selectedAccount) {
        if (this.ClientId) {
          this.ClientId = this.selectedAccount.Id;
        }
        else {
          this.ClientId = '';
        }
        if (this.selectedCategoryId) {
          this.searchRequest.CategoryId = this.selectedCategory.CategoryId;
          this.getCarrierFavoritesOnChange(this.selectedCategoryId);
        }
        else {
          this.selectedCategoryId = '';
          this.searchRequest.CategoryId = null;
          this.getCarrierFavoritesOnChange(this.selectedCategoryId);
        }
      }
      else {
  
      }
    }
  }

  getCarrierFavoritesOnChange(selectedCategoryId) {
    this.isSuccess = false;
    this.isError = false;
    this.selectedAccount = this._clientService.getSelectedAccount();
    this.CategoryId = selectedCategoryId;
    this.groupallowed = true;
    // this._loaderService.show();
    this.FavoriteType = 3;
    if (this.redirectToCarrierFavoritesAdminFlag) {
      if (this.selectedAccount) {
        this.ClientId = this.selectedAccount.Id;
      } else {
        this.ClientId = '';
      }

      if (this.CategoryId != undefined && this.CategoryId != '' && this.CategoryId != null) {
        this._carrierSearchService.GetGroups(1, '', this.CategoryId)
          .subscribe((result) => {
            this.favorites = result;
            this.favorites.sort((a, b) => {
              if (a.GroupName.toLowerCase() < b.GroupName.toLowerCase())
                return -1;
              if (a.GroupName.toLowerCase() > b.GroupName.toLowerCase())
                return 1;

              return 0;

            })
            // this._loaderService.hide();
          },
          (error) => {
            this.handleError(error)
          });
      }
      else {
        this.CategoryId = '';
        this.searchRequest.CarrierFavoriteId = null;
        this._carrierSearchService.GetGroups(1, '', this.CategoryId)
          .subscribe((result) => {
            this.favorites = result;
            this.favorites.sort((a, b) => {
              if (a.GroupName.toLowerCase() < b.GroupName.toLowerCase())
                return -1;
              if (a.GroupName.toLowerCase() > b.GroupName.toLowerCase())
                return 1;

              return 0;

            })
            // this._loaderService.hide();
          },
          (error) => {
            this.handleError(error)
          });
      }
    } else {
      if (this.selectedAccount) {
        this.ClientId = this.selectedAccount.Id;
      } else {
        this.ClientId = '';
      }

      if (this.CategoryId != undefined && this.CategoryId != '' && this.CategoryId != null) {
        this._carrierSearchService.GetGroups(this.FavoriteType, this.ClientId, this.CategoryId)
          .subscribe((result) => {
            this.favorites = result;
            this.favorites.sort((a,b) => {
          if(a.GroupName.toLowerCase() < b.GroupName.toLowerCase())
          return -1;
          if(a.GroupName.toLowerCase() > b.GroupName.toLowerCase())
          return 1;
    
          return 0;
          
        })
        if(this.redirectToCarrierFavoritesAdminFlag || this.redirectToClientMaintenanceFlag || this.redirectToSearchFlag || this._clientService.getLicensed() || this._clientService.getLicenseState() || this._clientService.getOwnership()) {
          
        }else{
        if(this.localStorage.getItem('CarrierFavoriteName')) {
          var name=this.localStorage.getItem('CarrierFavoriteName');
          let index=this.favorites.findIndex(favorite=> favorite.GroupName==name);
          if(index!=-1){
            this.selectedGroup=this.favorites[index];
          }
        }
      }
            // this._loaderService.hide();
          },
          (error) => {
            this.handleError(error)
          });
      }
      else {
        this.CategoryId = '';
        this.searchRequest.CarrierFavoriteId = null;
        this._carrierSearchService.GetGroups(this.FavoriteType, this.ClientId, this.CategoryId)
          .subscribe((result) => {
            this.favorites = result;
            this.favorites.sort((a, b) => {
              if (a.GroupName.toLowerCase() < b.GroupName.toLowerCase())
                return -1;
              if (a.GroupName.toLowerCase() > b.GroupName.toLowerCase())
                return 1;

              return 0;

            })
            // this._loaderService.hide();
          },
          (error) => {
            this.handleError(error)
          });
      }
    }

  }

  onCarrierFavoriteChange(favorite) {
    if (favorite) {
      this.selectedGroup = favorite;
      this.searchRequest.CarrierFavoriteId = favorite.GroupId;
    } else {
      this.selectedGroup = null;
      this.searchRequest.CarrierFavoriteId = null;
    }

  }

  goUseInReports() {
    if (this.gridOptions.api.getSelectedRows().length > 0) {
      var carriers: any = this.gridOptions.api.getSelectedRows();
      this._clientService.setCarriersForReport(carriers);
      this._router.navigateByUrl('/useinreports');
    } else {
      this.warningMsg = 'Please select at least one carrier.'
      document.getElementById("noCarrier").click();
    }
  }

  checkStatus() {
    if (this.gridOptions.api.getSelectedRows().length > 0) {
      document.getElementById("fatcaCheck").click();
    } else {
      this.warningMsg = 'Please select at least one carrier.'
      document.getElementById("noCarrier").click();

    }
  }

  generateFatcaReport() {
    let selectedCarriers: Array<Carrier>;
    let carrierIds: Array<any> = new Array<any>();
    carrierIds = this.setSelectedCarriers();
    if (carrierIds != null && carrierIds != undefined) {
      this._carrierSearchService.getCarriersReport(this._carrierSearchService.getCarrierSearchReportsURL() + 'reportType=CarrierSearch|reportSubType=Fatca|exportReport=true|exportFormat=excel', carrierIds)
        .subscribe((result) => {
          var folderName = result;
          this._carrierSearchService.downloadReport(folderName);
        }, (error) => { });

    }
  }

  generateTobaReport(type: string) {
    let selectedCarriers: Array<Carrier>;
    let carrierIds: Array<any> = new Array<any>();
    carrierIds = this.setSelectedCarriers();
    if (carrierIds != null && carrierIds != undefined) {
      if (type == 'offline') {
        this._carrierSearchService.getCarriersReport(this._carrierSearchService.getCarrierSearchReportsURL() + 'reportType=CarrierSearch|reportSubType=Toba|exportReport=true|exportFormat=excel|processingMode=offline', carrierIds)
          .subscribe((result) => {
          }, (error) => { });
      }
      else {
        this._carrierSearchService.getCarriersReport(this._carrierSearchService.getCarrierSearchReportsURL() + 'reportType=CarrierSearch|reportSubType=Toba|exportReport=true|exportFormat=excel', carrierIds)
          .subscribe((result) => {
            var folderName = result;
            this._carrierSearchService.downloadReport(folderName);
          }, (error) => { });
      }
    }
  }

  generateExcelReport() {
    let selectedCarriers: Array<Carrier>;
    let carrierIds: Array<any> = new Array<any>();
    let account: Account = this._clientService.getSelectedAccount();
    carrierIds = this.setSelectedCarriers();
    if (carrierIds != null && carrierIds != undefined) {
      this._carrierSearchService.getCarriersExcelReport(this._carrierSearchService.getCarrierSearchReportsURL() + 'pIsWillisUser=' + this.isWillisUser + '|reportType=CarrierSearch|reportSubType=ExcelDownload|exportReport=true|exportFormat=excel', account.AccountId, carrierIds, )
        .subscribe((result) => {
          var folderName = result;
          this._carrierSearchService.downloadReport(folderName);
        }, (error) => { });
    }
  }

  generatePdfReport() {
    let selectedCarriers: Array<Carrier>;
    let carrierIds: Array<any> = new Array<any>();
    carrierIds = this.setSelectedCarriers();
    if (carrierIds != null && carrierIds != undefined) {
      this._carrierSearchService.getCarriersReport(this._carrierSearchService.getCarrierSearchReportsURL() + 'pIsWillisUser=' + this.isWillisUser + '|reportType=CarrierSearch|reportSubType=PdfDownload|exportReport=true|exportFormat=pdf', carrierIds)
        .subscribe((result) => {
          var folderName = result;
          this._carrierSearchService.downloadReport(folderName);
        }, (error) => { });
    }
  }

  generateApprovalStatusReport() {
    let selectedCarriers: Array<Carrier>;
    let carrierIds: Array<any> = new Array<any>();
    carrierIds = this.setSelectedCarriers();
    if (carrierIds != null && carrierIds != undefined) {
      this._carrierSearchService.getCarriersReport(this._carrierSearchService.getCarrierSearchReportsURL() + 'reportType=CarrierSearch|reportSubType=FullApprovalStatus|exportReport=true|exportFormat=pdf|processingMode=offline', carrierIds)
        .subscribe((result) => {
        }, (error) => { });
    }
  }

  setSelectedCarriers() {
    let selectedCarriers: Array<Carrier>;
    let carrierIds: Array<any> = new Array<any>();
    if (this.gridOptions.api) {
      if (this.gridOptions.api.getSelectedRows().length > 0) {
        selectedCarriers = this.gridOptions.api.getSelectedRows();
        selectedCarriers.forEach(item => carrierIds.push(item.CarrierNumberId));
        return carrierIds;
      } else {
        this.warningMsg = 'Please select at least one carrier.'
        document.getElementById("noCarrier").click();
      }
    }
  }

  openPdfReport() {
    if (this.gridOptions.api.getSelectedRows().length > 0) {
      if (this._loggedInUser.getUserRoleCode() !== "ClientRead") {
        document.getElementById("BtnClientReportPdfModal").click();
      }
      else {
        this.setWillisUser('Yes', 'Pdf');
      }
    } else {
      this.warningMsg = 'Please select at least one carrier.'
      document.getElementById("noCarrier").click();
    }

  }

  openExcelReport() {
    if (this.gridOptions.api.getSelectedRows().length > 0) {
      if (this._loggedInUser.getUserRoleCode() == "ClientRead") {
        this.isWillisUser = 0;
      }
      else {
        this.isWillisUser = 1;
      }
      this.printMessage = "Do not circulate this report outside of Willis Towers Watson. Please note application disclaimers at the end of this report. Disclaimers must not be removed from any report downloaded from the system. ";
      document.getElementById("exceldownload").click();
    } else {
      this.warningMsg = 'Please select at least one carrier.'
      document.getElementById("noCarrier").click();
    }

  }

  setWillisUser(willisUserIndicator: string, exportFormat: string) {
    if (willisUserIndicator == "Yes") {
      this.isWillisUser = 0;
    }
    else {
      this.isWillisUser = 1;
    }
    this.printMessage = 'Do not circulate this report outside of Willis Towers Watson. Please note application disclaimers at the end of this report. Disclaimers must not be removed from any report downloaded from the system.';
    document.getElementById("pdfModalBtn").click();
  }

  setSelectedCompanyCodes() {
    let selectedCarriers: Array<Carrier>;
    let companyCodes: Array<any> = new Array<any>();
    if (this.gridOptions.api) {
      if (this.gridOptions.api.getSelectedRows().length > 0) {
        selectedCarriers = this.gridOptions.api.getSelectedRows();
        selectedCarriers.forEach(item => companyCodes.push(item.WillisCode));
        return companyCodes;
      }
    }
  }

  printdetail() {
    if (this.gridOptions.api.getSelectedRows().length > 0) {
      if (this.gridOptions.api.getSelectedRows().length > 10 && this.gridOptions.api.getSelectedRows().length <= 50) {
        this.printMessage = 'The documents you have selected are too large to print on-line, they will be prepared off-line and placed in your client-side documents when complete. You may continue while this is carried out. NOTE: the result of any off-line prints will be overwritten. ';
        document.getElementById("printdetail").click();
      }
      else if (this.gridOptions.api.getSelectedRows().length > 50) {
        this.printMessage = 'A maximum of 50 carriers can be selected for the printing operation.';
        document.getElementById("printdetail2").click();
      } else
        this.generatePrintDetailReport();
    } else {
      this.warningMsg = 'Please select at least one carrier.'
      document.getElementById("noCarrier").click();
    }

  }

  generatePrintDetailReport() {
    this._loaderService.show();
    let companyCodes: Array<any> = new Array<any>();
    companyCodes = this.setSelectedCompanyCodes();
    if (companyCodes != null && companyCodes != undefined) {

      this._carrierSearchService.getPrintDetailReport(this._carrierSearchService.getCarrierSearchPrintDetailReportURL(), companyCodes, this.selectedAccount.AccountId, this.selectedAccount.PartyName)
        .subscribe((result) => {
          if (companyCodes.length <= 10) {
            var folderName = result;
            this._carrierSearchService.downloadReport(folderName);
          }          
        }, (error) => { });
    }
    this._loaderService.hide();
  }

  onApprovalStatus() {
    if (this.gridOptions.api.getSelectedRows().length > 0) {
      if (this.gridOptions.api.getSelectedRows().length <= 50 && this.gridOptions.api.getSelectedRows().length > 0) {

        this.printMessage = 'The information you have selected will be processed offline and sent to you via email. Do you wish to proceed?';
        document.getElementById("approvalbtn").click();
      }
      if (this.gridOptions.api.getSelectedRows().length > 50) {
        this.printMessage = 'A maximum of 50 carriers can be selected for the report.';
        document.getElementById("approvalbtn2").click();
      }
    } else {
      this.warningMsg = 'Please select at least one carrier.'
      document.getElementById("noCarrier").click();
    }
  }

  onFactsheetDownload() {
    if (this.gridOptions.api.getSelectedRows().length > 0) {

      if (this.gridOptions.api.getSelectedRows().length <= 50) {
        this.printMessage = 'The report you have selected is too large to be processed online, it will be prepared offline and e-mailed to you. Do you wish to proceed?';
        document.getElementById("factsheetBtn").click();
      }
      if (this.gridOptions.api.getSelectedRows().length > 50) {
        this.printMessage = 'A maximum of 50 carriers can be selected for the report.';
        document.getElementById("factsheetBtn2").click();
      }
    } else {
      this.warningMsg = 'Please select at least one carrier.'
      document.getElementById("noCarrier").click();
    }
  }

  onToba() {
    if (this.gridOptions.api.getSelectedRows().length > 0) {
      if (this.gridOptions.api.getSelectedRows().length <= 50) {
        this.printMessage = 'Do not circulate this report outside of Willis Towers Watson. Please note application disclaimers at the end of this report. Disclaimers must not be removed from any report downloaded from the system.';
        document.getElementById("tobaModalBtn").click();
      }
      if (this.gridOptions.api.getSelectedRows().length > 50) {
        this.printMessage = 'The report you have selected is too large to be prepared online. It will be prepared offline and emailed to you. Do you wish to proceed?';
        document.getElementById("tobaModalBtn2").click();
      }
    } else {
      this.warningMsg = 'Please select at least one carrier.'
      document.getElementById("noCarrier").click();
    }

  }

  redirectToReport() {
    this.modalFlag = true;
    if (this.gridOptions.api.getSelectedRows()) {
      this._clientService.setRedirectToSearch(false);
      let selectedReportCarriers: Array<Carrier>;
      if (this.gridOptions.api) {
        if (this.gridOptions.api.getSelectedRows().length > 0) {
          selectedReportCarriers = this.gridOptions.api.getSelectedRows();
          this._clientService.setCarriersReport(selectedReportCarriers);
          this._clientService.setReportDate(this.dateOne, this.dateTwo);
          this._clientService.setRedirectToReport(this.modalFlag);
          this._clientService.setRedirectFromAdmin(false);
          this._router.navigateByUrl('/comparative-report');
        } else {
          this.warningMsg = 'Please select at least one carrier.'
          document.getElementById("noCarrier").click();
        }
      } else {
      }
    }
  }

  checkSearchFlag() {
    if (this._clientService.getRedirectToSearch()) {
      this.redirectToSearchFlag = this._clientService.getRedirectToSearch();
      console.log(this.redirectToSearchFlag + "  from reports");
    }
    else {
      this.redirectToSearchFlag = false;
      console.log(this.redirectToSearchFlag + "not from reports");
    }
  }

  generateFactSheetReport() {
    let companyCodes: Array<any> = new Array<any>();
    companyCodes = this.setSelectedCompanyCodes();
    if (companyCodes != null && companyCodes != undefined) {
      this._carrierSearchService.getFactsheetReport(this._carrierSearchService.getFactsheetReportURL(), companyCodes)
        .subscribe((result) => {
          //this.reportUrl = this._sanitizer.bypassSecurityTrustResourceUrl(this._settings.getReportsUrl() + result.substring(4));
        }, (error) => { });
    }
  }

}
