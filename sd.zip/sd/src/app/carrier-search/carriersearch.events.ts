import { Injectable, EventEmitter } from '@angular/core';

@Injectable()
export class CarrierSearchEvents {
    sortNullEvent: EventEmitter<any> = new EventEmitter();
    sortAscEvent: EventEmitter<any> = new EventEmitter();
    sortDescEvent: EventEmitter<any> = new EventEmitter();
}