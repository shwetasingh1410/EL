import { IPageAccessLevels } from '../shared/page-access-levels/page-access-levels'

export class CarrierSearchAccessLevels implements IPageAccessLevels {
    isApprovalStatusAvailable: boolean = false;
    isBusinessUnitAvailable: boolean = false;
    isQualifierAvailable: boolean = false;
    isOperatingCategoryAvailable: boolean = false;
    isRestrictionAvailable: boolean = false;
    isTobaDropdownAvailable: boolean = false;
    isLegalEntityAvailable: boolean = false;
    isDownloadApprovalStatusAvailable: boolean = false;
    isTOBAStatusHeaderAvailable: boolean = false;
    
}