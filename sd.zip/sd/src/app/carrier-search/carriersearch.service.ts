﻿import { Injectable } from '@angular/core';
import { Http,RequestOptions, Headers, URLSearchParams } from '@angular/http';
import { Observable } from 'rxjs/Rx';
import { serializeUrlParams } from '../shared/http/http.factory';
import { Settings } from '../shared/settings/settings.service';
import {
    Account,ApprovalStatus, BusinessUnit, CompanyType, Country, LegalEntity, LicenceType,
    OperatingCategory, Ownership, Qualifier, Restriction, State, LicenseState, RatingAgency, RatingAgencyScale,
    SearchRequest, Carrier,Category, FavoriteGroup
} from './carriersearch.model';
import { CarrierSearchHelper } from './carriersearch.helper';
import { LoggedInUser } from '../shared/loggedInUser/LoggedInUser';

@Injectable()
export class CarrierSearchService {
    constructor(private _http: Http, private _settings: Settings, private _loggedInUser: LoggedInUser) { }

    getAccounts(role: string, userId : string): Observable<Array<Account>> {
        if (role == 'SuperAdmin') {
            return this._http.get(this._settings.getApiUrl() + 'api/accounts/active')
                .map((response) => this.getAccountsHandler(response.json()));
        }
        else if (role == 'MSDBUAdmin' || role == 'MSDAdmin') {
            return this._http.get(this._settings.getApiUrl() + 'api/accounts/active/role-based')
                .map((response) => this.getAccountsHandler(response.json()));
        }
        else {
            return this._http.get(this._settings.getApiUrl() + 'api/users/' + userId +'/accounts')
                .map((response) => this.getAccountsHandler(response.json()));
        }
    }

    getAccountsHandler(response) {
        let result: Array<Account> = new Array<Account>();
        response.forEach(account => {
            result.push(CarrierSearchHelper.mapToAccount(account));
        });
        return result;
    }
   
       
    
        GetGroups(FavoriteType : number,ClientId : string,CategoryId : string): Observable<Array<FavoriteGroup>> {
            return this._http.get(this._settings.getApiUrl() + 'api/favorites/groups?FavoriteType='+FavoriteType+'&AccountId='+ClientId+'&CategoryId='+CategoryId)
            .map((response) => {
               let result: Array<FavoriteGroup> = new Array<FavoriteGroup>();
                response.json().forEach((group) => {
                    result.push(CarrierSearchHelper.mapToGroupInfo(group))
                });
                return result;
            });
        }
    
        GetCategories(CategoryType : number,ClientId : string): Observable<Array<Category>> {
            return this._http.get(this._settings.getApiUrl() + 'api/favorites/categories?FavoriteType='+CategoryType+'&AccountId='+ClientId)
            .map((response) => {
                let result: Array<Category> = new Array<Category>();
                response.json().forEach((category) => {
                    result.push(CarrierSearchHelper.mapToCategoryHelper(category))
                });
                return result;
            });
        }
    getCountries() {
        return this._http.get(this._settings.getApiUrl() + 'api/countries')
            .map((response) => this.getCountriesHandler(response.json()));
    }

    getCountriesHandler(response) {
        let result: Array<Country> = new Array<Country>();
        response.forEach((country) => {
            result.push(CarrierSearchHelper.mapToCountry(country))
        });
        return result;
    }

    getStates(countryId: string) {
        return this._http.get(this._settings.getApiUrl() + 'api/countries/' + countryId + '/states')
            .map((response) => this.getStatesHandler(response.json()));
    }

    getStatesHandler(response) {
        let result: Array<State> = new Array<State>();
        response.forEach((state) => {
            result.push(CarrierSearchHelper.mapToState(state))
        });
        return result;
    }

    getApprovalStatus() {
        return this._http.get(this._settings.getApiUrl() + 'api/reference-data/approval-status')
            .map((response) => this.getApprovalStatusHandler(response));
    }

    getApprovalStatusHandler(response) {
        let result: Array<ApprovalStatus> = new Array<ApprovalStatus>();
        JSON.parse(response).forEach((approvalStatus) => {
            result.push(CarrierSearchHelper.mapToApprovalStatus(approvalStatus))
        });
        return result;
    }

    getOwnerships() {
        return this._http.get(this._settings.getApiUrl() + 'api/reference-data/ownership')
            .map((response) => this.getOwnershipsHandler(response));
    }

    getOwnershipsHandler(response) {
        let result: Array<Ownership> = new Array<Ownership>();
        JSON.parse(response).forEach((ownership) => {
            result.push(CarrierSearchHelper.mapToOwnership(ownership))
        });
        return result;

    }


    getCompanyTypesHandler(response) {
        let result: Array<CompanyType> = new Array<CompanyType>();
        JSON.parse(response).forEach((companyType) => {
            result.push(CarrierSearchHelper.mapToCompanyType(companyType))
        });
        return result;
    }


    getBusinessUnitsHandler(response) {
        let result: Array<BusinessUnit> = new Array<BusinessUnit>();
        JSON.parse(response).forEach((businessUnit) => {
            result.push(CarrierSearchHelper.mapToBusinessUnit(businessUnit))
        });
        return result;
    }


    getQualifiersHandler(response) {
        let result: Array<Qualifier> = new Array<Qualifier>();
        JSON.parse(response).forEach((qualifier) => {
            result.push(CarrierSearchHelper.mapToQualifier(qualifier))
        });
        return result;
    }

    getOperatingCategoriesHandler(response) {
        let result: Array<OperatingCategory> = new Array<OperatingCategory>();
        JSON.parse(response).forEach((operatingCategory) => {
            result.push(CarrierSearchHelper.mapToOperatingCategory(operatingCategory))
        });
        return result;
    }

    getRestrictionsHandler(response) {
        let result: Array<Restriction> = new Array<Restriction>();
        JSON.parse(response).forEach((restriction) => {
            result.push(CarrierSearchHelper.mapToRestriction(restriction))
        });
        return result;
    }   

    getLegalEntitiesHandler(response) {
        let result: Array<LegalEntity> = new Array<LegalEntity>();
        JSON.parse(response).forEach((legalEntity) => {
            result.push(CarrierSearchHelper.mapToLegalEntity(legalEntity))
        });
        return result;
    }

    getReferenceData() {
        return this._http.get(this._settings.getApiUrl() + 'api/reference-data/all')
            .map((response) => {
                return response.json();
            });
    }
    
    getRatingAgencies() {
        return this._http.get(this._settings.getApiUrl() + 'api/rating-agencies')
            .map((response) => this.getRatingAgenciesHandler(response));
    }

    getRatingAgenciesHandler(response) {
        let result: Array<RatingAgency> = new Array<RatingAgency>();
        response.json().forEach((ratingAgency) => {
            result.push(CarrierSearchHelper.mapToRatingAgency(ratingAgency))
        });
        return result;
    }

    getLicenceCountries() {
        return this._http.get(this._settings.getApiUrl() + 'api/licenses/countries')
            .map((response) => this.getLicenceCountriesHandler(response));
    }

    getLicenceCountriesHandler(response) {
        let result: Array<Country> = new Array<Country>();
        response.json().forEach((country) => {
            result.push(CarrierSearchHelper.mapToCountry(country))
        });
        return result;
    }


    getLicenceStates(countryId: string) {
        return this._http.get(this._settings.getApiUrl() + 'api/licenses/countries/' + countryId + '/states')
            .map((response) => this.getLicenceStatesHandler(response));
    }

    getLicenceStatesHandler(response) {
        let result: Array<LicenseState> = new Array<LicenseState>();
        response.json().forEach((state) => {
            result.push(CarrierSearchHelper.mapToLicenseState(state))
        });
        return result;
    }

    getLicenceTypes(countryId: string) {
        return this._http.get(this._settings.getApiUrl() + 'api/licenses/countries/' + countryId + '/types')
            .map((response) =>
                this.getLicenceTypesHandler(response));
    }

    getLicenceTypesHandler(response) {
        let result: Array<LicenceType> = new Array<LicenceType>();
        response.json().forEach((licenceType) => {
            result.push(CarrierSearchHelper.mapToLicenceType(licenceType))
        });
        return result;
    }

    // get Rating Agencies
    getRatingAgencyScales(ratingAgencyId: string) {
        return this._http.get(this._settings.getApiUrl() + 'api/rating-agencies/' + ratingAgencyId + '/rating-scales')
            .map((response) => this.getRatingAgencyScalesHandler(response));
    }

    getRatingAgencyScalesHandler(response) {
        let result: Array<RatingAgencyScale> = new Array<RatingAgencyScale>();
        response.json().forEach((ratingAgencyScale) => {
            result.push(CarrierSearchHelper.mapToRatingAgencyScale(ratingAgencyScale))
        });
        return result;
    }

    // get Search Result
    getSearchResult(searchRequest: SearchRequest) {
        let params: URLSearchParams = new URLSearchParams();
        for (let key in searchRequest) {
            if (searchRequest.hasOwnProperty(key)) {
                let value = searchRequest[key];
                if (key == "ClientId" || key == "CarrierFavoriteId" || key == "CategoryId" || key == "CountryId"
                    || key == "LicenseCountryId" || key == "RatingAgencyId")
                    params.set(key, value);
                else 
                    params.set(key, encodeURIComponent(value));                
            }
        }

        return this._http.get(this._settings.getApiUrl() + 'api/carriers?' + params.toString())
            .map((response) => this.getSearchResultHandler(response));
    }

    getSearchResultHandler(response) {
        let result: Array<Carrier> = new Array<Carrier>();
        response.json().forEach((carrier) => {
            result.push(CarrierSearchHelper.mapToCarrier(carrier))
        });
        return result;
    }

    getCarriersReport(url: string, carrier: Array<Carrier>) {
        return this._http.post(url,
            JSON.stringify({ 'CarrierId': carrier, 'UserId': this._loggedInUser.getUserId() }))
            .map((response) => { return response.json(); });
    }

    getCarriersExcelReport(url: string, AccountId:string,carrier: Array<Carrier>) {
        return this._http.post(url,
            JSON.stringify({ 'CarrierId': carrier, 'UserId': this._loggedInUser.getUserId(), 'AccountId': AccountId }))
            .map((response) => { return response.json(); });
    }

    getFatcaReport(url: string, carrier: Array<Carrier>) {
        return this._http.post(url,
            JSON.stringify({ 'CarrierId': carrier, 'UserId': this._loggedInUser.getUserId() }))
            .map((response) => { return response.json()});
    }

    getCarrierSearchReportsURL() {
        return this._settings.getReportsUrl() + 'reports/carrier/params/'
    } 

    getCarrierSearchPrintDetailReportURL() {
        return this._settings.getReportsUrl() + 'reports/carrier/print-detail/'
    } 

    getPrintDetailReport(url: string, companyCodes: Array<number>, clientId: string, clientName: string) {
        return this._http.post(url,
            JSON.stringify({
                'CompanyCode': companyCodes, 'UserId': this._loggedInUser.getUserId(), 'ClientId': clientId, 'ClientName': clientName }))
            .map((response) => { return response.json(); });
    }

    downloadReport(folderName : string) {
        window.open(this._settings.getReportsUrl() + 'reports/carrier/download-file/'+folderName);
    }     

    getFactsheetReport(url: string, companyCode: Array<string>) {
        return this._http.post(url,
            JSON.stringify({
                'CompanyCode': companyCode, 'UserId': this._loggedInUser.getUserId()}))
            .map((response) => { return response.json(); });
    }

    getFactsheetReportURL() {
        return this._settings.getReportsUrl() + 'reports/carrier/financial-factsheet/'
    }     
}


