﻿import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { ClientService } from '../../select-client/client.service';
import {
  ApprovalStatus, BusinessUnit, CompanyType, Country, LegalEntity, LicenceType,
  OperatingCategory, Ownership, Qualifier, Restriction, State, Carrier, SearchRequest, RatingAgency,
  RatingAgencyScale
} from '.././carriersearch.model';
import { LoggedInUser } from '../../shared/loggedInUser/LoggedInUser';
import { CoolSessionStorage } from 'angular2-cool-storage';
import {
  CarrierSearchService
} from '.././carriersearch.service';
import { AppEvents } from '../../app.events';

@Component({
  selector: 'app-link-component',
  templateUrl: './link-component.component.html',
  styleUrls: ['./link-component.component.css']
})
export class LinkComponent implements OnInit {

  private params: any;
  value: string;
  clientId;
  carrierId;
  code;
  localStorage: CoolSessionStorage;
  willisCode: any;
  agInit(params: any): void {
    this.params = params;

  }
  constructor(private _carrierSearchService: CarrierSearchService, private _router: Router, private _route: ActivatedRoute, private _clientService: ClientService,
      private _loggedInUser: LoggedInUser, localStorage: CoolSessionStorage, private _appEvents: AppEvents) {
    this.localStorage=localStorage;
   }

  ngOnInit() {
    this.value = this.params.value;
  }


  navigatetodetail() {
    let tabName: string;
    let carriers: Array<Carrier> = new Array<Carrier>();
    carriers.push(this.params.data);
    this._clientService.setCarrierObject(carriers[0]);
    this.localStorage.setObject('carriers',carriers[0]);
    this.willisCode = carriers[0].WillisCode;

    this._appEvents.AddRecentlyViewedCarrierEvent.emit(carriers[0]);

    if (this._loggedInUser.getUserRoleCode() != "ClientRead") {
      tabName = "general";
    }
    else {
      tabName = "summary";
    }

    var cId: any = this.localStorage.getObject('account');
    this.clientId = cId.AccountId;
    this.carrierId = carriers[0].CarrierId;
    this.code = carriers[0].WillisCode;
    var code = 'code';
    var carrier = 'carrier';
    var client = 'client';
    this._router.navigate(['carrier-detail', client, this.clientId, carrier, this.carrierId, code, this.code, tabName]);
  } 
}
