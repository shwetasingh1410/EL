import { IPageAccessLevels } from './shared/page-access-levels/page-access-levels'

export class MsHomeAccessLevels implements IPageAccessLevels {
    IsAdminHomeAvailable: boolean = false;
    IsAddEditUserAvailable: boolean = false;
    IsCarrierFavouritesAvailable: boolean = false;
    IsClientMaintenanceAvailable: boolean = false;
    IsHomePageAdminAvailable: boolean = false;
    IsAnnouncementsAvailable: boolean = false;
    IsRatingScalesAvailable: boolean = false;
    IsDocumentFoldersAvailable: boolean = false;
    IsDocumentAccessAvailable: boolean = false;
    IsDisclaimersAvailable: boolean = false;
    IsTermsOfUseAvailable: boolean = false;
    IsLibraryAvailable: boolean = false;
    IsSuperUserAdminAvailable: boolean = false;
    IsWillisReaderReportsAvailable: boolean = false;
    IsReportsAvailable: boolean = false;
    IsMsgFilesAvailable: boolean = false;
    IsManageLibraryAvailable: boolean = false;
    
}


export class HomeAccessLevels implements IPageAccessLevels {
    IsDocumentSearchAvailable: boolean= false;
    IsRelatedLinksAccessAvailable: boolean= false;
    IsLibraryAccessAvailable: boolean= false;
    
    
    
    
   
}