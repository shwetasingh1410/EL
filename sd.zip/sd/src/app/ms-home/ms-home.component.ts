import { Component, OnInit } from '@angular/core';
import { TranslateService } from '../translate/translate.service';

@Component({
  selector: 'app-ms-home',
  templateUrl: './ms-home.component.html',
  styleUrls: ['./ms-home.component.css']
})
export class MsHomeComponent implements OnInit {

  constructor(private _translate: TranslateService) { }

  ngOnInit() {
        this.selectLang('en');
      }
    
      selectLang(lang: string) {
        this._translate.use(lang);
      }

}
