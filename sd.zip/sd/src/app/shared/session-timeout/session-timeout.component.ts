﻿import { Component, OnInit } from '@angular/core';
import { Http, RequestOptions, RequestOptionsArgs, Headers } from '@angular/http'
import { AuthService } from '../loggedInUser/auth.service';
import { Settings } from '../settings/settings.service';

@Component({
    selector: 'session-timeout',
    templateUrl: './session-timeout.component.html',
    styleUrls: ['./session-timeout.component.css']
})

export class SessionTimeoutComponent implements OnInit {

    constructor(private _settingsService: Settings, private _authService: AuthService, private _http: Http) {
        this._authService.signOut();
    }

    ngOnInit() {
        this._authService.signOut().subscribe((res) => {
            this.signOut();
        }, (error) => {
            this.signOut();
        });
    }

    private signOut(){
        let headers = new Headers();
        let options = new RequestOptions({ headers: headers, withCredentials: true });
        options.headers.append("sign-out", "sign-out");

        this._http.post(this._settingsService.getHostUrl() + "/session-expired", {}, options)
            .subscribe((response)=>{
                var details = response.json();
                window.location.href = details.logoutUrl;
                console.log('Sign out complete...')
            });
    }
}