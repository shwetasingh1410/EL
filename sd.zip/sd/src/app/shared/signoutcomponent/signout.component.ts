﻿import { Component, Inject, ViewChild, ElementRef, AfterViewInit, OnDestroy, OnInit, SecurityContext, NgZone } from '@angular/core';
import { Router } from '@angular/router';
import { Http, RequestOptions, Headers } from '@angular/http';
// import { RequestOptions } from '@angular/http/src/base_request_options';
import { Settings } from '../settings/settings.service';
import { AuthService } from '../loggedInUser/auth.service';

@Component({
    selector: 'app-signout',
    templateUrl: './signout.component.html',
    styleUrls: ['./signout.component.css']
})
export class SignOutComponent implements OnInit {

    constructor(private _authService: AuthService, private zone: NgZone, private _router: Router
        , private _settingsService: Settings, private _http: Http) {
        window['signOutComponent'] = {
            zone: this.zone,
            componentFn: () => this.signOutUser(),
            component: this,
        };
    }

    ngOnInit(): void {
        
    }

    signOutUser() {
        this._authService.signOut().subscribe((res) => {
            this.signOut();
        }, (error) => {
            this.signOut();
        });
    }

    private signOut(){
        let headers = new Headers();
        let options = new RequestOptions({ headers: headers, withCredentials: true });
        options.headers.append("X-XSRF-TOKEN", "sign-out");

        this._http.post(this._settingsService.getHostUrl() + "/log-out", {}, options)
            .subscribe((response)=>{
                var details = response.json();
                window.location.href = details.logoutUrl;
                console.log('Sign out complete...')
            });
    }
}