﻿export interface pageAccessLevel {
    isApprovalStatusAvailable: boolean;
    isBusinessUnitAvailable: boolean;
    isQualifierAvailable: boolean;
    isOperatingCategoryAvailable: boolean;
    isRestrictionAvailable: boolean;
    isTobaDropdownAvailable: boolean;
    isLegalEntityAvailable: boolean;
    

   
}