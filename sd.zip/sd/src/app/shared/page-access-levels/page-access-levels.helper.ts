import { Injectable } from '@angular/core';

import { PageAccessService } from '../../shared/page-access-levels/page-access-levels.service';
import { IPageAccessLevels } from '../../shared/page-access-levels/page-access-levels';

@Injectable()
export class PageAccessHelper{
    constructor(private _pageAccessService : PageAccessService){

    }

    getPageAccessLevelsDetails(pageName : string, pageAccessLevels : IPageAccessLevels) {
        this._pageAccessService.getPageAccessLevelsDetails(pageName).subscribe(result => {

            var allFeaturesAvailable = result.length == 0;

            for (var key in pageAccessLevels) {
                pageAccessLevels[key] = allFeaturesAvailable
                    || !(result.filter(c => c.Feature == key && c.DenyAction == "hide").length > 0);
            }

        }, (error) => {

        });
    }
}