export interface IPageAccessLevels { 

}