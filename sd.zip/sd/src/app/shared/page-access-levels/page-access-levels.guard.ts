﻿import { Injectable,Inject } from '@angular/core';
import { CanActivate, CanActivateChild, ActivatedRouteSnapshot, RouterStateSnapshot, Router } from '@angular/router';
import { Observable } from 'rxjs/Rx';
import { PageAccessService } from '../../shared/page-access-levels/page-access-levels.service';
import { Settings } from '../settings/settings.service';
import { Storage } from '../storage/storage.service';
@Injectable()
export class PageAccessAuthGuard implements CanActivate {

    constructor(private _router: Router, private _pageAccessService: PageAccessService, private _Settings: Settings
        , private _storage: Storage) { }


    public canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot)
        : boolean | Observable<boolean> | Promise<boolean> {
        let accepted = this._storage.getItem("isTermsOfUseAccepted");
        if (accepted !== "true") // && route.url[0].path !== "select-client")
        {
            var element = document.getElementById("BtnClosemodal");
            if (typeof (element) != 'undefined' && element != null) {
                document.getElementById("BtnClosemodal").click();
            }
            
            this._router.navigate(['/termsofuseError']);
            return false;
        }

        if (state.url.endsWith(route.url[0].path)) {
            this.checkPageAccessUser(route.url[0].path);
        }
        return true;

    }

    checkPageAccessUser(url: string) {
        var urlName = url;
        this._pageAccessService.getPageAcessDetails(urlName).subscribe(result => {
            if (result === false) {
                if (urlName === 'msHome') {
                    this._router.navigate(['/home']);
                    return false;
                }
                if (urlName === 'superuseradmin') {
                    this._router.navigate(['/msHome']);
                    return false;
                }
                if (urlName === 'termsofuseError') {
                    this._router.navigate(['/termsofuseError']);
                    return false;
                }
                else {
                    this._router.navigate(['/forbidden']);
                    return false;
                }

            }

            if (result === true && urlName === 'related-links') {
                window.open(this._Settings.getRelatedLinksUrl(), "_blank");
              
            }
            if (result === true && urlName === 'doc-library') {
                window.open(this._Settings.getLibraryUrl(), "_blank");
                
            }
           
            if (result === true && urlName === 'manage-library') {
                window.open(this._Settings.getManageLibraryUrl(), "_blank");
                
            }
            if (result === true && urlName === 'document-search') {
                window.open(this._Settings.getDocumentSearchUrl(), "_blank");
                
            }

        });




    }

}



