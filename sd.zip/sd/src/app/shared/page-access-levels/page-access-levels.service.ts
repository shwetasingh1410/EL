﻿import { Injectable } from '@angular/core';
import { Http, RequestOptions, Headers } from '@angular/http'

import { AccessLevel } from '../../shared/page-access-levels/page-access-levels.model';
import { Settings } from '../settings/settings.service';

import { LoggedInUser } from '../../shared/loggedInUser/LoggedInUser';
import { Observable } from 'rxjs/Rx';

@Injectable()
export class PageAccessService {
  constructor(private _http: Http, private _settings: Settings, private _loggedInUser: LoggedInUser) {

  }
  
  getPageAccessLevelsDetails(pageName: string) : Observable<AccessLevel[]> {
    let headers = new Headers();
    headers.append('Content-Type', 'application/json');
    let options = new RequestOptions({ headers: headers });
    return this._http.post(this._settings.getHostUrl() + '/api/page-access/' + pageName +'/accesslevels',
      JSON.stringify({
        'Role': this._loggedInUser.getUserRoleCode()
      }), options)
      .map(response => {
        return response.json() as AccessLevel[];
      });
  }


  getPageAcessDetails(pageName: string) {
    let headers = new Headers();
    headers.append('Content-Type', 'application/json');
    let options = new RequestOptions({ headers: headers });
    return this._http.post(this._settings.getHostUrl() + '/api/page-access/' + pageName,
      JSON.stringify({
        'Role': this._loggedInUser.getUserRoleCode()
      }), options) .map(response => {
        return response.json() as boolean;
      });
      
  }






}
