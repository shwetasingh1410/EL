﻿import { Injectable, Injector } from '@angular/core';
import { Http } from '@angular/http';
import { Observable } from 'rxjs/Rx';

import { Storage } from '../storage/storage.service';

@Injectable()
export class Settings {
  private hostUrl : string;
    private apiUrl: string;
    private reportsUrl: string;
    private summaryUrl: string;
    private formAMGraphUrl : string;
    private formSnPGraphUrl : string;
    
    
    constructor(private _http: Http, private _storage: Storage) {
        this.hostUrl= location.protocol + "//" + location.hostname + ':' + location.port;
    }

    getSettings(): Promise<boolean> {
        // call API Contoller
        return new Promise<boolean>((resolve, reject) => {
          this._http.get('api/configs')
            .map((result) => result.json())
              .subscribe((result) => {
                  console.log(result.WebApiUrl);
              this._storage.setItem("apiUrl", result.WebApiUrl);
              this._storage.setItem("documentapiUrl", result.DocumentWebApiUrl);
              this._storage.setItem("reportsUrl", result.ReportUrl);
              this._storage.setItem("accessToken", result.AccessToken);   
              this._storage.setItem("summaryUrl", result.ReportUrl);   
              this._storage.setItem("formSnPGraphUrl", result.ReportUrl);   
              this._storage.setItem("formAMGraphUrl", result.ReportUrl);
              this._storage.setItem("relatedLinksUrl", result.RelatedLinksUrl);
              this._storage.setItem("libraryUrl", result.LibraryUrl);
              this._storage.setItem("privacyPolicyUrl", result.PrivacyPolicyUrl);   
              this._storage.setItem("contactUsUrl", result.ContactUsUrl);   
              this._storage.setItem("manageLibraryUrl", result.ManageLibraryUrl);   
              this._storage.setItem("documentSearchUrl", result.DocumentSearchUrl);   
              this._storage.setItem("homecontactUsUrl", result.HomeContactUsUrl);
              this._storage.setItem("licensesUrl", result.LicensesUrl);   
                resolve(true);
              },
              (error) => {
                reject(true);
              });
        });
    }
    getHostUrl(): string {
      return this.hostUrl;
    }
    getApiUrl(): string {
      return this._storage.getItem("apiUrl");
    }

    getDocumentApiUrl(): string {
      return this._storage.getItem("documentapiUrl");
    }

    getReportsUrl() {
      return this._storage.getItem("reportsUrl");
    }
    getSummaryUrl() {
      return this._storage.getItem("summaryUrl");
    }
    getFormAMGraphUrl(){
      return this._storage.getItem("formSnPGraphUrl");
    }
    getFormSnPGraphUrl(){
      return this._storage.getItem("formAMGraphUrl");
    }
    getRelatedLinksUrl(){
      return this._storage.getItem("relatedLinksUrl");
    }
    getLibraryUrl(){
      return this._storage.getItem("libraryUrl");
    }
    getPrivacyPolicyUrl(){
      return this._storage.getItem("privacyPolicyUrl");
    }
    getContactUsUrl(){
      return this._storage.getItem("contactUsUrl");
    }
    getManageLibraryUrl(){
      return this._storage.getItem("manageLibraryUrl");
    }
    getDocumentSearchUrl(){
      return this._storage.getItem("documentSearchUrl");
    }
    getHomeContactUsUrl(){
      return this._storage.getItem("homecontactUsUrl");
    }

    getLicensesUrl(){
      return this._storage.getItem("licensesUrl");
    }

    getDevSettings() {
        this.apiUrl = (<any>window).apiUrl;
        this.reportsUrl = (<any>window).reportsUrl;
        this.summaryUrl = (<any>window).summaryUrl;
        this.formAMGraphUrl = (<any>window).formAMGraphUrl;
        this.formSnPGraphUrl = (<any>window).formSnPGraphUrl;
    }
}


export function SettingsFactory(settings: Settings) {
    return () => settings.getSettings();
}
