﻿import { ErrorHandler, Injectable, Injector } from '@angular/core';
import { Router } from '@angular/router';

@Injectable()
export  class  GlobalErrorHandler  implements  ErrorHandler  {
    constructor(private  _injector:  Injector) { }

    handleError(error) {
        console.log(error);
        let router = this._injector.get(Router);

        if (error.message == "SessionExpired" || error == "SessionExpired") {
            router.navigate(['./session-timeout']);
        }
        else if (error.message == "UnAuthorized" || error == "UnAuthorized") {
            router.navigate(['./unauthorised']);
        }
        else {
            console.log(error);
        }
    }
}