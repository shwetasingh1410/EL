﻿import { Injectable } from '@angular/core';
import { Http } from '@angular/http'

import { Role } from '../../edit-user/edituser.model';
import { Settings } from '../settings/settings.service';
import { Storage } from '../storage/storage.service';
import { Observable } from 'rxjs/Observable';
import { CoolSessionStorage } from 'angular2-cool-storage';
// import { window } from 'rxjs/operator/window';


@Injectable()
export class AuthService {
  
  private _isUserLoggedIn: Boolean;
  private _error: Error;

  constructor(private _http: Http, private _settings: Settings, private _storage: Storage,private localStorage:CoolSessionStorage) {
    //this.getUser();
  }

  signIn(): Promise<Boolean> {
    return new Promise<Boolean>((resolve, reject) => {
      this._settings.getSettings().then(response => {
        this._http.get(this._settings.getApiUrl() + 'api/auth/user')
          .subscribe((response) => {
            let user = response.json();
            var headers = response.headers;

            this._storage.setItem("userId", user.UserId);
            this._storage.setItem("userPrincipalId", user.UserPrincipalId);
            this._storage.setItem("roleId", user.RoleId);
            this._storage.setItem("roleCode", user.RoleCode);
            this._storage.setItem("roleDescription", user.RoleDescription);
            this._storage.setItem("rank", user.Rank);
            this._storage.setItem("userLatestTermsOfUseId", user.userLatestTermsOfUseId);
            this._storage.setItem("latestTermsOfUseId", user.latestTermsOfUseId);
            this._storage.setItem("apiAccessToken", headers.get('WebApi.AccessLevels'));
            this._storage.setItem("encryptedUserId", user.EncryptedUserId); 
            this._storage.setItem("autoProvisionedUser", user.autoProvisionedUser); 

            this._isUserLoggedIn = true;
            resolve(true);

          }, (error) => {
            this._isUserLoggedIn=false;
            this._error=error;
            resolve(false);
          })
      })
    });
  }

  signInComplete(){
    if(this._error)
    throw this._error;
  }

  signOut() {
    this.localStorage.clear();
    this._storage.clear();
      return Observable.forkJoin([
          this._http.get(this._settings.getApiUrl() + 'api/auth/logout'),
          this._http.get(this._settings.getReportsUrl() + 'sign-out')
        ]);
  }

  isUserLoggedIn(){
    return this._isUserLoggedIn;
  }
}

export function AuthServiceFactory(authService: AuthService) {
  return () => authService.signIn();
}