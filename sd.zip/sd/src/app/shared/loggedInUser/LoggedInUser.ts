﻿import { Injectable } from '@angular/core';
import { Http } from '@angular/http'

import { Role } from '../../edit-user/edituser.model';
import { Settings } from '../settings/settings.service';
import { Storage } from '../storage/storage.service';
import { SessionService } from '../user-attempt/user-attempt-session.service';

@Injectable()
export class LoggedInUser {
    UserPrincipalId: string;
    UserId: string;
    UserRole: Role;
    constructor(private _http: Http, private _settings: Settings, private _storage: Storage, private _sessionService: SessionService) {        
        //this.getUser();
    }
    
    redirectToOnePlace(){
        location.replace('https://qaoneplace.ehr.com/');
    }

    getUser() {
        this._http.get(this._settings.getApiUrl() + 'api/auth/user')
            .subscribe((response) => {
                let user = response.json();
                this.UserRole = new Role(user.RoleId, user.RoleCode, user.RoleDescription, user.Rank);
                this.UserId = user.UserId;
                this.UserPrincipalId = user.UserPrincipalId;                
            });
    }

    getRole() {
        if (this.UserRole == null) {
            this.UserRole = new Role(
                this._storage.getItem("roleId"), this._storage.getItem("roleCode")
                , this._storage.getItem("roleDescription"), this._storage.getItem("rank"));
        }

        return this.UserRole;
    }

    getUserId() {
        return this._storage.getItem("userId");
    }

    getUserPrinicpalId() {
        return this._storage.getItem("principalId");
    }
    
    getUserRoleCode() {
        return this._storage.getItem("roleCode"); 
    }

    getEncryptedUserId() {
        return this._storage.getItem("encryptedUserId");
    }
    getUserLatestTermsOfUseId() {
        return this._storage.getItem("userLatestTermsOfUseId");
    }
    getLatestTermsOfUseId() {
        return this._storage.getItem("latestTermsOfUseId");
    }
   
    getAutoProvisionedUserFlag() {
        return this._storage.getItem("autoProvisionedUser");
    }

    logout() {
    this._http.get(this._settings.getApiUrl() + 'api/auth/logout')
      .subscribe((response) => {
        this._sessionService.setsession(1);
      this.redirectToOnePlace();
                // TODO : redirect to oneplace
      });
  }
}