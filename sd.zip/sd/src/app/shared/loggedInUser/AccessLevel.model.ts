﻿export class AccessLevel {
    Feature: string;
    DenyAction: string;

    constructor(Feature: string, DenyAction: string) {
        this.Feature = Feature;
        this.DenyAction = DenyAction;
    }
}