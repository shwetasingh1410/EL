﻿import { Injectable, Injector  } from '@angular/core';
import {
    ConnectionBackend, RequestOptions, Headers, Request, RequestOptionsArgs,
    Response, XHRBackend, Http, URLSearchParams
} from '@angular/http';
import { Observable } from 'rxjs/Rx';

import 'rxjs/add/operator/catch';
import { Router } from '@angular/router';
import { Storage } from '../storage/storage.service';

@Injectable()
export class HttpProvider extends Http {
    constructor(backend: ConnectionBackend, defaultOptions: RequestOptions, private _storage: Storage,
    private _router: Router) {
        super(backend, defaultOptions);
    }
//     ngOnInit() {
//     this._router = this.injector.get(Router);
// }

    request(url: string | Request, options?: RequestOptions): Observable<Response> {
      if (!(options && options.headers)) {
        let headers = new Headers();
        options = new RequestOptions({ headers: headers, withCredentials: true });
      }
      
      options.headers.append('Content-Type', 'application/json');

      var apiUrl = url.toString();

      if (url instanceof Request) {
        apiUrl = url.url;
        url.headers = options.headers;
        url.withCredentials = true;
      }

      if (apiUrl.includes(this._storage.getItem("apiUrl"))) {
        options.headers.append('Authorization', 'Bearer ' + this._storage.getItem("accessToken"));
        options.headers.append('WebApi.AccessLevels', this._storage.getItem("apiAccessToken"));
      }

      if (apiUrl.includes(this._storage.getItem("reportsUrl"))) {
          options.headers.append('Authorization', 'Bearer ' + this._storage.getItem("accessToken"));
      }

      if (apiUrl.includes(this._storage.getItem("documentapiUrl"))) {
          options.headers.append('Authorization', 'Bearer ' + this._storage.getItem("accessToken"));
          options.headers.append('AuthUser', this._storage.getItem("userId"));
      }
      
      return super.request(url, options).catch(this.catchExpError(this));
    }
    catchExpError(self: HttpProvider) {
        // we have to pass HttpProvider's own instance here as `self`
        return (res: Response) => {
            let details = res.json();
          
          if (res.status === 401 || res.status === 403) {
            return Observable.throw(details.Code);
          }

          return Observable.throw(res);
        };
    }
}

export function httpFactory(xhrBackend: XHRBackend, requestOptions: RequestOptions, _storage: Storage, _router : Router): Http {
  return new HttpProvider(xhrBackend, requestOptions, _storage, _router);
}

export function serializeUrlParams(obj: Object): URLSearchParams {
    let params: URLSearchParams = new URLSearchParams();
    for (let key in obj) {
        if (obj.hasOwnProperty(key)) {
            let value = obj[key];

            params.set(key, value);
        }
    }
    return params;

}