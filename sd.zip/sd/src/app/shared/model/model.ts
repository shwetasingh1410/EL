export enum UserRole {
    SuperAdministrator = 1,
    MsdAdministrator,
    MsdBuAdministrator,
    WillisReader,
    ClientReader,
}