﻿import { Component, OnInit, Input, Output, ElementRef, EventEmitter } from '@angular/core';
import * as _ from 'lodash';
declare var window: any;

@Component({
    selector: 'termsofuseError',
    templateUrl: './termsofuseError.component.html',
    styleUrls: ['./termsofuseError.component.css']

})

  
export class TermsofuseErrorComponent implements OnInit {


    constructor() {

    }



    ngOnInit() {


    }

    signout() {
        window.signOutComponent.zone.run(function(){
                                    window.signOutComponent.componentFn();
                                });
    }
}

