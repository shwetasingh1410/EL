﻿import { Injectable } from '@angular/core';

@Injectable()
export class SessionService  { 

  public _session:number=1;

    
      
    

    setsession(value){
        this._session = value;
    }

    getsession(){
        return this._session;
    }
}

