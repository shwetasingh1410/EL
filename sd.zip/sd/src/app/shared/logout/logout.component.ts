﻿import { Component, OnInit, Input, Output, ElementRef, EventEmitter } from '@angular/core';
import * as _ from 'lodash';

import { AuthService } from '../loggedInUser/auth.service';

@Component({
    selector: 'logout',
    templateUrl: './logout.component.html',
    styleUrls: ['./logout.component.css']

})

export class LogoutComponent implements OnInit {


    constructor(private _authService: AuthService) {
        this._authService.signOut();
    }



    ngOnInit() {


    }
}

