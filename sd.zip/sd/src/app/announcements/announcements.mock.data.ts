﻿export const annoucementsSearchResult = [
    {
        "Title": 'New Carriers added',
        "Description": "New carriers have been added",
        "Expirydate": "Aug 2,2017",
        "DocLink": "Abc",
        "ExtLink": "XYZ",
        "clients": "",
        "AnnouncementId": "1"
    },
    {
        "Title": 'New Carriers added',
        "Description": "<b><i><u>New carriers have been added</u></i></b>",
        "Expirydate": "Aug 8,2017",
        "DocLink": "haskdhkahdkashdk",
        "ExtLink": "XYZ",
        "clients": "",
        "AnnouncementId": "2"
    }
];

export const accounts = [
    {
        'Id': 1,
        'PartyName': 'ABB Hongkong Limited',
        'PartyId':212323
    },
    {
        'Id': 2,
       'PartyName': 'Swiss Life (Espana)',
       'PartyId':232342
    },
    {
        'Id': 3,
        'PartyName': 'Farmers Insurance',
        'PartyId':453412
    },
    {
        'Id': 4,
        'PartyName': 'Zenith Insurance',
        'PartyId':124512
    },
    {
        'Id': 5,
        'PartyName': 'ABB Hongkong Limited1',
        'PartyId':212358
    },
    {
        'Id': 6,
        'PartyName': 'Swiss Life (Espana)1',
        'PartyId':232342,
    },
    {
        'Id': 7,
        'PartyName': 'Farmers Insurance1',
        'PartyId':453412
    },
    {
        'Id': 8,
        'PartyName': 'Zenith Insurance1',
        'PartyId':87854654646446
        
    }
];



