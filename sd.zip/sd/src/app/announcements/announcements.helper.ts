﻿//will help in common utility static functions 
import { Announcement, Account, AnnouncementClient } from './announcements.model';
export class AnnouncementsHelper {

    static mapToAnnouncement(announcements: any): Announcement {
        //return Announcements Object
        return new Announcement(announcements.Title, announcements.Body,
            announcements.ExpiryDate, announcements.WebLinkURL, announcements.DocumentLink,
            announcements.AnnouncementClients, announcements.AllClients, announcements.Id);
    }
    //static mapToAccount(userClient: any, action: AccountActionIndicator): Account {
    static mapToAccount(party: any): Account {
        return new Account(party.Id, party.SubscriptionId, party.PartyId, party.AccountId, party.PartyName, party.ConsultancyStatus,
            party.AssociateAllCarriers, party.AccessLevel);
    }

    static mapToAnnouncementClients(MosaicClientId: string): AnnouncementClient {
        //return Announcements Object

        return new AnnouncementClient(MosaicClientId);
    }
}