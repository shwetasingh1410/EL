﻿import { AnnouncementsHelper } from './announcements.helper';


export class AnnouncementClient {
    MosaicClientId: string;
    constructor(MosaicClientId: string) {
        this.MosaicClientId = MosaicClientId;
    }
}

//export class ClientInfo {
export class Announcement {
    Title: string;
    Body: string;
    ExpiryDate: string;
    WebLinkURL: string;
    AllClients: boolean;
    Id: string;
    DocumentLink: Array<AnnouncementDocumentLink>;
    AnnouncementClients: Array<AnnouncementClient>;

    // IsEdit: boolean;
    // IsDelete : boolean;

    constructor(Title: string, Body: string, ExpiryDate: string, WebLinkURL: string, DocumentLink: Array<AnnouncementDocumentLink>, AnnouncementClients: Array<AnnouncementClient>, AllClients: boolean, Id: string) {
        this.Title = Title;
        this.Body = Body;
        this.ExpiryDate = ExpiryDate;
        this.WebLinkURL = WebLinkURL;
        this.DocumentLink = DocumentLink;
        this.AllClients = AllClients;
        this.AnnouncementClients = AnnouncementClients;
       // this.AnnouncementClient = new Array<AnnouncementClient>();
       // if (AnnouncementClient !== null && AnnouncementClient !== undefined)
       //     AnnouncementClient.forEach((announcementClientId) => {
       //         this.AnnouncementClient
        //            .push(AnnouncementsHelper.mapToAnnouncementClients(announcementClientId));
       //     });
        this.Id = Id;
    }
}

export class Account {
    public Id: string;
    public SubscriptionId: string;
    public PartyId: number;
    public AccountId:string;
    public PartyName: string;
    public ConsultancyStatus: ConsultancyStatus;
    public AssociateAllCarriers: boolean;
    public AccessLevel: AccountAccess;
    public DisplayPartyName: string;

    constructor(Id: string, SubscriptionId: string, PartyId: number,AccountId:string, PartyName: string, ConsultancyStatus: ConsultancyStatus,
        AssociateAllCarriers: boolean, AccessLevel: AccountAccess) {
        this.Id = Id;
        this.SubscriptionId = SubscriptionId;
        this.PartyId = PartyId;
        this.AccountId = AccountId;
        this.PartyName = PartyName;
        this.ConsultancyStatus = ConsultancyStatus;
        this.AssociateAllCarriers = AssociateAllCarriers;
        this.AccessLevel = AccessLevel;

        if (ConsultancyStatus == 0)
            this.DisplayPartyName = PartyName + "(Non-Consultancy)";
        else
            this.DisplayPartyName = PartyName + "(Consultancy)";
    }
}

export class AnnouncementDocumentLink {
    AnnouncementId: string;
    DocumentLinkIndex: number;
    DocumentKey: string;
    DocumentTitle: string;
    DocumentURL: string;


    constructor(AnnouncementId: string, DocumentLinkIndex: number, DocumentKey: string, DocumentTitle: string, DocumentURL: string) {
        this.AnnouncementId = AnnouncementId;
        this.DocumentLinkIndex = DocumentLinkIndex;
        this.DocumentKey = DocumentKey;
        this.DocumentTitle = DocumentTitle;
        this.DocumentURL = DocumentURL;

    }
}

// public class EmailAnnouncement
// {
//     public string Subject { get; set; }

//     public List<string> AccountIds { get; set; }

//     public string Description { get; set; }

//     public string WebLinkUrl { get; set; }

//     public string DocumentLink { get; set; }
    
//     public bool IsAllClients { get; set; }
// } 

export class EmailAnnouncement
    {
        From: string;
        Subject:string;
        AccountIds: Array<AnnouncementClient>;
        TemplateName:string;
        templatePlaceholder: Array<TemplatePlaceholder>; 

constructor(From: string, Subject: string, AccountIds: any, TemplateName: string, templatePlaceholder: Array<TemplatePlaceholder>) {
        this.From = From;
        this.Subject = Subject;
        this.TemplateName = TemplateName;
        this.templatePlaceholder = templatePlaceholder;
        this.AccountIds = new Array<AnnouncementClient>();
        if (AccountIds !== null && AccountIds !== undefined)
            AccountIds.forEach((announcementClientId) => {
                this.AccountIds
                    .push(AnnouncementsHelper.mapToAnnouncementClients(announcementClientId));
            });
        
    }
    }

export class TemplatePlaceholder
    {
         Name:string;  

         Value:string; 
    }

    export enum ConsultancyStatus {
        NonConsultancy = 0,
        Consultancy
    }
    
    export enum AccountAccess {
        SuperUsersOnly,
        AllAdmins
        
    }





