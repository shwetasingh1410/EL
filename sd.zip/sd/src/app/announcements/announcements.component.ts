import { DomSanitizer } from '@angular/platform-browser';
import { Component, OnInit, AfterContentInit, SecurityContext } from '@angular/core';
import { AnnouncementsService } from './announcements.service';
import { Announcement, Account, AnnouncementDocumentLink, AnnouncementClient, EmailAnnouncement, TemplatePlaceholder, AccountAccess, ConsultancyStatus } from './announcements.model';
import { DatepickerComponent } from '../shared/datepicker/datepicker.component';
import * as _ from 'lodash';
import { Pipe, PipeTransform } from '@angular/core';
import { TruncateModule } from 'ng2-truncate';
import * as moment from 'moment/moment';
import { TranslateService } from '../translate/translate.service';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/observable/fromEvent';
import { Subscription } from 'rxjs/Subscription';
import { LoggedInUser } from '../shared/loggedInUser/LoggedInUser';
import { SanitizeHtml, SanitizeResourceUrl, SanitizeScript, SanitizeStyle, SanitizeUrl } from 'ng2-sanitize';
import { LoaderService } from '../shared/loaderComponent/Loader.service';
declare var $: any;
@Component({
  selector: 'app-announcements',
  templateUrl: './announcements.component.html',
  styleUrls: ['./announcements.component.css'],
  providers: [AnnouncementsService, LoggedInUser]
})
export class AnnouncementsComponent implements OnInit, AfterContentInit {

  isTableVisible = true;
  isCreateAnnouncementVisible = false;
  iseditTable = false;
  isEditingAnnouncement: boolean;
  isDisabled = true;
  assigned = [];
  announcementResult = [];
  specificAnnoucementsData: any;
  title: string;
  description: string;
  descriptionText: string;
  docLink: string;
  extLink: string;
  expiryDate: string;
  isError: boolean;
  isSuccess: boolean;
  isAlert: boolean;
  message: string;
  saveSuccess: false;
  clients: any;
  id: string;
  showDeleteConfirmation: boolean;
  private selectedLink: string = "No";
  selectedClients: Array<string>;
  availableclientList: Array<Account>;
  availableclient: Array<Account>;
  selectedUserAccountList: Array<Account>;
  removeSelectedAccounts: Array<string>;
  announcementId: string;
  clearannouncementId: string;
  saveorupdateflag: string;
  isAllClients: boolean;
  allClientsFlag: boolean;
  documentLink: Array<AnnouncementDocumentLink>;
  AnnouncementClients: Array<AnnouncementClient>;
  AccountIds: Array<string>;
  TemplateName: string;
  templatePlaceholder: Array<TemplatePlaceholder>;
  from: string;
  pageTitle: string;
  issave: boolean;
  subscription: Subscription;
  saveTitle: string;
  saveDescription: string;
  saveDate: string;
  saveFlag: boolean;
  noClientAdded: boolean;
  clientAdded: boolean;
  newExtLink:string;
  isSaveDisabled:boolean;

  constructor(private _loaderService: LoaderService, private _loggedInUser: LoggedInUser, private _announcementsService: AnnouncementsService, private _translate: TranslateService, private _sanitizer: DomSanitizer) {
    this.availableclientList = new Array<Account>();
    this.selectedUserAccountList = new Array<Account>();
    this.availableclient = new Array<Account>();
    this.AnnouncementClients = new Array<AnnouncementClient>();
    this.AccountIds = new Array<string>();
    this.templatePlaceholder = new Array<TemplatePlaceholder>();
    this.TemplateName = "Announcement.html";
    this.noClientAdded = true;
    this.clientAdded = false;
  }

  dateChange(expiryDate: string): void {
    this.expiryDate = expiryDate;
  }

  ngOnInit() {
    // this.richTextEditor();
    this.functionToFetchAccountsData();
    this._translate.use('en');
    this.noClientAdded = true;
    this.clientAdded = false;
  }

  ngAfterContentInit() {
    this.noClientAdded = true;
    this.clientAdded = false;
    //this.richTextEditor();
    this.functionToFetchData();
    this.isSelected('No');
    this.functionToFetchAccountsData();
    this.isAllClients = false;
    this.allClientsFlag = false;
    this.isSuccess = false;
    this.isError = false;
    this.isAlert = false;
    this.isEditingAnnouncement = false;
  }

  functionToFetchData() {
    this._loaderService.show();
    this._announcementsService
      .getAnnouncements().
      subscribe((result) => {
        this._loaderService.hide();
        this.announcementResult = result;
      }, (error) => {
        this._loaderService.hide();
        this.handleError(error)
      });
  }


  functionToFetchAccountsData() {
    this._loaderService.show();
    this._announcementsService.getAccounts()
      .subscribe((result) => {
        this._loaderService.hide();
        this.availableclientList = result;
        this.availableclient = _.cloneDeep(this.availableclientList);
      }, (error) => {
        this._loaderService.hide();
        this.handleError(error)
      });
  }

  deleteConfirmationModal(AnnouncementId: string) {
    document.getElementById("announcementId1").setAttribute('value', AnnouncementId);
    document.getElementById("deleteModal").click();
  }

  DeleteAnnouncement() {
    let AnnouncementId = (<HTMLInputElement>document.getElementById('announcementId1')).value;
    this._loaderService.show();

    this._announcementsService
      .DeleteAnnouncement(AnnouncementId)
      .subscribe(() => {
        this.functionToFetchData();
        this._loaderService.hide();
      }, (error) => {
        this._loaderService.hide();
        this.handleError(error)
      });
  }

  saverecord() {
    if (this.announcementId !== undefined && this.announcementId !== null) { /* Here If to have the Condition */
      this.updateAnnouncement();
    } else {
      this.createAnnouncement();
    }

  }

  addDays(theDate, days) {
    return new Date(theDate.getTime() + days * 24 * 60 * 60 * 1000);
  }

  displayinputDetails() {
    this.isTableVisible = false;
    this.isCreateAnnouncementVisible = true;
    this.iseditTable = true;
    this.isDisabled = true;
    this.isSaveDisabled=false;
    // $.getScript('./assets/scripts/richTextEditor.js');
    setTimeout(function () {
      $('#editor').html(this.description);
    }, 0);

    let expiryDate = this.addDays(new Date(), 7);
    this.expiryDate = moment(expiryDate).format('DD/MM/YYYY');

    this.pageTitle = "Create";
  }


  htmlToPlaintext(text) {
    // return text ? String(text).replace(/<[^>]+>/gm, '') : '';
    return text ? String(text).replace(/<[^>]+>/gm, '').replace(/&nbsp;/g, ' ').replace(/&amp;/g, '&') : '';

  }

  checkcreatevalidation() {
    
    var description = this.htmlToPlaintext($('#editor').html());

    if (this.title === undefined || this.title === null || this.title.trim() === "") {

      this.handleAlert("Title is Required");
      return false;
    }
    else if (description === undefined || description === null || description.trim() === "" || $('#editor').html() == "" || $('#editor').html() == '') {
      this.handleAlert("Description is Required");
      return false;
    }
    else if (this.expiryDate === "" || this.expiryDate === null || this.expiryDate.trim() === "") {
      this.handleAlert("Expiry Date is Required");
      return false;
    }
    else if (this.allClientsFlag === false) {
      if (this.selectedUserAccountList.length === 0) {
        this.handleAlert("Client is Required");
        return false;
      }
      else {
        return true;
      }
    }
    else {
      return true;
    }
  }

  onPaste(e : any){
    e.preventDefault();
       if( e.clipboardData ){
          this.descriptionText =(e.originalEvent || e).clipboardData.getData('text/plain') ;
          document.execCommand("insertText", false, this.descriptionText);
       }
         else if( (window as any).clipboardData ){
          this.descriptionText = (window as any).clipboardData.getData('Text');
      console.log("check" + this.descriptionText);
          if ((window as any).getSelection)
            (window as any).getSelection().getRangeAt(0).insertNode( document.createTextNode(this.descriptionText) );
        } 
      } 

       /* event.clipboardData 
                             //typecasting to any
                              or
                              || window['clipboardData'];  */


  createAnnouncement() {
    this.AnnouncementClients=[];
    this.isAlert = false;
    this.isError = false;
    this.isSuccess = false;
    this.description = $('#editor').html();
    //this.description = this.descriptionText.replace(/<\/?[^>]+(>|$)/g, "");
    if (this.checkcreatevalidation() === true) {
      this._loaderService.show();
      if (this.selectedUserAccountList.length > 0) {
        this.selectedUserAccountList.forEach((account) => {
          this.AnnouncementClients.push({ MosaicClientId: account.AccountId });
          this.AccountIds.push(account.AccountId);

        });
      }
      this.saveTitle = this.title;
      this.saveDescription = this.description;
      this.saveDate = this.expiryDate;

      this._announcementsService.CreateAnnouncement(this.title, this.description, this.expiryDate,
        this.extLink, this.allClientsFlag, this.documentLink, this.AnnouncementClients)
        .subscribe(result => {
          this._loaderService.hide();
          this.isSaveDisabled=true;
          this.showSuccess('Announcement saved successfully');
          this.isEditingAnnouncement = true;
          this.isDisabled = false;
          this.announcementId = result;
          this.saveFlag = true;
          
        }, (error) => {
          this._loaderService.hide();
          this.handleError(error)
        });
    }
  }

  updateAnnouncement() {
    this.isAlert = false;
    this.isError = false;
    this.isSuccess = false;
    this.description = ($('#editor').html());
    if (this.checkupdatevalidation() === true) {
      this._loaderService.show();
      this._announcementsService.UpdateAnnouncement(this.title, this.description, this.expiryDate, this.announcementId)
        .subscribe(() => {
          this._loaderService.hide();
          this.isSaveDisabled=false;
          this.showSuccess('Announcement updated successfully');
          this.saveFlag = false;
          
        }, (error) => {
          this._loaderService.hide();
          this.handleError(error)
        });
    }
  }



  checkupdatevalidation() {
    var description = this.htmlToPlaintext($('#editor').html());


    

    if (this.title === undefined || this.title === null || this.title.trim() === "") {

      this.handleAlert("Title is required");
      return false;
    }
    else if (description === undefined ||description === null || description.trim() === "" || $('#editor').html() == '') {
      this.handleAlert("Description is required");
      return false;
    }
    else if (this.expiryDate === "" || this.expiryDate === null || this.expiryDate.trim() === "") {
      this.handleAlert("Expiry Date is required");
      return false;
    }
    else {
      return true;
    }
  }

  EditAnnouncement(AnnouncementId: string) {

    this.isTableVisible = false;
    this.isCreateAnnouncementVisible = true;
    this.iseditTable = false;
    this.isDisabled = true;
    this.isEditingAnnouncement = true;
    this.getAnnouncementsById(AnnouncementId);
    this.announcementId = AnnouncementId;
    this.clearannouncementId = AnnouncementId;
    this.pageTitle = "Update";
    this.isSaveDisabled=false;
    //$.getScript('./assets/scripts/richTextEditor.js');
  }



  getAnnouncementsById(AnnouncementId: string) {
    this._loaderService.show();
    this._announcementsService.getAnnouncementsById(AnnouncementId)
      .subscribe((result) => {
        this._loaderService.hide();
        this.description = this._sanitizer.sanitize(SecurityContext.HTML, result.Body);
        $('#editor').html(this.description);
        this.title = result.Title;
        let expiryDate = new Date(result.ExpiryDate);
        this.expiryDate = moment(expiryDate).format('DD/MM/YYYY');
        this.extLink = result.WebLinkURL;
        this.allClientsFlag = result.AllClients;
        this.documentLink = result.DocumentLink;
        this.AnnouncementClients = result.AnnouncementClients;
        this.announcementId = result.Id;
        if (result.AnnouncementClients.length) {
          result.AnnouncementClients.forEach((announcementClientId) => {
            let index = this.availableclientList.findIndex((account) => account.AccountId == announcementClientId.MosaicClientId);
            this.selectedUserAccountList
              .push(this.availableclientList[index]);
            // this.availableclientList.splice(index, 1);
          });
        }
      }, (error) => {
        this._loaderService.hide();
        this.handleError(error)
      });
  }

  getHomepage() {
    this.noClientAdded = true;
    this.clientAdded = false;
    this.cleardetailsCreate();
    this.isTableVisible = true;
    this.isCreateAnnouncementVisible = false;
    this.iseditTable = false;
    this.isSuccess = false;
    this.isError = false;
    this.isAlert = false;
    this.isEditingAnnouncement = false;
    this.functionToFetchData();
  }

  cleardetails() {
    this.noClientAdded = true;
    this.clientAdded = false;
    if (this.announcementId !== undefined && this.announcementId !== null) {
      if (this.saveFlag === true) {
        this.cleardetailsSave(this.announcementId);
      } else {
        this.cleardetailsUpdate(this.announcementId);
      }

    } else {
      this.cleardetailsCreate();
    }

  }



  cleardetailsCreate() {
    this.noClientAdded = true;
    this.clientAdded = false;
    // $.getScript('./assets/scripts/richTextEditor.js');
    this.title = null;
    this.description = null;
    ($('#editor').html(this.description));
    this.docLink = null;
    this.extLink = null;
    let expiryDate = this.addDays(new Date(), 7);
    this.expiryDate = moment(expiryDate).format('DD/MM/YYYY');
    this.clients = null;
    this.setAssignUser('No');
    this.isSelected('No');
    this.announcementId = null;
    this.selectedClients = new Array<string>();
    this.removeSelectedAccounts = new Array<string>();
    this.selectedUserAccountList = new Array<Account>();
    this.functionToFetchAccountsData();

  }

  cleardetailsUpdate(announcementId) {
    this.functionToFetchAccountsData();
    this.getCancelAnnouncementsById(announcementId);
  }



  getCancelAnnouncementsById(AnnouncementId: string) {
    this._loaderService.show();
    this._announcementsService
      .getAnnouncementsById(AnnouncementId)
      .subscribe((result) => {
        this._loaderService.hide();
        this.description = this._sanitizer.sanitize(SecurityContext.HTML, result.Body);
        $('#editor').html(this.description);
        //this.description = result.Body;
        this.title = result.Title;
        let expiryDate = new Date(result.ExpiryDate);
        this.expiryDate = moment(expiryDate).format('DD/MM/YYYY');
        this.extLink = result.WebLinkURL;
        this.allClientsFlag = result.AllClients;
        this.documentLink = result.DocumentLink;
        this.AnnouncementClients = result.AnnouncementClients;
        this.announcementId = result.Id;
      }, (error) => {
        this._loaderService.hide();
        this.handleError(error)
      });
  }



  cleardetailsSave(announcementId) {
    this.functionToFetchAccountsData();
    this.getCancelSaveAnnouncementsById(announcementId);
  }



  getCancelSaveAnnouncementsById(AnnouncementId: string) {
    this._loaderService.show();
    this._announcementsService
      .getCancelSaveAnnouncementsById(AnnouncementId)
      .subscribe((result) => {
        this._loaderService.hide();
        this.description = this._sanitizer.sanitize(SecurityContext.HTML, result.Body);
        $('#editor').html(this.description);
        //this.description = result.Body;
        this.title = result.Title;
        let expiryDate = new Date(result.ExpiryDate);
        this.expiryDate = moment(expiryDate).format('DD/MM/YYYY');
        this.extLink = result.WebLinkURL;
        this.allClientsFlag = result.AllClients;
        this.documentLink = result.DocumentLink;
        this.AnnouncementClients = result.AnnouncementClients;
        this.announcementId = result.Id;
        this.saveFlag = false;
      }, (error) => {
        this._loaderService.hide();
        this.handleError(error)
      });
  }








  showSuccess(message: string) {

    this.isSuccess = true;
    setTimeout(() => {
      this.isSuccess = false;
    }, 3000);
    this.isError = false;
    this.isAlert = false;
    this.message = message;
  }

  showError(message: string) {
    this.isSuccess = false;
    this.isError = true;
    setTimeout(() => {
      this.isError = false;
    }, 3000);
    this.isAlert = false;
    this.message = message;

  }

  handleError(error) {
    this.isSuccess = false;
    this.isError = true;
    setTimeout(() => {
      this.isError = false;
    }, 3000);
    this.isAlert = false;
    //error.status = 412;
    if (error.status === 412) {
      this.showError('Error 412 : Input Output Validation Error. Please enter details again. ');
    }
    else if (error.status === 422) {
      this.showError('Error 422 : Business Validation Error. Please try again');
    }
    else if (error.status === 500) {
      this.showError('500 Internal Server Error. Please try again');
    }
    else {
      this.showError('Server Error. Please try again');
    }
  }

  handleAlert(message: string) {
    this.isAlert = true;
    setTimeout(() => {
      this.isAlert = false;
    }, 3000);
    this.isError = false;
    this.isSuccess = false;
    this.message = message;
  }


  getClientindexSelectedUserAccountList(accountId: string): number {
    return this.availableclientList.findIndex((account) => account.AccountId == accountId);
  }

  getClientindexRemovedUserAccountList(accountId: string): number {
    return this.selectedUserAccountList.findIndex((account) => account.AccountId == accountId);
  }

  addClientName() {
    this.selectedClients.forEach((clientId) => {
      let index = this.getClientindexSelectedUserAccountList(clientId);
      if (index !== -1) {
        let account: Account = this.availableclientList[index];

        var indexVal = this.selectedUserAccountList.findIndex((account) => account.AccountId == clientId);
        if (indexVal === -1) {
          this.selectedUserAccountList.push(account);
        }

        if (this.selectedUserAccountList.length > 0) {
          this.noClientAdded = false;
          this.clientAdded = true;
        }
        else {
          this.noClientAdded = true;
          this.clientAdded = false;
        }
      }
    });
  }

  removeClientName() {
    this.removeSelectedAccounts.forEach((clientId) => {
      let index = this.getClientindexRemovedUserAccountList(clientId);
      if (index !== -1) {
        let account: Account = this.selectedUserAccountList[index];

        this.selectedUserAccountList.splice(index, 1);
      }
      if (this.selectedUserAccountList.length > 0) {
        this.noClientAdded = false;
        this.clientAdded = true;
      }
      else {
        this.noClientAdded = true;
        this.clientAdded = false;
      }
    });

  }



  setAssignUser(e: string): void {

    this.selectedLink = e;
    if (e == "Yes") {
      //this.isAllClients = true;
      this.allClientsFlag = true;
      this.availableclientList = _.cloneDeep(this.availableclient);

    }
    else {
      //this.isAllClients = false;
      this.allClientsFlag = false;
      this.availableclientList = _.cloneDeep(this.availableclient);
      this.selectedUserAccountList.splice(0, this.selectedUserAccountList.length);


    }
  }

  isSelected(name: string): boolean {

    if (!this.selectedLink) {
      // if no radio button is selected, always return false so every nothing is shown
      return false;
    }

    return (this.selectedLink === name); // if current radio button is selected, return true, else return false  
  }



  makeHyperlink(url: string) {
    var link = 'http://' + this.extLink;
    var urlLink = "<a href=\"" + link + "\">" + url + "</a>";
    return urlLink;
  }



  SendEmail() {
    this._loaderService.show();
    if (this.extLink === undefined || this.extLink === null || this.extLink.trim() === "") {
      this.newExtLink="";
     }
     else
     {
      this.newExtLink = this.makeHyperlink(this.extLink);
     }
    

    this._announcementsService.SendMail(this.title, this.AccountIds, this.description, this.newExtLink, this.docLink, this.allClientsFlag)
      .subscribe(() => {
        this._loaderService.hide();
        this.isDisabled = true;
        this.isSaveDisabled=true;
        this.showSuccess('Announcement Email send successfully');
      }, (error) => {
        this._loaderService.hide();
        this.handleError(error)
      });
  }

  ///////////
  makeBold() {
    document.execCommand('bold', false, null);
  }

  makeItalics() {
    document.execCommand('italic', false, null);
  }

  makeUnderlined() {
    document.execCommand('underline', false, null);
  }

  makeLeft() {
    document.execCommand('justifyLeft', false, null);
  }

  makeCenter() {
    document.execCommand('justifyCenter', false, null);
  }

  makeRight() {
    document.execCommand('justifyRight', false, null);
  }
  insertUnorderedList() {
    document.execCommand('insertUnorderedList', false, null);
  }


  insertOrderedList() {
    document.execCommand('insertOrderedList', false, null);
  }

  makeSuperscript() {
    document.execCommand('superscript', false, null);
  }

  makeSubscript() {
    document.execCommand('subscript', false, null);
  }


  createLink() {
    var selected = document.getSelection();
    document.execCommand('createLink', false, 'http://' + selected);
  }

  removeLink() {
    document.execCommand('unlink', false, null);
  }

  generateHtmlCode() {
    HtmlElement2($("#editor"));

    function HtmlElement2(elem) {
      InsertHtml2($(elem).html());
    }

    function InsertHtml2(data) {
      var mywindow = window.open();
      mywindow.document.write('<html><head><title>Code</title>');
      mywindow.document.write('</head><body >');
      mywindow.document.write(data.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;"));
      mywindow.document.write('</body></html>');
      mywindow.document.close(); // necessary for IE >= 10
      mywindow.focus(); // necessary for IE >= 10
      //mywindow.close();
      return true;
    }
    // document.execCommand('htmlCode',false,null);
  }

}

