import { Component, OnInit } from '@angular/core';
import { TranslateService } from '../translate/translate.service';
import { Settings } from '../shared/settings/settings.service';

declare var $: any;
@Component({
  selector: 'app-document-search',
  templateUrl: './document-search.component.html',
  styleUrls: ['./document-search.component.css']
})
export class DocumentSearchComponent implements OnInit {
  constructor(private _translate: TranslateService) {

  }

  ngOnInit() {
    this._translate.use('en');
   
}
}



