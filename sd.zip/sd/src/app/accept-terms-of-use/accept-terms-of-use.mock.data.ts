﻿export const TermsOfUseResult = [
    {
        "Id": 1,
        "Version": 2,
        "TermsOfUseText": "Hi",
        "PublishedBy": "Abc",
        "PublishedOn": "05/08/2017",
        "CreatedBy": "Abbvnvcnv",
        "CreatedOn": "05/08/2017",
        "UpdatedBy":"XYX",
        "UpdatedOn":"15/08/2017"
    }
];

