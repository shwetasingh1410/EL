﻿import { Injectable } from '@angular/core';
import { Http, RequestOptions, Headers } from '@angular/http';
import { Observable } from 'rxjs/Rx';
import 'rxjs/add/operator/map';
import { AcceptTermsOfUseHelper } from './accept-terms-of-use.helper';
import { TermsOfUse } from './accept-terms-of-use.model';
import { TermsOfUseResult } from './accept-terms-of-use.mock.data';
import { Settings } from '../shared/settings/settings.service';

@Injectable()
export class AcceptTermsOfUseService {
    constructor(private _http: Http, private _settings: Settings) {
    }


    gettermsofuseByCurrentVersion(): Observable<TermsOfUse> {
        return this._http.get(this._settings.getApiUrl() + 'api/users/terms-of-use/version/current')
            .map((response) => this.gettermsofuseByCurrentVersionHandler(response.json()));
    }

    gettermsofuseByCurrentVersionHandler(response) {
        return AcceptTermsOfUseHelper.mapToTermsOfUse(response);

    }


    UpdateUserVersion(usersId: string, currentversionId: number) {
        let headers = new Headers();
        headers.append('Content-Type', 'application/json');
        let options = new RequestOptions({ headers: headers });
        return this._http.put(this._settings.getApiUrl() + 'api/users/terms-of-use/' + usersId + '/accept',
            JSON.stringify({
                'UserId': usersId,
                'Version': currentversionId
            }), options);
    }
}
