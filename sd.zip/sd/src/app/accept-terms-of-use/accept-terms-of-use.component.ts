﻿import { Component, OnInit, AfterContentInit } from '@angular/core';
import { AcceptTermsOfUseService } from './accept-terms-of-use.service';
import { TermsOfUse } from './accept-terms-of-use.model';
import { TermsOfUseResult } from './accept-terms-of-use.mock.data';
import { FormsModule } from '@angular/forms';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/observable/fromEvent';
import { Subscription } from 'rxjs/Subscription'
import * as _ from 'lodash';
import { TranslateService } from '../translate/translate.service';
import { LoggedInUser } from '../shared/loggedInUser/LoggedInUser';
import { Router } from '@angular/router';
declare var $: any;
@Component({
  selector: 'app-accept-terms-of-use',
  templateUrl: './accept-terms-of-use.component.html',
  styleUrls: ['./accept-terms-of-use.component.css'],
  providers: [AcceptTermsOfUseService, LoggedInUser]
})
export class AcceptTermsOfUseComponent implements OnInit, AfterContentInit {

  termsOfUseResult: Array<TermsOfUse>;
  isError: boolean;
  isSuccess: boolean;
  isAlert: boolean;
  message: string;
  saveSuccess: false;
  currentVersionId: number;
  termsOfUseText: string;
  acceptTermsOfUseFlag: boolean;
  issave: boolean;
  constructor(private _acceptTermsOfUseService: AcceptTermsOfUseService, private _translate: TranslateService, private _loggedInUser: LoggedInUser, private _router: Router) {

  }


  ngOnInit() {
    //$.getScript('./assets/scripts/richTextEditor.js');
    this.richTextEditor();
    this._translate.use('en');
  }



  ngAfterContentInit() {
this.richTextEditor();
    //this.functionToDisplayLatesttermsOfUseData();
    this.issave = true;

  }

  functionToDisplayLatesttermsOfUseData() {
    this._acceptTermsOfUseService
      .gettermsofuseByCurrentVersion().
      subscribe((result) => {
        $("#editor").eq(0).attr("contenteditable", false);
        $('#editor').html(result.TermsOfUseText);
        this.termsOfUseText = result.TermsOfUseText;
        this.currentVersionId = result.Version;
      }, (error) => this.handleError(error));
  }

  acceptTermsOfUse(e): void {

    if (e.target.checked) {
      this.acceptTermsOfUseFlag = true;
      this.issave = false;

    }
    else {
      this.acceptTermsOfUseFlag = false;
      this.issave = true;


    }
  }

  saverecord() {
    this._acceptTermsOfUseService.
      UpdateUserVersion(this._loggedInUser.getUserId(), this.currentVersionId)
      .subscribe((result) => {
        this._router.navigate(['/home']);

      }, (error) => this.handleError(error));
  }



  declinerecord() {
    this._loggedInUser.logout();
  }


  showSuccess(message: string) {
    this.message = message;
    this.isSuccess = true;
    setTimeout(() => {
      this.isSuccess = false;
    }, 3000);
    this.isError = false;
  }

  showError(message: string) {
    this.isSuccess = false;
    this.isError = true;
    setTimeout(() => {
      this.isError = false;
    }, 3000);
    this.message = message;

  }
    handleError(error) {
    this.isSuccess = false;
    this.isError = true;
    setTimeout(() => {
      this.isError = false;
    }, 3000);
    //error.status = 412;
    if(error.status === 412){
    this.showError('Error 412 : Input Output Validation Error. Please enter details again. ');  
    }
    else if(error.status === 422){
    this.showError('Error 422 : Business Validation Error. Please try again');
    }
    else if(error.status === 500){
    this.showError('500 Internal Server Error. Please try again');
    }
    else{
      this.showError('Server Error. Please try again');
    }
  }

  ///////////
  makeBold() {
    document.execCommand('bold', false, null);
  }

  makeItalics() {
    document.execCommand('italic', false, null);
  }

  makeUnderlined() {
    document.execCommand('underline', false, null);
  }

  makeLeft() {
    document.execCommand('justifyLeft', false, null);
  }

  makeCenter() {
    document.execCommand('justifyCenter', false, null);
  }

  makeRight() {
    document.execCommand('justifyRight', false, null);
  }
  insertUnorderedList() {
    document.execCommand('insertUnorderedList', false, null);
  }


  insertOrderedList() {
    document.execCommand('insertOrderedList', false, null);
  }

  // makeSuperscript() {
  //   document.execCommand('superscript', false, null);
  // }

  // makeSubscript() {
  //   document.execCommand('subscript', false, null);
  // }


  createLink() {
    var selected = document.getSelection();
    document.execCommand('createLink', false, 'http://' + selected);
  }

  generateHtmlCode() {
    HtmlElement2($("#editor"));

    function HtmlElement2(elem) {
      InsertHtml2($(elem).html());
    }

    function InsertHtml2(data) {
      var mywindow = window.open();
      mywindow.document.write('<html><head><title>Code</title>');
      mywindow.document.write('</head><body >');
      mywindow.document.write(data.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;"));
      mywindow.document.write('</body></html>');
      mywindow.document.close(); // necessary for IE >= 10
      mywindow.focus(); // necessary for IE >= 10
      //mywindow.close();
      return true;
    }
    // document.execCommand('htmlCode',false,null);
  }

  ///////////
  richTextEditor() {
    $(document).ready(function () {
      $("#subscript").click(function () {
        document.execCommand('subscript', false, null);
      });
      $("#superscript").click(function () {
        document.execCommand('superscript', false, null);
      });
    });
  }


}

