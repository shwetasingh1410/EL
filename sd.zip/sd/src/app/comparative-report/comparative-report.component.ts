import { Component, OnInit } from '@angular/core';
import { DatepickerComponent } from '../shared/datepicker/datepicker.component';
import * as moment from 'moment/moment';
import { Router } from '@angular/router';
import { ClientService } from '../select-client/client.service';
import { Settings } from '../shared/settings/settings.service';
import { LoggedInUser } from '../shared/loggedInUser/LoggedInUser';
import { ComparativeReportService } from './comparative-report.service';
import { SafeUrl, DomSanitizer } from '@angular/platform-browser';
declare var $: any;
//import { Carrier } from '../carrier-search/carriersearch.model';

declare var $: any;


@Component({
  selector: 'comparative-report',
  templateUrl: './comparative-report.component.html',
  styleUrls: ['./comparative-report.component.css'],
  providers:[ComparativeReportService]
})
export class ComparativeReport implements OnInit {
  selectedReportCarriers: Array<any>=[]
  selectedCarrierIds: Array<number>=[];
  dateOne: string=moment().format('DD/MM/YYYY');
  dateTwo: string=moment().format('DD/MM/YYYY');
  invertedDateOne: string;
  invertedDateTwo: string;
  result: string;
  modalFlag: boolean;
  buttonFlag: boolean
  Odate1: Date;
  reportUrl: SafeUrl;
  isDateValid: boolean = true;
  showMessage: boolean;
  dateErrMsg: string;
  constructor(private _comparativeReportService: ComparativeReportService, private _router: Router, private _clientService: ClientService, private _settings: Settings, private _sanitizer: DomSanitizer){

  }
  


  ngOnInit() { 
    this.dateChangeOne(this.dateOne);
    this.dateChangeTwo(this.dateTwo);
    this.modalFlag= false;
   this.modalLoad();
  
  }



  onModalClose(){
    this._clientService.setRedirectToSearch(false);
   

  }

  afterHidden(){
    this._clientService.setRedirectToSearch(false);
  }
  
modalLoad(){
   if(this._clientService.getRedirectToReport()){
     this.modalFlag = this._clientService.getRedirectToReport();
     this._clientService.setRedirectToReport(false);
     if(this.modalFlag = true){
      this.selectedReportCarriers = this._clientService.getCarriersReport();
      this.selectedReportCarriers.forEach(carrier => {
        this.selectedCarrierIds.push(carrier.CarrierNumberId);
      })
      this._comparativeReportService.getReportUrl(this.selectedCarrierIds,this._clientService.getReportDate(1),this._clientService.getReportDate(2)).subscribe(result => {
        //console.log(result);
        result = this._settings.getReportsUrl() + result.substring(4);
        this.reportUrl = this._sanitizer.bypassSecurityTrustResourceUrl(result);
        
      })
      document.getElementById("reportModal").click();
      //console.log(JSON.stringify(this.selectedReportCarriers)+"pass to url");
     }
  
}

}

generateExcel() {
    this._comparativeReportService.generateExcel(this.selectedCarrierIds,this._clientService.getReportDate(1),this._clientService.getReportDate(2))
      .subscribe((result) => {
        var folderName = result;
        this._comparativeReportService.downloadReport(folderName);
      }, (error) => { });
} 
  dateChangeOne(dateOne: string): void {
    this.dateOne = dateOne.split("/").join("-");
    this.isDateValid = true;
  }
  dateChangeTwo(dateTwo: string): void {
    this.dateTwo = dateTwo.split("/").join("-");
    this.isDateValid = true;
  }

  dateChangeOneManual(dateOne): void {
    this.dateOne=dateOne.target.value;
    this.isDateValid = moment(this.dateOne, 'DD/MM/YYYY', true).isValid()
    this.dateOne = this.dateOne.split("/").join("-");
  }

  dateChangeTwoManual(dateTwo): void {
    this.dateTwo=dateTwo.target.value;
    this.isDateValid = moment(this.dateTwo, 'DD/MM/YYYY', true).isValid()
    this.dateTwo = this.dateTwo.split("/").join("-");
  }

  redirectToSearch() {
    if (this.validateComparativeReport() == true){
      this.showMessage = false;
      this.buttonFlag = true;
      this._clientService.setRedirectToSearch(this.buttonFlag);
      this._clientService.setRedirectFromAdmin(this.buttonFlag);
      this._clientService.setReportDate(this.dateOne, this.dateTwo);
      this._router.navigate(['./carrier-search']);
    }      
  }
  invertDate(date) {
    return
  }
  validateComparativeReport() {
    var dateOne = this.dateOne.split("-").reverse().join("/");
    var dateTwo = this.dateTwo.split("-").reverse().join("/");
      var d1 = Date.parse(dateOne);
      var d2 = Date.parse(dateTwo);
      if(d2 < d1) {
        this.showMessage = true;
        this.dateErrMsg = 'Date One cannot be greater than Date Two';
        return false;
      } 
      if(this.isDateValid == false){
        this.showMessage = true;
        this.dateErrMsg = 'Please enter valid date';
        return false;
      }
      if (this.dateOne == undefined || this.dateOne == null || this.dateOne == '') {
        if (this.dateTwo == undefined || this.dateTwo == null || this.dateTwo == '') {
          this.showMessage = true;
          this.dateErrMsg = 'Please select both start and end date.'
          return false;
        } else {
          this.showMessage = true;
          this.dateErrMsg = 'Please select start date.'
          return false;
        }
      }
      if (this.dateTwo == undefined || this.dateTwo == null || this.dateTwo == '') {
        if (this.dateOne == undefined || this.dateOne == null || this.dateOne == '') {
          this.showMessage = true;
          this.dateErrMsg = 'Please select both start and end date.'
          return false;
        } else {
          this.showMessage = true;
          this.dateErrMsg = 'Please select end date.'
          return false;
        }
      }
    
    return true;
  }
}
