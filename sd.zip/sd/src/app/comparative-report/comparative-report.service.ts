import { Injectable } from '@angular/core';
import { Http, RequestOptions, Headers } from '@angular/http';
import { Observable } from 'rxjs/Rx';
import { serializeUrlParams } from '../shared/http/http.factory';
import { Settings } from '../shared/settings/settings.service';
import { LoggedInUser } from '../shared/loggedInUser/LoggedInUser';

@Injectable()
export class ComparativeReportService {
    constructor(private _http: Http, private _settings: Settings, private _loggedInUser: LoggedInUser) {
     

    }    

    getReportUrl(reportCarrier:Array<number>, dateone : string,datetwo : string): Observable<string> {
        console.log('d:'+reportCarrier)
        return this._http.post(this._settings.getReportsUrl() + 'reports/carrier/params/' + 'dateone='+dateone+'|'+'datetwo='+datetwo+'|reportType=Admin|reportSubType=MarketComparativeRatings|adminMode=1',
            JSON.stringify({ 'CarrierId': reportCarrier, 'UserId': this._loggedInUser.getUserId()}))
            .map((response) => {
                return response.json();
            });
    }

    generateExcel(reportCarrier:Array<number>, dateone : string,datetwo : string) {
        return this._http.post(this._settings.getReportsUrl() + 'reports/carrier/params/' + 'dateone='+dateone+'|'+'datetwo='+datetwo+'|reportType=Admin|reportSubType=MarketComparativeRatings|exportReport=true|exportFormat=excel|adminMode=1',
            JSON.stringify({ 'CarrierId': reportCarrier, 'UserId': this._loggedInUser.getUserId() }))
            .map((response) => { return response.json()});
    }

    downloadReport(folderName : string) {
        window.open(this._settings.getReportsUrl() + 'reports/carrier/download-file/'+folderName);
    } 
    
   
}