﻿
export class Entities {
    Id: number;
    Name: string;
    constructor(Id: number,  Name: string) {
        this.Id = Id;
        this.Name = Name;
       
    }
}

export class EntityAttributes {
    Id: number;
    Name: string;
    EntityId:number;
    constructor(Id: number,  Name: string,EntityId :number ) {
        this.Id = Id;
        this.Name = Name;
       this.EntityId = EntityId;
    } 
}

export class EntityAttributeValues {
    Value: string;
    constructor(Value: string) {
        this.Value = Value;
       
    } 
}

export class RecentlyViewedCarriers {
  CarrierId: string;
  LegalName: string;
  ViewedDate: Date;
  WillisCode: string;
  Country: string;
  CarrierNumberId: number;

  constructor(CarrierId: string, LegalName: string, ViewedDate: Date, WillisCode: string, Country: string, CarrierNumberId: number) {
    this.CarrierId = CarrierId;
    this.LegalName = LegalName;
    this.ViewedDate = ViewedDate;
    this.WillisCode = WillisCode;
    this.Country = Country;
    this.CarrierNumberId = CarrierNumberId;
  }
}

export class WhatsNewActivity {
  DateQueued: Date;
  WillisCode: string;
  LegalName: string;
  Country: string;
  Ownership: string;
  Category: string;
  CurrentValue: string;
  PreviousValue: string;
  FEINNbr: string;
  ClientReference: string;
  CarrierId: string;
  WhatsNewCategoryId: number;
  CarrierNumberId: number;

  constructor(DateQueued: Date, WillisCode: string, LegalName: string, Country: string, Ownership: string,
    Category: string, CurrentValue: string, PreviousValue: string, FEINNbr: string, ClientReference: string,
    CarrierId: string, WhatsNewCategoryId: number, CarrierNumberId: number) {
    this.DateQueued = DateQueued;
    this.WillisCode = WillisCode;
    this.LegalName = LegalName;
    this.Country = Country;
    this.Ownership = Ownership;
    this.Category = Category;
    this.CurrentValue = CurrentValue;
    this.PreviousValue = PreviousValue;
    this.FEINNbr = FEINNbr;
    this.ClientReference = ClientReference;
    this.CarrierId = CarrierId;
    this.WhatsNewCategoryId = WhatsNewCategoryId;  
    this.CarrierNumberId = CarrierNumberId;
  }
}