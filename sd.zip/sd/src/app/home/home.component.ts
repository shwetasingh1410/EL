﻿import { Component, OnInit, AfterContentInit, SecurityContext } from '@angular/core';
import { Router } from '@angular/router';
import { HomePageService } from './home.service';
import { Entities, EntityAttributes, EntityAttributeValues, RecentlyViewedCarriers, WhatsNewActivity } from './home.model';
import { FormsModule } from '@angular/forms';
import 'rxjs/add/observable/fromEvent';
import { TranslateService } from '../translate/translate.service';
import { Carrier } from "app/carrier-search/carriersearch.model";
import { ClientService } from '../select-client/client.service';
import { LoaderService } from '../shared/loaderComponent/Loader.service';
import { LoggedInUser } from '../shared/loggedInUser/LoggedInUser';
import { Settings } from '../shared/settings/settings.service';
import { SafeUrl, DomSanitizer } from '@angular/platform-browser';
declare var $: any;
import { CoolSessionStorage } from 'angular2-cool-storage';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css'],
  providers: [HomePageService]
})
export class HomeComponent implements OnInit {
  selectedCarrier;
  localStorage: CoolSessionStorage;
  entityname: string;
  homepageadminText: string;
  isError: boolean;
  isSuccess: boolean;
  message: string;
  carriers: Array<RecentlyViewedCarriers>;
  whatsNew: Array<WhatsNewActivity>;
  excelUrl: SafeUrl;
  homeContactUsEmailId: string;
  constructor(private _loaderService: LoaderService,private _homePageService: HomePageService, private _translate: TranslateService,
    private _clientService: ClientService, private _router: Router, private _loggedInUser: LoggedInUser,
    private _settings: Settings, private _sanitizer: DomSanitizer,localStorage:CoolSessionStorage) {
    this.entityname = "HomePageAdmin";
    this.homeContactUsEmailId = this._settings.getHomeContactUsUrl();
    this.localStorage = localStorage;
  }
  ngOnInit() {
    $.getScript('./assets/scripts/richTextEditor.js');
    this.selectLang('en');
    this.functionToDisplayHomepageadminText();
    this.displayRecentlyViewedCarriers();
    this.displayWhatsNew();
    this.export();
  }

  selectLang(lang: string) {
    // set current lang;
    this._translate.use(lang);
  }

  functionToDisplayHomepageadminText() {
    this._loaderService.show();
    this._homePageService
      .gethomepageadminText().
      subscribe((result) => {
        this._loaderService.hide();
        $('#editor').html(this._sanitizer.sanitize(SecurityContext.HTML, result.Value["_body"]));
      }, (error) =>{ 
        this._loaderService.hide();
        this.handleError(error)});
  }

  displayRecentlyViewedCarriers() {
    this._loaderService.show();
    this._homePageService
      .getRecentlyViewedCarriers().
      subscribe((result) => {
        this._loaderService.hide();
        this.carriers = result;
      },(error) =>{ 
        this._loaderService.hide();
        this.handleError(error)});    
  }

  displayWhatsNew() {
    this._loaderService.show();
    var account:any=this.localStorage.getObject('account'); 
    if(account){
      this._homePageService.getWhatsNew(account.Id).
      subscribe((result) => {
        this._loaderService.hide();
        this.whatsNew = result;
      },(error) =>{ 
        this._loaderService.hide();
        this.handleError(error)});
    }else{
      this._homePageService.getWhatsNew('').
      subscribe((result) => {
        this._loaderService.hide();
        this.whatsNew = result;
      },(error) =>{ 
        this._loaderService.hide();
        this.handleError(error)});
    }
    
  }

  naviagateToCarrierDetails_whatsNew(index: number) {      
      let tabName: string;
      let role: string = this._loggedInUser.getRole().RoleCode;
      let carriers: Array<Carrier> = new Array<Carrier>();
      var data = this.whatsNew[index];
      carriers.push(new Carrier(data.CarrierId, data.LegalName, null, data.Country, null, null, data.WillisCode, null, null, null,
          null, null, null, null, null, null, null, null, null, null, null, null, null, data.CarrierNumberId, '', '',null,null,null,null,null,null,null,null,null));
          this._clientService.setCarrierObject(carriers[0]);
      if (data.Category == "Ratings" || data.Category == "Documents")
          tabName = "documents";
      else if (data.Category == "Financials" || data.Category == "Name Change") {
          if (role != "ClientRead")
              tabName = "general";
          else
              tabName = "summary";
      }     
      var account:any=this.localStorage.getObject('account'); 
      this.localStorage.setObject('carriers',data);
      var code='code';
      var carrier='carrier';
      var client='client';
      // this._clientService.setCarriers(carriers);
      if(account && data.WillisCode && data.CarrierId)
      this._router.navigate(['carrier-detail',client,account.AccountId,carrier,data.CarrierId,code,data.WillisCode,tabName]);
      else if(data.WillisCode && data.CarrierId){
        this._clientService.setRevertUrl(tabName);
        this._router.navigate(['select-client']);
      }else{
        this._router.navigate(['forbidden']);
      }
  }

  naviagateToCarrierDetails_carrier(index: number) {
    // let carriers: Array<Carrier> = new Array<Carrier>();
    var data = this.carriers[index];
    this._clientService.setCarrierObject(data);
    var code = 'code';
    var carrier = 'carrier';
    var client = 'client';
    //var account = this._clientService.getSelectedAccount();
    var account: any = this.localStorage.getObject('account');
    this.localStorage.setObject('carriers',data);
    this.selectedCarrier = this.localStorage.getObject('carriers');
    var tabName
    if (this._loggedInUser.getUserRoleCode() != "ClientRead") {
      tabName = "general";
    }
    else {
      tabName = "summary";
    }
    if (account)
      this._router.navigate(['carrier-detail', client, account.AccountId, carrier, data.CarrierId, code, data.WillisCode, tabName]);
    else {
      this._clientService.setRevertUrl(tabName);
      this._router.navigate(['select-client']);
    }
  }

  export() {
    this._loaderService.show();
    var account: any = this.localStorage.getObject('account');
    this._homePageService.getWhatsNewReportUrl(account).subscribe((result) => {
      result = this._settings.getReportsUrl() + result.substring(4);
      this.excelUrl = result;
      this._loaderService.hide();
    },(error) =>{ 
      this._loaderService.hide();
      this.handleError(error)});
  }

  handleError(error) {
    this.isSuccess = false;
    this.isError = true;
    setTimeout(() => {
      this.isError = false;
    }, 3000);
    this.showError('Some Error Occured, please report to support team along with steps to reproduce');
  }
  showError(message: string) {
    this.isSuccess = false;
    this.isError = true;
    setTimeout(() => {
      this.isError = false;
    }, 3000);
    this.message = message;

  }

}

