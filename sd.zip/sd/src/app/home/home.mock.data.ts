﻿export const EntityAttributeValueResult = [
    {
        "Id": 1,
        "Value": "Hello",
        "AttributeId": 1,
        "UpdatedBy":"XYX",
        "UpdatedOn":"15/08/2017"
    }
];

