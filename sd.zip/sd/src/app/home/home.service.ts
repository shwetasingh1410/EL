﻿import { Injectable } from '@angular/core';
import { Http, RequestOptions, Headers } from '@angular/http';
import { Observable } from 'rxjs/Rx';
import 'rxjs/add/operator/map';
import { HomePageHelper } from './home.helper';
import { Entities, EntityAttributes, EntityAttributeValues, RecentlyViewedCarriers, WhatsNewActivity } from './home.model';

import { Settings } from '../shared/settings/settings.service';
import { LoggedInUser } from '../shared/loggedInUser/LoggedInUser';

@Injectable()
export class HomePageService {
  constructor(private _http: Http, private _settings: Settings, private _loggedInUser: LoggedInUser) {
  }

  gethomepageadminText(): Observable<EntityAttributeValues> {
    return this._http.get(this._settings.getApiUrl() + 'api/contents/home-page-text')
      .map((response) => this.gethomepageadminTextHandler(response));
  }

  gethomepageadminTextHandler(response) {
    return HomePageHelper.mapToEntityAttributeValue(response);

  }

  getRecentlyViewedCarriers(): Observable<Array<RecentlyViewedCarriers>> {
    return this._http.get(this._settings.getApiUrl() + 'api/statistics/recently-viewed')
      .map((response) => this.getRecentlyViewedCarriersHandler(response.json()));
  }

  getRecentlyViewedCarriersHandler(response) {
    let link: string;
    let result: Array<RecentlyViewedCarriers> = new Array<RecentlyViewedCarriers>();
    response.forEach((carrier) => {
        result.push(new RecentlyViewedCarriers(carrier.CarrierId, carrier.LegalName, carrier.ViewedDate, carrier.WillisCode, carrier.Country, carrier.CarrierNumberId));
    });

    return result;
  }

  getWhatsNew(accountId:string): Observable<Array<WhatsNewActivity>> {
    return this._http.get(this._settings.getApiUrl() + 'api/statistics/whats-new/'+accountId)
      .map((response) => this.getWhatsNewDataHandler(response.json()));
  }

  getWhatsNewDataHandler(response) {
    let result: Array<WhatsNewActivity> = new Array<WhatsNewActivity>();
    response.forEach((data) => {
      result.push(new WhatsNewActivity(data.DateQueued, data.WillisCode, data.LegalName, data.Country, data.Ownership,
        data.Category, data.CurrentValue, data.PreviousValue, data.FEINNbr, data.ClientReference, data.CarrierId,
        data.WhatsNewCategoryId, data.CarrierNumberId));
    });
    return result;
  }

  getWhatsNewReportUrl(account): Observable<string> {
    if(account){
      return this._http.post(this._settings.getReportsUrl() + 'reports/carrier/Miscellaneous/params/pUserID=' +   this._loggedInUser.getUserId() + '|pClientID='+account.AccountId+
      '|reportType=WhatsNew|reportSubType=Excel|exportReport=true|exportFormat=excel|reportNumber=30',
        JSON.stringify({ 'userId': this._loggedInUser.getUserId() }))
        .map((response) => {
          return response.json();
        });
    
    }
    else{
      return this._http.post(this._settings.getReportsUrl() + 'reports/carrier/Miscellaneous/params/pUserID=' +   this._loggedInUser.getUserId() + '|reportType=WhatsNew|reportSubType=Excel|exportReport=true|exportFormat=excel|reportNumber=30',
        JSON.stringify({ 'userId': this._loggedInUser.getUserId() }))
        .map((response) => {
          return response.json();
        });
    }
    
}
}


