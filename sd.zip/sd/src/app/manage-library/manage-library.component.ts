import { Component, OnInit } from '@angular/core';
import { TranslateService } from '../translate/translate.service';
import { Settings } from '../shared/settings/settings.service';
import { DomSanitizer, SafeResourceUrl, SafeUrl } from '@angular/platform-browser';
import { Http, RequestOptions, Headers } from '@angular/http';

declare var $: any;
@Component({
  selector: 'app-manage-library',
  templateUrl: './manage-library.component.html',
  styleUrls: ['./manage-library.component.css']
})
export class ManageLibraryComponent implements OnInit {
  // trustedDashboardUrl: SafeUrl;
  // fetchedHtml: any;
  constructor(private _translate: TranslateService, private _Settings: Settings, private sanitizer: DomSanitizer, private http: Http) {

  }

  ngOnInit() {
    this._translate.use('en');
    // // this.url = this.sanitizer.bypassSecurityTrustUrl(this._Settings.getManageLibraryUrl());


    // this.trustedDashboardUrl = this.sanitizer.bypassSecurityTrustResourceUrl(this._Settings.getManageLibraryUrl());


    // var headers = new Headers();
    // headers.append('x-forwarded-host', 'application/json');
    // this.http.get(this._Settings.getManageLibraryUrl(), { headers: headers }).subscribe(response => {
    //   this.fetchedHtml = response.json();



    // }
    // )
  }
}




