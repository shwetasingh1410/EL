import { Component, OnInit, AfterContentInit, SecurityContext } from '@angular/core';
import { HomePageAdminService } from './home-page-admin.service';
import { Entities, EntityAttributes, EntityAttributeValues } from './home-page-admin.model';
import { LoaderService } from '../shared/loaderComponent/Loader.service';
import { FormsModule } from '@angular/forms';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/observable/fromEvent';
import { Subscription } from 'rxjs/Subscription'
import * as _ from 'lodash';
declare var $: any;
import { TranslateService } from '../translate/translate.service';
import { DomSanitizer } from '@angular/platform-browser';

@Component({
  selector: 'app-home-page-admin',
  templateUrl: './home-page-admin.component.html',
  styleUrls: ['./home-page-admin.component.css'],
  providers: [HomePageAdminService]

})
export class HomePageAdminComponent implements OnInit, AfterContentInit {
  isError: boolean;
  isSuccess: boolean;
  message: string;
  saveSuccess: false;
  homepageadminText: string;
  subscription: Subscription;
  isAlert: boolean;


  issave: boolean;
  constructor(private _loaderService: LoaderService, private _homePageAdminService: HomePageAdminService, private _translate: TranslateService, private _sanitizer: DomSanitizer) {
  }


  ngOnInit() {
    this._translate.use('en');
    this.richTextEditor();
  }

  ngAfterContentInit() {
    this.functionToDisplayHomepageadminText();
    this.issave = false;
    this.richTextEditor();
  }

  functionToDisplayHomepageadminText() {
    this._loaderService.show();
    this._homePageAdminService
      .gethomepageadminText().
        subscribe((result) => {
          this._loaderService.hide();
            this.homepageadminText = this._sanitizer.sanitize(SecurityContext.HTML, result.Value["_body"]);
            $('#editor').html(this.homepageadminText);
        
      }, (error) =>{ 
        this._loaderService.hide();
        this.handleError(error)});
  }

  saverecord() {
      this.isAlert = false;
      this.isError = false;
      this.isSuccess = false;
      var str1 = $("#editor").html();
      var str2 = $("#editor").html();
      var regex1 = /<div\s*[\/]?>/gi;
      var regex2 = /<br\s*[\/]?>/gi;
      var regex4 = /(<([^>]+)>)/ig;
      var regex3 = /&nbsp;/gi;
      var str3 = str1.replace(regex1, "");
      var str4 = str3.replace(regex2, "");
      var str5 = str4.replace(regex3, "");
      var str6 = str5.replace(regex4, "");
      if (str6 == '') {
      this.handleAlert('Enter text then submit');
      this._loaderService.hide();
    }
    else {
      this.homepageadminText = ($("#editor").html());
      let hometext: string = this.homepageadminText.replace('/\s|&nbsp;/', '');

      if (this.checkvalidation() === true) {
        if (hometext) {
          this._homePageAdminService.UpdateHomepageadminText(this.homepageadminText)
            .subscribe((result) => {
              this.showSuccess('Message updated successfully');
              this.functionToDisplayHomepageadminText();
              this._loaderService.hide();

            }, (error) =>{ 
              this._loaderService.hide();
              this.handleError(error)});
        }


      }
    }
  }

  saverecordOld() {
    this.homepageadminText = ($('#editor').html());
    this._loaderService.show();
    let hometext: string = this.homepageadminText.replace('/\s|&nbsp;/', '');

    if (this.checkvalidation() === true) {
      if (hometext) {
        this._homePageAdminService.UpdateHomepageadminText(this.homepageadminText)
          .subscribe((result) => {
            this.showSuccess('Message updated successfully');
            this.functionToDisplayHomepageadminText();
            this._loaderService.hide();

          }, (error) =>{ 
            this._loaderService.hide();
            this.handleError(error)});
      }


    }
  }


  checkvalidation() {
    this.homepageadminText = ($('#editor').html());
    if (this.homepageadminText === undefined || this.homepageadminText === null || this.homepageadminText === "" || this.homepageadminText.trim() === "" || $('#editor').html() == "") {
      this.handleAlert("Message is Required");
      return false;
    }
    else {
      return true;
    }
  }




  getHomepage() {
    $('#editor').html('');
    this.functionToDisplayHomepageadminText();
    this.issave = false;
    this.isSuccess = false;
    this.isError = false;
  }


  showSuccess(message: string) {
    this.message = message;
    this.isSuccess = true;
    setTimeout(() => {
      this.isSuccess = false;
    }, 3000);
    this.isError = false;
    this.isAlert = false;
  }

  showError(message: string) {
    this.message = message;
    this.isSuccess = false;
    this.isError = true;
    setTimeout(() => {
      this.isError = false;
    }, 3000);
    this.isAlert = false;

  }

  handleError(error) {
    this.isSuccess = false;
    this.isError = true;
    setTimeout(() => {
      this.isError = false;
    }, 3000);
    //error.status = 412;
    if (error.status === 412) {
      this.showError('Error 412 : Input Output Validation Error. Please enter details again. ');
    }
    else if (error.status === 422) {
      this.showError('Error 422 : Business Validation Error. Please try again');
    }
    else if (error.status === 500) {
      this.showError('500 Internal Server Error. Please try again');
    }
    else {
      this.showError('Server Error. Please try again');
    }
  }

  handleAlert(message: string) {
    this.isAlert = true;
    setTimeout(() => {
      this.isAlert = false;
    }, 3000);
    this.isError = false;
    this.isSuccess = false;
    this.message = message;
  }

  makeBold() {
    document.execCommand('bold', false, null);
  }

  makeItalics() {
    document.execCommand('italic', false, null);
  }

  makeUnderlined() {
    document.execCommand('underline', false, null);
  }

  makeLeft() {
    document.execCommand('justifyLeft', false, null);
  }

  makeCenter() {
    document.execCommand('justifyCenter', false, null);
  }

  makeRight() {
    document.execCommand('justifyRight', false, null);
  }
  insertUnorderedList() {
    document.execCommand('insertUnorderedList', false, null);
  }


  insertOrderedList() {
    document.execCommand('insertOrderedList', false, null);
  }

  createLink() {
    var selected = document.getSelection();
    document.execCommand('createLink', false, 'http://' + selected);
  }
  removeLink() {
    document.execCommand('unlink', false, null);
  }

  generateHtmlCode() {
    HtmlElement2($("#editor"));

    function HtmlElement2(elem) {
      InsertHtml2($(elem).html());
    }

    function InsertHtml2(data) {
      var mywindow = window.open();
      mywindow.document.write('<html><head><title>Code</title>');
      mywindow.document.write('</head><body >');
      mywindow.document.write(data.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;"));
      mywindow.document.write('</body></html>');
      mywindow.document.close(); // necessary for IE >= 10
      mywindow.focus(); // necessary for IE >= 10

      return true;
    }

  }


  richTextEditor() {
    $(document).ready(function () {
      $("#subscript").click(function () {
        document.execCommand('subscript', false, null);
      });
      $("#superscript").click(function () {
        document.execCommand('superscript', false, null);
      });
    });
  }

}



