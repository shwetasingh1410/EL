import { Component, OnInit } from '@angular/core';
import { DatepickerComponent } from '../shared/datepicker/datepicker.component';
import * as moment from 'moment/moment';
import { SafeUrl, DomSanitizer } from '@angular/platform-browser';
import { Carrier } from '../carrier-search/carriersearch.model';
import { ClientService } from '../select-client/client.service';
import { Settings } from '../shared/settings/settings.service';
import { LoggedInUser } from '../shared/loggedInUser/LoggedInUser';
import { UseInReportsService } from './use-in-reports.service';

@Component({
  selector: 'use-in-reports',
  templateUrl: './use-in-reports.component.html',
  styleUrls: ['./use-in-reports.component.css'],
  providers: [UseInReportsService]
})

export class UseInReports implements OnInit {
  isDateValid: boolean = true;
  yearly: string;
  subYearlyValue: string;
  subYearly: string;
  year5s: string;
  year4s: string;
  year3s: string;
  year2s: string;
  year1s: string;
  years: string;
  checkYear5: boolean;
  checkYear4: boolean;
  checkYear3: boolean;
  checkYear2: boolean;
  checkYear1: boolean;
  year5: number;
  year4: number;
  year3: number;
  year2: number;
  year1: number;
  today: Date;
  rating: string;
  finance: string;
  movement: string;
  flag: string;
  flag1: string;
  selectedCarriers: Array<Carrier>;
  selectedCarrierIds: Array<number> = [];
  startDate: string=moment().format('DD/MM/YYYY');
  endDate: string=moment().format('DD/MM/YYYY');
  reportName: string;
  accountId: string;
  displayMessage: string;
  pdfSelectionFlag: boolean;
  reportType: string = 'excel';
  onload: boolean;
  showMessageStart: boolean;
  dateErrMsg: string;

  constructor(private _clientService: ClientService, private _useInReportService: UseInReportsService) { }

  ngOnInit() {
    this.startDateChange(this.startDate);
    this.endDateChange(this.endDate);
    this.yearly = "yearly";
    this.subYearly="0";
    this.showMessageStart = false;
    this.setSelectedCarriers();
    this.onload = true;
    this.setYearValues();
    if (this._clientService.getSelectedAccount())
      this.accountId = this._clientService.getSelectedAccount().AccountId;
  }

  selectedOption: string = "rating"

  setRadio(report: string): void {
    this.onload = false;
    this.showMessageStart = false;
    this.selectedOption = report;
    this.reset();
    if (report == 'rating') {
      this.reportName = "Ratings";
    }
    else {
      this.reportName = "Ratings Movement"
    }
    if (report == 'finance') {
      this.clearPdfSelection();
    }
    
  }

  clearPdfSelection() {
    this.reportType = "excel";
  }

  reset() {
    this.reportType = "excel";
    // this.startDate = moment().format('DD/MM/YYYY');
    // this.endDate = moment().format('DD/MM/YYYY');
    this.pdfSelectionFlag = false;
    this.checkYear1 = false;
    this.checkYear2 = false;
    this.checkYear3 = false;
    this.checkYear4 = false;
    this.checkYear5 = false;
    this.yearly = "yearly";
    this.years="";
    this.disableRad2();
    this.dateErrMsg ='';
  }


  getYearsList() {
    if (this.checkYear1 == true) {
      this.year1s = this.year1.toString() + ",";
    }
    else {
      this.year1s = "";
    }
    if (this.checkYear2 == true) {
      this.year2s = this.year2.toString() + ",";
    }
    else {
      this.year2s = "";
    }
    if (this.checkYear3 == true) {
      this.year3s = this.year3.toString() + ",";
    }
    else {
      this.year3s = "";
    }
    if (this.checkYear4 == true) {
      this.year4s = this.year4.toString() + ",";
    }
    else {
      this.year4s = "";
    }
    if (this.checkYear5 == true) {
      this.year5s = this.year5.toString();
    }
    else {
      this.year5s = "";
    }
    this.years = this.year1s + this.year2s + this.year3s + this.year4s + this.year5s;
    this.years = this.years.replace(/,$/, "");    
  }

  selectedQuarter() {
    this.subYearlyValue = this.subYearly;
  }


  isSelected(name: string): boolean {

    if (!this.selectedOption) {
      return false;
    }
    else {
      return (this.selectedOption === name)
    }
  }

  setFlag(f: string) {
    this.flag = f;
  }

  setFlag1(g: string) {
    this.flag1 = g;
  }

  selectedFlag(name: string) {
    if (!this.flag) {
      return (this.flag = "enabled")
    }
    else {
      return (this.flag = "disabled")
    }

  }

  selectedFlag1(name: string) {
    if (!this.flag1) {
      return (this.flag1 = "enabled")
    }
    else {
      return (this.flag1 = "disabled")
    }

  }

  pdfSelection(e): void {
    if (e.target.checked) {
      this.pdfSelectionFlag = true;
      this.reportType = 'pdf';
    }
    else {
      this.pdfSelectionFlag = false;
      this.reportType = 'excel';
    }
  }

  startDateManual(startDate): void {
    this.startDate=startDate.target.value;
    this.isDateValid = moment(this.startDate, 'DD/MM/YYYY', true).isValid();
    this.startDate = this.startDate.split("/").join("-");
  }

  endDateManual(endDate): void {
    this.endDate=endDate.target.value;
    this.isDateValid = moment(this.endDate, 'DD/MM/YYYY', true).isValid();
    this.endDate = this.endDate.split("/").join("-");
  }
  

  startDateChange(startDate : string): void {
    this.isDateValid =true;
    this.startDate = startDate.split("/").join("-");
  }

  endDateChange(endDate : string): void {
    this.isDateValid = true;
    this.endDate = endDate.split("/").join("-");
  }

  setSelectedCarriers() {
    this.selectedCarriers = this._clientService.getCarriersReport();
    if (this.selectedCarriers != null && this.selectedCarriers != undefined) {
      this.selectedCarriers.forEach(carrier => {
        this.selectedCarrierIds.push(carrier.CarrierNumberId);
      })
    }
  }

  validateRatingsReport() {
    var dateOne = this.startDate.split("-").reverse().join("/");
    var dateTwo = this.endDate.split("-").reverse().join("/");
      var d1 = Date.parse(dateOne);
      var d2 = Date.parse(dateTwo);
      if(d2 < d1) {
        this.showMessageStart = true;
        this.dateErrMsg = ' Start Date cannot be greater than End Date';
        return false;
      } 
    if (this.selectedOption == 'rating' || this.selectedOption == 'movement') {
      if(this.isDateValid == false){
        this.showMessageStart = true;
        this.dateErrMsg = 'Please enter valid date';
        return false;
      }
      if (this.startDate == undefined || this.startDate == null || this.startDate == '') {
        if (this.endDate == undefined || this.endDate == null || this.endDate == '') {
          this.showMessageStart = true;
          this.dateErrMsg = 'Please select both start and end date.'
          return false;
        } else {
          this.showMessageStart = true;
          this.dateErrMsg = 'Please select start date.'
          return false;
        }
      }
      if (this.endDate == undefined || this.endDate == null || this.endDate == '') {
        if (this.startDate == undefined || this.startDate == null || this.startDate == '') {
          this.showMessageStart = true;
          this.dateErrMsg = 'Please select both start and end date.'
          return false;
        } else {
          this.showMessageStart = true;
          this.dateErrMsg = 'Please select end date.'
          return false;
        }
      }
    }
    return true;
  }

  validateFinanceReport()
  {
    if (this.yearly == "yearly" && (this.years == undefined || this.years == null || this.years == '')) {
      this.showMessageStart = true;
      this.dateErrMsg = 'Please select year(s).'
      return false;
    }

    return true;
  }

  generateReport(type: string) {
    if ((this.selectedOption == 'rating' || this.selectedOption == 'movement') && (this.startDate == undefined || this.endDate == undefined)) {
      this.showMessageStart = true;
    } else {
      this.showMessageStart = false;
      if (this.selectedCarrierIds != null && this.selectedCarrierIds != undefined) {
        if (type == 'offline') {
          this.offlineReport();
        }
        else {
          if (this.selectedOption == 'rating') {
            this._useInReportService.getRatingsReportUrl(this.selectedCarrierIds, this.startDate, this.endDate, this.accountId, this.reportType, this.capitalise(this.reportType))
              .subscribe((result) => {
                var folderName = result;
                this._useInReportService.downloadReport(folderName);
              }, (error) => { });
          }
          if (this.selectedOption == 'movement') {
            this._useInReportService.getRatingsMovementReportUrl(this.selectedCarrierIds, this.startDate, this.endDate, this.accountId, this.reportType, this.capitalise(this.reportType))
              .subscribe((result) => {
                var folderName = result;
                this._useInReportService.downloadReport(folderName);
              }, (error) => { });
          }
          if (this.selectedOption == 'finance') {
            this._useInReportService.getFinanceReportUrl(this.selectedCarrierIds, this.years, this.subYearly, this.accountId)
              .subscribe((result) => {
                var folderName = result;
                this._useInReportService.downloadReport(folderName);
              }, (error) => { });
          }
        }
      }
    }
  }

  offlineReport() {
    this.displayMessage = 'Please note that we do not guarantee and are not responsible for the accuracy of this information. ';
    document.getElementById("offlineInfobtn").click();
  }

  generateOfflineReport() {
    if (this.selectedOption == 'rating') {
      this._useInReportService.getOfflineRatingsReportUrl(this.selectedCarrierIds, this.startDate, this.endDate, this.accountId, this.reportType, this.capitalise(this.reportType))
        .subscribe((result) => {
        }, (error) => { });
    }
    if (this.selectedOption == 'movement') {
      this._useInReportService.getOfflineRatingsMovementReportUrl(this.selectedCarrierIds, this.startDate, this.endDate, this.accountId, this.reportType, this.capitalise(this.reportType))
        .subscribe((result) => {
        }, (error) => { });
    }
    if (this.selectedOption == 'finance') {
      this._useInReportService.getOfflineFinanceReportUrl(this.selectedCarrierIds, this.years, this.subYearly, this.accountId)
        .subscribe((result) => {
        }, (error) => { });
    }
  }

  runReport() {
    if (this.selectedOption == 'rating' || this.selectedOption == 'movement') {
      if (this.validateRatingsReport() == true) {
        this.showMessageStart = false;
        if (this.selectedCarrierIds.length < 50) {
          this.displayMessage = 'Please note applicable disclaimers at the end of this report. Disclaimers must not be removed from any reports downloaded from the system. ';
          document.getElementById("onlineModalbtn").click();
          this.generateReport("online");
        }
        if (this.selectedCarrierIds.length >= 50) {
          this.displayMessage = 'This report is too large to be processed online. It will be processed offline and sent to you via email. Do you wish to proceed? ';
          document.getElementById("offlineModalbtn").click();
        }
      }
    }
    if (this.selectedOption == 'finance') {
      if(this.validateFinanceReport()==true){        
        this.showMessageStart = false;       
        if (this.selectedCarrierIds.length < 50) {
          this.displayMessage = 'Please note that we do not guarantee and are not responsible for the accuracy of this information. ';
          document.getElementById("onlineModalbtn").click();
          this.generateReport("online");
        }
        if (this.selectedCarrierIds.length >= 50) {
          this.displayMessage = 'This report is too large to be processed online. It will be processed offline and sent to you via email. Do you wish to proceed? ';
          document.getElementById("offlineModalbtn").click();
        }
      }
    }
  }


  capitalise(text: string) {
    return text.charAt(0).toUpperCase() + text.slice(1);
  }

  setYearValues() {
    let today = new Date();
    this.year5 = today.getFullYear();
    this.year4 = this.year5 - 1; this.year3 = this.year4 - 1; this.year2 = this.year3 - 1; this.year1 = this.year2 - 1;
  }

  disableRad2() {
    if(document.getElementById("onlyLast"))
    (<HTMLInputElement>document.getElementById("onlyLast")).disabled = true;
    if(document.getElementById("lastPlus"))
    (<HTMLInputElement>document.getElementById("lastPlus")).disabled = true;
    if(document.getElementById("corresponding"))
    (<HTMLInputElement>document.getElementById("corresponding")).disabled = true;
    if(document.getElementById("year1"))
    (<HTMLInputElement>document.getElementById("year1")).disabled = false;
    if(document.getElementById("year2"))
    (<HTMLInputElement>document.getElementById("year2")).disabled = false;
    if(document.getElementById("year3"))
    (<HTMLInputElement>document.getElementById("year3")).disabled = false;
    if(document.getElementById("year4"))
    (<HTMLInputElement>document.getElementById("year4")).disabled = false;
    if(document.getElementById("year5"))
    (<HTMLInputElement>document.getElementById("year5")).disabled = false;
    this.subYearly = "0";


  }
  disableRad1() {
    if(document.getElementById("onlyLast"))
    (<HTMLInputElement>document.getElementById("onlyLast")).disabled = false;
    if(document.getElementById("lastPlus"))
    (<HTMLInputElement>document.getElementById("lastPlus")).disabled = false;
    if(document.getElementById("corresponding"))
    (<HTMLInputElement>document.getElementById("corresponding")).disabled = false;
    if(document.getElementById("year1"))
    (<HTMLInputElement>document.getElementById("year1")).disabled = true;
    if(document.getElementById("year2"))
    (<HTMLInputElement>document.getElementById("year2")).disabled = true;
    if(document.getElementById("year3"))
    (<HTMLInputElement>document.getElementById("year3")).disabled = true;
    if(document.getElementById("year4"))
    (<HTMLInputElement>document.getElementById("year4")).disabled = true;
    if(document.getElementById("year5"))
    (<HTMLInputElement>document.getElementById("year5")).disabled = true;
    
    this.checkYear1 = false;
    this.checkYear2 = false;
    this.checkYear3 = false;
    this.checkYear4 = false;
    this.checkYear5 = false;
    this.years="";
    this.subYearly ="1";
    this.subYearlyValue="1";   
    this.showMessageStart =false;
    this.dateErrMsg="";
    this.yearly = "quaterly";
  }
}
