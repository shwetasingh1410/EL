﻿import { Injectable } from '@angular/core';
import { Http, RequestOptions, Headers } from '@angular/http';
import { Observable } from 'rxjs/Rx';
import 'rxjs/add/operator/map';
import { LoggedInUser } from '../shared/loggedInUser/LoggedInUser';
//import { environment } from '../../environments/environment';
import {Settings } from '../shared/settings/settings.service';

@Injectable()
export class UseInReportsService {
    constructor(private _http: Http, private _settings: Settings, private _loggedInUser: LoggedInUser) {
    
    }  
   
    getRatingsReportUrl(reportCarrier:Array<number>, startDate : string, endDate : string, clientId : string, reportType :string, reportTypeText :string) {  
        return this._http.post(this._settings.getReportsUrl() + 'reports/carrier/params/' + 'startDate='+startDate+'|'+'endDate='+endDate+'|reportType=ClientReports|reportSubType=Ratings'+reportTypeText+'|exportReport=true|exportFormat='+reportType,
            JSON.stringify({ 'CarrierId': reportCarrier, 'UserId': this._loggedInUser.getUserId(), 'AccountId': clientId}))
            .map((response) => {
                return response.json();
            });
    }

    getOfflineRatingsReportUrl(reportCarrier:Array<number>, startDate : string, endDate : string, clientId : string, reportType :string, reportTypeText :string) {  
        return this._http.post(this._settings.getReportsUrl() + 'reports/carrier/params/' + 'startDate='+startDate+'|'+'endDate='+endDate+'|reportType=ClientReports|reportSubType=Ratings'+reportTypeText+'|exportReport=true|exportFormat='+reportType+'|processingMode=offline',
            JSON.stringify({ 'CarrierId': reportCarrier, 'UserId': this._loggedInUser.getUserId(), 'AccountId': clientId}))
            .map((response) => {
                return response.json();
            });
    }
    
    getRatingsMovementReportUrl(reportCarrier:Array<number>, startDate : string, endDate : string, clientId : string, reportType :string, reportTypeText :string) {  
        return this._http.post(this._settings.getReportsUrl() + 'reports/carrier/params/' + 'startDate='+startDate+'|'+'endDate='+endDate+'|reportType=ClientReports|reportSubType=RatingsMovement'+reportTypeText+'|exportReport=true|exportFormat='+reportType,
            JSON.stringify({ 'CarrierId': reportCarrier, 'UserId': this._loggedInUser.getUserId(), 'AccountId': clientId}))
            .map((response) => {
                return response.json();
            });
    }

    getOfflineRatingsMovementReportUrl(reportCarrier:Array<number>, startDate : string, endDate : string, clientId : string, reportType :string, reportTypeText :string) {  
        return this._http.post(this._settings.getReportsUrl() + 'reports/carrier/params/' + 'startDate='+startDate+'|'+'endDate='+endDate+'|reportType=ClientReports|reportSubType=RatingsMovement'+reportTypeText+'|exportReport=true|exportFormat='+reportType+'|processingMode=offline',
            JSON.stringify({ 'CarrierId': reportCarrier, 'UserId': this._loggedInUser.getUserId(), 'AccountId': clientId}))
            .map((response) => {
                return response.json();
            });
    }

    getFinanceReportUrl(reportCarrier:Array<number>, years : string, quarter : string, clientId : string) {  
        return this._http.post(this._settings.getReportsUrl() + 'reports/carrier/params/' + 'selectedYear='+years+'|'+'quarter='+quarter+'|reportType=ClientReports|reportSubType=Financial|exportReport=true|exportFormat=excel',
            JSON.stringify({ 'CarrierId': reportCarrier, 'UserId': this._loggedInUser.getUserId(), 'AccountId': clientId}))
            .map((response) => {
                return response.json();
            });
    }

    getOfflineFinanceReportUrl(reportCarrier:Array<number>, years : string, quarter : string, clientId : string) {  
        return this._http.post(this._settings.getReportsUrl() + 'reports/carrier/params/' + 'selectedYear='+years+'|'+'quarter='+quarter+'|reportType=ClientReports|reportSubType=Financial|exportReport=true|exportFormat=excel|processingMode=offline',
            JSON.stringify({ 'CarrierId': reportCarrier, 'UserId': this._loggedInUser.getUserId(), 'AccountId': clientId}))
            .map((response) => {
                return response.json();
            });
    }

    downloadReport(folderName : string) {
        window.open(this._settings.getReportsUrl() + 'reports/carrier/download-file/'+folderName);
    }    
}
    