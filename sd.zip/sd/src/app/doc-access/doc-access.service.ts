import { Injectable } from '@angular/core';
import { Http, RequestOptions, Headers } from '@angular/http';
import { Observable } from 'rxjs/Rx';
import 'rxjs/add/operator/map';

import { Settings } from '../shared/settings/settings.service';
import { DocAccessHelper } from './doc-access.helper';
import { Account,DocumentInfo,FolderInfo,ClientInfo,User,UserInfo } from './doc-access.model';


@Injectable()
export class DocAccessService {
    constructor(private _http: Http, private _settings: Settings) {
    }

    GetAccounts(): Observable<Array<Account>> {
        return this._http.get(this._settings.getApiUrl() + 'api/accounts/active/role-based')
        .map((response) => {
            let result: Array<Account> = new Array<Account>();
            response.json().forEach((account) => {
                result.push(DocAccessHelper.mapToAccountInfo(account));
            });
            return result;
        });
    }

    GetUsers(userName:string): Observable<Array<User>> {
        return this._http.get(this._settings.getDocumentApiUrl() + 'api/document-access/'+userName+'/users')
        .map((response) => {
            let result: Array<User> = new Array<User>();
            response.json().forEach((user) => {
                result.push(DocAccessHelper.mapToUser(user));
            });
            return result;
        });
    }
    
    GetFolder(): Observable<Array<FolderInfo>> {
        return this._http.get(this._settings.getDocumentApiUrl()+'api/document-access')
        .map((response) => {
            let result: Array<FolderInfo> = new Array<FolderInfo>();
            response.json().forEach((folder) => {
                result.push(DocAccessHelper.mapToFolderInfo(folder));
            });
            return result;
        });
    }

    GetDocumentByFolder(FolderPath:string): Observable<Array<DocumentInfo>> {
        return this._http.get(this._settings.getDocumentApiUrl()+'api/documentread/?FolderPath='+FolderPath)
        .map((response) => {
            let result: Array<DocumentInfo> = new Array<DocumentInfo>();
            response.json().forEach((document) => {
                result.push(DocAccessHelper.mapToDocumentInfo(document));
            });
            return result;
        });
    }

    GetUserInfo(userId:string): Observable<Array<UserInfo>> {
        return this._http.get(this._settings.getDocumentApiUrl()+'api/document-access/'+userId+'/user-documents')
        .map((response) => {
            let result: Array<UserInfo> = new Array<UserInfo>();
            response.json().forEach((userDoc) => {
                result.push(DocAccessHelper.mapToUserInfo(userDoc));
            });
            return result;
        });
    }

    GetDocumentsMappedUserInfo(documentKey:string): Observable<Array<UserInfo>> {
        return this._http.get(this._settings.getDocumentApiUrl()+'api/document-access/'+documentKey+'/user-documentsbydockey')
        .map((response) => {
            let result: Array<UserInfo> = new Array<UserInfo>();
            response.json().forEach((userDoc) => {
                result.push(DocAccessHelper.mapToAssociatedUserInfo(userDoc));
            });
            return result;
        });
    }

    GetClientInfo(AccountId:string): Observable<Array<ClientInfo>> {
        let headers = new Headers();
        headers.append('Content-Type', 'application/json');
        let options = new RequestOptions({ headers: headers });
        return this._http.post(this._settings.getDocumentApiUrl()+'api/document-access/client-documents',
            JSON.stringify({
                'AccountId': AccountId
            }), options).map(response => {
                let result: Array<ClientInfo> = new Array<ClientInfo>();
                    response.json().forEach((client) => {
                        result.push(DocAccessHelper.mapToClientInfo(client));
                    });
                    return result;
            });
    }

    GetDocumentsMappedClientInfo(documentKey:string): Observable<Array<ClientInfo>> {
        return this._http.get(this._settings.getDocumentApiUrl()+'api/document-access/'+documentKey+'/client-documentsbydockey')
        .map((response) => {
            let result: Array<ClientInfo> = new Array<ClientInfo>();
            response.json().forEach((client) => {
                result.push(DocAccessHelper.mapToAssociatedClientInfo(client));
            });
            return result;
        });
    }

    PostDocumentForClient(AccountId:string,DocumentKey:string,DocumentName:string,Category:string,DocumentFolderId:string) {
        let headers = new Headers();
        headers.append('Content-Type', 'application/json');
        let options = new RequestOptions({ headers: headers });
        return this._http.post(this._settings.getDocumentApiUrl()+'api/document-access',
            JSON.stringify({
                'AccountId': AccountId,
                'DocumentKey': DocumentKey,
                'DocumentName' : DocumentName,
                'Category':Category,
                'DocumentFolderId':DocumentFolderId
            }), options);
    }

    PostDocumentForUser(UserId:string,DocumentKey:string,DocumentName:string,Category:string,DocumentFolderId:string) {
        let headers = new Headers();
        headers.append('Content-Type', 'application/json');
        let options = new RequestOptions({ headers: headers });
        return this._http.post(this._settings.getDocumentApiUrl()+'api/document-access/createuseraccess',
            JSON.stringify({
                'UserId': UserId,
                'DocumentKey': DocumentKey,
                'DocumentName' : DocumentName,
                'Category':Category,
                'DocumentFolderId':DocumentFolderId
            }), options);
    }

    DeleteDocumentClientInfo(clientDocumentId: string) {
            return this._http.delete(this._settings.getDocumentApiUrl()+'api/document-access/'+clientDocumentId+'/client-document');
    }

    DeleteDocumentUserInfo(userDocumentId: string) {
            return this._http.delete(this._settings.getDocumentApiUrl()+'api/document-access/'+userDocumentId+'/user-document');
    }
    
}
