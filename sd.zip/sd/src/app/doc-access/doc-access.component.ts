import { Component, OnInit } from '@angular/core';
import { TranslateService } from '../translate/translate.service';
import { DocAccessService } from './doc-access.service';
import { Account,FolderInfo,DocumentInfo,ClientInfo,User,UserInfo,AccountAccess,ConsultancyStatus } from './doc-access.model';
import { GridOptions } from "ag-grid";
import { DocAccessDeleteComponent } from './doc-access-delete/doc-access-delete.component';
import { DocAccessEvents } from './doc-access.events';
import { LoggedInUser } from '../shared/loggedInUser/LoggedInUser';
import { LoaderService } from '../shared/loaderComponent/Loader.service';


declare var $:any;
//import $ from 'jquery';

@Component({
  selector: 'app-doc-access',
  templateUrl: './doc-access.component.html',
  styleUrls: ['./doc-access.component.css'],
  providers: [DocAccessService,DocAccessEvents,LoggedInUser]
})
export class DocAccessComponent implements OnInit {
  clientView=false;
  documentView=true;
  userView=false;
  gridOptions: GridOptions;
  gridOptionsDocumentClient: GridOptions;
  gridOptionsUser: GridOptions;
  gridOptionsDocumentUser: GridOptions;
  accountList:Array<Account>=[];
  clientList:Array<ClientInfo>=[];
  userDocumentList:Array<UserInfo>=[];
  documentFolderList:Array<FolderInfo>=[];
  documentList:Array<DocumentInfo>=[];
  allDocumentList:Array<DocumentInfo>=[];
  userList:Array<User>=[];
  selectedFolderName:string;
  selectedDocument:DocumentInfo;
  selectedDoc:DocumentInfo;
  selectedFolder:FolderInfo;
  selectedAccount:Account;
  selectedUser:User;
  success:boolean=false;
  successUser:boolean=false;
  accountExist:boolean=false;
  userExist:boolean=false;
  accountDocumentExist:boolean=false;
  userDocumentExist:boolean=false;
  error:boolean=false;
  errorUser:boolean=false;
  errorFields:boolean=false;
  userName:string='';
  searchResults:boolean=false;
  selectedUserName:string='';
  searchMessage:string='';
  selectedIndex:number;
  errFolderName:boolean=false;
  errClientName:boolean=false;
  errUserName:boolean=false;
  errDocumentName:boolean=false;
  errDocName:boolean=false;
  errMsgClient:string='';
  errMsgDocument:string='';
  errMsgUser:string='';
  errMsgFolder:string='';

  constructor(private _loaderService:LoaderService,private _loggedInUser:LoggedInUser, private _translate: TranslateService, private _docAccessService:DocAccessService, private _docAccessEvents:DocAccessEvents) { }

  ngOnInit() {
    //$.getScript('./assets/scripts/init.js');
    this.selectLang('en');
    this.reload();
    this._loaderService.show();
    this._docAccessEvents.folderDeleteEvent.subscribe(
      (showMenu) => {
        if(this.selectedDoc){
        this._loaderService.hide();
        this.getDocumentsAssociatedToClientInfo();
        }
        else{
        this._loaderService.hide();
        this.getDocumentClientInfo();
        }
      }
    );
    this._docAccessEvents.folderDeleteUserEvent.subscribe(
      (showMenu) => {
        if(this.selectedDoc){
          this._loaderService.hide();
        this.getDocumentsAssociatedToUserInfo();
        }
        else{
          this._loaderService.hide();
        this.getDocumentUserInfo();
        }
      }
    );
  }

  reload() {
    this.selectedDocument=null;
    this.selectedFolder=null;
    this.selectedUser=null;
    this.errUserName=false;
    this.errClientName=false;
    this.errFolderName=false;
    this.errDocumentName=false;
    this.errDocName=false;
    this.errMsgDocument='';
    this.errMsgClient='';
    this.errMsgUser='';
    this.errMsgFolder='';
    this.selectedAccount=null;
    this.errorFields=false;
    this.selectedDoc=undefined;
    this.searchMessage='';
    this.accountExist=false;
    this.userExist=false;
    this.accountDocumentExist=false;
    this.userDocumentExist=false;
    this.selectedFolderName='';
    this.documentList=[];
    this.allDocumentList=[];
    this.accountList=[];
    this.documentFolderList=[];
    this.selectedUserName='';
    this.getAccounts();
    this.getFolderInfo();
    this.loadClient();
    this.loadUser();
    this.loadDocumentClient();
    this.loadDocumentUser();
  }

  loadClient() {
    this.gridOptions = <GridOptions>{};
    this.gridOptions.rowSelection = 'multiple';
    this.gridOptions.suppressMenuHide= true;
    this.gridOptions.enableSorting = true;    
    this.gridOptions.rowHeight = 40;
    this.gridOptions.headerHeight = 40;
    this.gridOptions.columnDefs = [
      {
        headerName: "Category",
        field: 'Category',
        width: 170,
        cellStyle: { 'white-space': 'normal' }
      },
      {
        headerName: "Document",
        field: "DocumentName",
        width: 150,
        cellStyle: { 'white-space': 'normal' }
      },
      {
        headerName: "Client",
        field: 'ClientName',
        width: 220,
        cellStyle: { 'white-space': 'normal' }
      },
      {
        headerName: "Delete",
        cellRendererFramework: DocAccessDeleteComponent,
        width: 50,
        cellStyle: { 'white-space': 'normal' }
      }
    ];
    this.gridOptions.columnTypes={
      'EditableColumn' : {editable:true}
    };
    this.gridOptions.rowData=[];
  }

  loadDocumentClient() {
    this.gridOptionsDocumentClient = <GridOptions>{};
    this.gridOptionsDocumentClient.rowSelection = 'multiple';
    this.gridOptionsDocumentClient.suppressMenuHide= true;
    this.gridOptionsDocumentClient.enableSorting = true;
    this.gridOptionsDocumentClient.rowHeight = 40;
    this.gridOptionsDocumentClient.headerHeight = 40;
    this.gridOptionsDocumentClient.columnDefs = [
      
      {
        headerName: "Document",
        field: "DocumentName",
        width: 295,
        cellStyle: { 'white-space': 'normal' }
      },
      {
        headerName: "Client",
        field: 'ClientName',
        width: 250,
        cellStyle: { 'white-space': 'normal' }
      },
      {
        headerName: "Delete",
        cellRendererFramework: DocAccessDeleteComponent,
        width: 55,
        cellStyle: { 'white-space': 'normal' }
      }
    ];
    this.gridOptionsDocumentClient.columnTypes={
      'EditableColumn' : {editable:true}
    };
    this.gridOptionsDocumentClient.rowData=[];
  }

  loadUser() {
    this.gridOptionsUser = <GridOptions>{};
    this.gridOptionsUser.rowSelection = 'multiple';
    this.gridOptionsUser.suppressMenuHide= true;
    this.gridOptionsUser.enableSorting = true;    
    this.gridOptionsUser.rowHeight = 40;
    this.gridOptionsUser.headerHeight = 40;
    this.gridOptionsUser.columnDefs = [
      {
        headerName: "Category",
        field: 'Category',
        width: 170,
        cellStyle: { 'white-space': 'normal' }
      },
      {
        headerName: "Document",
        field: "DocumentName",
        width: 150,
        cellStyle: { 'white-space': 'normal' }
      },
      {
        headerName: "User",
        field: 'UserName',
        width: 215,
        cellStyle: { 'white-space': 'normal' }
      },
      {
        headerName: "Delete",
        cellRendererFramework: DocAccessDeleteComponent,
        width: 55,
        cellStyle: { 'white-space': 'normal' }
      }
    ];
    this.gridOptionsUser.columnTypes={
      'EditableColumn' : {editable:true}
    };
    this.gridOptionsUser.rowData=[];
  }

  loadDocumentUser() {
    this.gridOptionsDocumentUser = <GridOptions>{};
    this.gridOptionsDocumentUser.rowSelection = 'multiple';
    this.gridOptionsDocumentUser.suppressMenuHide= true;
    this.gridOptionsDocumentUser.enableSorting = true;    
    this.gridOptionsDocumentUser.rowHeight = 40;
    this.gridOptionsDocumentUser.headerHeight = 40;
    this.gridOptionsDocumentUser.columnDefs = [
      
      {
        headerName: "Document",
        field: "DocumentName",
        width: 305,
        cellStyle: { 'white-space': 'normal' }
      },
      {
        headerName: "User",
        field: 'UserName',
        width: 240,
        cellStyle: { 'white-space': 'normal' }
      },
      {
        headerName: "Delete",
        cellRendererFramework: DocAccessDeleteComponent,
        width: 55,
        cellStyle: { 'white-space': 'normal' }
      }
    ];
    this.gridOptionsDocumentUser.columnTypes={
      'EditableColumn' : {editable:true}
    };
    this.gridOptionsDocumentUser.rowData=[];
  }

  getAccounts(){
    this._loaderService.show();
    this._docAccessService.GetAccounts().subscribe(result => {
      if(result){
        this.accountList=result;
        var msdbuDropdown;
        var msdDropdown;
        msdDropdown=this.accountList.filter(client => client.AccessLevel== AccountAccess.AllAdmins);
        msdbuDropdown=this.accountList.filter(client => client.AccessLevel== AccountAccess.AllAdmins && client.ConsultancyStatus==ConsultancyStatus.NonConsultancy);
        if(this._loggedInUser.getUserRoleCode() === 'MSDAdmin') {
          this._loaderService.hide();
          this.accountList=msdDropdown;
        }
        if(this._loggedInUser.getUserRoleCode() === 'MSDBUAdmin') {
          this._loaderService.hide();
          this.accountList=msdbuDropdown;
        }
      }
    }, (error) =>{ 
      this._loaderService.hide();
    });
  }

  getFolderInfo(){
    this._loaderService.show();
    this._docAccessService.GetFolder().subscribe(result => {
      if(result){
        this.documentFolderList=result;
        this._loaderService.hide();
      }
    }, (error) =>{ 
      this._loaderService.hide();
     });
  }

  onFolderChange(folder) {
    if(folder){
      this.selectedFolder=folder;
      this.selectedFolderName=folder.DocumentFolder;
      if(this.selectedFolderName)
      this.getDocumentInfo(this.selectedFolderName);
    }else{
      this.selectedFolderName='';
      this.selectedDocument=undefined;
      this.documentList=[];
    }
  }

  onAccountChange(account) {
    if(account){
      this.selectedAccount=account;
      this.getDocumentClientInfo();
    }
    else{
      this.accountExist=false;
      this.selectedAccount=undefined;
    }
  }

  getDocumentInfo(folderPath:string){
    this._loaderService.show();
    this._docAccessService.GetDocumentByFolder(folderPath).subscribe(result => {
      if(result){
        this._loaderService.hide();
        this.documentList=result;
      }
    }, (error) =>{ 
      this._loaderService.hide();
    });
  }

  addDocumentForClient() {
    if(this.selectedAccount){
      
    }else{
      this.errMsgClient='Please select a client'
      this.errClientName=true;
      setTimeout(() => {
        this.errClientName = false;
      }, 2000);
    }
    if(this.selectedFolder){
      
    }else{
      this.errMsgFolder='Please select a folder'
      this.errFolderName=true;
      setTimeout(() => {
        this.errFolderName = false;
      }, 2000);
    }
    if(this.selectedDocument){
      
    }else{
      this.errMsgDocument='Please select a document'
      this.errDocumentName=true;
      setTimeout(() => {
        this.errDocumentName = false;
      }, 2000);
    }

    if(this.selectedDoc){
      
    }else{
      this.errMsgDocument='Please select a document'
      this.errDocName=true;
      setTimeout(() => {
        this.errDocName = false;
      }, 2000);
    }
    if(!this.selectedDoc){
      if(this.selectedAccount && this.selectedDocument && this.selectedFolder){
        if(this.selectedDocument.DocumentId && this.selectedDocument.DocumentName && this.selectedDocument.Category && this.selectedAccount.AccountId && this.selectedFolder.DocumentFolderId) {
          let index = this.clientList.findIndex(client => client.DocumentName == this.selectedDocument.DocumentName);
          if(index == -1) {
            this._docAccessService.PostDocumentForClient(this.selectedAccount.AccountId,this.selectedDocument.DocumentId,this.selectedDocument.DocumentName,this.selectedDocument.Category,this.selectedFolder.DocumentFolderId).subscribe(result => {
              this.getDocumentClientInfo();
              this.selectedDocument=null;
              this.selectedDoc=null;
              this.selectedFolder=null;
              this.success = true;
              setTimeout(() => {
                this.success = false;
              }, 2000);
            });
          }else{
            this.error=true;
            setTimeout(() => {
              this.error = false;
            }, 2000);
          }
        }
      }else{
      }
    }else{
      if(this.selectedAccount && this.selectedDoc && this.selectedFolder){
        if(this.selectedDoc.DocumentId && this.selectedDoc.DocumentName && this.selectedDoc.Category && this.selectedAccount.AccountId && this.selectedFolder.DocumentFolderId) {
          let index = this.clientList.findIndex(client => client.ClientName == this.selectedAccount.PartyName);
          if(index == -1) {
            this._docAccessService.PostDocumentForClient(this.selectedAccount.AccountId,this.selectedDoc.DocumentId,this.selectedDoc.DocumentName,this.selectedDoc.Category,this.selectedFolder.DocumentFolderId).subscribe(result => {
              this.getDocumentsAssociatedToClientInfo();
              this.selectedAccount=null;
              this.success = true;
              setTimeout(() => {
                this.success = false;
              }, 2000);
            });
          }else{
            this.error=true;
            setTimeout(() => {
              this.error = false;
            }, 2000);
          }
        }
      } else{
      }
    }
    
  }

  getDocumentClientInfo() {
    if(this.selectedAccount){
      if(this.selectedAccount.AccountId){
        this._loaderService.show();
        this._docAccessService.GetClientInfo(this.selectedAccount.AccountId).subscribe(result => {
          this.clientList=result;
          this.accountExist=true;
          if(this.gridOptions.api){
            this.gridOptions.api.setRowData(this.clientList);
            this._loaderService.hide();
          }else{
            this.gridOptions.rowData=this.clientList;
            this._loaderService.hide();
          }
        });
      }
    }
    this.accountExist=false;
  }


  // User Specific Functionality Starts

  

  resetUser() {
    this.userName='';
    this.selectedUserName='';
    this.selectedIndex=null;
    this.searchMessage='';
    this.searchResults=false;
  }

  fetchUser() {
    this._loaderService.show();
    this.searchMessage='';
    this.userName=this.selectedUserName;
    this.searchResults=false;
    this.searchMessage='Please wait while your request is being processed...'
    if(this.userName) {
      this._docAccessService.GetUsers(this.userName).subscribe(result => {
        this.searchMessage=''
        this.userList=result;
        this.searchResults=true;
    document.getElementById("userselect").click();
    this._loaderService.hide();
      }, (error) =>{ 
        this._loaderService.hide();
      });
    }
    else{
      this.searchMessage='Please enter some search criteria.';
      this.searchResults=false;
      this._loaderService.hide();
    }
  }

  bindUser(){
    this.selectedUser=this.userList[this.selectedIndex];
    this.selectedUserName=this.userList[this.selectedIndex].DisplayName;
    this.searchResults=false;
    this.searchMessage='';
    this.userName='';
    if(this.selectedDoc){

    }else
    this.getDocumentUserInfo();
  }

  getDocumentUserInfo() {
    this._loaderService.show();
    if(this.selectedUser){
      if(this.selectedUser.UserId){
        this._docAccessService.GetUserInfo(this.selectedUser.UserId).subscribe(result => {
          this.userDocumentList=result;
          this.userExist=true;
          if(this.gridOptionsUser.api){
            this.gridOptionsUser.api.setRowData(this.userDocumentList);
            this._loaderService.hide();
          }else{
            this.gridOptionsUser.rowData=this.userDocumentList;
            this._loaderService.hide();
          }
        }, (error) =>{ 
          this._loaderService.hide();
        });
      }
    }else{
      this._loaderService.hide();
      this.userExist=false;
    }
  }

  addDocumentForUser() {
    if(this.selectedDoc){
      
    }else{
      this.errMsgDocument='Please select a document'
      this.errDocName=true;
      setTimeout(() => {
        this.errDocName = false;
      }, 3000);
    }
    if(this.selectedUserName){
      
    }else{
      this.errMsgUser='Please select a user'
      this.errUserName=true;
      setTimeout(() => {
        this.errUserName = false;
      }, 3000);
    }
    if(this.selectedFolder){
      
    }else{
      this.errMsgFolder='Please select a folder'
      this.errFolderName=true;
      setTimeout(() => {
        this.errFolderName = false;
      }, 3000);
    }
    if(this.selectedDocument){
      
    }else{
      this.errMsgDocument='Please select a document'
      this.errDocumentName=true;
      setTimeout(() => {
        this.errDocumentName = false;
      },3000);
    }
    if(!this.selectedDoc){
      if(this.selectedDocument){
        
      }else{
        this.errMsgDocument='Please select a document'
        this.errDocumentName=true;
        setTimeout(() => {
          this.errDocumentName = false;
        }, 3000);
      }
      if(this.selectedUser && this.selectedDocument && this.selectedFolder){
        if(this.selectedDocument.DocumentId && this.selectedDocument.DocumentName && this.selectedDocument.Category && this.selectedUser.UserId && this.selectedFolder.DocumentFolderId) {
          let index = this.userDocumentList.findIndex(userDoc => userDoc.DocumentName == this.selectedDocument.DocumentName);
          if(index == -1) {
            this._docAccessService.PostDocumentForUser(this.selectedUser.UserId,this.selectedDocument.DocumentId,this.selectedDocument.DocumentName,this.selectedDocument.Category,this.selectedFolder.DocumentFolderId).subscribe(result => {
              this.getDocumentUserInfo();
              this.selectedDocument=null;
              this.selectedFolder=null;
              this.successUser = true;
              setTimeout(() => {
                this.successUser = false;
              }, 3000);
            });
          }else{
            this.errorUser=true;
            setTimeout(() => {
              this.errorUser = false;
            }, 3000);
          }
        }
      }else{
        
      }
    }
    else{
      if(this.selectedUser && this.selectedDoc && this.selectedFolder){
        if(this.selectedDoc.DocumentId && this.selectedDoc.DocumentName && this.selectedDoc.Category && this.selectedUser.UserId && this.selectedFolder.DocumentFolderId) {
          let index = this.userDocumentList.findIndex(userDoc => userDoc.UserName == this.selectedUser.DisplayName);
          if(index == -1) {
            this._docAccessService.PostDocumentForUser(this.selectedUser.UserId,this.selectedDoc.DocumentId,this.selectedDoc.DocumentName,this.selectedDoc.Category,this.selectedFolder.DocumentFolderId).subscribe(result => {
              this.getDocumentsAssociatedToUserInfo();
              this.selectedUser=null;
              this.selectedUserName=null;
              this.successUser = true;
              setTimeout(() => {
                this.successUser = false;
              }, 3000);
            });
          }else{
            this.errorUser=true;
            setTimeout(() => {
              this.errorUser = false;
            }, 3000);
          }
        }
      }else{
        
      }
    }
  }

  // User Specific Functionality Ends


  // Document Specific Functionality Starts

  onFolderChangeinDocument(folder){
    if(folder){
      this.selectedFolder=folder;
      this.selectedFolderName=folder.DocumentFolder;
      if(this.selectedFolderName)
      this.getAllDocuments(this.selectedFolderName);
    }else{
      this.selectedFolderName='';
      this.selectedDocument=undefined;
      this.allDocumentList=[];
    }

  }

  getAllDocuments(folderPath:string){
    this._loaderService.show();
    var folderPath=folderPath;
    this._docAccessService.GetDocumentByFolder(folderPath).subscribe(result => {
      if(result){
        this.allDocumentList=result;
        this._loaderService.hide();
      }
    })
  }


  onAccountChangeInDocument(account) {
    if(account){
      this.selectedAccount=account;
    }else{
      this.selectedAccount=undefined;
    }
  }

  onDocumentChange(document) {
    if(document){
      this.selectedDoc=document;
      this.getDocumentsAssociatedToClientInfo();
      this.getDocumentsAssociatedToUserInfo();
    }else{
      this.selectedDoc=undefined;
      this.accountDocumentExist=false;
      this.userDocumentExist=false;
    }
  }

  getDocumentsAssociatedToClientInfo() {
    this._loaderService.show();
    if(this.selectedDoc){
      if(this.selectedDoc.DocumentId){
        this._docAccessService.GetDocumentsMappedClientInfo(this.selectedDoc.DocumentId).subscribe(result => {
          this.clientList=result;
          this.accountDocumentExist=true;
          if(this.gridOptionsDocumentClient.api){
            this._loaderService.hide();
            this.gridOptionsDocumentClient.api.setRowData(this.clientList);
          }else{
            this._loaderService.hide();
            this.gridOptionsDocumentClient.rowData=this.clientList;
          }
        });
      }
    }else{
      this._loaderService.hide();
      this.accountDocumentExist=false;
    }

  }

  getDocumentsAssociatedToUserInfo() {
    this._loaderService.show();
    if(this.selectedDoc){
      if(this.selectedDoc.DocumentId){
        this._docAccessService.GetDocumentsMappedUserInfo(this.selectedDoc.DocumentId).subscribe(result => {
          this.userDocumentList=result;
          this.userDocumentExist=true;
          if(this.gridOptionsDocumentUser.api){
            this._loaderService.hide();
            this.gridOptionsDocumentUser.api.setRowData(this.userDocumentList);
          }else{
            this._loaderService.hide();
            this.gridOptionsDocumentUser.rowData=this.userDocumentList;
          }
        });
      }
    }else{
      this._loaderService.hide();
      this.userDocumentExist=false;
    }
  }

  // Document Specific Functionality Ends

  selectLang(lang: string) {
    this._translate.use(lang);
  }

  shuffleview(data) {
    if(data=='1') {
      this.reload();
      this.documentView=true;
      this.clientView=false;
  this.userView=false;
    }

    if(data=='2') {
      this.reload();
      this.documentView=false;
      this.clientView=true;
  this.userView=false;
    }

    if(data=='3') {
      this.reload();
      this.documentView=false;
      this.clientView=false;
      this.userView=true;
    }
  }

}
