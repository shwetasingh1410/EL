import { Component, OnInit } from '@angular/core';
import { DocAccessService } from '../doc-access.service';
import {DocAccessEvents} from '../doc-access.events';

@Component({
  selector: 'app-doc-access-delete',
  templateUrl: './doc-access-delete.component.html',
  styleUrls: ['./doc-access-delete.component.css']
})
export class DocAccessDeleteComponent implements OnInit {

  private params: any;
  clientDocumentId:string;
  userDocumentId:string;
  constructor( private _docAccessService:DocAccessService, private _docAccessEvents:DocAccessEvents) { }

  ngOnInit() {
  }

  agInit(params: any): void {
    this.params = params;
  }

deletefromgrid() {
  console.log('deleted'+this.params);
  if(this.params){
    this.clientDocumentId=this.params.data.ClientDocumentId;
    this.userDocumentId=this.params.data.UserDocumentId;
    if(this.clientDocumentId){
      if(confirm('Are you sure you want to delete this folder?'))
      this._docAccessService.DeleteDocumentClientInfo(this.clientDocumentId).subscribe(result => {
        // this._docFolderComponent.getFolderInfo();
        this._docAccessEvents.folderDeleteEvent.emit(true);
      })
    }
    if(this.userDocumentId){
      if(confirm('Are you sure you want to delete this folder?'))
      this._docAccessService.DeleteDocumentUserInfo(this.userDocumentId).subscribe(result => {
        // this._docFolderComponent.getFolderInfo();
        this._docAccessEvents.folderDeleteUserEvent.emit(true);
      })
    }
  }
}
}
