import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DocAccessDeleteComponent } from './doc-access-delete.component';

describe('DocAccessDeleteComponent', () => {
  let component: DocAccessDeleteComponent;
  let fixture: ComponentFixture<DocAccessDeleteComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DocAccessDeleteComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DocAccessDeleteComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
