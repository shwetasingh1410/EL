export class Account {
    public Id: string;
    public SubscriptionId: string;
    public PartyId: number;
    public AccountId:string;
    public PartyName: string;
    public ConsultancyStatus: ConsultancyStatus;
    public AssociateAllCarriers: boolean;
    public AccessLevel: AccountAccess;
    public DisplayPartyName: string;

    constructor(Id: string, SubscriptionId: string, PartyId: number,AccountId:string, PartyName: string, ConsultancyStatus: ConsultancyStatus,
        AssociateAllCarriers: boolean, AccessLevel: AccountAccess) {
        this.Id = Id;
        this.SubscriptionId = SubscriptionId;
        this.PartyId = PartyId;
        this.AccountId = AccountId;
        this.PartyName = PartyName;
        this.ConsultancyStatus = ConsultancyStatus;
        this.AssociateAllCarriers = AssociateAllCarriers;
        this.AccessLevel = AccessLevel;

        if (ConsultancyStatus == 0)
            this.DisplayPartyName = PartyName + "(Non-Consultancy)";
        else
            this.DisplayPartyName = PartyName + "(Consultancy)";
    }
}

export class FolderInfo {
    DocumentFolderId: string;
    DocumentFolder: string;
    ClientAccess:string;

    constructor(DocumentFolderId: string, DocumentFolder:string, ClientAccess:string ) {
        this.DocumentFolderId = DocumentFolderId;
        this.DocumentFolder = DocumentFolder;
        this.ClientAccess = ClientAccess;
    }
}

export class DocumentInfo {
    DocumentId: string;
    DocumentName: string;
    Category:string;

    constructor(DocumentId: string, DocumentName:string,Category:string) {
        this.DocumentId = DocumentId;
        this.DocumentName = DocumentName;
        this.Category=Category;
    }
}

export class ClientInfo {
    ClientDocumentId: string;
    DocumentKey: string;
    DocumentName:string;
    AccountId:string;
    ClientName:string;
    Category:string;

    constructor(ClientDocumentId: string, DocumentKey:string,DocumentName:string,Category:string,AccountId:string,ClientName:string) {
        this.ClientDocumentId = ClientDocumentId;
        this.DocumentKey = DocumentKey;
        this.DocumentName = DocumentName;
        this.Category=Category;
        this.AccountId = AccountId;
        this.ClientName = ClientName;
    }
}

export class User {
    UserId:string;
    PrincipalId:string;
    DisplayName:string;
    EmailAddress:string;

    constructor(UserId: string, PrincipalId:string,DisplayName:string,EmailAddress:string) {
        this.UserId = UserId;
        this.PrincipalId = PrincipalId;
        this.DisplayName = DisplayName;
        this.EmailAddress = EmailAddress;
    }
}

export class UserInfo {
    UserDocumentId:string;
    DocumentKey:string; 
    DocumentName:string;
    UserId:string;
    UserName:string;
    Category:string;

    constructor(UserDocumentId: string, DocumentKey:string,DocumentName:string,Category:string,UserId:string,UserName:string) {
        this.UserDocumentId = UserDocumentId;
        this.DocumentKey = DocumentKey;
        this.DocumentName = DocumentName;
        this.Category=Category;
        this.UserId = UserId;
        this.UserName = UserName;
    }
}

export enum ConsultancyStatus {
    NonConsultancy = 0,
    Consultancy
}

export enum AccountAccess {
    SuperUsersOnly,
    AllAdmins
    
}