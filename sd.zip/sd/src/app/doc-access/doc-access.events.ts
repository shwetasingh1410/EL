import { Injectable, EventEmitter } from '@angular/core';

@Injectable()
export class DocAccessEvents {
    folderDeleteEvent: EventEmitter<any> = new EventEmitter();
    folderDeleteUserEvent: EventEmitter<any> = new EventEmitter();
}