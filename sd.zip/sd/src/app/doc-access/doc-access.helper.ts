import { Account, DocumentInfo, FolderInfo, ClientInfo, User, UserInfo } from './doc-access.model';

export class DocAccessHelper {

    static mapToAccountInfo(party: any): Account {
        return new Account(party.Id, party.SubscriptionId, party.PartyId, party.AccountId, party.PartyName, party.ConsultancyStatus,
            party.AssociateAllCarriers, party.AccessLevel);
    }
    
    static mapToFolderInfo(folder: any): FolderInfo {
        return new FolderInfo(folder.DocumentFolderId,folder.DocumentFolder,folder.ClientAccess);
    }

    static mapToDocumentInfo(document: any): DocumentInfo {
        return new DocumentInfo(document.DocumentId,document.DocumentName,document.Category);
    }

    static mapToClientInfo(client: any): ClientInfo {
        return new ClientInfo(client.ClientDocumentId,client.DocumentKey,client.DocumentName,client.Category,client.AccountId,client.ClientName);
    }

    static mapToAssociatedClientInfo(client: any): ClientInfo {
        return new ClientInfo(client.ClientDocumentId,client.DocumentKey,client.DocumentName,'',client.AccountId,client.ClientName);
    }

    static mapToUser(user: any): User {
        return new User(user.UserId,user.PrincipalId,user.DisplayName,user.EmailAddress);
    }

    static mapToUserInfo(userDoc: any): UserInfo {
        return new UserInfo(userDoc.UserDocumentId,userDoc.DocumentKey,userDoc.DocumentName,userDoc.Category,userDoc.UserId,userDoc.UserName);
    }

    static mapToAssociatedUserInfo(userDoc: any): UserInfo {
        return new UserInfo(userDoc.UserDocumentId,userDoc.DocumentKey,userDoc.DocumentName,'',userDoc.UserId,userDoc.UserName);
    }
}
