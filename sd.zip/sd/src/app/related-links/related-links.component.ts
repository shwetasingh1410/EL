import { Component, OnInit } from '@angular/core';
import { TranslateService } from '../translate/translate.service';

declare var $: any;
@Component({
  selector: 'app-related-links',
  templateUrl: './related-links.component.html',
  styleUrls: ['./related-links.component.css']
})
export class RelatedLinksComponent implements OnInit {
  constructor(private _translate: TranslateService) {
    
  }

  ngOnInit() {
    this._translate.use('en');

  }
}