import { DomSanitizer } from '@angular/platform-browser';
import { Component, OnInit, OnChanges, AfterContentInit, SecurityContext } from '@angular/core';
import { DisclaimersService } from './disclaimers.service';
import { RatingAgency, RatingAgencyDisclaimer, WTWDisclaimer } from './disclaimers.model';
import { LoaderService } from '../shared/loaderComponent/Loader.service';
import { TranslateService } from '../translate/translate.service';
//import $ from 'jQuery';
declare var $: any;
@Component({
  selector: 'app-disclaimers',
  templateUrl: './disclaimers.component.html',
  styleUrls: ['./disclaimers.component.css'],
  providers: [DisclaimersService]
})
export class DisclaimersComponent implements OnInit, AfterContentInit {
  n : number;
  text: string;
  disclaimer: string;
  IsHidden: boolean;
  result: Array<RatingAgency>;
  disclaimerResult: RatingAgencyDisclaimer;
  WTWdisclaimerResult: WTWDisclaimer;
  isError: boolean;
  isSuccess: boolean;
  isAlert: boolean;
  message: string;
  saveSuccess: false;
  RatingAgencyDisclaimer: RatingAgencyDisclaimer
  Id: number;
  RatingAgencyId: number;
  UpdatedRatingAgencyDisclaimer: RatingAgencyDisclaimer;
  disclaimerTextPlain: string;

  constructor(private _disclaimerService: DisclaimersService, private _loaderService: LoaderService, private _translate: TranslateService, private _sanitizer: DomSanitizer) {
    this.Id = 0;
    this.RatingAgencyId = 0;
    this.disclaimer = '';
    this.IsHidden = true;
    this.disclaimerTextPlain = '';
  }

  ngOnInit() {
    this.richTextEditor();
    this._translate.use('en');
  }

  ngAfterContentInit(): void {
    this.GetRatingAgencies();
    // $.getScript('./assets/scripts/richTextEditor.js');
    this.richTextEditor();
  }

  setHidden() {
    this.IsHidden = !this.IsHidden;
  }

  GetDisclaimer() {
    //$.getScript('./assets/scripts/richTextEditor.js');
     this._loaderService.show();
    this.isAlert = false;
    this.isSuccess = false;
    this.isError = false;
    this._disclaimerService.GetDisclaimer().subscribe(WTWdisclaimerResult => {
        this.WTWdisclaimerResult = WTWdisclaimerResult;
        this.disclaimer = this._sanitizer.sanitize(SecurityContext.HTML, WTWdisclaimerResult.DisclaimerText);
        $('#editor').html(this.disclaimer);
      //this.disclaimer = WTWdisclaimerResult.DisclaimerText;
      this.IsHidden = WTWdisclaimerResult.IsHidden;
       this._loaderService.hide();
      }, (error) =>{ 
        this._loaderService.hide();
        this.handleError(error)});
  }

  GetRatingAgencies() {
    this._loaderService.show();
    this.isAlert = false;
    this.isSuccess = false;
    this.isError = false;
    this._disclaimerService.GetRatingAgencies().subscribe(result => {
      this._loaderService.hide();
      this.result = result;
      this.GetDisclaimer();
    }, (error) =>{ 
      this._loaderService.hide();
      this.handleError(error)});
  }

  GetDisclaimerByRatingAgencyId(id: number) {
    this.isAlert = false;
    this.isSuccess = false;
    this.isError = false;
    this._loaderService.show();
    if (id != 0) {
      this._disclaimerService.GetDisclaimerByRatingAgencyId(id).subscribe(disclaimerResult => {
        // console.log("Result on selecting Agency:");
        // console.log(disclaimerResult);
        if (disclaimerResult) {
          this._loaderService.hide();
          this.Id = disclaimerResult.Id;
          this.RatingAgencyId = disclaimerResult.RatingAgencyId;
          this.disclaimer = disclaimerResult.DisclaimerText;
          this.IsHidden = disclaimerResult.IsHidden;
          $('#editor').html(disclaimerResult.DisclaimerText);
        } else {
          this._loaderService.hide();
          this.Id = null;
          $('#editor').html('');
        }
      }, (error) =>{ 
        this._loaderService.hide();
        this.handleError(error)});
    }
    else {
      this._loaderService.hide();
      this.GetDisclaimer();
    }

  }

  saveData() {
    this._loaderService.show();
    this.isAlert = false;
    this.isError = false;
    this.isSuccess = false;
    // var str = $("#editor").html();
    // var regex = /<br\s*[\/]?>/gi;
    // var regex2 = /<div\s*[\/]?>/gi;
    // $("#editor").html(str
    //   .replace(regex, "")
    //   .replace(regex2, "")
    // );
    var str1 = $("#editor").html();
    var str2 = $("#editor").html();
    var regex1 = /<div\s*[\/]?>/gi;
    var regex2 = /<br\s*[\/]?>/gi;
    var regex4 = /(<([^>]+)>)/ig;
    var regex3 = /&nbsp;/gi;
    var str3 = str1.replace(regex1,"");
    var str4 = str3.replace(regex2,"");
    var str5 = str4.replace(regex3,"");
    var str6 =  str5.replace(regex4, "");

    if (str6 == '' && this.IsHidden === false) {
 this._loaderService.hide();
      this.handleAlert();
    } else {
      if (this.RatingAgencyId === 0 || this.RatingAgencyId.toString() === "0") {
        this._disclaimerService.GetDisclaimer().subscribe(WTWdisclaimerResult => {
          if (WTWdisclaimerResult) {
            this._loaderService.hide();
            this.updateDisclaimer();
          }
          else {
            this._loaderService.hide();
            this.createDisclaimer();
          }
        }, (error) =>{ 
          this._loaderService.hide();
          this.handleError(error)});

      } else {
        this._disclaimerService.GetDisclaimerByRatingAgencyId(this.RatingAgencyId)
          .subscribe(disclaimerResult => {
            if (disclaimerResult) {
              this._loaderService.hide();
              this.updateDisclaimer();
            } else {
              this._loaderService.hide();
              this.createDisclaimer();
            }
          }
          );

      }
    }
  }

  htmlToPlaintext(text) {
    // return text ? String(text).replace(/<[^>]+>/gm, '') : '';
    return text ? String(text).replace(/<[^>]+>/gm, '').replace(/&nbsp;/g, ' ').replace(/&amp;/g, '&') : '';

  }
  createDisclaimer() {
    this.isAlert = false;
    this.isError = false;
    this.isSuccess = false;
    this.disclaimer = ($('#editor').html());
    this.disclaimerTextPlain = this.htmlToPlaintext(this.disclaimer);
    this._loaderService.show();

    this._disclaimerService.PostDisclaimer(this.RatingAgencyId, this.disclaimer, this.IsHidden, this.disclaimerTextPlain)
      .subscribe((result) => {
        if (result) {
          this._loaderService.hide();
          this.Id = result;
          this.showSuccess('Disclaimer Created');
        }
        else{
          this.showError('Disclaimer Creation failed');
          this._loaderService.hide();
        }
      }, (error) =>{ 
        this._loaderService.hide();
        this.handleError(error)});
  }

  updateDisclaimer() {
    this.isAlert = false;
    this.disclaimer = ($('#editor').html());
    this.disclaimerTextPlain = this.htmlToPlaintext(this.disclaimer);
    this._loaderService.show();
    this._disclaimerService.PutDisclaimer(this.Id, this.RatingAgencyId, this.disclaimer, this.IsHidden, this.disclaimerTextPlain)
      .subscribe((result) => {
        if (result){
          this.showSuccess('Disclaimer Updated');
          this._loaderService.hide();
        }
        else {
          this.showError('Disclaimer Updation failed');
          this._loaderService.hide();
        }

      }, (error) =>{ 
        this._loaderService.hide();
        this.handleError(error)});
  }

  showSuccess(message: string) {
    this.isAlert = false;
    this.isError = false;
    this.isSuccess = true;
    setTimeout(() => {
      this.isSuccess = false;
    }, 3000);
    this.message = message;

  }

  showError(message: string) {
    this.isError = true;
    setTimeout(() => {
      this.isError = false;
    }, 3000);
    this.isAlert = false;
    this.isSuccess = false;
    this.message = message;
  }
  // handleError(error) {
  //   this.isAlert = false;
  //   this.isSuccess = false;
  //   this.showError('Some Error Occured, please report to support team along with steps to reproduce');
  // }
  handleError(error) {
    this.isSuccess = false;
    this.isError = true;
    setTimeout(() => {
      this.isError = false;
    }, 3000);
    this.isAlert = false;
    //error.status = 412;
    if (error.status === 412) {
      this.showError('Error 412 : Input Output Validation Error. Please enter details again. ');
    }
    else if (error.status === 422) {
      this.showError('Error 422 : Business Validation Error. Please try again');
    }
    else if (error.status === 500) {
      this.showError('500 Internal Server Error. Please try again');
    }
    else {
      this.showError('Server Error. Please try again');
    }
  }

  handleAlert() {
    this.isAlert = true;
    setTimeout(() => {
      this.isAlert = false;
    }, 3000);
    this.isError = false;
    this.isSuccess = false;
    this.message = 'Please enter Disclaimer text and then submit';
  }
  ///////////
  makeBold() {
    document.execCommand('bold', false, null);
  }

  makeItalics() {
    document.execCommand('italic', false, null);
  }

  makeUnderlined() {
    document.execCommand('underline', false, null);
  }

  makeLeft() {
    document.execCommand('justifyLeft', false, null);
  }

  makeCenter() {
    document.execCommand('justifyCenter', false, null);
  }

  makeRight() {
    document.execCommand('justifyRight', false, null);
  }
  insertUnorderedList() {
    document.execCommand('insertUnorderedList', false, null);
  }


  insertOrderedList() {
    document.execCommand('insertOrderedList', false, null);
  }
  createLink() {
    let selected = document.getSelection();
     document.execCommand('createLink', false, 'http://' + selected);
  }
  
  removeLink(){
  document.execCommand('unlink', false, null);
}
  generateHtmlCode() {
    HtmlElement2($("#editor"));

    function HtmlElement2(elem) {
      InsertHtml2($(elem).html());
    }

    function InsertHtml2(data) {

    var mywindow =  window.open("", "_blank", "toolbar=yes,scrollbars=yes,resizable=yes,top=500,left=500,width=400,height=400");
      mywindow.document.write('<html><head><title>HtmlCode:TextEditor</title>');
      mywindow.document.write('</head><body >');
      mywindow.document.write(data.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;"));
      mywindow.document.write('</body></html>');
      mywindow.document.close(); // necessary for IE >= 10
      mywindow.focus(); // necessary for IE >= 10
      return true;
    }
  }


  richTextEditor() {
    $(document).ready(function () {
      $("#subscript").click(function () {
        document.execCommand('subscript', false, null);
      });
      $("#superscript").click(function () {
        document.execCommand('superscript', false, null);
      });
    });
  }
}



