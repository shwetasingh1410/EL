import { Injectable } from '@angular/core';
import { Http, RequestOptions, Headers } from '@angular/http';
import { Observable } from 'rxjs';
import 'rxjs/add/operator/map';

import { environment } from '../../environments/environment';
import { Settings } from '../shared/settings/settings.service';

@Injectable()
export class DownloadFileService {

  constructor(private _http: Http, private _settings: Settings) { }

  GetRatingAgencyNameDocument(documetName:string) {
    return this._http.get(this._settings.getDocumentApiUrl() + 'api/documents/rating-agency-documents/' + documetName)
        .map((response) => response.json());

}

}
