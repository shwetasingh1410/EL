import { Component, OnInit } from '@angular/core';
import { DownloadFileService } from './download-file.service';
import { Router, ActivatedRoute } from '@angular/router';
import * as FileSaver  from 'file-saver';

@Component({
  selector: 'app-download-file',
  templateUrl: './download-file.component.html',
  styleUrls: ['./download-file.component.css'],
  providers: [DownloadFileService]
})
export class DownloadFileComponent implements OnInit {
  downloadDoucmentName:string;
  sub;
  constructor(private _downloadService:DownloadFileService,private _route:ActivatedRoute) { }

  ngOnInit() {
    this.sub = this._route.params.subscribe(params => {
      this.downloadDoucmentName = params['docName'];
      this.getRatingAgencyNameDocument(this.downloadDoucmentName);
    })
  }

  getRatingAgencyNameDocument(documetratingAgencyName: string) {
    this._downloadService.GetRatingAgencyNameDocument(this.downloadDoucmentName)
      .subscribe((result) => {
        this.downloadHelpDocument(result);
      }, (error) => console.log(error));
  }

  downloadHelpDocument(data) {
    var content = this.base64ToArrayBuffer(data.Content);
    var blob = new Blob([content], { type: data.ContentType });
    var fileName = this.downloadDoucmentName;
    var url = window.URL.createObjectURL(blob);
    FileSaver.saveAs(blob, fileName);
  }

  base64ToArrayBuffer(base64) {
    var binaryString = window.atob(base64);
    var binaryLen = binaryString.length;
    var bytes = new Uint8Array(binaryLen);
    for (var i = 0; i < binaryLen; i++) {
      var ascii = binaryString.charCodeAt(i);
      bytes[i] = ascii;
    }
    return bytes;
  }

}
