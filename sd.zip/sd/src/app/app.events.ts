﻿import { Injectable, EventEmitter } from '@angular/core';

@Injectable()
export class AppEvents {    
    AddRecentlyViewedCarrierEvent: EventEmitter<any> = new EventEmitter();  
}