import { Component, OnInit } from '@angular/core';
import { TranslateService } from '../translate/translate.service';
import { AcceptTermsOfUseService } from '../accept-terms-of-use/accept-terms-of-use.service';
import { DisclaimersService } from '../disclaimers/disclaimers.service';
import { RatingAgency } from '../disclaimers/disclaimers.model';
import { Settings } from '../shared/settings/settings.service';
import { FooterEvents } from './footer.events';
declare var $: any;
@Component({
  selector: 'app-footer',
  templateUrl: './footer.component.html',
  styleUrls: ['./footer.component.css'],
  providers: [AcceptTermsOfUseService, DisclaimersService]
})
export class FooterComponent implements OnInit {
  logo: string;
  currentVersionId: number;
  termsOfUseText: string;
  isFooterError: boolean;
  message: string;
  result: Array<RatingAgency>;
  amBestRatingAgencyID: any;
  spRatingAgencyID: any;
  moodeysRatingAgencyID: any;
  fitchRatingAgencyID: any;
  contactUsEmailId: string;
  displayWtwDisclaimer: boolean;
  displayAmBestRatingAgencyDisclaimer: boolean;
  displaySPRatingAgencyDisclaimer: boolean;
  displayMoodyRatingAgencyDisclaimer: boolean;
  displayFitchRatingAgencyDisclaimer: boolean;
  year: number;




  constructor(private _footerEvents:FooterEvents,private _translate: TranslateService, private _acceptTermsOfUseService: AcceptTermsOfUseService, private _disclaimerService: DisclaimersService, private _settings: Settings) {
    this.logo = '/assets/images/wtw-logo.png';
  }

  ngOnInit() {
    this.year = new Date().getFullYear();
    $.getScript('./assets/scripts/richTextEditor.js');
    this._translate.use('en');
    this.GetRatingAgencies();
    this.contactUsEmailId = this._settings.getContactUsUrl();
    this.displayWtwDisclaimer = false;
    this.displayAmBestRatingAgencyDisclaimer = false;
    this.displaySPRatingAgencyDisclaimer = false;
    this.displayMoodyRatingAgencyDisclaimer = false;
    this.displayFitchRatingAgencyDisclaimer = false;
    this._footerEvents.footerDisclaimerEvent.subscribe(
      (showMenu) => {
        this.openDisclaimer();
      },(error) => {
            this.handleError(error)}
    );

  }

  openTermOfuse() {
    this.functionToDisplayFooterLatesttermsOfUseData();
    document.getElementById("BtnFootermodal").click();
  }




  functionToDisplayFooterLatesttermsOfUseData() {
    this._acceptTermsOfUseService
      .gettermsofuseByCurrentVersion().
      subscribe((result) => {

        $('#editorfooteraccepttermsofuse').html(result.TermsOfUseText);
        this.termsOfUseText = result.TermsOfUseText;
        this.currentVersionId = result.Version;
      }, (error) => this.handleError(error));
  }



  GetRatingAgencies() {
    this._disclaimerService.GetRatingAgencies().subscribe(result => {
      this.result = result;
      this.result.forEach((re) => {
        if (re.RatingAgencyName === "A.M. Best") {
          this.amBestRatingAgencyID = re.RatingAgencyId;
        }
        if (re.RatingAgencyName === "Standard & Poor's") {
          this.spRatingAgencyID = re.RatingAgencyId;
        }
        if (re.RatingAgencyName === "Moody's") {
          this.moodeysRatingAgencyID = re.RatingAgencyId;
        }
        if (re.RatingAgencyName === "Fitch") {
          this.fitchRatingAgencyID = re.RatingAgencyId;
        }


      });

    });
  }


  openDisclaimer() {
    // this.GetRatingAgencies();
    this.GetWtwDisclaimer();
    this.GetAmBestRatingAgencyDisclaimer();
    this.GetSPRatingAgencyDisclaimer();
    this.GetMoodyRatingAgencyDisclaimer();
    this.GetFitchRatingAgencyDisclaimer();
    document.getElementById("BtnFooterDisclaimermodal").click();
  }



  GetWtwDisclaimer() {
    this._disclaimerService.GetDisclaimer().subscribe(WTWdisclaimerResult => {

      if (WTWdisclaimerResult.IsHidden === false) {
        setTimeout(function () { $('#editorWtwDisclaimer').html(WTWdisclaimerResult.DisclaimerText); }, 5);
        this.displayWtwDisclaimer = true;

      }
      else {
        this.displayWtwDisclaimer = false;
      }
    }, (error) => this.handleError(error));
  }


  GetAmBestRatingAgencyDisclaimer() {
    this._disclaimerService.GetDisclaimerByRatingAgencyId(this.amBestRatingAgencyID).subscribe(disclaimerResult => {
      if (disclaimerResult.IsHidden === false) {
        setTimeout(function () { $('#editorAmBestRatingAgencyDisclaimer').html(disclaimerResult.DisclaimerText); }, 5);
        this.displayAmBestRatingAgencyDisclaimer = true;
      }
      else {
        this.displayAmBestRatingAgencyDisclaimer = false;
      }

    }, (error) => this.handleError(error));
  }

  GetSPRatingAgencyDisclaimer() {
    this._disclaimerService.GetDisclaimerByRatingAgencyId(this.spRatingAgencyID).subscribe(disclaimerResult => {
      if (disclaimerResult.IsHidden === false) {
        setTimeout(function () { $('#editorSPRatingAgencyDisclaimer').html(disclaimerResult.DisclaimerText); }, 5);
        this.displaySPRatingAgencyDisclaimer = true;
      }
      else {
        this.displaySPRatingAgencyDisclaimer = false;
      }
    }, (error) => this.handleError(error));
  }

  GetMoodyRatingAgencyDisclaimer() {
    this._disclaimerService.GetDisclaimerByRatingAgencyId(this.moodeysRatingAgencyID).subscribe(disclaimerResult => {
      if (disclaimerResult.IsHidden === false) {
        setTimeout(function () { $('#editorMoodyRatingAgencyDisclaimer').html(disclaimerResult.DisclaimerText); }, 5);
        this.displayMoodyRatingAgencyDisclaimer = true;
      }
      else {
        this.displayMoodyRatingAgencyDisclaimer = false;
      }

    }, (error) => this.handleError(error));
  }

  GetFitchRatingAgencyDisclaimer() {
    this._disclaimerService.GetDisclaimerByRatingAgencyId(this.fitchRatingAgencyID).subscribe(disclaimerResult => {
      if (disclaimerResult.IsHidden === false) {
        setTimeout(function () { $('#editorFitchRatingAgencyDisclaimer').html(disclaimerResult.DisclaimerText);; }, 5);
        this.displayFitchRatingAgencyDisclaimer = true;
      }
      else {
        this.displayFitchRatingAgencyDisclaimer = false;
      }
    }, (error) => this.handleError(error));
  }

  openPrivacyPolicyUrl() {
    window.open(this._settings.getPrivacyPolicyUrl(), "_blank");

  }




  showError(message: string) {
    this.isFooterError = true;
    setTimeout(() => {
      this.isFooterError = false;
    }, 3000);
    this.message = message;
  }


  handleError(error) {
    this.isFooterError = true;
    setTimeout(() => {
      this.isFooterError = false;
    }, 3000);
    throw error;
  }



}
