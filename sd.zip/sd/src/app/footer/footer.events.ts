import { Injectable, EventEmitter } from '@angular/core';

@Injectable()
export class FooterEvents {
    footerDisclaimerEvent: EventEmitter<any> = new EventEmitter();
}