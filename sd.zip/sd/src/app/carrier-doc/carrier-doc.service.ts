﻿import { Injectable } from '@angular/core';
import { Http, URLSearchParams } from '@angular/http';
import { Observable } from 'rxjs/Rx';
import { serializeUrlParams } from '../shared/http/http.factory';
import { Settings } from '../shared/settings/settings.service';
import { LoggedInUser } from '../shared/loggedInUser/LoggedInUser';

@Injectable()
export class CarrierDocService {
    constructor(private _http: Http, private _settings: Settings, private _loggedInUser: LoggedInUser) { }


    getDocumentReport(userId: string, clientId: string, reportType: string): Observable<Document> {
        return this._http.get(this._settings.getDocumentApiUrl() + 'api/documents/reports/users/'+userId+'/'+clientId+'/report-type/'+reportType)
            .map((response) => response.json());
    }
     


    GetDownloadedDocumentInfo(userId: string, clientId: string, reportType: string): Observable<any> {
        return this._http.get(this._settings.getDocumentApiUrl() + 'api/documents/reports/users/' + userId + '/' + clientId + '/' + reportType)
            .map((response) => response.json());
    }
}


