﻿import { Component, OnInit } from '@angular/core';
import { LoggedInUser } from '../shared/loggedInUser/LoggedInUser';
import { CarrierDocService } from './carrier-doc.service';
import * as FileSaver  from 'file-saver';
import { ClientService } from '../select-client/client.service';
import { Account } from '../select-client/select-client.model';
import { log } from 'util';

@Component({
  selector: 'app-carrier-doc',
  templateUrl: './carrier-doc.component.html',
  styleUrls: ['./carrier-doc.component.css'],
  providers: [CarrierDocService, LoggedInUser]
})
export class CarrierDocComponent implements OnInit {
  document;
  userId: string;
  reportType: string;
  isError: boolean;
  message: string;
  Filename: string;
  dateToday : string;
  selectedAccount: Account;
  clientId: string;  

  constructor(private _carrierDocService: CarrierDocService,private _clientService: ClientService,  private _loggedInUser: LoggedInUser) {
    //var check = this._loggedInUser.getUserRoleCode();
    this.isError = false;
    this.selectedAccount = this._clientService.getSelectedAccount();
    this.clientId = this.selectedAccount.AccountId;
  }
  ngOnInit() {
    this.getDocumentReports();
    this.isError = false;
    this.getDateToPrint();
    console.log("Date:"+this.dateToday);
    
  }

  getDocumentReports() {
    this.userId = this._loggedInUser.getUserId();
    this.reportType = 'PrintDetail';
    this._carrierDocService.getDocumentReport(this.userId, this.clientId, this.reportType)
      .subscribe((result) => {
        console.log(result)
        if(result == null){
          this.showError('No Documents found');
        }
        else{
        this.isError = false;
        this.document = result;
        this.Filename = this.document.Filename;
        }
        // this.downloadReport(this.document);
        //this._carrierDocService.downloadReport(this.document);
      }, (error) => this.handleError(error));
    
  }

  // downloadReport2(Filename) {
  //   this._carrierDocService.downloadReport(Filename);
  // }
  getDateToPrint() {
    let today = new Date();
    let date = today.getDate();
    let mon = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
    let month = mon[today.getMonth()];

    let year = today.getFullYear();

    this.dateToday = month + " " + date + "," + year;
  }
  handleError(error) {
    this.showError('Some Error Occured, Not able to Fetch batch Document');
  }
  showError(message: string) {
    this.isError = true;
    setTimeout(() => {
      this.isError = false;
    }, 3000);
    this.message = message;
  }

  /* -- */
  downloadReport(doc) {
      if (doc) {
          
          this._carrierDocService.GetDownloadedDocumentInfo(this.userId, this.clientId, this.reportType).subscribe(result => {
        this.isError = false;
        this.fetchFile(result);
      }, (error) => this.handleError(error));
    }

  }

  fetchFile(data) {
    var content = this.base64ToArrayBuffer(data.Content);
    var blob = new Blob([content], { type: data.ContentType });
    var filename = data.Filename + '.' + data.Extension;
    var url = window.URL.createObjectURL(blob);
    FileSaver.saveAs(blob, filename);
  }

  base64ToArrayBuffer(base64) {
    var binaryString = window.atob(base64);
    var binaryLen = binaryString.length;
    var bytes = new Uint8Array(binaryLen);
    for (var i = 0; i < binaryLen; i++) {
      var ascii = binaryString.charCodeAt(i);
      bytes[i] = ascii;
    }
    return bytes;
  }
}
