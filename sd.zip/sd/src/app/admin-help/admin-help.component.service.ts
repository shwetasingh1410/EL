﻿import { Injectable } from '@angular/core';
import { Http, RequestOptions, Headers } from '@angular/http';
import { Observable } from 'rxjs/Rx';
import 'rxjs/add/operator/map';
import {Settings } from '../shared/settings/settings.service';

@Injectable()
export class AdminHelpService {
    constructor(private _http: Http, private _settings: Settings) {
    }

    
   

    GetAdminHelpDocument(documetName:string) {
        return this._http.get(this._settings.getDocumentApiUrl() + 'api/documents/help-document/' + documetName)
            .map((response) => response.json());

    }

    
}
    