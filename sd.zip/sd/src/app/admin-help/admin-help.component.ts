import { Component, OnInit } from '@angular/core';
import { TranslateService } from '../translate/translate.service';
import { AdminHelpService } from './admin-help.component.service';
import * as FileSaver from 'file-saver';

declare var $: any;
@Component({
  selector: 'app-admin-help',
  templateUrl: './admin-help.component.html',
  styleUrls: ['./admin-help.component.css'],
  providers: [AdminHelpService]
})
export class AdminHelpComponent implements OnInit {

  downloadDocumentName: string;
  isHelpError: boolean;
  message: string;

  constructor(private _translate: TranslateService, private _adminHelpService: AdminHelpService) {
    this.downloadDocumentName = "MosaicAdminHelp.pdf";

  }

  ngOnInit() {
    this.GetAdminHelpDocument(this.downloadDocumentName);
    this._translate.use('en');

  }


  GetAdminHelpDocument(documetName: string) {
    this._adminHelpService
      .GetAdminHelpDocument(documetName)
      .subscribe((result) => {
        this.downloadHelpDocument(result);
      }, (error) => this.handleError(error));


  }

  downloadHelpDocument(data) {
    var content = this.base64ToArrayBuffer(data.Content);
    var blob = new Blob([content], { type: data.ContentType });
    var fileName = this.downloadDocumentName;
    var url = window.URL.createObjectURL(blob);
    FileSaver.saveAs(blob, fileName);
  }

  base64ToArrayBuffer(base64) {
    var binaryString = window.atob(base64);
    var binaryLen = binaryString.length;
    var bytes = new Uint8Array(binaryLen);
    for (var i = 0; i < binaryLen; i++) {
      var ascii = binaryString.charCodeAt(i);
      bytes[i] = ascii;
    }
    return bytes;
  }


  showError(message: string) {
    this.isHelpError = true;
    setTimeout(() => {
      this.isHelpError = false;
    }, 3000);
    this.message = message;
  }


  handleError(error) {
    this.isHelpError = true;
    setTimeout(() => {
      this.isHelpError = false;
    }, 3000);
    if (error.status === 412) {
      this.showError('Error 412 : Input Output Validation Error. Please enter details again. ');
    }
    else if (error.status === 422) {
      this.showError('Error 422 : Business Validation Error. Please try again');
    }
    else if (error.status === 500) {
      this.showError('500 Internal Server Error. Please try again');
    }
    else {
      this.showError('Document is not avilable for download.');
    }
  }


}