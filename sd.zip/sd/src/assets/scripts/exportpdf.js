﻿function exportpdf(divName, companyCode, disclaimer) {

    var elementId = document.getElementById(divName);
    var date = new Date();
    var year = date.getFullYear();
    var month = date.getMonth() + 1;      // "+ 1" becouse the 1st month is 0
    var day = date.getDate();
    var minutes = date.getMinutes();
    var milliSeconds = date.getMilliseconds();
    // $("button").hide();
    /*kendo.drawing.drawDOM(elementId).then(function (group) {
        group.options.set("pdf", {
            paperSize: "A4",
            title : title,
            margin: {
                left: "10mm",
                top: "10mm",
                right: "10mm",
                bottom: "10mm"
            },
            margin: { left: "0cm", top: "1cm", right: "0cm", bottom: "1cm" },
            multiPage:true
        });
          
        kendo.drawing.pdf.saveAs(group, fileName+".pdf");
        $("button").show();
    }); */

    $(".exportpdfcontainer").html($("#" + disclaimer).html());

    var fileName = 'General_PDF' + '_' + year + '_' + month + '_' + day;
    // var generatedDate = year + '_' + month + '_' + day;
    kendo.drawing.drawDOM($("#" + divName), {
        allPages: true,
        paperSize: "A4",
        scale: 0.45,
        multiPage: true,
        forcePageBreak: ".new-page",                
        margin: { left: "0.5cm", top: "1cm", right: "0.5cm", bottom: "1cm" },
        // template: "<div class='page-template'><div class='footer' style='right:20px; left:170px; position:absolute;bottom: 20px;background-color: white; font-size :15px;'> Strictly Private & Confidential – For Internal Use Only.  Please note applicable disclaimers at the end of this report. Page #: pageNum # of #: totalPages # </div></div>"
        template: $("#footer-pdf").html()
    }).then(function (group) {
        // $("button").hide();
        return kendo.drawing.exportPDF(group);
    }).done(function (data) {   
        // $("button").hide();
        kendo.saveAs({
            dataURI: data,
            fileName: fileName + ".pdf",
        });

        // $("button").show();
    });
}

