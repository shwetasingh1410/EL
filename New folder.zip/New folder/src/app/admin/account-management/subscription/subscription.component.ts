import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-subscription',
  templateUrl: './subscription.component.html',
  styleUrls: ['./subscription.component.css']
})
export class SubscriptionComponent implements OnInit {
  showRouting : boolean;
  showDetails: boolean;
  

  constructor() { }

  ngOnInit() {
    this.showRouting = false;
    this.showDetails = true;

  }
  selectload() {
    this.showDetails = true;
    this.showRouting = true;
  }
  continue() {
    this.showDetails = true;
    this.showRouting = true;
  }

}
