import { ModuleWithProviders } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { HomeComponent } from './home/home.component';
import { SubscriptionComponent } from './admin/account-management/subscription/subscription.component';
import { ClientInformationComponent } from './admin/account-management/subscription/client-information/client-information.component';
import { ElinformationComponent } from './admin/account-management/subscription/elinformation/elinformation.component';
import { UserMaintenanceComponent } from './admin/account-management/subscription/user-maintenance/user-maintenance.component';
import { AddNewUsersComponent } from './admin/account-management/subscription/user-maintenance/add-new-users/add-new-users.component';
import { ExistingUsersComponent } from './admin/account-management/subscription/user-maintenance/existing-users/existing-users.component';


const routes: Routes = [
    { path: '', redirectTo: 'home', pathMatch: 'full' },
    { path: 'home', component: HomeComponent },
    { path: 'subscription', component: SubscriptionComponent },
    { path: 'reports', loadChildren: 'app/table/table.module#TableModule' },
    {
        path: 'subscription', component: SubscriptionComponent, children: [
            { path: 'clientInfo', component: ClientInformationComponent },
            { path: 'energyLossesInfo', component: ElinformationComponent },
            {
                path: 'userMaintenance', component: UserMaintenanceComponent, children: [
                    { path: 'addNewUsers', component: AddNewUsersComponent },
                    { path: 'existingUsers', component: ExistingUsersComponent },
                    { path: '**', redirectTo: '\addNewUsers' },
                ]
            },
            { path: '**', redirectTo: '\clientInfo' },
        ]
    },

];

export const routing: ModuleWithProviders = RouterModule.forRoot(routes);