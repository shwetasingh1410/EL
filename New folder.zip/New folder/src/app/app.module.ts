import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';
import { AppComponent } from './app.component';
import { HttpClientModule } from '@angular/common/http';

// Import the Animations module
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

// Import the ButtonsModule
import { HomeComponent } from './home/home.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { SubscriptionComponent } from './admin/account-management/subscription/subscription.component';
import {ClientInformationComponent} from './admin/account-management/subscription/client-information/client-information.component';
import {ElinformationComponent} from './admin/account-management/subscription/elinformation/elinformation.component';
import {UserMaintenanceComponent} from './admin/account-management/subscription/user-maintenance/user-maintenance.component';
import {AddNewUsersComponent} from './admin/account-management/subscription/user-maintenance/add-new-users/add-new-users.component';
import {ExistingUsersComponent} from './admin/account-management/subscription/user-maintenance/existing-users/existing-users.component';

//Import routing
import { routing } from './app.routing';
import { FooterComponent } from './footer/footer.component';

@NgModule({
    declarations: [
        AppComponent,
        HomeComponent,
        DashboardComponent,
        FooterComponent,
        SubscriptionComponent,
        ClientInformationComponent,
        ElinformationComponent,
        UserMaintenanceComponent,
        AddNewUsersComponent,
        ExistingUsersComponent

    ],
    imports: [
        BrowserModule,
        FormsModule,
        HttpModule,
        HttpClientModule,
        // Register the modules
        BrowserAnimationsModule,
        // Register routing
        routing
    ],
    providers: [],
    bootstrap: [AppComponent]
})
export class AppModule { }