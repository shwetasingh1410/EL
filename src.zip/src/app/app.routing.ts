import { ModuleWithProviders } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { CustomReportComponent } from './reports/custom-report/custom-report.component';

const routes: Routes = [
    { path: '', redirectTo: 'home', pathMatch: 'full' },
    { path: 'home', component: HomeComponent },
    { path: 'subscription', loadChildren: 'app/admin/account-management/subscription/subscription.module#SubscriptionModule' },
    { path: 'search', loadChildren: 'app/search/search.module#SearchModule' },
    { path: 'customReports', component: CustomReportComponent }
];

export const AppRouting: ModuleWithProviders = RouterModule.forRoot(routes);